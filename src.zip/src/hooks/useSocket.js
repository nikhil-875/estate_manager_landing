// src/hooks/useSocket.js
import { useEffect, useRef, useCallback } from 'react';
import { io } from 'socket.io-client';
import { useDispatch } from 'react-redux';
import { setOnlineUsers, setUserPresence } from '../redux/chatSlice'; // Assuming chatSlice is in redux folder
import { chatApi } from '../api/chatApi'; // Assuming chatApi is in api folder
import { env } from '../config/env'; // Assuming env is in config folder

/**
 * Custom React Hook for managing Socket.IO connections and events.
 * Encapsulates all socket logic, including connection, event listeners,
 * and event emitters, providing a clean interface for components.
 *
 * @param {number} currentUserId - The ID of the currently authenticated user.
 * @param {Function} refetchConversations - Function to refetch conversations from RTK Query.
 * @returns {object} An object containing functions to emit socket events.
 */
export const useSocket = (currentUserId, refetchConversations) => {
  const dispatch = useDispatch();
  const socketRef = useRef(null);
  const selectedConversationIdRef = useRef(null); // To keep track of the currently selected conversation ID

  // Update the ref whenever selectedConversationId changes in the parent component
  const updateSelectedConversationIdRef = useCallback((id) => {
    selectedConversationIdRef.current = id;
  }, []);

  // Memoized callback for handling real-time messages
  const handleRealtimeMessage = useCallback((newMessage) => {
    const currentSelectedId = selectedConversationIdRef.current;
    const isSender = String(newMessage.senderId) === String(currentUserId);

    // Update conversations data in Redux store
    dispatch(chatApi.util.updateQueryData('getConversations', currentUserId, (draftConversations) => {
      const convoToUpdate = draftConversations.find(c => String(c.conversationId) === String(newMessage.conversationId));
      if (convoToUpdate) {
        convoToUpdate.lastMessage = newMessage.message;
        convoToUpdate.lastMessageAt = newMessage.createdAt;
        convoToUpdate.lastMessageId = newMessage.id;

        const previousUnread = convoToUpdate.unread || 0;

        // Increment unread count only if not sender and not in the currently selected conversation
        if (!isSender && String(newMessage.conversationId) !== String(currentSelectedId)) {
          convoToUpdate.unread = previousUnread + 1;
        } else if (!isSender && String(newMessage.conversationId) === String(currentSelectedId)) {
          // If in current conversation, mark as read (unread = 0)
          convoToUpdate.unread = 0;
        }
      } else {
        // If conversation not found, refetch all conversations (e.g., for new conversations)
        refetchConversations();
      }
    }));

    // Update messages data for the specific conversation
    dispatch(chatApi.util.updateQueryData('getMessages', { conversationId: newMessage.conversationId }, (draftMessages) => {
      if (!Array.isArray(draftMessages)) {
        return [newMessage]; // Initialize if draftMessages is not an array
      }

      let messageProcessed = false;
      // If it's an optimistic update (has tempId), replace the existing temp message
      if (newMessage.tempId) {
        const existingMessageIndex = draftMessages.findIndex(msg => String(msg.tempId) === String(newMessage.tempId));
        if (existingMessageIndex > -1) {
          draftMessages[existingMessageIndex] = newMessage;
          messageProcessed = true;
        }
      }

      // If not processed (e.g., new message without tempId or tempId not found), add it
      if (!messageProcessed) {
        const messageExistsById = draftMessages.some(msg => String(msg.id) === String(newMessage.id));
        if (!messageExistsById) {
          draftMessages.push(newMessage);
        }
      }
      // Ensure messages are sorted by creation time
      draftMessages.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    }));
  }, [dispatch, currentUserId, refetchConversations]);

  // Memoized callback for handling message status updates (delivered, seen, updated)
  const handleMessageStatusUpdate = useCallback((updatedMessages) => {
    const messagesToUpdate = Array.isArray(updatedMessages) ? updatedMessages : [updatedMessages];

    if (messagesToUpdate.length > 0) {
      const conversationId = messagesToUpdate[0].conversationId;

      dispatch(chatApi.util.updateQueryData('getMessages', { conversationId: conversationId }, (draftMessages) => {
        messagesToUpdate.forEach(updatedMsg => {
          const index = draftMessages.findIndex(msg => String(msg.id) === String(updatedMsg.id));
          if (index > -1) {
            draftMessages[index].status = updatedMsg.status;
            if (updatedMsg.isEdited !== undefined) {
              draftMessages[index].isEdited = updatedMsg.isEdited;
            }
            if (updatedMsg.isDeleted !== undefined) {
              draftMessages[index].isDeleted = updatedMsg.isDeleted;
              draftMessages[index].message = updatedMsg.message;
            }
          }
        });
      }));

      // If any message was marked as 'seen' by the other user, update unread count for that conversation
      if (messagesToUpdate.some(msg => msg.status === 'seen' && String(msg.senderId) !== String(currentUserId))) {
        dispatch(chatApi.util.updateQueryData('getConversations', currentUserId, (draftConversations) => {
          const convoToUpdate = draftConversations.find(c => String(c.conversationId) === String(conversationId));
          if (convoToUpdate) {
            convoToUpdate.unread = 0;
          }
        }));
      }
    }
  }, [dispatch, currentUserId]);

  // Memoized callback for handling message deletion
  const handleMessageDeleted = useCallback((deletedMessageInfo) => {
    dispatch(chatApi.util.updateQueryData('getMessages', { conversationId: deletedMessageInfo.conversationId }, (draftMessages) => {
      const index = draftMessages.findIndex(msg => String(msg.id) === String(deletedMessageInfo.messageId));
      if (index > -1) {
        draftMessages[index].isDeleted = true;
        // Ensure the message content is updated to "This message was deleted." for all users
        draftMessages[index].message = deletedMessageInfo.message || 'This message was deleted.';
        if (deletedMessageInfo.status) draftMessages[index].status = deletedMessageInfo.status;
      }
    }));
  }, [dispatch]);

  // Main useEffect for socket connection and event listeners
  useEffect(() => {
    if (!currentUserId) {
      return;
    }

    // Initialize socket connection if not already connected
    if (!socketRef.current) {
      socketRef.current = io(env.API_URL, { withCredentials: true });
    }

    const socket = socketRef.current;

    // Emit 'join' event when user ID is available
    socket.emit('join', currentUserId);

    // Set up socket event listeners
    socket.on('receive_message', handleRealtimeMessage);
    socket.on('message_sent', handleRealtimeMessage);
    socket.on('error_sending_message', (errorPayload) => console.error("Socket error:", errorPayload));
    socket.on('user_presence_update', (presenceData) => {
      dispatch(setUserPresence(presenceData)); // Update individual user presence
      dispatch(setOnlineUsers(prevOnlineUsers => { // Update overall online users list
        const isOnline = presenceData.status === 'online';
        const currentSet = new Set(prevOnlineUsers);
        if (isOnline) {
          currentSet.add(presenceData.userId);
        } else {
          currentSet.delete(presenceData.userId);
        }
        return Array.from(currentSet);
      }));
    });
    socket.on('current_online_users', (onlineUsersWithPresence) => {
      const onlineUserIds = onlineUsersWithPresence.map(u => u.userId);
      dispatch(setOnlineUsers(onlineUserIds)); // Set initial online users list
      onlineUsersWithPresence.forEach(user => dispatch(setUserPresence(user))); // Set initial presence for all online users
    });
    socket.on('message_status_update', handleMessageStatusUpdate);
    socket.on('message_updated', handleMessageStatusUpdate);
    socket.on('message_deleted', handleMessageDeleted);

    // Cleanup function: disconnect socket and remove all listeners
    return () => {
      if (socketRef.current) {
        socket.off('receive_message', handleRealtimeMessage);
        socket.off('message_sent', handleRealtimeMessage);
        socket.off('error_sending_message');
        socket.off('user_presence_update');
        socket.off('current_online_users');
        socket.off('message_status_update');
        socket.off('message_updated');
        socket.off('message_deleted');
        // Optionally, if you want to disconnect the socket when the component unmounts
        // socket.disconnect();
        // socketRef.current = null;
      }
    };
  }, [currentUserId, dispatch, handleRealtimeMessage, handleMessageStatusUpdate, handleMessageDeleted]);

  /**
   * Emits a 'send_message' event to the socket.
   * @param {object} payload - The message payload.
   * @param {Function} callback - Optional callback for acknowledgment.
   */
  const emitSendMessage = useCallback((payload, callback) => {
    if (socketRef.current) {
      socketRef.current.emit('send_message', payload, callback);
    }
  }, []);

  /**
   * Emits a 'messages_seen_in_conversation' event to the socket.
   * @param {object} payload - The payload containing conversationId and userId.
   */
  const emitMessagesSeen = useCallback((payload) => {
    if (socketRef.current) {
      socketRef.current.emit('messages_seen_in_conversation', payload);
    }
  }, []);

  /**
   * Emits a 'delete_message' event to the socket.
   * @param {object} payload - The payload containing messageId and conversationId.
   * @param {Function} callback - Optional callback for acknowledgment.
   */
  const emitDeleteMessage = useCallback((payload, callback) => {
    if (socketRef.current) {
      socketRef.current.emit('delete_message', payload, callback);
    }
  }, []);

  return {
    emitSendMessage,
    emitMessagesSeen,
    emitDeleteMessage,
    updateSelectedConversationIdRef, // Expose this to update the ref from parent
  };
};
