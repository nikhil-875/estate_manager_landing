import { useEffect, useMemo, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { MENU_ITEMS } from "../constants/config";
import { useGetMeQuery } from "../api/authApi";
import { handlePostAuth } from "../utils/authUtils";

export const usePermissions = () => {
  const token = localStorage.getItem("token");
  const dispatch = useDispatch();

  const { permissions = [] } = useSelector((state) => state.auth);

  const { data: meData, isLoading: isMeLoading } = useGetMeQuery(undefined, {
    skip: !token,
  });

  useEffect(() => {
    if (meData?.data) {
      handlePostAuth({
        userData: meData.data,
        token,
        dispatch,
      })
    }
  }, [meData?.data, token, dispatch]);

  const canHavePermission = useCallback(
    (permissionKey) => permissions.includes(permissionKey),
    [permissions]
  );

  const filteredMenuItems = useMemo(() => {
    const filterItem = (item) => {
      const required = item.requiredPermission;
      const hasPermission =
        required == null ||
        (Array.isArray(required)
          ? required.some((perm) => permissions.includes(perm))
          : permissions.includes(required));

      if (!hasPermission) return null;

      let filteredChildren = null;
      if (Array.isArray(item.children) && item.children.length > 0) {
        filteredChildren = item.children.map(filterItem).filter(Boolean);
        if (filteredChildren.length === 0 && !item.path) return null;
      }

      return {
        ...item,
        ...(filteredChildren ? { children: filteredChildren } : {}),
      };
    };

    return MENU_ITEMS.map(filterItem).filter(Boolean);
  }, [permissions]);

  return {
    permissions,
    canHavePermission,
    filteredMenuItems,
    loading: isMeLoading,
  };
};
