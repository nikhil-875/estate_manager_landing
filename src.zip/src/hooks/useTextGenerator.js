// src/hooks/useTextGenerator.js

import { useState, useEffect } from 'react';
import { pipeline } from '@xenova/transformers';

export function useTextGenerator(prompt, options = {}) {
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!prompt) return;
    let cancelled = false;
    setLoading(true);

    (async () => {
      // load a small in-browser GPT-2 model
      const generator = await pipeline('text-generation', 'Xenova/gpt2');
      const result = await generator(prompt, {
        max_new_tokens: options.maxTokens || 30,
        ...options.parameters,
      });
      if (!cancelled) {
        setOutput(result[0].generated_text);
        setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [prompt, options.maxTokens, JSON.stringify(options.parameters)]);

  return { output, loading };
}
