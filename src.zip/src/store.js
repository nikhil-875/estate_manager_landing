import { configureStore, combineReducers } from '@reduxjs/toolkit';

// Your existing slice reducers
import authReducer from './redux/authSlice';
import companyReducer from './redux/companySlice';
import chatReducer from './redux/chatSlice';

// RTK Query APIs (including the new listingApi)
import { authApi } from './api/authApi';
import { statsApi } from './api/statApi';
import { companyApi } from './api/company';
import { subscriptionApi } from './api/subscription';
import { uploadApi } from './api/uploadApi';
import { settingsApi } from './api/settingsApi';
import { propertyApi } from './api/propertyApi';
import { chatApi } from './api/chatApi';
import { maintenanceApi } from './api/maintenance';
import { supportApi } from './api/supportApi';
import { listingApi } from './api/listingApi'; // ← IMPORT listingApi
import { aiApi } from './api/aiApi';
import { ownerApi } from './api/owner';
import { tenantApi } from './api/tenantApi';

// 1️⃣ Combine all reducers, including each api.reducer
const rootReducer = combineReducers({
  auth: authReducer,
  company: companyReducer,
  chat: chatReducer,

  // existing RTK Query API reducers
  [authApi.reducerPath]: authApi.reducer,
  [statsApi.reducerPath]: statsApi.reducer,
  [companyApi.reducerPath]: companyApi.reducer,
  [subscriptionApi.reducerPath]: subscriptionApi.reducer,
  [uploadApi.reducerPath]: uploadApi.reducer,
  [settingsApi.reducerPath]: settingsApi.reducer,
  [propertyApi.reducerPath]: propertyApi.reducer,
  [chatApi.reducerPath]: chatApi.reducer,
  [maintenanceApi.reducerPath]: maintenanceApi.reducer,
  [supportApi.reducerPath]: supportApi.reducer,
  [ownerApi.reducerPath]: ownerApi.reducer,
  //  → Add listingApi.reducer here
  [listingApi.reducerPath]: listingApi.reducer,
  [aiApi.reducerPath]: aiApi.reducer,
  [tenantApi.reducerPath]: tenantApi.reducer,   
});

// 2️⃣ Create the store, adding all the api middlewares (including listingApi.middleware)
export const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(
      authApi.middleware,
      statsApi.middleware,
      companyApi.middleware,
      subscriptionApi.middleware,
      uploadApi.middleware,
      settingsApi.middleware,
      propertyApi.middleware,
      chatApi.middleware,
      maintenanceApi.middleware,
      supportApi.middleware,
      aiApi.middleware,
      listingApi.middleware,
      ownerApi.middleware,
      tenantApi.middleware,
    ),
  // devTools: process.env.NODE_ENV !== 'production',
});
