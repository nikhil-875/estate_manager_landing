import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  messages: {},
  onlineUsers: [],
  userPresence: {},
};

const chatSlice = createSlice({
  name: 'chat',
  initialState,
  reducers: {
    clearMessages: (state, action) => {
      const { conversationId } = action.payload;
      if (state.messages[conversationId]) {
        delete state.messages[conversationId];
      }
    },
    setOnlineUsers: (state, action) => {
      state.onlineUsers = action.payload;
    },
    setUserPresence: (state, action) => {
      state.userPresence[action.payload.contactId] = {
        status: action.payload.status,
        lastSeenAt: action.payload.lastSeenAt,
      };
    },
  },
});

export const { clearMessages, setOnlineUsers, setUserPresence } = chatSlice.actions;

export default chatSlice.reducer;
