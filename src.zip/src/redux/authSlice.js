import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  user: { type: "guest" },
  permissions: [],
  isAuthenticated: false,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setUser(state, action) {
      state.user = action.payload.user;
      state.permissions = action.payload.permissions || [];
      state.isAuthenticated = true;
    },
    clearUser(state) {
      state.user = null;
      state.permissions = [];
      state.isAuthenticated = false;
      localStorage.removeItem('token');
    },
  },
});

export const { setUser, clearUser } = authSlice.actions;
export default authSlice.reducer;
