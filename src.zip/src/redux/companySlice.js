import { createSlice } from '@reduxjs/toolkit';

const companySlice = createSlice({
    name: 'company',
    initialState: null,
    reducers: {
        setCompany(state, action) {
            return action.payload;
        },
        clearCompany() {
            return null;
        },
    },
});

export const { setCompany, clearCompany } = companySlice.actions;
export default companySlice.reducer;
