export const getFallbackImage = (name) => {
    // Ensure 'name' is a string and not empty, otherwise default to 'U' for 'Unknown'
    const safeName = typeof name === 'string' && name.length > 0 ? name : 'Unknown';
    const initialChar = safeName.charAt(0).toUpperCase();

    return `https://placehold.co/150x150/aabbcc/ffffff?text=${initialChar}`;
};

export const handleImageError = (e, name) => {
    const fallbackImage = getFallbackImage(name);
    e.currentTarget.onerror = null;
    e.currentTarget.src = fallbackImage;
};
