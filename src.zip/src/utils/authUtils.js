// src/utils/authUtils.js

import { setUser } from "../redux/authSlice";
import { setCompany } from "../redux/companySlice";
import { settingsApi } from "../api/settingsApi";

/**
 * Handles setting user & permissions, fetching general settings, updating title, and dispatching Redux state.
 *
 * @param {Object} params
 * @param {Object} params.userData - The user data object (must include `permissions`, `company_id`, etc.)
 * @param {string} params.token - JWT token for the user
 * @param {Function} params.dispatch - Redux dispatch function
 * @param {Function} [params.navigate] - Optional. React Router navigate function (for redirection)
 * @param {boolean} [params.redirect=true] - Whether to redirect to dashboard or not
 * @returns {Promise<void>}
 */
export const handlePostAuth = async ({
  userData,
  token,
  dispatch,
}) => {

  dispatch(setUser({
    user: userData,
    permissions: userData?.permissions || [],
    token
  }));

  // Set company + title
  if (userData?.company_id) {
    const settingsRes = await dispatch(
      settingsApi.endpoints.getGeneralSettings.initiate({ companyId: userData.company_id })
    );

    const companySettings = settingsRes?.data?.data;
    if (companySettings) {
      document.title = companySettings.application_name || "Estate Manager";
      dispatch(setCompany(companySettings));
    }
  } else {
    document.title = "Estate Manager";
    dispatch(setCompany({}));
  }
};
