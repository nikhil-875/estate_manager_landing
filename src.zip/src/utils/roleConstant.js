export const roleConstant = {
    SuperAdmin: 1,
    Manager: 2,
    Owner: 3,
    Tenant: 4,
    Contractor : 5,
}