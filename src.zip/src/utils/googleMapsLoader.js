/**
 * Utility for loading Google Maps API consistently across the application
 */

import { env } from "../config/env";

let isLoading = false;
let isLoaded = false;
const callbacks = [];
const GOOGLE_MAP_API_KEY = env.GOOGLE_MAPS_API_KEY;

/**
 * Load Google Maps API script
 * @param {string} apiKey - Google Maps API key
 * @param {Array<string>} libraries - Libraries to load (e.g. ['places'])
 * @param {Function} callback - Optional callback to execute when API is loaded
 * 
 */
export const loadGoogleMapsApi = (apiKey = GOOGLE_MAP_API_KEY, libraries = ['places'], callback = null) => {
  if (window.google && window.google.maps) {
    console.log("Google Maps already loaded");
    isLoaded = true;
    if (callback) callback();
    return;
  }

  // If already loading, add callback to queue
  if (isLoading) {
    console.log("Google Maps already loading, adding callback to queue");
    if (callback) callbacks.push(callback);
    return;
  }

  // Start loading
  console.log("Starting to load Google Maps API");
  isLoading = true;
  if (callback) callbacks.push(callback);

  // Create script element for Google Maps
  const gmapsScript = document.createElement('script');
  const librariesParam = libraries.join(',');

  // Define callback function in window scope
  window.initGoogleMapsApi = () => {
    console.log("Google Maps API initialized");
    isLoaded = true;
    isLoading = false;
    callbacks.forEach(cb => cb());
    callbacks.length = 0; // Clear callbacks
  };

  // Set script attributes
  const scriptUrl = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=${librariesParam}&callback=initGoogleMapsApi&loading=async&v=weekly`;

  console.log("Loading Google Maps with URL:", scriptUrl);
  
  gmapsScript.src = scriptUrl;
  gmapsScript.id = 'googleMapsApiScript';
  gmapsScript.async = true;
  gmapsScript.defer = true;

  // Add error handling
  gmapsScript.onerror = (error) => {
    console.error('Error loading Google Maps API script:', error);
    isLoading = false;
  };

  document.head.appendChild(gmapsScript);
};

/**
 * Check if Google Maps API is loaded
 * @returns {boolean} - Whether API is loaded
 */
export const isGoogleMapsLoaded = () => {
  const loaded = isLoaded || (window.google && window.google.maps);
  if (!loaded) {
    console.log("Google Maps not loaded yet");
  }
  return loaded;
}; 