import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import {
  Login,
  Register,
  Dashboard,
  UserDashboard,
  CompanyDetails,
  MaintainerList,
  ExpenseDashboard,
  InvoicePage,
  ContactList,
  TenantList,
  RoleList,
  NoticeBoard,
  Transaction,
  Customers,
  Units,
  Settings,
  Subscriptions,
  Properties,
  PropertyListing,
  Maintenance,
  ForgotPassword,
  ResetPassword,
  PhoneVerification,
  VerificationCode,
  GuestDashboard,
  InvitationAccept,
  SwitchAccount, 
  SupportTickets, 
  Listing
} from "../pages";
import { PublicRoute } from "./PublicRoute";
import { ProtectedRoute } from "./ProtectedRoute";
export const AppRoutes = () => {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        {/* <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} /> */}
        {/* <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
        <Route path="/register" element={<PublicRoute><Register /></PublicRoute>} />
        <Route path="/forgot-password" element={<PublicRoute><ForgotPassword /></PublicRoute>} />
        <Route path="/reset-password" element={<PublicRoute><ResetPassword /></PublicRoute>} /> */}
        {/* <Route path="/property-listing" element={<PublicRoute><PropertyListing /></PublicRoute>} /> */}
        <Route path="/invitation-accept" element={<InvitationAccept />} />
        <Route path="/verify-phone" element={<PhoneVerification />} />
        <Route path="/verify-code" element={<VerificationCode />} />
        <Route path="*" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />

        {/* Protected Routes */}
        <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/contacts" element={<ProtectedRoute><ContactList /></ProtectedRoute>} />
        <Route path="/notes" element={<ProtectedRoute><NoticeBoard /></ProtectedRoute>} />
        <Route path="/maintainers" element={<ProtectedRoute><MaintainerList /></ProtectedRoute>} />
        <Route path="/tenants" element={<ProtectedRoute><TenantList /></ProtectedRoute>} />
        <Route path="/transactions" element={<ProtectedRoute><Transaction /></ProtectedRoute>} />
        <Route path="/customer" element={<ProtectedRoute><Customers /></ProtectedRoute>} />
        <Route path="/companies" element={<ProtectedRoute><UserDashboard /></ProtectedRoute>} />
        <Route path="/company" element={<ProtectedRoute><CompanyDetails /></ProtectedRoute>} />
        <Route path="/units" element={<ProtectedRoute><Units /></ProtectedRoute>} />
        <Route path="/roles" element={<ProtectedRoute><RoleList /></ProtectedRoute>} />
        <Route path="/expenses" element={<ProtectedRoute><ExpenseDashboard /></ProtectedRoute>} />
        <Route path="/invoices" element={<ProtectedRoute><InvoicePage /></ProtectedRoute>} />
        <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
        <Route path="/properties" element={<ProtectedRoute><Properties /></ProtectedRoute>} />
        <Route path="/maintenance" element={<ProtectedRoute><Maintenance /></ProtectedRoute>} />
        <Route path="/subscriptions" element={<ProtectedRoute><Subscriptions /></ProtectedRoute>} />
        <Route path="/account" element={<ProtectedRoute><SwitchAccount /></ProtectedRoute>} />
        <Route path="/support" element={<ProtectedRoute><SupportTickets /></ProtectedRoute>} />
        <Route path="/listing" element={<ProtectedRoute><Listing /></ProtectedRoute>} />
      </Routes>
    </Router>
  );
};