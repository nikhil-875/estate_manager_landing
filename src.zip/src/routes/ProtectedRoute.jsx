import { Loader } from "../components/Loader";
import { usePermissions } from "../hooks/usePermissions";
import { Layout } from "../components/Layout";
import { env } from "../config/env";

export const ProtectedRoute = ({ children }) => {
  // --- Token extraction from URL ---
  const params = new URLSearchParams(window.location.search);
  const tokenFromUrl = params.get('token');
  if (tokenFromUrl) {
    localStorage.setItem('token', tokenFromUrl);
    // Clean the URL (remove token param)
    window.history.replaceState({}, document.title, window.location.pathname);
  }
  // --- End token extraction ---

  const { loading } = usePermissions();
  const token = localStorage.getItem("token");
  const isAuthenticated = !!token;

  if (loading) return <Loader />;
  if (!isAuthenticated) {
    return window.location.href = env.LANDING_URL;
  }
  return <Layout>{children}</Layout>;
};

