import React, { useState } from "react";
import { Form } from "react-bootstrap";

const statusClass = {
  failed: 'bg-light-danger text-danger',
  'awaiting payment': 'bg-light-warning text-warning',
  pending: 'bg-light-warning text-warning',  // added pending
};

export const RecentOrders = ({ payload }) => {
  const { transactions = [] } = payload;
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const pageSize = 4;

  const filtered = transactions.filter(t =>
    (`${t.first_name || ''} ${t.last_name || ''}`)
      .toLowerCase()
      .includes(search.toLowerCase()) ||
    (t.title || '').toLowerCase().includes(search.toLowerCase())
  );
  const pageCount = Math.ceil(filtered.length / pageSize);
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  // Updated to show only a user-friendly date (e.g., "Apr 24, 2025")
  const fmtDate = iso => {
    const date = new Date(iso);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="card" style={{ minHeight: '32rem', padding: '10px' }}>
      <div className="card-header card-no-border pb-0">
        <div className="header-top d-flex justify-content-between align-items-center">
          <h4>Recent Orders</h4>
          <Form.Control
            size="sm"
            type="text"
            placeholder="Search…"
            style={{ width: 180 }}
            value={search}
            onChange={e => {
              setPage(1);
              setSearch(e.target.value);
            }}
          />
        </div>
      </div>

      <div className="card-body pt-0 recent-orders px-0">
        <div className="table-responsive">
          <table className="table align-middle mb-0">
            <thead className="table-light">
              <tr>
                <th>Date</th>
                <th>Customer</th>
                <th>Plan</th>
                <th>Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {paged.map((t, i) => (
                <tr key={i}>
                  <td>{fmtDate(t.created_at)}</td>
                  <td>{`${t.first_name || ''} ${t.last_name || ''}`.trim()}</td>
                  <td>{t.title || ''}</td>
                  <td>${(parseFloat(t.amount) || 0).toFixed(2)}</td>
                  <td>
                    <span
                      className={`badge rounded-pill ${
                        statusClass[t.payment_status?.toLowerCase()] || 'bg-light text-dark'
                      }`}
                    >
                      {t.payment_status || ''}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="d-flex justify-content-end mt-3">
          <ul className="pagination pagination-sm mb-0">
            <li className={`page-item ${page === 1 ? 'disabled' : ''}`}>
              <button className="page-link" onClick={() => setPage(page - 1)}>
                Previous
              </button>
            </li>
            {Array.from({ length: pageCount }).map((_, idx) => (
              <li
                key={idx}
                className={`page-item ${idx + 1 === page ? 'active' : ''}`}
              >
                <button className="page-link" onClick={() => setPage(idx + 1)}>
                  {idx + 1}
                </button>
              </li>
            ))}
            <li className={`page-item ${page === pageCount ? 'disabled' : ''}`}>
              <button className="page-link" onClick={() => setPage(page + 1)}>
                Next
              </button>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
