import React, { useState } from 'react';

export const MaintainerForm = ({ properties=[{ id: 1, name: 'Property A' }], types=[{ id: 1, name: 'Admin' }] }) => {
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    phone_number: '',
    property_id: [],
    type_id: '',
    profile: null,
  });

  const handleChange = (e) => {
    const { name, value, type, files, multiple } = e.target;

    if (type === 'file') {
      setFormData({
        ...formData,
        [name]: multiple ? Array.from(files) : files[0],
      });
    } else if (name === 'property_id') {
      const selectedOptions = Array.from(e.target.selectedOptions, option => option.value);
      setFormData({ ...formData, property_id: selectedOptions });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const data = new FormData();
    for (const key in formData) {
      if (Array.isArray(formData[key])) {
        formData[key].forEach(val => data.append(`${key}[]`, val));
      } else {
        data.append(key, formData[key]);
      }
    }

    fetch('/maintainer', {
      method: 'POST',
      body: data,
    })
    .then(res => res.json())
    .then(result => {
      console.log('Form submitted successfully', result);
      // Handle success (e.g., toast, redirect)
    })
    .catch(error => {
      console.error('Form submission error:', error);
      // Handle error (e.g., show validation feedback)
    });
  };

  return (
    <form onSubmit={handleSubmit} encType="multipart/form-data">
      <div className="row">
        <div className="form-group col-md-6 col-lg-6">
          <label className="form-label">First Name</label>
          <input
            type="text"
            name="first_name"
            className="form-control"
            placeholder="Enter First Name"
            required
            value={formData.first_name}
            onChange={handleChange}
          />
        </div>
        <div className="form-group col-md-6 col-lg-6">
          <label className="form-label">Last Name</label>
          <input
            type="text"
            name="last_name"
            className="form-control"
            placeholder="Enter Last Name"
            required
            value={formData.last_name}
            onChange={handleChange}
          />
        </div>
        <div className="form-group col-md-6 col-lg-6">
          <label className="form-label">Email</label>
          <input
            type="email"
            name="email"
            className="form-control"
            placeholder="Enter Email"
            required
            value={formData.email}
            onChange={handleChange}
          />
        </div>
        <div className="form-group col-md-6 col-lg-6">
          <label className="form-label">Password</label>
          <input
            type="password"
            name="password"
            className="form-control"
            placeholder="Enter Password"
            required
            value={formData.password}
            onChange={handleChange}
          />
        </div>
        <div className="form-group col-md-6">
          <label className="form-label">Phone Number</label>
          <input
            type="text"
            name="phone_number"
            className="form-control"
            placeholder="Enter Phone Number"
            required
            value={formData.phone_number}
            onChange={handleChange}
          />
        </div>
        <div className="form-group col-md-6">
          <label className="form-label">Property</label>
          <select
            multiple
            name="property_id"
            className="form-control"
            value={formData.property_id}
            onChange={handleChange}
            required
          >
            {properties.map((prop) => (
              <option key={prop.id} value={prop.id}>
                {prop.name}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group col-md-6">
          <label className="form-label">Type</label>
          <select
            name="type_id"
            className="form-control"
            value={formData.type_id}
            onChange={handleChange}
            required
          >
            <option value="" disabled>Select Type</option>
            {types.map((type) => (
              <option key={type.id} value={type.id}>
                {type.name}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group col-md-6">
          <label className="form-label">Profile</label>
          <input
            type="file"
            name="profile"
            className="form-control"
            onChange={handleChange}
          />
        </div>
      </div>
      <button type="submit" className="btn btn-primary btn-rounded">
        Create
      </button>
    </form>
  );
};

