import React, { useEffect, useMemo, useState } from "react";
import { Dropdown } from "react-bootstrap";
import { FaArrowUp, FaArrowDown, FaEllipsisV, FaUsers } from "react-icons/fa";
import ReactApexChart from "react-apexcharts";

export const UsersCard = ({ payload }) => {
  const { user_types = [], monthly_registrations = [] } = payload;
  const mdata = monthly_registrations.map(m => ({
    year: +m.month.slice(0, 4),
    month: m.month,
    value: m.new_users,
    growth: m.monthly_growth_rate,
  }));
  const years = Array.from(new Set(mdata.map(d => d.year))).sort();
  const ydata = years.map((y, i) => {
    const sum = mdata.filter(d => d.year === y).reduce((s, d) => s + d.value, 0);
    const prev = i > 0
      ? mdata.filter(d => d.year === years[i - 1]).reduce((s, d) => s + d.value, 0)
      : 0;
    return {
      year: y,
      total: sum,
      growth: prev ? ((sum - prev) / prev * 100).toFixed(2) : '0.00'
    };
  });

  const [mode, setMode] = useState('Year');
  const [sel, setSel] = useState(String(years.at(-1)));

  useEffect(() => {
    setSel(mode === 'Year' ? String(years.at(-1)) : mdata.at(-1).month);
  }, [mode, years, mdata]);

  const { figure, pct, label } = useMemo(() => {
    if (mode === 'Year') {
      const r = ydata.find(d => String(d.year) === sel) || {};
      return {
        figure: r.total || 0,
        pct: r.growth || '0.00',
        label: `Year ${sel}`
      };
    } else {
      const r = mdata.find(d => d.month === sel) || {};
      return {
        figure: r.value || 0,
        pct: (r.growth || 0).toFixed(2),
        label: sel
      };
    }
  }, [mode, sel, ydata, mdata]);

  const seriesData = mdata.filter(d =>
    mode === 'Year' ? d.year === +sel : d.year === +sel.slice(0, 4)
  );
  const opts = {
    chart: { sparkline: { enabled: true }, type: 'area' },
    stroke: { curve: 'smooth', width: 2 },
    fill: { type: 'gradient', gradient: { opacityFrom: 0.5, opacityTo: 0 } },
    tooltip: { theme: 'light' },
    xaxis: { categories: seriesData.map(d => d.month) },
  };
  const series = [{ name: '', data: seriesData.map(d => d.value) }];
  const up = Number(pct) >= 0;
  const tip = Object.entries(user_types).map(([k, v]) => `${k}: ${v}`).join(', ');

  return (
    <div className="card">
      <div className="card-header card-no-border pb-0">
        <div className="header-top daily-revenue-card d-flex justify-content-between align-items-center">
          <h4>Total Users</h4>
          <Dropdown className="icon-dropdown">
            <Dropdown.Toggle variant="link" className="btn p-0">
              <FaEllipsisV />
            </Dropdown.Toggle>
            <Dropdown.Menu align="end">
              <Dropdown.Header>Year</Dropdown.Header>
              {years.map(y => (
                <Dropdown.Item
                  key={y}
                  active={mode === 'Year' && sel === String(y)}
                  onClick={() => { setMode('Year'); setSel(String(y)); }}
                >
                  {y}
                </Dropdown.Item>
              ))}
              <Dropdown.Divider />
              <Dropdown.Header>Month</Dropdown.Header>
              {mdata.map(d => d.month).map(m => (
                <Dropdown.Item
                  key={m}
                  active={mode === 'Month' && sel === m}
                  onClick={() => { setMode('Month'); setSel(m); }}
                >
                  {m}
                </Dropdown.Item>
              ))}
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>

      <div className="card-body pb-0 total-sells" style={{ padding: '1.5rem 0' }}>
        <div className="d-flex align-items-center gap-3">
          <div
            className="rounded-circle d-flex justify-content-center align-items-center flex-shrink-0"
            style={{ width: 52, height: 52, background: '#7a70ba' }}
          >
            <FaUsers
              className="text-white"
              style={{ width: '2em', height: '2em' }}
            />
          </div>
          <div className="flex-grow-1">
            <div className="d-flex align-items-center gap-2">
              <h2 title={tip}>{figure.toLocaleString()}</h2>
              <div className="d-flex total-icon align-items-center gap-1">
                <p className={`mb-0 up-arrow ${up ? 'bg-light-success' : 'bg-light-danger'}`}>
                  {up
                    ? <FaArrowUp style={{ width: '2em', height: '2em' }} className="text-success" />
                    : <FaArrowDown style={{ width: '2em', height: '2em' }} className="text-danger" />
                  }
                </p>
                <span className={`f-w-500 ${up ? 'font-success' : 'font-danger'}`}>
                  {up ? '+' : ''}{pct}%
                </span>
              </div>
            </div>
            <p className="text-truncate">{label}</p>
          </div>
        </div>

        <ReactApexChart options={opts} series={series} type="area" height={90} />
      </div>
    </div>
  );
};

export const DataCard = ({
  title,
  icon,
  bgColor,
  payload,
  yearlyKey,
  monthlyKey,
  yearlyValueKey,
  yearlyPctKey,
  monthlyValueKey,
  monthlyPctKey,
}) => {
  const { yearly_data = [], monthly_data = [] } = payload;
  const years = yearly_data.map(d => d[yearlyKey]).sort();
  const months = monthly_data.map(d => d[monthlyKey]).sort();

  const [mode, setMode] = useState('Year');
  const [sel, setSel] = useState(String(years.at(-1)));

  useEffect(() => {
    setSel(mode === 'Year' ? String(years.at(-1)) : months.at(-1));
  }, [mode, years, months]);

  const { figure, pct, label } = useMemo(() => {
    if (mode === 'Year') {
      const r = yearly_data.find(d => String(d[yearlyKey]) === sel) || {};
      const displayYear = sel && sel !== 'undefined' ? sel : '-';
      return {
        figure: r[yearlyValueKey] || 0,
        pct: (r[yearlyPctKey] || 0).toFixed(2),
        label: `Year ${displayYear}`
      };
    } else {
      const r = monthly_data.find(d => d[monthlyKey] === sel) || {};
      return {
        figure: r[monthlyValueKey] || 0,
        pct: (r[monthlyPctKey] || 0).toFixed(2),
        label: sel && sel !== 'undefined' ? sel : '-'
      };
    }
  }, [
    mode,
    sel,
    yearly_data,
    monthly_data,
    yearlyKey,
    monthlyKey,
    yearlyValueKey,
    yearlyPctKey,
    monthlyValueKey,
    monthlyPctKey,
  ]);

  const seriesData = monthly_data.filter(d =>
    mode === 'Year'
      ? d.year === +sel
      : d.year === +sel.slice(0, 4)
  ).map(d => ({ month: d[monthlyKey], value: d[monthlyValueKey] }));

  const opts = {
    chart: { sparkline: { enabled: true }, type: 'area' },
    stroke: { curve: 'smooth', width: 2 },
    fill: { type: 'gradient', gradient: { opacityFrom: 0.5, opacityTo: 0 } },
    tooltip: { theme: 'light' },
    xaxis: { categories: seriesData.map(d => d.month) },
  };
  const series = [{ name: '', data: seriesData.map(d => d.value) }];
  const up = Number(pct) >= 0;

  // render the passed-in icon at 2em
  const renderedIcon = icon && React.isValidElement(icon)
    ? React.cloneElement(icon, { style: { width: '2em', height: '2em' } })
    : null;

  return (
    <div className="card">
      <div className="card-header card-no-border pb-0">
        <div className="header-top daily-revenue-card d-flex justify-content-between align-items-center">
          <h4>{title}</h4>
          <Dropdown className="icon-dropdown">
            <Dropdown.Toggle variant="link" className="btn p-0">
              <FaEllipsisV />
            </Dropdown.Toggle>
            <Dropdown.Menu align="end">
              <Dropdown.Header>Year</Dropdown.Header>
              {years.map(y => (
                <Dropdown.Item
                  key={y}
                  active={mode === 'Year' && sel === String(y)}
                  onClick={() => { setMode('Year'); setSel(String(y)); }}
                >
                  {y}
                </Dropdown.Item>
              ))}
              <Dropdown.Divider />
              <Dropdown.Header>Month</Dropdown.Header>
              {months.map(m => (
                <Dropdown.Item
                  key={m}
                  active={mode === 'Month' && sel === m}
                  onClick={() => { setMode('Month'); setSel(m); }}
                >
                  {m}
                </Dropdown.Item>
              ))}
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>

      <div className="card-body pb-0 total-sells" style={{ padding: '1.5rem 0' }}>
        <div className="d-flex align-items-center gap-3">
          <div
            className="rounded-circle d-flex justify-content-center align-items-center flex-shrink-0"
            style={{ width: 52, height: 52, background: bgColor }}
          >
            {renderedIcon}
          </div>
          <div className="flex-grow-1">
            <div className="d-flex align-items-center gap-2">
              <h2>{figure.toLocaleString()}</h2>
              <div className="d-flex total-icon align-items-center gap-1">
                <p className={`mb-0 up-arrow ${up ? 'bg-light-success' : 'bg-light-danger'}`}>
                  {up
                    ? <FaArrowUp style={{ width: '2em', height: '2em' }} />
                    : <FaArrowDown style={{ width: '2em', height: '2em' }} />
                  }
                </p>
                <span className={`f-w-500 ${up ? 'font-success' : 'font-danger'}`}>
                  {up ? '+' : ''}{pct}%
                </span>
              </div>
            </div>
            <p className="text-truncate">{label}</p>
          </div>
        </div>

        <ReactApexChart options={opts} series={series} type="area" height={90} />
      </div>
    </div>
  );
};
