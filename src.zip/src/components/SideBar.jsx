import React, { useState, useEffect } from "react";
import logoIcon from "../assets/logo/logo_light.png";
import { Link, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { env } from "../config/env";

export const Sidebar = ({
  isCollapsed,
  isMobileOpen,
  onToggleSidebar,
  menuItems = [],
  pinnedMenus = [],
  onTogglePin,
  logoSize = 45,
  titleFontSize = 16,
  theme,
}) => {
  const company = useSelector(state => state.company);
  const appName = company?.application_name || 'Propfinda';
  const appLogo = company?.logo || logoIcon;
  const [activeMenu, setActiveMenu] = useState(null);
  const [activeSubmenu, setActiveSubmenu] = useState(null);
  const isMobile = window.innerWidth <= 768;
  const location = useLocation();

  useEffect(() => {
    // Check which menu item should be active based on current route
    const currentPath = location.pathname;

    // Check main menu items and their children
    menuItems.forEach(item => {
      if (item.path === currentPath) {
        setActiveMenu(item.id);
      }

      // Check submenu items
      if (item.children) {
        item.children.forEach(child => {
          if (child.path === currentPath) {
            setActiveMenu(item.id);
            setActiveSubmenu(child.id);
          }
        });
      }
    });
  }, [location.pathname, menuItems]);

  const handleLinkClick = () => {
    if (isMobile && isMobileOpen) {
      onToggleSidebar();
    }
  };

  const pinnedItems = menuItems.filter((item) => pinnedMenus.includes(item.id));
  const regularItems = menuItems.filter((item) => !pinnedMenus.includes(item.id));

  const sections = regularItems.reduce((acc, item) => {
    const section = item.section || "General";
    if (!acc[section]) acc[section] = [];
    acc[section].push(item);
    return acc;
  }, {});

  const renderMenuItem = (item, index) => {
    const isSubmenuOpen = activeMenu === item.id;
    const isPinned = pinnedMenus.includes(item.id);
    const isExpandable = Boolean(item.children && item.children.length > 0);
    const isActive = location.pathname === item.path;
    const MenuLink = isExpandable ? "div" : Link;

    // Check if any child is active for highlighting parent
    const hasActiveChild = isExpandable &&
      item.children.some(child => location.pathname === child.path);

    return (
      <li
        key={item.id || index}
        className={`sidebar-item ${isPinned ? "pinned" : ""} 
                   ${isActive || hasActiveChild ? "active" : ""} 
                   ${isSubmenuOpen ? "open" : ""}`}
      >
        <MenuLink
          to={!isExpandable ? item.path : undefined}
          className={`sidebar-link ${!isExpandable ? "link-nav" : ""}`}
          onClick={(e) => {
            if (isExpandable) {
              e.preventDefault();
              setActiveMenu((prev) => (prev === item.id ? null : item.id));
            } else {
              handleLinkClick();
            }
          }}
          aria-expanded={isSubmenuOpen}
          data-title={item.title}
        >
          {item.icon && (
            <span className="sidebar-icon">
              {typeof item.icon === 'string' ? (
                <i className={`fa ${item.icon}`} />
              ) : (
                item.icon
              )}
            </span>
          )}
          {!isCollapsed && <span className="sidebar-label">{item.title}</span>}

          {!isCollapsed && isExpandable && (
            <span className={`sidebar-arrow ${isSubmenuOpen ? 'open' : ''}`}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="6 9 12 15 18 9"></polyline>
              </svg>
            </span>
          )}

          {!isCollapsed && (
            <span
              className={`sidebar-pin ${isPinned ? 'pinned' : ''}`}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onTogglePin(item.id);
              }}
              title={isPinned ? "Unpin" : "Pin"}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 2v12M4 8l8 8 8-8"></path>
              </svg>
            </span>
          )}
        </MenuLink>

        {isExpandable && (
          <ul className={`sidebar-submenu ${isSubmenuOpen ? "open" : ""}`}>
            {item.children.map((child, childIndex) => {
              const isChildActive = location.pathname === child.path;

              return (
                <li
                  key={child.id || childIndex}
                  className={`sidebar-submenu-item ${isChildActive ? "active" : ""}`}
                >
                  <Link
                    to={child.path}
                    className="sidebar-submenu-link"
                    onClick={handleLinkClick}
                    data-title={child.title}
                  >
                    {child.icon && (
                      <span className="sidebar-submenu-icon">
                        {typeof child.icon === 'string' ? (
                          <i className={`fa ${child.icon}`} />
                        ) : (
                          child.icon
                        )}
                      </span>
                    )}
                    <span className="sidebar-submenu-label">{child.title}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </li>
    );
  };

  return (
    <aside
      className={`sidebar 
        ${isCollapsed ? "collapsed" : ""} 
        ${isMobileOpen ? "open" : ""} 
        ${theme === "dark" ? "dark" : ""}`}
    >
      <div className="sidebar-header">
        <Link to={env.LANDING_URL} className="sidebar-logo">
          <img
            src={appLogo}
            alt="Logo"
            className="sidebar-logo-img"
          />
          {!isCollapsed && (
            <div className="sidebar-logo-text">
              <span className="sidebar-logo-title">{appName}</span>
              <span className="sidebar-logo-subtitle">Estate Manager</span>
            </div>
          )}
        </Link>
        <button className="sidebar-toggle" onClick={onToggleSidebar} aria-label="Toggle sidebar">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M15 18l-6-6 6-6"></path>
          </svg>
        </button>
      </div>

      <div className="sidebar-content">
        {pinnedItems.length > 0 && (
          <div className="sidebar-section">
            <h6 className="sidebar-section-title">Pinned</h6>
            <ul className="sidebar-nav">{pinnedItems.map(renderMenuItem)}</ul>
          </div>
        )}

        {Object.entries(sections).map(([sectionName, items]) => (
          <div key={sectionName} className="sidebar-section">
            <h6 className="sidebar-section-title">
              {sectionName.charAt(0).toUpperCase() + sectionName.slice(1)}
            </h6>
            <ul className="sidebar-nav">{items.map(renderMenuItem)}</ul>
          </div>
        ))}
      </div>

      <div className="sidebar-footer">
        <a href="/help" className="sidebar-footer-link">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
          </svg>
          {!isCollapsed && <span>Help & Support</span>}
        </a>
      </div>
    </aside>
  );
};
