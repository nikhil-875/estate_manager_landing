import React from 'react';
import { Card, Badge, Row, Col, Button } from 'react-bootstrap';
import { FaBed, FaBath, FaRulerCombined, FaComments, FaMapMarkerAlt } from 'react-icons/fa';

const PropertyListingCard = ({ property, onInquireClick }) => {
  return (
    <Card className="property-card">
      <div className="image-container">
        <Card.Img src={property.image} style={{ objectFit: 'cover', height: '100%', width: '100%' }} />
        <Badge
          bg={property.details.status === 'Available' ? 'success' : 'warning'}
          className="card-badge"
        >
          {property.details.status}
        </Badge>
        <div className="card-img-overlay-gradient"></div>
      </div>

      <Card.Body className="px-4 py-4">
        <h5 className="card-title">{property.name}</h5>
        <div className="property-address mb-3">
          <FaMapMarkerAlt className="me-2" size={14} />
          {property.address}
        </div>

        <Row className="mb-4">
          <Col xs={4}>
            <div className="property-feature">
              <div className="feature-icon mx-auto">
                <FaBed />
              </div>
              <div className="mt-1">{property.details.bedrooms} Beds</div>
            </div>
          </Col>
          <Col xs={4}>
            <div className="property-feature">
              <div className="feature-icon mx-auto">
                <FaBath />
              </div>
              <div className="mt-1">{property.details.bathrooms} Baths</div>
            </div>
          </Col>
          <Col xs={4}>
            <div className="property-feature">
              <div className="feature-icon mx-auto">
                <FaRulerCombined />
              </div>
              <div className="mt-1">{property.details.area}</div>
            </div>
          </Col>
        </Row>

        <Card.Text className="text-muted mb-4" style={{ fontSize: '0.9rem', height: '60px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {property.description.substring(0, 120)}{property.description.length > 120 && '...'}
        </Card.Text>

        <div className="d-flex justify-content-between align-items-center mt-3">
          <div className="property-price">${property.rent}/mo</div>
          <Button
            variant="primary"
            className="inquire-btn"
            onClick={() => onInquireClick(property)}
          >
            <FaComments /> Inquire Now
          </Button>
        </div>
      </Card.Body>
    </Card>
  );
};

export default PropertyListingCard; 