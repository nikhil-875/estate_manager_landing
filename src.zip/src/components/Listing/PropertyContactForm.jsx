import React from 'react';
import { Modal, Form, InputGroup, Button, Row, Col, Spinner } from 'react-bootstrap';
import { FaUser, FaRegEnvelope, FaAngleDoubleRight } from 'react-icons/fa';

const PropertyContactForm = ({ 
  show, 
  onHide, 
  userInfo, 
  onUserInfoChange, 
  onSubmit, 
  isSubmitting, 
  hasFilledUserInfo 
}) => {
  return (
    <Modal
      show={show}
      onHide={() => {
        onHide();
      }}
      centered
      backdrop="static"
      keyboard={false}
      className="user-info-modal"
    >
      <Modal.Header closeButton>
        <Modal.Title className="fs-5">
          <div className="d-flex align-items-center">
            <div className="me-2 text-primary">
              <FaUser />
            </div>
            <div>
              <span className="fw-bold">Your Contact Information</span>
            </div>
          </div>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p className="text-muted mb-4">Please provide your details so the property manager can contact you.</p>

        <Form onSubmit={onSubmit}>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-4">
                <Form.Label>First Name</Form.Label>
                <InputGroup>
                  <InputGroup.Text className="bg-transparent"><FaUser className="text-muted" /></InputGroup.Text>
                  <Form.Control
                    type="text"
                    value={userInfo.firstName}
                    onChange={e => onUserInfoChange({ ...userInfo, firstName: e.target.value })}
                    required
                  />
                </InputGroup>
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-4">
                <Form.Label>Last Name</Form.Label>
                <InputGroup>
                  <InputGroup.Text className="bg-transparent"><FaUser className="text-muted" /></InputGroup.Text>
                  <Form.Control
                    type="text"
                    value={userInfo.lastName}
                    onChange={e => onUserInfoChange({ ...userInfo, lastName: e.target.value })}
                    required
                  />
                </InputGroup>
              </Form.Group>
            </Col>
          </Row>
          <Form.Group className="mb-4">
            <Form.Label>Email Address</Form.Label>
            <InputGroup>
              <InputGroup.Text className="bg-transparent"><FaRegEnvelope className="text-muted" /></InputGroup.Text>
              <Form.Control
                type="email"
                value={userInfo.email}
                onChange={e => onUserInfoChange({ ...userInfo, email: e.target.value })}
                required
              />
            </InputGroup>
          </Form.Group>
          <div className="d-flex justify-content-end gap-3 mt-4">
            <Button
              variant="secondary"
              className="cancel-btn"
              onClick={() => {
                onHide();
              }}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              type="submit"
              className="submit-btn"
              disabled={isSubmitting}
            >
              {isSubmitting ?
                <Spinner as="span" animation="border" size="sm" className="me-2" /> :
                <FaAngleDoubleRight className="me-2" />
              }
              Continue
            </Button>
          </div>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default PropertyContactForm; 