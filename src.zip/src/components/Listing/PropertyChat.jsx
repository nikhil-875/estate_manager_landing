import React, { useRef, useEffect } from 'react';
import { Modal, Form, Button, Spinner } from 'react-bootstrap';
import { FaComments, FaPaperPlane } from 'react-icons/fa';

const PropertyChat = ({
  show,
  onHide,
  propertyName,
  chatMessages,
  chatStep,
  messageInput,
  onMessageInputChange,
  onSendMessage,
  isLoadingChatHistory,
  isSendingMessage,
  onButtonClick,
  resetChat
}) => {
  const chatEndRef = useRef(null);

  // Auto-scroll chat when messages change
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  return (
    <Modal
      show={show}
      onHide={() => {
        onHide();
        resetChat();
      }}
      centered
      size="md"
      backdrop="static"
      className="chat-modal"
    >
      <Modal.Header closeButton>
        <Modal.Title className="fs-5">
          <div className="d-flex align-items-center">
            <div className="me-2 text-primary">
              <FaComments />
            </div>
            <div>
              <span className="fw-bold">Inquiry:</span> {propertyName}
            </div>
          </div>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body style={{ height: '60vh', display: 'flex', flexDirection: 'column' }}>
        {/* Loading state for chat history */}
        {isLoadingChatHistory && chatMessages.length <= 1 && (
          <div className="d-flex justify-content-center align-items-center h-100">
            <Spinner animation="border" variant="primary" />
            <span className="ms-2">Loading conversation history...</span>
          </div>
        )}

        {/* Chat messages */}
        <div className="chat-messages-container flex-grow-1 overflow-auto">
          {chatMessages.map(msg => (
            <div key={msg.id} className={`d-flex ${msg.sender === 'user' ? 'justify-content-end' : 'justify-content-start'}`}>
              <div className={msg.sender === 'user' ? 'user-message' : 'system-message'}>
                {msg.icon && <div className="message-icon mb-2">{msg.icon}</div>}
                <div className="chat-message-bubble">
                  {msg.isTyping ? (
                    <div className="typing-indicator">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                  ) : (
                    msg.text
                  )}
                </div>
                {msg.buttons && (
                  <div className="chat-message-buttons">
                    {msg.buttons.map(btn => (
                      <button
                        key={btn.text}
                        className="chat-button"
                        onClick={() => onButtonClick(btn)}
                      >
                        {btn.text}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>

        <div className="chat-input-container mt-auto">
          <Form onSubmit={onSendMessage} className="d-flex align-items-center">
            <Form.Control
              className="chat-input me-2"
              placeholder="Type a message..."
              value={messageInput}
              onChange={e => onMessageInputChange(e.target.value)}
              disabled={chatStep !== 'openChat' || isSendingMessage}
            />
            <Button
              type="submit"
              className="send-button"
              disabled={chatStep !== 'openChat' || !messageInput.trim() || isSendingMessage}
              style={{
                color: 'white',
                minWidth: '45px',
                padding: 0,
                marginLeft: '10px',
                boxShadow: '0 3px 10px rgba(67, 97, 238, 0.3)'
              }}
              aria-label="Send message"
            >
              {isSendingMessage ?
                <Spinner size="sm" animation="border" style={{ color: 'white' }} /> :
                <FaPaperPlane style={{ color: 'white' }} />
              }
            </Button>
          </Form>
        </div>
      </Modal.Body>
    </Modal>
  );
};

export default PropertyChat; 