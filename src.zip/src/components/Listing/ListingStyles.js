// Extracted styles for property listings
export const pageStyles = `
  :root {
    --primary-color: #4361ee;
    --primary-light: #4361ee15;
    --secondary-color: #3f37c9;
    --accent-color: #f72585;
    --success-color: #4cc9f0;
    --warning-color: #f8961e;
    --text-color: #2b2d42;
    --text-light: #8d99ae;
    --bg-light: #f8f9fa;
    --transition-speed: 0.3s;
    --card-shadow: 0 8px 30px rgba(0,0,0,0.07);
    --hover-shadow: 0 15px 35px rgba(67, 97, 238, 0.15);
  }

  body {
    color: var(--text-color);
  }

  /* Modern card styling */
  .property-card {
    border: none;
    border-radius: 18px;
    overflow: hidden;
    box-shadow: var(--card-shadow);
    transition: all var(--transition-speed) ease;
    height: 100%;
  }
  
  .property-card:hover {
    transform: translateY(-10px);
    box-shadow: var(--hover-shadow);
  }
  
  .card-img-overlay-gradient {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: linear-gradient(180deg, rgba(0,0,0,0) 60%, rgba(0,0,0,0.75) 100%);
  }
  
  .image-container {
    position: relative;
    height: 220px;
    overflow: hidden;
  }
  
  .card-badge {
    position: absolute;
    top: 12px;
    right: 12px;
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 700;
    padding: 5px 10px;
    border-radius: 30px;
    z-index: 2;
  }

  .property-card .card-title {
    font-weight: 700;
    font-size: 1.25rem;
    margin-bottom: 0.5rem;
  }
  
  /* Search styling */
  .search-container {
    border-radius: 24px;
    background-color: #fff;
    box-shadow: 0 15px 35px rgba(0,0,0,0.05);
    border: none;
  }
  
  .search-bar {
    border-radius: 100px;
    overflow: hidden;
    box-shadow: 0 10px 25px rgba(67, 97, 238, 0.07);
    transition: all var(--transition-speed) ease;
  }
  
  .search-bar:focus-within {
    box-shadow: 0 12px 30px rgba(67, 97, 238, 0.12);
  }

  .search-btn {
    border-top-right-radius: 100px !important;
    border-bottom-right-radius: 100px !important;
    padding-left: 2rem !important;
    padding-right: 2rem !important;
    background-color: var(--primary-color) !important;
    border-color: var(--primary-color) !important;
  }

  /* Property details */
  .feature-icon {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: var(--primary-light);
    color: var(--primary-color);
    border-radius: 12px;
    margin-bottom: 0.5rem;
  }
  
  .property-feature {
    text-align: center;
    font-size: 0.9rem;
  }

  .property-address {
    color: var(--text-light);
    font-size: 0.9rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
  }

  .property-price {
    font-weight: 800;
    color: var(--primary-color);
    font-size: 1.5rem;
  }

  .inquire-btn {
    border-radius: 100px;
    padding: 0.5rem 1.25rem;
    font-weight: 600;
    border: none;
    background-color: var(--primary-color);
    display: flex;
    align-items: center;
    gap: 0.5rem;
    transition: all var(--transition-speed) ease;
  }

  .inquire-btn:hover {
    background-color: var(--secondary-color);
    transform: translateY(-3px);
    box-shadow: 0 8px 15px rgba(67, 97, 238, 0.2);
  }

  /* Chat modal styling */
  .chat-modal .modal-content {
    border-radius: 24px;
    border: none;
    box-shadow: 0 25px 50px rgba(0,0,0,0.1);
    overflow: hidden;
  }

  .chat-modal .modal-header {
    border-bottom: 1px solid rgba(0,0,0,0.05);
    background-color: #fff;
    padding: 1.5rem;
  }

  .chat-messages-container {
    scroll-behavior: smooth;
    padding: 1.5rem;
  }

  .system-message {
    background-color: #f0f2fa;
    color: var(--text-color);
    border-radius: 18px 18px 18px 0;
    padding: 1rem 1.5rem;
    margin-bottom: 1.5rem;
    max-width: 85%;
    position: relative;
    box-shadow: 0 3px 10px rgba(0,0,0,0.03);
  }

  .user-message {
    background-color: var(--primary-color);
    color: white;
    border-radius: 18px 18px 0 18px;
    padding: 1rem 1.5rem;
    margin-bottom: 1.5rem;
    margin-left: auto;
    max-width: 85%;
    position: relative;
    box-shadow: 0 3px 10px rgba(67, 97, 238, 0.2);
  }

  .chat-message-bubble {
    white-space: pre-wrap;
    word-wrap: break-word;
    font-size: 0.95rem;
    line-height: 1.5;
  }

  .chat-message-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-top: 1rem;
  }
  
  .chat-button {
    border-radius: 100px;
    padding: 0.5rem 1rem;
    border: 1px solid var(--primary-color);
    color: var(--primary-color);
    background-color: white;
    font-size: 0.85rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  
  .chat-button:hover {
    background-color: var(--primary-color);
    color: white;
  }
  
  .chat-input-container {
    border-top: 1px solid rgba(0,0,0,0.05);
    padding: 1rem 1.5rem;
  }
  
  .chat-input {
    border-radius: 100px;
    border: 1px solid rgba(0,0,0,0.1);
    padding: 0.75rem 1.25rem;
  }

  .chat-input:focus {
    box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
    border-color: var(--primary-color);
  }
  
  .send-button {
    border-radius: 50%;
    width: 45px;
    height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: var(--primary-color);
    border: none;
    transition: all 0.2s ease;
  }
  
  .send-button:hover {
    background-color: var(--secondary-color);
    transform: scale(1.05);
  }

  /* Message icons and typing indicator */
  .message-icon {
    display: flex;
    align-items: center;
    font-size: 1.1rem;
  }

  .typing-indicator {
    display: flex;
    align-items: center;
  }

  .typing-indicator span {
    height: 8px;
    width: 8px;
    margin: 0 2px;
    background-color: #bbb;
    border-radius: 50%;
    display: inline-block;
    opacity: 0.5;
    animation: pulse 1.5s infinite ease-in-out;
  }

  .typing-indicator span:nth-child(1) {
    animation-delay: 0s;
  }

  .typing-indicator span:nth-child(2) {
    animation-delay: 0.2s;
  }

  .typing-indicator span:nth-child(3) {
    animation-delay: 0.4s;
  }

  @keyframes pulse {
    0%, 100% {
      transform: scale(0.7);
      opacity: 0.5;
    }
    50% {
      transform: scale(1);
      opacity: 1;
    }
  }

  /* User info modal styling */
  .user-info-modal .modal-content {
    border-radius: 24px;
    border: none;
    overflow: hidden;
    box-shadow: 0 25px 50px rgba(0,0,0,0.15);
  }
  
  .user-info-modal .modal-body {
    padding: 2rem;
  }
  
  .form-control {
    border-radius: 12px;
    padding: 0.75rem 1.25rem;
    border: 1px solid rgba(0,0,0,0.1);
    transition: all 0.2s ease;
  }
  
  .form-control:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
  }
  
  .form-label {
    font-weight: 600;
    margin-bottom: 0.5rem;
    font-size: 0.9rem;
  }
  
  .submit-btn {
    border-radius: 12px;
    padding: 0.75rem 2rem;
    font-weight: 600;
    background-color: var(--primary-color);
    border: none;
    transition: all 0.2s ease;
  }
  
  .submit-btn:hover {
    background-color: var(--secondary-color);
    transform: translateY(-3px);
    box-shadow: 0 8px 15px rgba(67, 97, 238, 0.2);
  }

  .cancel-btn {
    border-radius: 12px;
    padding: 0.75rem 2rem;
    font-weight: 600;
    background-color: #f1f3f5;
    border: none;
    color: var(--text-color);
    transition: all 0.2s ease;
  }
  
  .cancel-btn:hover {
    background-color: #e9ecef;
    color: #212529;
  }
  
  /* Empty and error states */
  .empty-state, .error-state {
    text-align: center;
    padding: 4rem 1rem;
  }
  
  .empty-state-icon, .error-state-icon {
    font-size: 4rem;
    margin-bottom: 1.5rem;
    opacity: 0.5;
  }
  
  .loading-state {
    text-align: center;
    padding: 4rem 1rem;
  }
  
  /* Responsive tweaks */
  @media (max-width: 768px) {
    .search-container {
      border-radius: 18px;
    }
    
    .property-card {
      border-radius: 16px;
    }
    
    .image-container {
      height: 180px;
    }
    
    .property-price {
      font-size: 1.25rem;
    }
  }
  
  @media (max-width: 576px) {
    .chat-modal .modal-body {
      height: 75vh;
    }
    
    .system-message, .user-message {
      max-width: 90%;
    }
  }
`; 