// src/components/Listing/listingWizard.jsx

import React, { useState, useEffect, useRef } from 'react';
import {
  Card,
  ProgressBar,
  Form,
  Row,
  Col,
  Button,
  ListGroup,
  Spinner
} from 'react-bootstrap';
import { useManageListingMutation } from '../../api/listingApi';
import { useGenerateFAQsMutation } from '../../api/aiApi';    
import { toast } from 'react-toastify';

/* ------------------------------------------------------------------
   Wizard steps
------------------------------------------------------------------ */
const STEP_TITLES = [
  'Basic Info',
  'Requirements',
  'Viewing',
  'Quick Answers',
  'Publish',
];

/* ------------------------------------------------------------------
   Build flat form-state from API object, including hidden fields
------------------------------------------------------------------ */
const buildForm = (d = {}, user = {}) => {
  const b = d.basic || {};
  const faqs = d.faqs || [];
  const viewings = d.viewings || [];
  const reqs = d.requirements || [];

  const has = label =>
    reqs.some(r => r.label.toLowerCase() === label.toLowerCase());

  return {
    /* META */
    isEditing: d.isEditing || false,
    listing_id: b.id || null,

    /* HIDDEN PARAMS */
    property_id: b.property_id || null,
    unit_id: b.unit_id || null,
    company_id: d.company_id || null,
    uid: user.id,
    propertyType: d.propertyType || 'Apartment',
    address: d.address || '',

    /* ---------------- 1. BASIC ---------------- */
    title: b.title || '',
    description: b.description || '',
    price_per_month: b.price_per_month || '',
    rent_frequency: d.rent_frequency || 'Monthly',
    is_available: b.is_available ?? true,
    is_furnished: b.is_furnished ?? false,
    available_from: b.available_from || '',

    /* ---------------- 2. REQUIREMENTS ---------------- */
    deposit_required: Number(b.deposit_amount) > 0,
    deposit_amount: b.deposit_amount || '',
    requiresPayslip: has('Payslip'),
    requiresBankStatement: has('Bank Statement'),
    requiresEmploymentContract: has('Employment Contract'),
    requiresLandlordLetter: has('Previous Landlord Letter'),
    requiresIDDocument: has('ID Document'),
    notes: d.notes || '',

    /* ---------------- 3. VIEWINGS ---------------- */
    viewings: viewings.map(v => ({
      scheduled_date: v.scheduled_date,
      start_time: v.start_time,
      end_time: v.end_time,
      location: v.location,
      notes: v.notes,
    })),

    /* ---------------- 4. FAQ ---------------- */
    faqs: faqs.map((q, i) => ({
      question: q.question,
      answer: q.answer,
      is_active: q.is_active ?? true,
      display_order: q.display_order ?? i,
    })),
  };
};

/* ------------------------------------------------------------------
   MAIN WIZARD COMPONENT
------------------------------------------------------------------ */
export default function ListingWizard({ onClose, userId, initialData = {} }) {
  const [stepIndex, setStepIndex] = useState(0);
  const [formData, setFormData] = useState(buildForm(initialData, userId));
  const [manageListing, { isLoading: isCreating }] = useManageListingMutation();
  const [generateFAQs, { isLoading: isGeneratingFAQs }] = useGenerateFAQsMutation();
  const isLoading = isCreating || isGeneratingFAQs;

  // on initialData change, re-build form
  useEffect(() => {
    setStepIndex(0);
    setFormData(buildForm(initialData, userId));
  }, [initialData]);

  const isFirst = stepIndex === 0;
  const isLast = stepIndex === STEP_TITLES.length - 1;

  const next = () => setStepIndex(i => Math.min(i + 1, STEP_TITLES.length - 1));
  const back = () => setStepIndex(i => Math.max(i - 1, 0));

  const submit = async () => {
    // Build requirements array from boolean flags
    const requirements = [
      ...(formData.requiresPayslip ? [{ label: 'Payslip', description: 'Recent payslip showing income', is_mandatory: true }] : []),
      ...(formData.requiresBankStatement ? [{ label: 'Bank Statement', description: 'Last 3 months bank statement', is_mandatory: true }] : []),
      ...(formData.requiresEmploymentContract ? [{ label: 'Employment Contract', description: 'Current employment contract', is_mandatory: true }] : []),
      ...(formData.requiresLandlordLetter ? [{ label: 'Previous Landlord Letter', description: 'Reference from previous landlord', is_mandatory: true }] : []),
      ...(formData.requiresIDDocument ? [{ label: 'ID Document', description: 'Official identification document', is_mandatory: true }] : []),
    ];

    // Check if we need to generate FAQs from property data
    if (formData.faqs.length === 0) {
      try {
        const response = await generateFAQs({ propertyId: formData.property_id, unitId: formData.unit_id });
        formData.faqs = response.data.faqs;
      } catch (err) {
        console.error('Error auto-generating FAQs:', err);
        // Continue with submission even if FAQ generation fails
      }
    }

    // Build common payload properties
    const basePayload = {
      /* 1. BASIC */
      uid: userId,
      property_id: formData.property_id,
      unit_id: formData.unit_id,
      company_id: formData.company_id,
      title: formData.title,
      description: formData.description,
      propertyType: formData.propertyType,
      address: formData.address,
      price_per_month: formData.price_per_month,
      rent_frequency: formData.rent_frequency,
      is_available: formData.is_available,
      is_furnished: formData.is_furnished,
      available_from: formData.available_from,

      /* 2. REQUIREMENTS */
      deposit_amount: formData.deposit_amount,
      requirements: requirements,
      notes: formData.notes,

      /* 3. VIEWINGS */
      viewings: formData.viewings,

      /* 4. FAQ */
      faqs: formData.faqs,
    };

    try {
      let result;

      if (formData.isEditing && formData.listing_id) {
        // Update existing listing
        result = await manageListing({
          listing_id: formData.listing_id,
          ...basePayload
        }).unwrap();
        toast.success('Listing updated successfully');
      } else {
        // Create new listing
        result = await manageListing(basePayload).unwrap();
        toast.success('Listing created successfully');
      }

      onClose(result);
    } catch (err) {
      console.error('Failed to create/update listing:', err);
      toast.error('Failed to save listing. Please try again.');
    }
  };

  const Step = (() => {
    switch (STEP_TITLES[stepIndex]) {
      case 'Basic Info': return BasicInfoStep;
      case 'Requirements': return RequirementsStep;
      case 'Viewing': return ViewingStep;
      case 'Quick Answers': return FaqStep;
      case 'Publish': return PublishStep;
      default: return () => null;
    }
  })();

  return (
    <Card className="shadow-sm border-0" style={{ minHeight: 520 }}>
      <Card.Body>
        <ProgressBar now={((stepIndex + 1) / STEP_TITLES.length) * 100} className="mb-4" />

        <Row className="mb-4 text-center small text-white g-2">
          {STEP_TITLES.map((t, i) => (
            <Col key={t}>
              <div className={`p-2 rounded fw-semibold ${i === stepIndex
                ? i === STEP_TITLES.length - 1
                  ? 'bg-secondary text-white'
                  : 'bg-primary'
                : 'bg-success'
                }`}>
                {i + 1}. {t}
              </div>
            </Col>
          ))}
        </Row>

        <Step value={formData} onChange={setFormData} />
      </Card.Body>

      <Card.Footer className="d-flex justify-content-end gap-1 py-1 border-0">
        {!isFirst && <Button variant="secondary" onClick={back}>Back</Button>}
        {!isLast
          ? <Button variant="primary" onClick={next}>Next</Button>
          : <Button
            variant="success"
            onClick={submit}
            disabled={isLoading}
          >
            {formData.isEditing ? 'Update' : 'Publish'}
          </Button>
        }
      </Card.Footer>
    </Card>
  );
}

/* ------------------------------------------------------------------
   STEP 1 – BASIC INFO (with AI text generation)
------------------------------------------------------------------ */
const BasicInfoStep = ({ value, onChange }) => {
  const [isGenerating, setIsGenerating] = useState(false);

  const generateContent = async () => {
    try {
      setIsGenerating(true);

      // Prepare context for generation
      const context = {
        propertyType: value.propertyType || 'Apartment',
        isFurnished: value.is_furnished ? 'furnished' : 'unfurnished',
        rent: value.price_per_month,
        availableFrom: value.available_from
      };

      // This would be your API call using transformers
      // Replace with actual implementation
      const response = await fetch('/api/ai/generate-listing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(context)
      });

      if (!response.ok) throw new Error('Failed to generate content');

      const data = await response.json();

      // Update form with generated content
      onChange({
        ...value,
        title: data.title || value.title,
        description: data.description || value.description
      });

      toast.success('Content generated successfully!');
    } catch (error) {
      console.error('AI generation error:', error);
      toast.error('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Form>
      <Row className="g-3">
        <Col md={12}>
          <div className="d-flex align-items-center gap-2">
            <Form.Group controlId="title" className="flex-grow-1">
              <Form.Label>Listing Title</Form.Label>
              <Form.Control
                value={value.title}
                onChange={e => onChange({ ...value, title: e.target.value })}
              />
            </Form.Group>
            <Button
              variant="outline-primary"
              size="sm"
              style={{ marginTop: '30px' }}
              onClick={generateContent}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" className="me-1" />
                  Generating...
                </>
              ) : (
                <>AI Generate</>
              )}
            </Button>
          </div>
        </Col>

        <Col md={12}>
          <Form.Group controlId="availableFrom">
            <Form.Label>Available From</Form.Label>
            <Form.Control
              type="date"
              value={value.available_from}
              onChange={e => onChange({ ...value, available_from: e.target.value })}
            />
          </Form.Group>
        </Col>

        <Col xs={12} className="d-flex align-items-center">
          <Form.Check
            type="checkbox"
            id="isAvailable"
            label="Is Available"
            checked={value.is_available}
            onChange={e => onChange({ ...value, is_available: e.target.checked })}
            className="me-4"
          />
          <Form.Check
            type="checkbox"
            id="isFurnished"
            label="Is Furnished"
            checked={value.is_furnished}
            onChange={e => onChange({ ...value, is_furnished: e.target.checked })}
          />
        </Col>

        <Col xs={12}>
          <Form.Group controlId="description">
            <Form.Label>Description</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              value={value.description}
              onChange={e => onChange({ ...value, description: e.target.value })}
              placeholder="Click 'AI Generate' to automatically create a description"
            />
          </Form.Group>
        </Col>
      </Row>
    </Form>
  );
};

/* ------------------------------------------------------------------
   STEP 2 – REQUIREMENTS (UI unchanged)
------------------------------------------------------------------ */
const RequirementsStep = ({ value, onChange }) => {
  const lastAmount = useRef(value.deposit_amount);
  useEffect(() => {
    if (value.deposit_amount) lastAmount.current = value.deposit_amount;
  }, [value.deposit_amount]);

  const reqSwitch = (field, label) => (
    <Col xs={6} md={4} key={field}>
      <Form.Check
        type="switch"
        id={field}
        label={label}
        checked={value[field]}
        onChange={e => onChange({ ...value, [field]: e.target.checked })}
      />
    </Col>
  );

  return (
    <Form>
      <Row className="g-3 mb-3">
        <Col md={6}>
          <Row className="g-2 align-items-end">
            <Col xs="auto">
              <Form.Label>Frequency</Form.Label>
              <Form.Select
                value={value.rent_frequency}
                onChange={e => onChange({ ...value, rent_frequency: e.target.value })}
                style={{ width: '150px' }}
              >
                <option>Monthly</option>
                <option>Annual</option>
                <option>Bi-Annual</option>
              </Form.Select>
            </Col>
            <Col>
              <Form.Group controlId="rent">
                <Form.Label>{value.rent_frequency} Rent</Form.Label>
                <Form.Control
                  type="number"
                  min="0"
                  value={value.price_per_month}
                  onChange={e => onChange({ ...value, price_per_month: e.target.value })}
                  style={{ width: '190px' }}
                />
              </Form.Group>
            </Col>
          </Row>
        </Col>

        <Col md={6}>
          <Form.Label className="d-block">Deposit</Form.Label>
          <div className="d-flex align-items-center">
            <Form.Check
              type="switch"
              id="depositRequired"
              checked={value.deposit_required}
              onChange={e => {
                if (e.target.checked) {
                  onChange({
                    ...value,
                    deposit_required: true,
                    deposit_amount: lastAmount.current || '',
                  });
                } else {
                  onChange({
                    ...value,
                    deposit_required: false,
                    deposit_amount: '',
                  });
                }
              }}
              className="me-2"
            />
            <Form.Control
              type="number"
              min="0"
              placeholder="Amount"
              style={{ width: '260px' }}
              value={value.deposit_amount}
              disabled={!value.deposit_required}
              onChange={e => onChange({ ...value, deposit_amount: e.target.value })}
            />
          </div>
        </Col>
      </Row>

      <Row className="g-3 mb-3">
        {reqSwitch('requiresPayslip', 'Payslip')}
        {reqSwitch('requiresBankStatement', 'Bank Statement')}
        {reqSwitch('requiresEmploymentContract', 'Employment Contract')}
        {reqSwitch('requiresLandlordLetter', 'Previous Landlord Letter')}
        {reqSwitch('requiresIDDocument', 'ID Document')}
      </Row>

      <Row>
        <Col xs={12}>
          <Form.Group controlId="notes">
            <Form.Label>Other Notes</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              value={value.notes}
              onChange={e => onChange({ ...value, notes: e.target.value })}
            />
          </Form.Group>
        </Col>
      </Row>
    </Form>
  );
};

/* ------------------------------------------------------------------
   STEP 3 – VIEWING (UI unchanged)
------------------------------------------------------------------ */
function ViewingStep({ value, onChange }) {
  const blank = { scheduled_date: '', start_time: '', end_time: '', location: '', notes: '' };
  const [saved, setSaved] = useState(value.viewings || []);
  const [pending, setPending] = useState(blank);

  useEffect(() => {
    setSaved(value.viewings || []);
    setPending(blank);
  }, [value.viewings]);

  useEffect(() => {
    onChange({ ...value, viewings: saved });
  }, [saved]);

  const addSlot = () => {
    if (!pending.scheduled_date) return;
    setSaved([...saved, pending]);
    setPending(blank);
  };
  const upd = (f, v) => setPending({ ...pending, [f]: v });

  return (
    <Form>
      {saved.map((s, i) => (
        <div key={i} className="mb-3 p-3 border rounded">
          <Row className="g-2">
            <Col md={3}><b>Date:</b> {s.scheduled_date}</Col>
            <Col md={3}><b>From:</b> {s.start_time}</Col>
            <Col md={3}><b>To:</b> {s.end_time}</Col>
            <Col md={3}><b>Loc:</b> {s.location}</Col>
          </Row>
          {s.notes && (
            <Row className="mt-2"><Col><em>{s.notes}</em></Col></Row>
          )}
        </div>
      ))}

      <div className="mb-3 p-3 border rounded">
        <Row className="g-3 align-items-end">
          <Col md={3}>
            <Form.Control
              type="date"
              value={pending.scheduled_date}
              onChange={e => upd('scheduled_date', e.target.value)}
            />
          </Col>
          <Col md={2}>
            <Form.Control
              type="time"
              value={pending.start_time}
              onChange={e => upd('start_time', e.target.value)}
            />
          </Col>
          <Col md={2}>
            <Form.Control
              type="time"
              value={pending.end_time}
              onChange={e => upd('end_time', e.target.value)}
            />
          </Col>
          <Col md={5}>
            <Form.Control
              placeholder="Location"
              value={pending.location}
              onChange={e => upd('location', e.target.value)}
            />
          </Col>
        </Row>
        <Row className="g-3 mt-2">
          <Col xs={12}>
            <Form.Control
              as="textarea"
              rows={2}
              placeholder="Notes (optional)"
              value={pending.notes}
              onChange={e => upd('notes', e.target.value)}
            />
          </Col>
        </Row>
      </div>

      <Button onClick={addSlot}>Add Viewing Slot</Button>
    </Form>
  );
}

/* ------------------------------------------------------------------
   STEP 4 – FAQ (UI unchanged)
------------------------------------------------------------------ */
const FaqStep = ({ value, onChange }) => {
  const [generateFAQs] = useGenerateFAQsMutation();
  const [uploadingFile, setUploadingFile] = useState(false);
  const [extractedText, setExtractedText] = useState('');
  const [generatingFaqs, setGeneratingFaqs] = useState(false);
  const [error, setError] = useState(null);
  const [faqInput, setFaqInput] = useState('');
  const [file, setFile] = useState(null);

  // Helper to download sample FAQs file
  const downloadSampleFaqs = () => {
    const sample = `Q: What is the pet policy? | A: Small pets are allowed with a deposit.\nQ: Is parking included? | A: Yes, one parking spot is included.\nQ: Are utilities included in the rent? | A: Water is included, electricity is billed separately.\nQ: Is the apartment furnished? | A: Yes, it comes fully furnished.\nQ: What is the minimum lease term? | A: 12 months.`;
    const blob = new Blob([sample], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample-faqs.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    // Set the textarea value when faqs change - format as one line Q&A pairs
    const faqText = value.faqs.map(f => `Q: ${f.question} | A: ${f.answer}`).join('\n');
    setFaqInput(faqText);
  }, [value.faqs]);

  const handleFileChange = async (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    setFile(selectedFile);

    try {
      setUploadingFile(true);
      setError(null);

      // Check file size before uploading
      if (selectedFile.size > 50 * 1024 * 1024) { // 50MB limit
        throw new Error("File too large. Please upload a document less than 50MB.");
      }

      // Extract text from file directly using FormData
      const fd = new FormData();
      fd.append('file', selectedFile);

      // Add timeout handling for OCR requests - matches property.ai.jsx
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000); // 60 second timeout

      // Use the OCR endpoint
      const ocrRes = await fetch('/ocr', {
        method: 'POST',
        headers: { Accept: 'application/json' },
        body: fd,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!ocrRes.ok) throw new Error(`OCR Service Error: ${ocrRes.status} ${await ocrRes.text()}`);

      // Check content-type to determine how to process the response
      const contentType = ocrRes.headers.get('content-type');
      let ocrData;

      if (contentType && contentType.includes('application/json')) {
        // Process as JSON
        try {
          ocrData = await ocrRes.json();
        } catch (jsonError) {
          console.error('Failed to parse JSON response:', jsonError);
          ocrData = await ocrRes.text();
        }
      } else {
        // Process as text
        ocrData = await ocrRes.text();
      }

      console.log('OCR Data:', ocrData);

      // Extract text from OCR response
      let txt;
      try {
        // More robust OCR data extraction - matches property.ai.jsx exactly
        if (typeof ocrData === 'string') {
          // If response is already plain text, use it directly
          txt = ocrData;
        } else if (ocrData.results && Array.isArray(ocrData.results) && ocrData.results.length > 0) {
          if (Array.isArray(ocrData.results[0].extracted_text)) {
            txt = ocrData.results[0].extracted_text.map(lineObj =>
              typeof lineObj === 'object' && lineObj.line ? lineObj.line : String(lineObj)
            ).join('\n');
          } else if (typeof ocrData.results[0].extracted_text === 'string') {
            txt = ocrData.results[0].extracted_text;
          }
        } else if (ocrData.text) {
          txt = ocrData.text;
        } else {
          txt = JSON.stringify(ocrData); // Fallback if structure is unknown
        }
      } catch (parseError) {
        console.error("Error parsing OCR data:", parseError);
        txt = typeof ocrData === 'string' ? ocrData : JSON.stringify(ocrData);
      }

      if (!txt || txt.trim() === '') {
        throw new Error("No text could be extracted from the document. Please try another file.");
      }

      console.log('Extracted text:', txt);
      setExtractedText(txt);

      // Generate FAQs from extracted text
      await generateFaqsFromText(txt);

    } catch (err) {
      console.error('Error processing file:', err);
      setError(err.message || "Failed to process document. Please try again.");
      toast.error(err.message || "Failed to process document");
    } finally {
      setUploadingFile(false);
    }
  };

  const generateFaqsFromText = async (text) => {
    try {
      setGeneratingFaqs(true);
      setError(null);

      const response = await generateFAQs({ extractedText: text });

      if (response.data.faqs && response.data.faqs.length > 0) {
        // Update form with generated FAQs
        onChange({
          ...value,
          faqs: response.data.faqs
        });

        // Also update the FAQ input field for better UX
        const faqText = response.data.faqs.map(f => `Q: ${f.question} | A: ${f.answer}`).join('\n');
        setFaqInput(faqText);

        toast.success('FAQs generated successfully from document');
      } else {
        // If no FAQs were generated, try generating them from property data
        if (value.property_id) {
          await generateFaqsFromProperty();
        } else {
          throw new Error('No FAQs could be generated from the document');
        }
      }
    } catch (err) {
      console.error('Error generating FAQs:', err);
      setError(err.message || "Failed to generate FAQs");
      toast.error(err.message || "Failed to generate FAQs");
    } finally {
      setGeneratingFaqs(false);
    }
  };

  const generateFaqsFromProperty = async () => {
    if (!value.property_id && !value.unit_id) {
      toast.error('Property information is required to generate FAQs');
      return;
    }

    try {
      setGeneratingFaqs(true);
      setError(null);

      const response = await generateFAQs({ propertyId: value.property_id, unitId: value.unit_id });

      if (response.data.faqs && response.data.faqs.length > 0) {
        // Update form with generated FAQs
        onChange({
          ...value,
          faqs: response.data.faqs
        });

        toast.success('FAQs generated successfully from property details');
      } else {
        throw new Error('No FAQs were generated');
      }
    } catch (err) {
      console.error('Error generating FAQs:', err);
      setError(err.message || "Failed to generate FAQs");
      toast.error(err.message || "Failed to generate FAQs");
    } finally {
      setGeneratingFaqs(false);
    }
  };

  return (
    <>
      <Form.Group className="mb-3">
        <Form.Label>FAQs (Questions and Answers for the property)</Form.Label>
        <Form.Control
          as="textarea"
          rows={4}
          value={faqInput}
          onChange={e => {
            setFaqInput(e.target.value);
            // Parse input to update FAQs array
            try {
              const text = e.target.value;
              const faqLines = text.split('\n').filter(Boolean);

              const parsedFaqs = faqLines.map((line, index) => {
                // Parse "Q: question | A: answer" format
                const parts = line.split('|');
                let question = '', answer = '';

                if (parts.length >= 2) {
                  // Format with pipe separator
                  const qPart = parts[0].trim();
                  const aPart = parts[1].trim();

                  if (qPart.startsWith('Q:')) {
                    question = qPart.substring(2).trim();
                  }

                  if (aPart.startsWith('A:')) {
                    answer = aPart.substring(2).trim();
                  }
                } else {
                  // Try to find Q: and A: in the same line without pipe
                  const qMatch = line.match(/Q:\s*([^|]+?)(?=\s*A:|$)/i);
                  const aMatch = line.match(/A:\s*(.+)$/i);

                  if (qMatch) question = qMatch[1].trim();
                  if (aMatch) answer = aMatch[1].trim();
                }

                return {
                  question,
                  answer,
                  is_active: true,
                  display_order: index
                };
              }).filter(faq => faq.question && faq.answer);

              if (parsedFaqs.length > 0) {
                onChange({
                  ...value,
                  faqs: parsedFaqs
                });
              }
            } catch (err) {
              console.error('Error parsing FAQs:', err);
            }
          }}
          placeholder="Q: What is the pet policy? | A: Small pets are allowed with a deposit.\nQ: Is parking included? | A: Yes, one parking spot is included."
        />
        <Form.Text className="text-muted">
          Enter each FAQ as "Q: question | A: answer" with one FAQ per line.
        </Form.Text>
      </Form.Group>
      <div className="d-flex gap-2 mb-2">
        <Button
          variant="outline-primary"
          onClick={generateFaqsFromProperty}
          disabled={generatingFaqs || !value.property_id}
        >
          {generatingFaqs ? 'Generating...' : 'Generate FAQs from Property'}
        </Button>
        <Button variant="outline-secondary" size="sm" onClick={downloadSampleFaqs}>
          Download Sample FAQs (.txt)
        </Button>
         
      </div>
      {/* <div className="d-flex gap-2 mb-3">
       
      </div> */}

      <Form.Group className="mt-3">
        <Form.Label>Upload Document to Generate FAQs</Form.Label>
        <div className="d-flex align-items-center">
          <Form.Control
            type="file"
            accept=".pdf,.doc,.docx,.txt,.json,.csv,.xlsx"
            onChange={handleFileChange}
            disabled={uploadingFile || generatingFaqs}
          />
          {(uploadingFile || generatingFaqs) && (
            <Spinner animation="border" size="sm" className="ms-2" />
          )}
        </div>
        <Form.Text className="text-muted">
          Upload a document with property details to automatically generate FAQs.
        </Form.Text>
      </Form.Group>

      {error && (
        <div className="alert alert-danger mt-3">{error}</div>
      )}

      {file && (
        <div className="mt-3 p-2 border rounded">
          <div className="fw-bold">{file.name}</div>
          <div className="small text-muted">{`${(file.size / 1024).toFixed(0)}KB`}</div>
        </div>
      )}

    </>
  );
};

/* ------------------------------------------------------------------
   STEP 5 – PUBLISH / SUMMARY (UI unchanged)
------------------------------------------------------------------ */
const PublishStep = ({ value }) => {
  const dash = v => (v != null && v.toString().trim()) ? v : '—';
  return (
    <Card className="border-light">
      <ListGroup variant="flush">
        {[
          ['Title', dash(value.title)],
          ['Type', dash(value.propertyType)],
          ['Rent', dash(value.price_per_month)],
          ['Deposit', value.deposit_required ? dash(value.deposit_amount) : 'No'],
          ['Available From', dash(value.available_from)],
          ['Description', dash(value.description)],
        ].map(([lab, val]) => (
          <ListGroup.Item key={lab}>
            <Row>
              <Col md={3} className="fw-semibold">{lab}:</Col>
              <Col md={9}>{val}</Col>
            </Row>
          </ListGroup.Item>
        ))}
      </ListGroup>
      <Card.Footer className="text-center border-0">
        Click <strong>{value.isEditing ? 'Update' : 'Publish'}</strong> to finish.
      </Card.Footer>
    </Card>
  );
};
