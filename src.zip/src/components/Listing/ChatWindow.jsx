import React, { useState, useRef, useEffect } from 'react';
import {
  Form,
  Button,
  Dropdown,
  ListGroup,
  Spinner
} from 'react-bootstrap';
import { FaPaperPlane, FaCalendarAlt, FaCheck, FaTimes } from 'react-icons/fa';

/* ------------------------------------------------------------------
   Chat-scrollbar CSS
------------------------------------------------------------------ */
const globalStyles = `
.chat-scrollbar {
  overflow-y: scroll;
  scrollbar-width: none;
}
.chat-scrollbar:hover {
  scrollbar-width: thin;
  scrollbar-color: #C0C0C0 #EFEFEF;
}
.chat-scrollbar::-webkit-scrollbar {
  width: 0;
  background: transparent;
}
.chat-scrollbar:hover::-webkit-scrollbar {
  width: 8px;
}
.chat-scrollbar:hover::-webkit-scrollbar-track {
  background: #EFEFEF;
  border-radius: 4px;
}
.chat-scrollbar:hover::-webkit-scrollbar-thumb {
  background-color: #C0C0C0;
  border-radius: 4px;
  border: 2px solid #EFEFEF;
}
.chat-scrollbar:hover::-webkit-scrollbar-thumb:active {
  background-color: #C0C0C0;
}

.quick-response {
  background-color: #7B5FFF;
  color: #FFF;
  border-radius: 20px;
  padding: 8px 12px;
  font-size: 0.9rem;
  cursor: pointer;
  text-align: center;
  transition: all 0.2s ease;
  border: none;
}

.quick-response:hover {
  background-color: #6a4fdd;
  transform: translateY(-2px);
  box-shadow: 0 3px 8px rgba(123, 95, 255, 0.3);
}

.message-bubble {
  padding: 10px 14px;
  border-radius: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,.1);
  line-height: 1.4;
  word-break: break-word;
  max-width: 100%;
  white-space: pre-line;
}

.message-bubble.mine {
  background-color: #7B5FFF;
  color: #FFFFFF;
}

.message-bubble.other {
  background-color: #FFFFFF;
  color: #333333;
}

.message-bubble.system {
  background-color: #EFEFEF;
  color: #333333;
}

.message-bubble.pending {
  opacity: 0.7;
}

.message-bubble.failed {
  border: 1px solid #ff5252;
}

.button-option {
  background-color: #f0f0f0;
  color: #333;
  border-radius: 12px;
  padding: 6px 10px;
  margin: 4px 0;
  font-size: 0.9rem;
  display: block;
  border: 1px solid #ddd;
}

.send-button {
  border-radius: 20px;
  padding: 8px 16px;
  background-color: #7B5FFF;
  border: none;
  font-size: 0.9rem;
  transition: all 0.2s ease;
}

.send-button:hover:not(:disabled) {
  background-color: #6a4fdd;
  transform: translateY(-2px);
  box-shadow: 0 3px 8px rgba(123, 95, 255, 0.3);
}

.send-button:disabled {
  background-color: #b3b3b3;
  cursor: not-allowed;
}
`;


// Parse message content to format buttons properly
const formatMessageContent = (message) => {
  if (!message) return '';
  
  // Check if message contains button data
  if (message.includes('__BUTTONS__')) {
    const [textPart] = message.split('__BUTTONS__');
    // Only return the main text, ignore buttons
    return textPart.trim();
  }
  
  return message;
};

/* =================================================================
   CHAT WINDOW (Updated to work with API data) 
================================================================= */
export default function ChatWindow({
  newMessages = [],
  onSend,
}) {
  const [input, setInput] = useState('');
  const containerRef = useRef(null);

  // Auto scroll to bottom when messages change
  useEffect(() => {
    const el = containerRef.current;
    if (el) {
      setTimeout(() => {
        el.scrollTop = el.scrollHeight;
      }, 50);
    }
  }, [newMessages.length]);

  // Handle message submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    onSend(input.trim());
    setInput('');
  };

  // Don't show empty conversations
  if (newMessages.length === 0) {
    return (
      <div className="d-flex flex-column justify-content-center align-items-center h-100 text-muted">
        <p>No messages yet</p>
        <p className="small">Start the conversation by sending a message</p>
      </div>
    );
  }

  return (
    <div
      className="d-flex flex-column h-100"
      style={{ fontFamily: "'Outfit', sans-serif", width: '100%' }}
    >
      <style>{globalStyles}</style>

      {/* Chat area */}
      <div
        ref={containerRef}
        className="flex-grow-1 chat-scrollbar px-3"
        style={{ maxHeight: '55vh', paddingTop: 10, paddingBottom: 10, width: '100%' }}
      >
        {/* Regular messages */}
        {newMessages && newMessages.length > 0 ? (
          (() => {
            // Group messages by date
            const messagesByDate = {};
            newMessages.forEach(message => {
              // Extract date from createdAt if available or use existing date
              const messageDate = message.message_data?.createdAt 
                ? new Date(message.message_data.createdAt).toLocaleDateString() 
                : (message.date || new Date().toLocaleDateString());
              
              if (!messagesByDate[messageDate]) {
                messagesByDate[messageDate] = [];
              }
              
              // Handle API response format or existing format
              if (message.message_data) {
                const { message_data } = message;
                messagesByDate[messageDate].push({
                  id: message_data.id,
                  msg: formatMessageContent(message_data.message),
                  sender: message.sender || 'You',
                  time: new Date(message_data.createdAt).toLocaleTimeString(undefined, {
                    hour: '2-digit',
                    minute: '2-digit'
                  }),
                  date: messageDate,
                  pending: message_data.status === 'pending',
                  failed: message_data.status === 'failed'
                });
              } else {
                messagesByDate[messageDate].push(message);
              }
            });
            
            // Get dates in order
            const dates = Object.keys(messagesByDate).sort();
            
            return dates.map(date => (
              <div key={date}>
                {/* Date header */}
                <div className="text-center my-3">
                  <span style={{
                    background: '#f0f0f0',
                    padding: '4px 10px',
                    borderRadius: '12px',
                    fontSize: '0.8rem',
                    color: '#666'
                  }}>
                    {new Date(date).toLocaleDateString(undefined, {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </span>
                </div>
                
                {/* Messages for this date */}
                {messagesByDate[date].map((m) => {
                  const isMine = m.sender === 'You';
                  const isSystem = m.sender === 'System';
                  const isPending = m.pending === true;
                  const isFailed = m.failed === true;
                  
                  let messageClasses = 'message-bubble ';
                  if (isMine) messageClasses += 'mine ';
                  else if (isSystem) messageClasses += 'system ';
                  else messageClasses += 'other ';
                  if (isPending) messageClasses += 'pending ';
                  if (isFailed) messageClasses += 'failed ';
                  
                  return (
                    <div
                      key={m.id}
                      className={`d-flex mb-2 ${isMine ? 'justify-content-end' : 'justify-content-start'}`}
                    >
                      <div
                        className="position-relative"
                        style={{
                          maxWidth: '70%',
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: isMine ? 'flex-end' : 'flex-start',
                        }}
                      >
                        {!isMine && !isSystem && (
                          <div
                            style={{
                              fontSize: '0.8rem',
                              color: '#555',
                              marginBottom: 2,
                              fontWeight: 500,
                            }}
                          >
                            {m.sender}
                          </div>
                        )}
                        <div className={messageClasses}>
                          {m.msg}
                          {isPending && (
                            <span className="ms-2">
                              <Spinner animation="border" size="sm" />
                            </span>
                          )}
                          {isFailed && (
                            <span className="ms-2 text-danger">
                              <FaTimes />
                            </span>
                          )}
                        </div>
                        <div
                          style={{
                            fontSize: '0.7rem',
                            color: '#888',
                            marginTop: 4,
                            alignSelf: isMine ? 'flex-end' : 'flex-start',
                          }}
                        >
                          {m.time || ''}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ));
          })()
        ) : (
          <div className="text-center text-muted py-3">
            No messages yet in this conversation.
          </div>
        )}
      </div>

      {/* Message input area */}
      <Form onSubmit={handleSubmit} className="d-flex px-3 pb-3">
        <Form.Control
          placeholder="Type a message…"
          value={input}
          onChange={e => setInput(e.target.value)}
          style={{
            borderRadius: 20,
            border: '1px solid #ccc',
            padding: '10px 15px',
            fontSize: '0.9rem',
          }}
        />
        <Button
          type="submit"
          variant="primary"
          className="ms-2 d-flex align-items-center send-button"
          disabled={!input.trim()}
        >
          <FaPaperPlane className="me-1" />
          Send
        </Button>
      </Form>
    </div>
  );
}
