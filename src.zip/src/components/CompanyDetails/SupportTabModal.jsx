import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';
import { useCreateSupportMessageMutation, useUploadSupportAttachmentMutation } from '../../api/company';
import { useGetS3DownloadUrlQuery, useGetS3UploadUrlMutation, useUploadFileToS3Mutation } from '../../api/uploadApi';

const statusBadge = (status) => {
  if (typeof status !== 'string') status = 'Unknown';
  const map = {
    failed: 'danger',
    pending: 'warning',
    paid: 'success',
    open: 'primary',
    resolved: 'success',
    allocated: 'info',
  };
  return (
    <span className={`badge bg-${map[status.toLowerCase()] || 'secondary'}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
};

const priorityBadge = (priority) => {
  if (typeof priority !== 'string') priority = 'Normal';
  const map = {
    low: 'secondary',
    medium: 'warning',
    high: 'danger',
    urgent: 'danger',
  };
  return (
    <span className={`badge bg-${map[priority.toLowerCase()] || 'secondary'}`}>
      {priority.charAt(0).toUpperCase() + priority.slice(1)}
    </span>
  );
};

const timeAgo = (iso) => {
  if (!iso) return 'some time ago';
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  const hrs = Math.floor(diff / 36e5);

  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(diff / 864e5)}d ago`;
};

const AttachmentItem = ({ attachment }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const { data, error, isLoading } = useGetS3DownloadUrlQuery(attachment.file_url, {
    skip: !attachment.file_url,
  });

  const getFileIcon = (mimeType) => {
    if (!mimeType) return "bi-file-earmark";
    if (mimeType.startsWith('image/')) return "bi-file-earmark-image";
    if (mimeType.startsWith('video/')) return "bi-file-earmark-play";
    if (mimeType.startsWith('audio/')) return "bi-file-earmark-music";
    if (mimeType.includes('pdf')) return "bi-file-earmark-pdf";
    if (mimeType.includes('word') || mimeType.includes('document')) return "bi-file-earmark-word";
    if (mimeType.includes('excel') || mimeType.includes('spreadsheet')) return "bi-file-earmark-excel";
    return "bi-file-earmark";
  };

  const isImage = attachment.mime_type?.startsWith('image/');

  return (
    <div className="attachment-item border rounded p-2 mb-1 bg-light">
      <div className="d-flex align-items-center">
        <i className={`bi ${getFileIcon(attachment.mime_type)} me-2 fs-5`}></i>
        <div className="flex-grow-1 text-truncate">
          <span className="small fw-medium">{attachment.file_name}</span>
          {attachment.file_size && <span className="ms-2 text-muted small">({attachment.file_size})</span>}
        </div>
        
        {isLoading ? (
          <div className="spinner-border spinner-border-sm text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        ) : error ? (
          <span className="text-danger small">Error</span>
        ) : (
          <div className="d-flex">
            {isImage && (
              <button 
                className="btn btn-sm btn-link p-0 me-2" 
                onClick={() => setIsExpanded(!isExpanded)}
                title={isExpanded ? "Collapse" : "Preview"}
              >
                <i className={`bi ${isExpanded ? "bi-arrows-angle-contract" : "bi-arrows-angle-expand"}`}></i>
              </button>
            )}
            <a 
              href={data?.data?.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="btn btn-sm btn-link p-0"
              title="Download"
            >
              <i className="bi bi-download"></i>
            </a>
          </div>
        )}
      </div>
      
      {/* Image preview if expanded */}
      {isImage && isExpanded && data?.data?.url && (
        <div className="mt-2 text-center">
          <img 
            src={data.data.url} 
            alt={attachment.file_name} 
            className="img-fluid rounded" 
            style={{ maxHeight: '200px' }} 
          />
        </div>
      )}
    </div>
  );
};

export const SupportTab = ({ data = [], isLoading: isLoadingTicketsProp }) => {
  const loggedInUser = useSelector((state) => state.auth.user);
  const [tickets, setTickets] = useState([]);
  const [activeCat, setActiveCat] = useState('open');
  const [search, setSearch] = useState('');
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [comment, setComment] = useState('');
  const [internalOnly, setInternalOnly] = useState(false);
  const [attachmentFile, setAttachmentFile] = useState(null);
  const fileInputRef = useRef(null);

  const [
    createSupportMessage,
    { isLoading: isSendingMessage, error: sendMessageError },
  ] = useCreateSupportMessageMutation();

  const [
    uploadSupportAttachment,
    { isLoading: isUploadingAttachment, error: uploadAttachmentError },
  ] = useUploadSupportAttachmentMutation();

  const [getS3UploadUrl] = useGetS3UploadUrlMutation();
  const [uploadFileToS3] = useUploadFileToS3Mutation();


  const statusOptions = ['Open', 'Resolved', 'Allocated', 'Pending'];
  const priorityOptions = ['Low', 'Medium', 'High', 'Urgent'];

  useEffect(() => {
    if (data && data.length > 0) {
      const processedTickets = data.map(ticket => ({
        ...ticket,
        messages: Array.isArray(ticket.messages) ? ticket.messages : [],
        status: ticket.status || 'Unknown', // Ensure status is a string
        priority: ticket.priority || 'Normal', // Ensure priority is a string
      }));
      setTickets(processedTickets);
      // Set activeCat to the status of the first ticket or a common default like 'open'
      const uniqueStatuses = [...new Set(processedTickets.map(t => String(t.status).toLowerCase()))]; // Ensure statuses are strings for Set
      setActiveCat(uniqueStatuses.includes('open') ? 'open' : (uniqueStatuses[0] || 'open'));
    } else {
      setTickets([]);
      setActiveCat('open'); // Default if no data
    }
  }, [data]);

  const filteredTickets = useMemo(
    () =>
      tickets
        .filter((t) => String(t.status).toLowerCase() === activeCat.toLowerCase()) // Ensure lowercase comparison
        .filter((t) =>
          t.title?.toLowerCase().includes(search.toLowerCase())
        ),
    [tickets, activeCat, search]
  );

  const handleApiError = (error, context) => {
    console.error(`API Error (${context}):`, error);
  };


  // Unified function to update ticket (for comments, status, priority)
  const updateTicketOnServer = async (ticketId, updates) => {
    if (!ticketId && !selectedTicket) return null;
    const currentTicket = selectedTicket || tickets.find(t => t.ticket_id === ticketId);
    if (!currentTicket) return null;

    const payload = {
      ticket_id: currentTicket.ticket_id,
      status: updates.status !== undefined ? updates.status : currentTicket.status,
      priority: updates.priority !== undefined ? updates.priority : currentTicket.priority,
      sender_id: loggedInUser.id,
      message: updates.message || "",
      is_internal: updates.is_internal !== undefined ? updates.is_internal : (updates.message ? internalOnly : false),
    };

    try {
      const response = await createSupportMessage(payload).unwrap();
      if (updates.status || updates.priority) {
        setTickets(prevTickets => prevTickets.map(t => t.ticket_id === currentTicket.ticket_id ? { ...t, ...updates } : t));
        if (selectedTicket?.ticket_id === currentTicket.ticket_id) {
          setSelectedTicket(s => ({ ...s, ...updates }));
        }
      }
      return response; 
    } catch (err) {
      handleApiError(err, `updating ticket with ${JSON.stringify(updates)}`);
      return null;
    }
  };


  const addComment = async () => {
    if (!comment.trim() || !selectedTicket) return;

    const messagePayload = {
      message: comment,
      is_internal: internalOnly,
      status: selectedTicket.status,
      priority: selectedTicket.priority,
    };

    const createdMessageResponse = await updateTicketOnServer(selectedTicket.ticket_id, messagePayload);

    if (createdMessageResponse) {
      const newMsgFromServer = {
        message_id: createdMessageResponse.message_id || createdMessageResponse.id || Date.now(), 
        created_at: createdMessageResponse.created_at || new Date().toISOString(),
        message: comment,
        internal: internalOnly,
        sender_id: loggedInUser.id,
      };

      setTickets((prevTickets) =>
        prevTickets.map((t) =>
          t.ticket_id === selectedTicket.ticket_id
            ? { ...t, messages: [...(t.messages || []), newMsgFromServer] }
            : t
        )
      );
      setSelectedTicket((s) => ({
        ...s,
        messages: [...(s.messages || []), newMsgFromServer],
      }));

      // Handle attachment upload if a file is selected and message was created with a backend ID
      if (attachmentFile && newMsgFromServer.message_id && newMsgFromServer.message_id !== Date.now()) {
        // Step 1: Request a signed S3 URL
        const s3Response = await getS3UploadUrl({
          key: `uploads/tickets-${selectedTicket.ticket_id}/${newMsgFromServer.message_id}_${attachmentFile.name}`,
          fileType: attachmentFile.type,
          fileName: attachmentFile.name,
        }).unwrap();

        // Step 2: Upload the file to S3
        await uploadFileToS3({
          uploadUrl: s3Response.data.url,
          file: attachmentFile,
        }).unwrap();

        // Step 3: Register the uploaded file in your system
        const attachmentPayload = {
          action: 'insert',
          ticket_id: selectedTicket.ticket_id,
          message_id: newMsgFromServer.message_id,
          file_name: attachmentFile.name,
          file_url: s3Response.data.key,
          file_size: `${(attachmentFile.size / 1024).toFixed(0)}KB`,
          mime_type: attachmentFile.type,
        };

        try {
          await uploadSupportAttachment(attachmentPayload).unwrap();
          console.log('Attachment uploaded successfully');
        } catch (err) {
          handleApiError(err, 'uploading attachment');
        }
      }

      setComment('');
      setInternalOnly(false);
      setAttachmentFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const changeStatus = async (newStatus) => {
    if (!selectedTicket || selectedTicket.status === newStatus) return;
    await updateTicketOnServer(selectedTicket.ticket_id, { status: newStatus, message: `Status changed to ${newStatus}` });
  };

  const changePriority = async (newPriority) => {
    if (!selectedTicket || selectedTicket.priority === newPriority) return;
    await updateTicketOnServer(selectedTicket.ticket_id, { priority: newPriority, message: `Priority changed to ${newPriority}` });
  };


  const closeModal = () => {
    setSelectedTicket(null);
    setInternalOnly(false);
    setAttachmentFile(null);
    setComment('');
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  if (isLoadingTicketsProp && !tickets.length) {
    return <div className="text-center py-4"><div className="spinner-border text-primary" role="status"><span className="visually-hidden">Loading tickets...</span></div></div>;
  }

  return (
    <>
      <div className="pt-3">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h5 className="mb-0">Tickets</h5>
        </div>
        <ul className="nav nav-tabs">
          {[...new Set(tickets.map((t) => String(t.status).toLowerCase()))]
            .sort()
            .map((cat) => (
              <li className="nav-item" key={cat}>
                <button
                  className={`nav-link text-capitalize ${activeCat.toLowerCase() === cat ? ' active' : ''}`}
                  onClick={() => setActiveCat(cat)}
                >
                  {cat}
                </button>
              </li>
            ))}
          {tickets.length === 0 && !isLoadingTicketsProp && (
            <li className="nav-item">
              <button className={`nav-link ${activeCat === 'open' ? 'active' : ''}`} onClick={() => setActiveCat('open')}>Open</button>
            </li>
          )}
        </ul>

        <input
          className="form-control my-3"
          placeholder="Search tickets by title…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <div className="list-group">
          {filteredTickets.length > 0 ? (
            filteredTickets.map((t) => (
              <button
                key={t.ticket_id}
                className="list-group-item list-group-item-action d-flex justify-content-between align-items-center"
                onClick={() => setSelectedTicket(t)}
              >
                <div>
                  <div className="fw-bold mb-1">{t.title} <small className="text-muted">#{t.ticket_id}</small></div>
                  <small className="text-muted me-2">
                    {(t.messages || []).length} comment{((t.messages || []).length) !== 1 && 's'}
                  </small>
                  {statusBadge(t.status)}
                  <span className="ms-1">{priorityBadge(t.priority)}</span>
                </div>
                <small className="text-muted">{timeAgo(t.created_at)}</small>
              </button>
            ))
          ) : (
            <div className="text-center text-muted py-4">
              {isLoadingTicketsProp ? 'Loading...' : `No ${activeCat} tickets found${search ? ' matching your search' : ''}.`}
            </div>
          )}
        </div>
      </div>

      {selectedTicket && (
        <>
          <div className="modal-backdrop fade show" onClick={closeModal} />
          <div className="modal fade show d-block" role="dialog" style={{ display: 'block' }} aria-labelledby="ticketModalLabel" aria-hidden={!selectedTicket}>
            <div className="modal-dialog modal-dialog-centered modal-lg" style={{ maxWidth: '700px' }}>
              <div className="modal-content" style={{ minHeight: '600px' }}>
                <div className="modal-header">
                  <h5 className="modal-title" id="ticketModalLabel">
                    Ticket #{selectedTicket.ticket_id}: {selectedTicket.title}
                  </h5>
                  <button type="button" className="btn-close" onClick={closeModal} aria-label="Close" />
                </div>

                <div className="modal-body">
                  <div className="d-flex flex-wrap align-items-center mb-3">
                    <strong className="me-2 mb-2 mb-md-0">Status:</strong>
                    <div className="dropdown me-md-3 mb-2 mb-md-0">
                      <button
                        className="btn btn-outline-secondary dropdown-toggle btn-sm text-capitalize"
                        type="button"
                        id="dropdownMenuButtonStatus"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                        disabled={isSendingMessage}
                      >
                        {selectedTicket.status}
                      </button>
                      <ul className="dropdown-menu" aria-labelledby="dropdownMenuButtonStatus">
                        {statusOptions.map((opt) => (
                          <li key={opt}>
                            <button
                              className={`dropdown-item text-capitalize ${selectedTicket.status.toLowerCase() === opt.toLowerCase() ? 'active' : ''}`}
                              onClick={() => changeStatus(opt)}
                              disabled={isSendingMessage}
                            >
                              {opt}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <strong className="me-2 mb-2 mb-md-0">Priority:</strong>
                    <div className="dropdown mb-2 mb-md-0">
                      <button
                        className="btn btn-outline-secondary dropdown-toggle btn-sm text-capitalize"
                        type="button"
                        id="dropdownMenuButtonPriority"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                        disabled={isSendingMessage}
                      >
                        {selectedTicket.priority}
                      </button>
                      <ul className="dropdown-menu" aria-labelledby="dropdownMenuButtonPriority">
                        {priorityOptions.map((opt) => (
                          <li key={opt}>
                            <button
                              className={`dropdown-item text-capitalize ${selectedTicket.priority.toLowerCase() === opt.toLowerCase() ? 'active' : ''}`}
                              onClick={() => changePriority(opt)}
                              disabled={isSendingMessage}
                            >
                              {opt}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  <hr />

                  <h6>Comments</h6>
                  <div className="mb-3" style={{ maxHeight: '250px', overflowY: 'auto', border: '1px solid #eee', padding: '10px', borderRadius: '4px' }}>
                    {(selectedTicket.messages || []).length > 0 ? (selectedTicket.messages || []).map((m) => (
                      <div key={m.message_id || m.created_at} className="mb-2 pb-2 border-bottom">
                        <div className="small text-muted d-flex justify-content-between">
                          <span>
                            <strong>User {m.sender_id || loggedInUser.id}</strong> - {new Date(m.created_at).toLocaleString()}
                          </span>
                          {m.internal && (
                            <span className="badge bg-info ms-2">Internal</span>
                          )}
                        </div>
                        <div className="mt-1" style={{ whiteSpace: "pre-wrap" }}>{m.message}</div>
                        
                        {/* Display attachments if present */}
                        {m.attachments && m.attachments.length > 0 && (
                          <div className="mt-2">
                            {m.attachments.map((attachment, index) => (
                              <AttachmentItem 
                                key={index} 
                                attachment={attachment} 
                                ticketId={selectedTicket.ticket_id} 
                                messageId={m.message_id} 
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    )) : <p className="text-muted fst-italic">No comments yet.</p>}
                  </div>

                  <h6>Add Comment</h6>
                  <form onSubmit={(e) => { e.preventDefault(); addComment(); }}>
                    <textarea
                      className="form-control mb-2"
                      rows="3"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      disabled={isSendingMessage || isUploadingAttachment}
                      placeholder="Type your comment here..."
                    />
                    <div className="d-flex justify-content-between align-items-center mt-2">
                      <div>
                        <input
                          type="file"
                          id={`fileInput-${selectedTicket.ticket_id}`}
                          style={{ display: 'none' }}
                          onChange={(e) => {
                            if (e.target.files && e.target.files.length > 0) {
                              setAttachmentFile(e.target.files[0]);
                            } else {
                              setAttachmentFile(null);
                            }
                          }}
                          ref={fileInputRef}
                        />
                        <label
                          htmlFor={`fileInput-${selectedTicket.ticket_id}`}
                          className={`btn btn-sm mb-0 ${attachmentFile ? 'btn-success' : 'btn-outline-secondary'}`}
                        >
                          <i className="bi bi-paperclip"></i> {attachmentFile ? attachmentFile.name : 'Attach file'}
                        </label>
                        {attachmentFile && (
                          <button
                            type="button"
                            className="btn btn-sm btn-link text-danger p-0 ms-2"
                            onClick={() => {
                              setAttachmentFile(null);
                              if (fileInputRef.current) fileInputRef.current.value = "";
                            }}
                            title="Remove attachment"
                          >
                            <i className="bi bi-x-circle"></i>
                          </button>
                        )}
                      </div>
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id={`internalCheck-${selectedTicket.ticket_id}`}
                          checked={internalOnly}
                          onChange={() => setInternalOnly((v) => !v)}
                          disabled={isSendingMessage || isUploadingAttachment}
                        />
                        <label className="form-check-label" htmlFor={`internalCheck-${selectedTicket.ticket_id}`}>
                          Internal
                        </label>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="btn btn-primary mt-3"
                      disabled={isSendingMessage || isUploadingAttachment || !comment.trim()}
                    >
                      {isSendingMessage ? 'Sending Comment…' : (isUploadingAttachment ? 'Uploading File...' : 'Add Comment')}
                    </button>
                    {(sendMessageError || uploadAttachmentError) && (
                      <div className="alert alert-danger mt-2 small p-2">
                        {sendMessageError && `Failed to send comment: ${sendMessageError.data?.message || sendMessageError.status}`}
                        {uploadAttachmentError && `Failed to upload attachment: ${uploadAttachmentError.data?.message || uploadAttachmentError.status}`}
                      </div>
                    )}
                  </form>
                </div>

                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={closeModal}
                  >
                    Done
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};

