// DocumentTabModal.jsx (Updated)
import React, { useState, useMemo } from 'react';

const statusBadge = (status) => {
  const map = {
    failed: 'danger',
    pending: 'warning',
    paid: 'success',
    open: 'primary',
    resolved: 'success',
    allocated: 'info'
  };
  return <span className={`badge bg-${map[status.toLowerCase()] || 'secondary'}`}>{status}</span>;
};

export const TransactionTable = ({ data = [] }) => {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(null);
  const perPage = 10;

  const filtered = useMemo(() => {
    if (!search.trim()) return data;
    const q = search.toLowerCase();
    return data.filter(
      (tx) =>
        tx.description?.toLowerCase().includes(q) ||
        String(tx.amount)?.includes(q) ||
        tx.created_at?.includes(q) ||
        tx.payment_status?.toLowerCase().includes(q)
    );
  }, [search, data]);

  const paginated = filtered.slice((page - 1) * perPage, page * perPage);
  const pageCount = Math.ceil(filtered.length / perPage);

  const formatDate = (iso) =>
    new Date(iso).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

  const closeModal = () => setSelected(null);

  return (
    <>
      <div className="pt-3">
        <h5 className="mb-3">Transactions</h5>
        <input
          className="form-control mb-3"
          placeholder="Search transactions…"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
        />
        <div style={{ overflowX: 'auto' }}>
          <table className="table table-hover align-middle">
            <thead className="table-light">
              <tr>
                <th style={{ width: '140px' }}>Invoice Date</th>
                <th>Description</th>
                <th style={{ width: '100px' }}>Amount</th>
                <th style={{ width: '150px' }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {paginated.length ? (
                paginated.map((tx, i) => (
                  <tr key={tx.invoice_id} className={i % 2 ? 'table-active' : ''}>
                    <td>{formatDate(tx.created_at)}</td>
                    <td>
                      <button className="btn btn-link p-0" onClick={() => setSelected(tx)}>
                        {tx.description}
                      </button>
                    </td>
                    <td>${tx.amount}</td>
                    <td>{statusBadge(tx.payment_status)}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="text-center py-4">No matching transactions.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {pageCount > 1 && (
          <nav>
            <ul className="pagination">
              <li className={`page-item${page === 1 ? ' disabled' : ''}`}>
                <button className="page-link" onClick={() => setPage((p) => Math.max(p - 1, 1))}>‹ Prev</button>
              </li>
              {[...Array(pageCount)].map((_, idx) => (
                <li key={idx+1} className={`page-item${page === idx+1 ? ' active' : ''}`}>
                  <button className="page-link" onClick={() => setPage(idx+1)}>{idx+1}</button>
                </li>
              ))}
              <li className={`page-item${page === pageCount ? ' disabled' : ''}`}>
                <button className="page-link" onClick={() => setPage((p) => Math.min(p + 1, pageCount))}>Next ›</button>
              </li>
            </ul>
          </nav>
        )}
      </div>

      {selected && (
        <>
          <div className="modal-backdrop fade show" onClick={closeModal}/>
          <div className="modal fade show d-block" role="dialog">
            <div className="modal-dialog modal-dialog-centered" style={{ maxWidth: '520px', width: '100%' }}>
              <div className="modal-content" style={{ minHeight: '600px' }}>
                <div className="modal-header">
                  <h5 className="modal-title">Invoice #{selected.invoice_id}</h5>
                  <button className="btn-close" onClick={closeModal}/>
                </div>
                <div className="modal-body">
                  <p><strong>Description:</strong> {selected.description}</p>
                  <p><strong>Invoice Date:</strong> {formatDate(selected.created_at)}</p>
                  <p><strong>Amount:</strong> ${selected.amount}</p>
                  <p><strong>Status:</strong> {statusBadge(selected.payment_status)}</p>
                </div>
                <div className="modal-footer">
                  <button className="btn btn-secondary" onClick={closeModal}>Close</button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};

