import React from "react";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";

export const Footer = () => {
    const company = useSelector(state => state?.company);
    const copyright = company?.copyright || 'Propfinda';
    const currentYear = new Date().getFullYear();
    const location = useLocation();
    
    // Hide footer on specific pages
    const hideFooterPaths = ['/properties', '/contacts'];
    const shouldHideFooter = hideFooterPaths.some(path => location.pathname.includes(path));
    
    if (shouldHideFooter) {
        return null; // Don't render footer on specified pages
    }

    return (
        <footer className="footer">
            <div className="footer-copyright">
                <span>&copy; {currentYear} {copyright}. All rights reserved.</span>
            </div>

            <div className="footer-links">
                <a href="/terms" className="footer-link">Terms</a>
                <a href="/privacy" className="footer-link">Privacy</a>
                <a href="/help" className="footer-link">Help</a>
                <span className="footer-version">v1.2.0</span>
            </div>
        </footer>
    );
};
