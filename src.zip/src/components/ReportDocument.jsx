import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FiCalendar } from 'react-icons/fi';

export default function ReportDocument({ data, dateRange, filters }) {
  // Debug logger
  useEffect(() => {
    console.log('ReportDocument data:', data);
  }, [data]);

  // State
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [selectedYear, setSelectedYear] = useState('');
  const [predefined, setPredefined] = useState('');
  const [prompt, setPrompt] = useState('');
  const [moreFilters, setMoreFilters] = useState(false);
  const [filterValues, setFilterValues] = useState({
    owner: '',
    property: '',
    unit: '',
    tenant: '',
  });
  const [searchValue, setSearchValue] = useState('');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Helper to truncate long text
  const truncate = (text, max = 40) =>
    text.length > max ? text.slice(0, max) + '...' : text;

  // Options & sample data
  const predefinedOptions = [
    { value: '', label: 'Select report' },
    { value: 'ai-report', label: 'AI Report' },
    { value: 'financial', label: 'Financial Summary' },
    { value: 'occupancy', label: 'Occupancy Report' },
  ];
  const yearOptions = ['2022', '2023', '2024', '2025'];
  const previousReports = [
    {
      id: 1,
      name: 'Financial Summary – May',
      from: '2025-05-01',
      to: '2025-05-31',
      description: 'Monthly revenue and expense overview',
      url: '#',
    },
    {
      id: 2,
      name: 'Tenant AI Insights',
      from: '2025-06-01',
      to: '2025-06-15',
      description: 'Deep dive into tenant behavior with AI',
      url: '#',
    },
    {
      id: 3,
      name: 'Occupancy Q2',
      from: '2025-04-01',
      to: '2025-06-30',
      description: 'Quarterly occupancy analysis across units',
      url: '#',
    },
    
    // …add more data as needed to see pagination in action
  ];

  // Handlers
  const handleGenerate = () => {
    console.log('Generate clicked', {
      fromDate,
      toDate,
      selectedYear,
      predefined,
      prompt,
      filters: { ...filters, ...filterValues },
    });
    // TODO: integrate generation API
  };

  // Inline styles
  const styles = {
    page: {
      backgroundColor: 'transparent',
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'flex-start',
      padding: 0,
      height: '100%',
      margin: 0,
    },
    card: {
      backgroundColor: '#fff',
      borderRadius: 8,
      boxShadow: '0 8px 16px rgba(0,0,0,0.1)',
      width: '100%',
      height: '100%',
      padding: '1.5rem',
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
      overflowY: 'auto',
      margin: 0,
    },
    title: {
      fontSize: '1.75rem',
      fontWeight: 700,
      margin: 0,
    },
    row: {
      display: 'flex',
      gap: '1rem',
      alignItems: 'flex-end',
    },
    field: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.25rem',
      flex: 1,
    },
    label: {
      fontWeight: 600,
    },
    input: {
      border: '1px solid #d1d5db',
      borderRadius: 6,
      padding: '0.5rem 0.75rem',
      fontSize: '1rem',
      width: '100%',
      boxSizing: 'border-box',
    },
    dateWrapper: {
      position: 'relative',
    },
    icon: {
      position: 'absolute',
      right: '0.75rem',
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: '#6b7280',
    },
    button: {
      backgroundColor: '#3b82f6',
      color: '#fff',
      padding: '0.75rem',
      fontSize: '1rem',
      border: 'none',
      borderRadius: 6,
      cursor: 'pointer',
      transition: 'background 0.2s',
      width: '100%',
    },
    moreToggle: {
      background: 'none',
      border: 'none',
      color: '#3b82f6',
      fontWeight: 600,
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: '0.25rem',
      padding: 0,
    },
    filtersGrid: {
      marginTop: '0.75rem',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '0.75rem',
    },
    searchWrapper: {
      margin: '0.5rem 0',
    },
    tableWrapper: {
      overflowX: 'auto',
      borderRadius: 6,
      border: '1px solid #e5e7eb',
      flexGrow: 1,
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
      textAlign: 'left',
      fontSize: '0.875rem',
    },
    th: {
      backgroundColor: '#f9fafb',
      padding: '0.5rem 0.75rem',
      fontWeight: 600,
      borderBottom: '1px solid #e5e7eb',
    },
    td: {
      padding: '0.5rem 0.75rem',
      borderBottom: '1px solid #e5e7eb',
    },
    downloadLink: {
      color: '#3b82f6',
      textDecoration: 'none',
      fontSize: '1.25rem',
    },
    paginationContainer: {
      display: 'flex',
      justifyContent: 'flex-end',
      alignItems: 'center',
      gap: '0.5rem',
      marginTop: '0.75rem',
    },
    pageButton: {
      border: '1px solid #d1d5db',
      borderRadius: 4,
      background: '#fff',
      padding: '0.25rem 0.5rem',
      cursor: 'pointer',
    },
    activePageButton: {
      background: '#3b82f6',
      color: '#fff',
      borderColor: '#3b82f6',
    },
  };

  // Filtered list
  const filtered = previousReports.filter(
    (r) =>
      r.name.toLowerCase().includes(searchValue.toLowerCase()) ||
      r.description.toLowerCase().includes(searchValue.toLowerCase())
  );

  // Pagination logic
  const totalPages = Math.ceil(filtered.length / itemsPerPage);
  const startIdx = (currentPage - 1) * itemsPerPage;
  const paginated = filtered.slice(startIdx, startIdx + itemsPerPage);

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h1 style={styles.title}>Create Report</h1>

        {/* Date From / To / Year */}
        <div style={styles.row}>
          <div style={styles.field}>
            <label style={styles.label}>Date From</label>
            <div style={styles.dateWrapper}>
              <DatePicker
                selected={fromDate}
                onChange={setFromDate}
                placeholderText="Start date"
                customInput={<input style={styles.input} />}
              />
              <FiCalendar style={styles.icon} />
            </div>
          </div>
          <div style={styles.field}>
            <label style={styles.label}>Date To</label>
            <div style={styles.dateWrapper}>
              <DatePicker
                selected={toDate}
                onChange={setToDate}
                placeholderText="End date"
                customInput={<input style={styles.input} />}
              />
              <FiCalendar style={styles.icon} />
            </div>
          </div>
          <div style={styles.field}>
            <label style={styles.label}>Year</label>
            <select
              style={styles.input}
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
            >
              <option value="">Select year</option>
              {yearOptions.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Predefined Report */}
        <div style={styles.field}>
          <label style={styles.label}>Predefined Report</label>
          <select
            style={styles.input}
            value={predefined}
            onChange={(e) => setPredefined(e.target.value)}
          >
            {predefinedOptions.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        </div>

        {/* AI Prompt */}
        {predefined === 'ai-report' && (
          <div style={styles.field}>
            <label style={styles.label}>AI Prompt</label>
            <input
              type="text"
              style={styles.input}
              placeholder="Enter your prompt..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
          </div>
        )}

        {/* More Filters */}
        <div>
          <button
            style={styles.moreToggle}
            onClick={() => setMoreFilters(!moreFilters)}
          >
            {moreFilters ? '▾' : '▸'} More Filters
          </button>
          {moreFilters && (
            <div style={styles.filtersGrid}>
              {['owner', 'property', 'unit', 'tenant'].map((key) => (
                <input
                  key={key}
                  type="text"
                  style={styles.input}
                  placeholder={key.charAt(0).toUpperCase() + key.slice(1)}
                  value={filterValues[key]}
                  onChange={(e) =>
                    setFilterValues((prev) => ({
                      ...prev,
                      [key]: e.target.value,
                    }))
                  }
                />
              ))}
            </div>
          )}
        </div>

        {/* Generate Button */}
        <button
          style={styles.button}
          onClick={handleGenerate}
          onMouseEnter={(e) =>
            (e.currentTarget.style.backgroundColor = '#2563eb')
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.backgroundColor = '#3b82f6')
          }
        >
          Generate
        </button>

        {/* Search Bar */}
        <div style={styles.searchWrapper}>
          <input
            type="text"
            style={styles.input}
            placeholder="Search reports..."
            value={searchValue}
            onChange={(e) => {
              setSearchValue(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>

        {/* Previous Reports Table */}
        <div style={{ flexGrow: 1 }}>
          <h2 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 600 }}>
            Previous Reports
          </h2>
          <div style={styles.tableWrapper}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Report Name</th>
                  <th style={styles.th}>Date Range</th>
                  <th style={styles.th}></th>
                  <th style={styles.th}>Description</th>
                  <th style={styles.th}></th>
                </tr>
              </thead>
              <tbody>
                {paginated.map((r) => (
                  <tr key={r.id}>
                    <td style={styles.td}>{r.name}</td>
                    <td style={styles.td}>{r.from}</td>
                    <td style={styles.td}>{r.to}</td>
                    <td style={styles.td}>{truncate(r.description)}</td>
                    <td style={styles.td}>
                      <a href={r.url} download style={styles.downloadLink}>
                        ⬇
                      </a>
                    </td>
                  </tr>
                ))}
                {paginated.length === 0 && (
                  <tr>
                    <td style={styles.td} colSpan={5}>
                      No reports found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination footer right */}
          {totalPages > 1 && (
            <div style={styles.paginationContainer}>
              <button
                style={styles.pageButton}
                onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                disabled={currentPage === 1}
              >
                Prev
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <button
                    key={page}
                    style={{
                      ...styles.pageButton,
                      ...(page === currentPage
                        ? styles.activePageButton
                        : {}),
                    }}
                    onClick={() => setCurrentPage(page)}
                    disabled={page === currentPage}
                  >
                    {page}
                  </button>
                )
              )}
              <button
                style={styles.pageButton}
                onClick={() =>
                  setCurrentPage((p) => Math.min(p + 1, totalPages))
                }
                disabled={currentPage === totalPages}
              >
                Next
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

ReportDocument.propTypes = {
  data: PropTypes.any,
  dateRange: PropTypes.string,
  filters: PropTypes.object,
};

ReportDocument.defaultProps = {
  data: {},
  dateRange: '',
  filters: {},
};
