// ─────────────────────────────────────────────────────────────
// src/components/Transaction/UploadModal.jsx   (Merged Version)
// ─────────────────────────────────────────────────────────────
import React, { useEffect, useMemo, useRef, useState } from 'react'
import {
  useImportTransactionMutation,
  useManageTransactionMutation,
} from '../../api/owner'

/* -------------------------------------------------------------------------- */
/*                                ENV / CONSTS                                */
/* -------------------------------------------------------------------------- */
const DEEPSEEK_KEY   = 'sk-faadc59472ec4c5180e66baa69ec3bab'
const DEEPSEEK_MODEL = 'deepseek-chat'

const defaultCategories = ['Utilities', 'Salary', 'Shopping', 'Rent', 'Misc']

export default function UploadModal() {
  /* ---------------------------- LOCAL STATE ----------------------------- */
  const [transactions, setTransactions]   = useState([])       // pristine DB snapshot
  const [rows,          setRows]          = useState([])       // grid (editable)
  const [selectedRows,  setSelectedRows]  = useState(new Set())
  const [ownerFilter,   setOwnerFilter]   = useState('')
  const [fileFilter,    setFileFilter]    = useState('')

  /* column search filters */
  const [colFilters, setColFilters]       = useState({
    date:'', desc:'', cat:'', ref:'', type:''
  })

  const [categories,      setCategories]      = useState(defaultCategories)
  const [selectedFiles,   setSelectedFiles]   = useState([])
  const [loading,         setLoading]         = useState(false)
  const [importDone,      setImportDone]      = useState(false)
  const [analysisText,    setAnalysisText]    = useState('')
  const [rawText,         setRawText]         = useState('')
  const [csvUrl,          setCsvUrl]          = useState(null)
  const [summaries,       setSummaries]       = useState([])
  const [error,           setError]           = useState(null)
  const [showDeleteModal, setShowDeleteModal] = useState(false)

  const fileInputRef = useRef(null)
  const newRowIdRef  = useRef(-1)   // negative IDs for newly-added rows

  /* ------------------------- RTK-QUERY hooks --------------------------- */
  const [
    importTransaction,
    { isError: importError, error: importErr },
  ] = useImportTransactionMutation()

  const [
    manageTransaction,
    { data: manageData, isError: manageError, error: manageErr },
  ] = useManageTransactionMutation()

  /* -------------------------------------------------------------------- */
  /*                      LOAD EXISTING TRANSACTIONS                      */
  /* -------------------------------------------------------------------- */
  useEffect(() => {
    const $modal = window.$('#uploadModal')
    if (!$modal.length) return

    const onShow = () =>
      manageTransaction({
        action:'get_transaction_document',
      })

    $modal.on('show.bs.modal', onShow)
    return () => $modal.off('show.bs.modal', onShow)
  }, [manageTransaction])

  /* snapshot → rows ----------------------------------------------------- */
  useEffect(() => {
    if (!Array.isArray(manageData)) return
    setTransactions(manageData)
    setRows(manageData.map(tx => ({
      id:          tx.id,
      line_id:     tx.line_id ?? null,
      txn_date:    tx.txn_date || '',
      description: tx.description || '',
      category:    tx.category    || '',
      reference:   tx.reference   || '',
      type:        parseFloat(tx.money_in||'0')>0 ? 'Credited':'Debited',
      amount:      (parseFloat(tx.money_in)||parseFloat(tx.money_out)||0).toFixed(2),
      parent_id:   tx.parent_id,
      document_id: tx.document_id,
      file_name:   tx.file_name,
      deleted:     tx.deleted || false,
    })))
  }, [manageData])

  /* keep categories in sync -------------------------------------------- */
  useEffect(() => {
    const s = new Set(defaultCategories)
    rows.forEach(r => r.category && s.add(r.category))
    setCategories([...s])
  }, [rows])

  /* -------------------------------------------------------------------- */
  /*                         FILTER & DATALISTS                           */
  /* -------------------------------------------------------------------- */
  const visibleRows = useMemo(() =>
    rows
      .filter(r=>!r.deleted)
      .filter(r=>
        (!ownerFilter || String(r.parent_id)  === ownerFilter) &&
        (!fileFilter  || String(r.document_id)=== fileFilter)  &&
        (!colFilters.date || (r.txn_date||'').includes(colFilters.date)) &&
        (!colFilters.desc || (r.description||'').toLowerCase().includes(colFilters.desc.toLowerCase())) &&
        (!colFilters.cat  || (r.category||'').toLowerCase().includes(colFilters.cat.toLowerCase())) &&
        (!colFilters.ref  || (r.reference||'').toLowerCase().includes(colFilters.ref.toLowerCase())) &&
        (!colFilters.type || (r.type||'').toLowerCase().includes(colFilters.type.toLowerCase()))
      ),
  [rows, ownerFilter, fileFilter, colFilters])

  const filterOptions = useMemo(() => {
    const o = { date:new Set(), desc:new Set(), cat:new Set(), ref:new Set(), type:new Set() }
    rows.filter(r=>!r.deleted).forEach(r=>{
      o.date.add(r.txn_date);       o.desc.add(r.description)
      o.cat.add(r.category);        o.ref.add(r.reference)
      o.type.add(r.type)
    })
    return Object.fromEntries(
      Object.entries(o).map(([k,s])=>[k,[...s].filter(Boolean).sort()])
    )
  }, [rows])

  /* -------------------------------------------------------------------- */
  /*                     SELECT / DELETE / ADD ROW                        */
  /* -------------------------------------------------------------------- */
  const allSelected = visibleRows.length>0 && visibleRows.every(r=>selectedRows.has(r.id))
  const toggleSelectAll = () =>
    setSelectedRows(allSelected?new Set():new Set(visibleRows.map(r=>r.id)))
  const handleRowSelect = id =>
    setSelectedRows(prev=>{const n=new Set(prev);n.has(id)?n.delete(id):n.add(id);return n})

  const confirmDelete = () => selectedRows.size && setShowDeleteModal(true)
  const cancelDelete  = () => setShowDeleteModal(false)

  const doDelete = async () => {
    setShowDeleteModal(false); setLoading(true); setError(null)
    try {
      await manageTransaction({
        action:'delete_transaction',
        ids:[...selectedRows],
      }).unwrap()
      setRows(rows.map(r=>selectedRows.has(r.id)?{...r,deleted:true}:r))
      setSelectedRows(new Set())
    } catch(e){ setError(e?.message||String(e)) }
    finally { setLoading(false) }
  }

  const addRowAtTop = () =>
    setRows([{id:newRowIdRef.current--,line_id:null,txn_date:'',description:'',
              category:'',reference:'',type:'Credited',amount:'',
              document_id:null,deleted:false},
             ...rows])

  /* -------------------------------------------------------------------- */
  /*                       OCR  /  LLM  HELPERS                           */
  /* -------------------------------------------------------------------- */
  const errorToString = e =>
    typeof e==='string' ? e : e?.message ? e.message : JSON.stringify(e,null,2)

  async function extractText(file){
    const fd=new FormData(); fd.append('file',file)
    const res=await fetch('/ocr',{method:'POST',body:fd})
    if(!res.ok) throw new Error(`OCR error ${res.status}`)
    const ct=res.headers.get('content-type')||''
    if(ct.includes('json')){
      const j=await res.json()
      const ext=j.results?.[0]?.extracted_text
      return Array.isArray(ext)? ext.map(l=>l.line||l).join('\n')
                               : String(ext||j.text||'')
    }
    return res.text()
  }

  async function deepSeekChat(messages){
    const res=await fetch('https://api.deepseek.com/chat/completions',{
      method:'POST',
      headers:{
        'Content-Type':'application/json',
        Authorization:`Bearer ${DEEPSEEK_KEY}`
      },
      body:JSON.stringify({model:DEEPSEEK_MODEL,messages})
    })
    if(!res.ok){
      let err=`DeepSeek error ${res.status}`
      try{ const j=await res.json(); err=j.error?.message||err }catch{}
      throw new Error(err)
    }
    const j=await res.json()
    return j.choices?.[0]?.message?.content||''
  }

  const padLine=a=>{while(a.length<8)a.push('');return a.slice(0,8)}
  const guessReference=d=>{
    const t=d.match(/\b[A-Z0-9]{6,}\b/i); if(t) return t[0]
    const w=d.match(/\b([A-Z][a-z]+)\b/g)
    return w&&w.length>=2?`${w[0]} ${w[1]}`:''
  }
  const normaliseLines=txt=>txt.split(/\r?\n/)
    .map(raw=>{
      const p=padLine(raw.trim().split('|').map(s=>s.trim()))
      if(!p[3]) p[3]=guessReference(p[2])
      return p.join('|')
    })
    .filter(Boolean)
    .join('\n')

  async function classifyAndNormalize(txt){
    const prompt=`You are a bank-statement parser. Output **EXACTLY 8 fields per line**, separated by a single " | " (pipe) character:

1) Money In   — numeric with two decimals, no commas. If deposit / salary / income, wages, put it here.  
   it must never been 0. that not <= 0 look for deposits, salary, income, wages, and amount that could be associated with it 
   excample PAYMENT [01] WAGES 0.00 0.00 2,145.83 4,584.71 the amount is 2,145.83 because
2) Money Out  — numeric with two decimals, no commas. Use for withdrawals / purchases / fees.  
3) Description — verbatim from statement (do not alter casing or punctuation).  
4) Reference   — first alphanumeric ID (≥6 chars) *or* the name of the person / company / place.  
5) Date        — YYYY-MM-DD.  
6) Category    — one of: Shopping, Salary, Utilities, Fees, Deposit, Withdrawal, Food, Transport, Entertainment, Rent, Loan, Debit Order, Uncategorized.  
7) Recurring   — true if obviously monthly (wages, subscriptions, account fees); otherwise false.
8) from the data identify the type of document, Bank statement, Invoices , Receipts , Statement of Account, Credit Notes, Debit Notes, General Ledger, Tax Returns, Balance Sheet, Unknown
**Always produce exactly six “ | ” delimiters (8 columns) per line**:

MoneyIn|MoneyOut|Description|Reference|YYYY-MM-DD|Category|Recurring|DocumentType

Return *plain text only* – no markdown, no headings, no extra commentary.`
    const ai=await deepSeekChat([
      {role:'system',content:prompt},
      {role:'user',content:txt},
    ])
    return normaliseLines(ai.trim())
  }

  /* -------------------------------------------------------------------- */
  /*                            CSV BUILD                                 */
  /* -------------------------------------------------------------------- */
  useEffect(() => {
    if (!rows.length){ setCsvUrl(null); return }
    const header = 'Date,Description,Category,Reference,MoneyIn,MoneyOut,Recurring,DocumentType'
    const body   = rows.map(r=>{
      const moneyIn  = r.type==='Credited'?r.amount:''
      const moneyOut = r.type==='Debited' ?r.amount:''
      return [
        r.txn_date, r.description, r.category, r.reference,
        moneyIn, moneyOut, r.recurring||'', r.document_type||'',
      ].map(v=>String(v).includes(',')||String(v).includes('"')
              ? `"${String(v).replace(/"/g,'""')}"`
              : v)
       .join(',')
    })
    setCsvUrl(URL.createObjectURL(new Blob([[header,...body].join('\n')],{type:'text/csv'})))
  }, [rows])

  /* -------------------------------------------------------------------- */
  /*                          UPLOAD & ANALYSE                            */
  /* -------------------------------------------------------------------- */
  const handleUploadAndAnalyse = async () => {
    if (!selectedFiles.length) return
    setLoading(true); setImportDone(false); setSummaries([]); setError(null)
    try {
      const newSum=[]; let combinedAI='', combinedRaw=''
      for (const file of selectedFiles) {
        const raw = await extractText(file)
        combinedRaw += `\n=== ${file.name} ===\n${raw}\n`
        const norm = await classifyAndNormalize(raw)
        combinedAI += `\n${norm}\n`
        const res  = await importTransaction({
         fileName:file.name, lines:norm,
        }).unwrap()
        newSum.push({file:file.name, ...res})
      }
      await manageTransaction({
        action:'get_transaction_document',
      }).unwrap()

      setSummaries(newSum); setRawText(combinedRaw.trim())
      setAnalysisText(combinedAI.trim()); setImportDone(true)

      window.dispatchEvent(new Event('transactions:refresh'))  // 🔔 refresh list
    } catch(e){ setError(errorToString(e)) }
    finally { setLoading(false); setSelectedFiles([]) }
  }

  /* -------------------------------------------------------------------- */
  /*                       PROCESS (no new files)                         */
  /* -------------------------------------------------------------------- */
  const handleProcessTransaction = async () => {
    setLoading(true); setError(null)
    try {
      const payload = rows.map(r=>{
        const orig = transactions.find(t=>t.id===r.id)||{}
        const old  = {}
        const diff = (k,nv,ov)=>{ if ((ov??'')!== (nv??'')) old[k]=ov??null }
        diff('txn_date',r.txn_date,orig.txn_date)
        diff('description',r.description,orig.description)
        diff('category',r.category,orig.category)
        diff('reference',r.reference,orig.reference)
        const origType = parseFloat(orig.money_in||'0')>0?'Credited':'Debited'
        const origAmt  = (parseFloat(orig.money_in)||parseFloat(orig.money_out)||0).toFixed(2)
        diff('type', r.type, origType); diff('amount', r.amount, origAmt)

        return {
          id:r.id>0?r.id:null,
          line_id:r.line_id,
          txn_date:r.txn_date,
          description:r.description,
          category:r.category,
          reference:r.reference,
          type:r.type,
          amount:parseFloat(r.amount||0),
          document_id:r.document_id,
          old_values:old,
        }
      })

      await manageTransaction({
        action:'process_transaction',
        rows:payload,
      }).unwrap()

      setImportDone(true)
      window.dispatchEvent(new Event('transactions:refresh'))  // 🔔 refresh list
    } catch(e){ setError(errorToString(e)) }
    finally { setLoading(false) }
  }

  /* -------------------------------------------------------------------- */
  /*                               UI                                     */
  /* -------------------------------------------------------------------- */
  const mainButtonText = selectedFiles.length?'Upload & Analyze':'Done'
  const handleMainClick =
    selectedFiles.length ? handleUploadAndAnalyse : handleProcessTransaction

  const statusLabel = loading ? 'Working…'
                     : importDone ? 'Your transactions have been processed.'
                     : 'Upload your bank statement, invoice, or any financial document.'

  /* -------------------------------------------------------------------- */
  /*                               RENDER                                 */
  /* -------------------------------------------------------------------- */
  return (
    <>
      {/* MAIN MODAL ------------------------------------------------------ */}
      <div className="modal fade" id="uploadModal" tabIndex={-1} aria-hidden="true">
        <div className="modal-dialog modal-xl">
          <div className="modal-content" style={{minHeight:'670px'}}>
            <div className="modal-header">
              <h5 className="modal-title">Quick Statement Upload</h5>
              <button className="btn-close" data-bs-dismiss="modal"/>
            </div>

            <div className="modal-body">
              {/* TOP CONTROLS --------------------------------------------- */}
              <div className="row mb-3 g-2 align-items-end">
                {/* file filter */}
                <div className="col-md-5">
                  <label className="form-label">Select File</label>
                  <select className="form-select" value={fileFilter}
                          onChange={e=>setFileFilter(e.target.value)}>
                    <option value="">All files</option>
                    {Array.from(new Set(rows.map(r=>r.document_id))).filter(Boolean)
                      .map(id=>(
                        <option key={id} value={id}>
                          {rows.find(r=>r.document_id===id)?.file_name || id}
                        </option>
                    ))}
                  </select>
                </div>
                {/* owner filter */}
                <div className="col-md-5">
                  <label className="form-label">Filter by Owner</label>
                  <select className="form-select" value={ownerFilter}
                          onChange={e=>setOwnerFilter(e.target.value)}>
                    <option value="">All owners</option>
                    {Array.from(new Set(rows.map(r=>r.parent_id))).map(pid=>{
                      const t = transactions.find(t=>t.parent_id===pid)||{}
                      return (
                        <option key={pid} value={pid}>
                          {(t.first_name||'')+' '+(t.last_name||'')}
                        </option>
                      )
                    })} 
                  </select>
                </div>
                {/* upload button */}
                <div className="col-md-2 d-flex flex-column">
                  <label className="form-label invisible">Upload</label>
                  <button className="btn btn-outline-primary w-100"
                          onClick={()=>fileInputRef.current?.click()}>
                    Upload Files
                  </button>
                  <input ref={fileInputRef} type="file"
                         accept=".pdf,.jpg,.jpeg,.png,.txt"
                         hidden multiple
                         onChange={e=>{
                           setSelectedFiles(Array.from(e.target.files||[]))
                           setImportDone(false); setSummaries([])
                         }}/>
                </div>
              </div>

              {/* ROW CONTROLS --------------------------------------------- */}
              <div className="controls-container mb-3">
                <span className="small text-muted">{statusLabel}</span>
                <div className="d-flex gap-2">
                  <button className="btn btn-sm btn-danger"
                          disabled={!selectedRows.size||loading}
                          onClick={confirmDelete}>
                    🗑️ Delete Selected
                  </button>
                  <button className="btn btn-sm btn-success" onClick={addRowAtTop}>
                    ➕ Add Row
                  </button>
                </div>
              </div>

              {/* GRID ------------------------------------------------------ */}
              <form id="statement-form">
                <div className="table-wrapper">
                  <table>
                    <thead>
                      <tr>
                        <th><input type="checkbox" checked={allSelected}
                                   onChange={toggleSelectAll}/></th>
                        <th>Date</th><th className="description">Description</th>
                        <th>Category</th><th>Reference</th><th>Type</th><th>Amount</th>
                      </tr>
                      <tr className="filters-row">
                        <th/>
                        {['date','desc','cat','ref','type'].map(k=>(
                          <th key={k}>
                            <div className="filter-wrapper">
                              <input className="form-control form-control-sm"
                                     list={`filter-${k}-list`}
                                     placeholder="Filter…"
                                     value={colFilters[k]}
                                     onChange={e=>setColFilters({...colFilters,[k]:e.target.value})}/>
                              <button type="button" className="clear-filter"
                                      onClick={()=>setColFilters({...colFilters,[k]:''})}>
                                &times;
                              </button>
                            </div>
                          </th>
                        ))}
                        <th/>
                      </tr>
                    </thead>
                    <tbody>
                      {visibleRows.map(r=>(
                        <tr key={r.id}>
                          <td><input type="checkbox"
                                     checked={selectedRows.has(r.id)}
                                     onChange={()=>handleRowSelect(r.id)}/></td>
                          <td><input type="date" className="form-control"
                                     value={r.txn_date}
                                     onChange={e=>setRows(rows.map(x=>x.id===r.id?{...x,txn_date:e.target.value}:x))}/>
                          </td>
                          <td className="description">
                            <input className="form-control"
                                   value={r.description}
                                   onChange={e=>setRows(rows.map(x=>x.id===r.id?{...x,description:e.target.value}:x))}/>
                          </td>
                          <td>
                            <select className="form-select" value={r.category}
                                    onChange={e=>setRows(rows.map(x=>x.id===r.id?{...x,category:e.target.value}:x))}>
                              {categories.map(c=><option key={c}>{c}</option>)}
                            </select>
                          </td>
                          <td><input className="form-control"
                                     value={r.reference}
                                     onChange={e=>setRows(rows.map(x=>x.id===r.id?{...x,reference:e.target.value}:x))}/>
                          </td>
                          <td>
                            <select className="form-select" value={r.type}
                                    onChange={e=>setRows(rows.map(x=>x.id===r.id?{...x,type:e.target.value}:x))}>
                              <option>Credited</option><option>Debited</option>
                            </select>
                          </td>
                          <td><input type="number" step="0.01" className="form-control"
                                     value={r.amount}
                                     onChange={e=>setRows(rows.map(x=>x.id===r.id?{...x,amount:e.target.value}:x))}/>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {/* datalists */}
                  {Object.entries(filterOptions).map(([k,opts])=>(
                    <datalist id={`filter-${k}-list`} key={k}>
                      {opts.map(v=><option key={v} value={v}/>)}
                    </datalist>
                  ))}
                </div>
              </form>

              {/* ERRORS ---------------------------------------------------- */}
              {error&&<div className="alert alert-danger">Error: {error}</div>}
              {importError&&<div className="alert alert-danger">Import error: {errorToString(importErr)}</div>}
              {manageError&&<div className="alert alert-danger">Document error: {errorToString(manageErr)}</div>}
            </div>

            {/* FOOTER ------------------------------------------------------ */}
            <div className="modal-footer">
              <a className="btn btn-outline-secondary me-auto"
                 href={csvUrl||'#'} download="transactions.csv"
                 style={{pointerEvents:csvUrl?'auto':'none',opacity:csvUrl?1:0.5}}>
                Download CSV
              </a>
              <button className="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button className="btn btn-primary" onClick={handleMainClick} disabled={loading}>
                {loading?'Working…':mainButtonText}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* DELETE CONFIRMATION MODAL -------------------------------------- */}
      {showDeleteModal&&(
        <div className="modal fade show" style={{display:'block',background:'rgba(0,0,0,.5)'}} tabIndex={-1}>
          <div className="modal-dialog modal-sm modal-dialog-centered">
            <div className="modal-content" style={{maxHeight:'230px',overflowY:'auto'}}>
              <div className="modal-header">
                <h5 className="modal-title">Confirm Deletion</h5>
                <button className="btn-close" onClick={cancelDelete}/>
              </div>
              <div className="modal-body">
                Delete {selectedRows.size} record{selectedRows.size===1?'':'s'}? This marks them as deleted.
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary btn-sm" onClick={cancelDelete}>Cancel</button>
                <button className="btn btn-danger btn-sm" onClick={doDelete} disabled={loading}>
                  {loading?'Deleting…':'Delete'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* INLINE STYLES ---------------------------------------------------- */}
      <style>{`
        #statement-form .table-wrapper{display:block;max-height:350px;overflow-y:auto;margin-bottom:8px}
        #statement-form table{width:100%;table-layout:fixed;border-collapse:collapse}
        #statement-form thead th{position:sticky;top:0;background:#f4f4f4;z-index:2}
        #statement-form thead .filters-row th{background:#fff;top:35px;z-index:1;border-top:none}
        #statement-form th:first-child,#statement-form td:first-child{width:32px;text-align:center}
        #statement-form td,#statement-form th{padding:8px;border:1px solid #ccc}
        #statement-form td.description{width:70%}
        #statement-form td.description input{width:100%}
        #statement-form td:last-child{width:10%}
        .controls-container{display:flex;justify-content:space-between;gap:8px;align-items:center}
        .filter-wrapper{position:relative}
        .clear-filter{position:absolute;top:50%;right:6px;transform:translateY(-50%);
          background:none;border:none;font-size:1rem;cursor:pointer;color:#888;line-height:1}
        .clear-filter:hover{color:#000}
      `}</style>
    </>
  )
}
