import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from 'react-bootstrap';
import { toast } from 'react-toastify';
import { useEndImpersonationMutation } from '../api/authApi';
import { useSelector } from 'react-redux';

const ImpersonationBanner = () => {
  const [endImpersonation, { isLoading }] = useEndImpersonationMutation();
  const user = useSelector((state) => state.auth.user);
  const USER_EMAIL = user?.email;
  const [visible, setVisible] = useState(true);
  const navigate = useNavigate();
  const impersonated = user?.impersonated

  if (!impersonated || !visible) {
    return null;
  }

  const handleEndImpersonation = async () => {
    try {
      const { data } = await endImpersonation();
      if (data.status === 'success' && data.token) {
        localStorage.setItem('token', data.token);
        toast.success('Returned to original user account');
        navigate('/');
        window.location.reload();
      }
    } catch (error) {
      console.error('End impersonation error:', error);
      const errorMsg = error.data?.message || 'Failed to end impersonation';
      toast.error(errorMsg);
    }
  };

  return (
    <div className="impersonation-banner">
      <span className="impersonation-icon">⚠️</span>
      <span className="impersonation-text">
        You are currently viewing as <span className="impersonation-email">{USER_EMAIL}</span>.
      </span>
      <Button
        variant="light"
        className="impersonation-btn"
        onClick={handleEndImpersonation}
        disabled={isLoading}
      >
        {isLoading ? 'Returning...' : 'Return to your account'}
      </Button>
      {/* <button
        className="impersonation-close"
        aria-label="Close banner"
        onClick={() => setVisible(false)}
      >
        &times;
      </button> */}
    </div>
  );
};

export default ImpersonationBanner; 