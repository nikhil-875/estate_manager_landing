import ReactApexChart from "react-apexcharts";
import { FaEllipsisV } from "react-icons/fa";

export const SalesOverview = ({ payload }) => {
    const { monthlyData = [] } = payload;
    const months = Array.from(new Set(monthlyData.map(d => d.month))).sort();
    const types = Array.from(new Set(monthlyData.map(d => d.subscription_type)));

    const series = types.map(type => ({
        name: type,
        data: months.map(month => {
            const rec = monthlyData.find(d => d.month === month && d.subscription_type === type);
            return rec ? rec.total_amount : 0;
        }),
    }));

    const options = {
        chart: { type: 'bar', stacked: true, toolbar: { show: false } },
        plotOptions: { bar: { columnWidth: '45%', borderRadius: 4 } },
        dataLabels: { enabled: false },
        legend: { show: true, position: 'top' },
        grid: { strokeDashArray: 4 },
        stroke: { width: 0 },
        colors: ['#2196f3', '#7a70ba', '#ff7043'],
        tooltip: { theme: 'light' },
        xaxis: { categories: months },
        yaxis: { labels: { formatter: v => v.toLocaleString() } },
    };

    return (
        <div className="card" style={{ minHeight: '32rem' }}>
            <div className="card-header card-no-border pb-0">
                <div className="header-top d-flex justify-content-between align-items-center">
                    <h4>Sales Overview</h4>
                    <FaEllipsisV />
                </div>
            </div>
            <div className="card-body pt-0">
                <ReactApexChart options={options} series={series} type="bar" height={320} />
            </div>
        </div>
    );
};