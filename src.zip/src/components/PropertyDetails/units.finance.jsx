// src/components/PropertyDetails/UnitFinance.jsx

import React from 'react';
import TransactionsSection from './TransactionsSection.jsx';
import BondTrackSection    from './BondTrackSection.jsx';

export const UnitFinance = ({ subTab, propertyId, unitId, userId }) => {
  return (
    <>
      {subTab === 'Bond Track'
        ? (
          <BondTrackSection
            propertyId={propertyId}
            unitId={unitId}
            userId={userId}
          />
        )
        : (
          <TransactionsSection
            propertyId={propertyId}
            unitId={unitId}
            userId={userId}
          />
        )}
    </>
  );
};

export default UnitFinance;
