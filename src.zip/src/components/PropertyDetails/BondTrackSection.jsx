// src/components/PropertyDetails/BondTrackSection.jsx
import React, { useState, useEffect, useCallback } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { toast } from 'react-toastify';

/* ──────── API hooks ──────── */
import {
  useGetBondQuery,
  useManageBondMutation,
  useManageGoalMutation,
  useLazyGetGoalsQuery,
} from '../../api/propertyApi';

/* ──────── Helpers ──────── */
const money = (n = 0, c = 'R') =>
  `${c}${Number(n).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
const round2 = (x) => Math.round((x + Number.EPSILON) * 100) / 100;
const palette = ['#816CFB', '#1BA3F3', '#18B86F', '#F28C45'];
const safeDate = (d) => (d ? (isNaN(new Date(d)) ? null : new Date(d)) : null);

/* ─────────── Re-usable small components ─────────── */
const Field = ({
  label,
  prepend,
  type = 'text',
  value,
  error,
  onChange,
  ...rest
}) => (
  <div className={`col-md-${rest.col12 ? 12 : 6}`}>
    <label className="form-label fw-medium">
      {label}
      {rest.required && <span className="text-danger"> *</span>}
    </label>
    <div className="input-group">
      {prepend && (
        <span className="input-group-text bg-white border-end-0">{prepend}</span>
      )}
      <input
        {...rest}
        type={type}
        className={`form-control ${
          prepend ? 'border-start-0' : ''
        } ${error ? 'is-invalid' : ''}`}
        value={value}
        onChange={onChange}
      />
      {error && <div className="invalid-feedback">{error}</div>}
    </div>
  </div>
);

/* ─────────── Summary cards ─────────── */
const BondCards = ({
  summary,
  currency,
  onSetup,
  totalActualSaved,
  totalGoalSaved,
}) => (
  <div className="row g-1 mb-3">
    {[
      ['Bond Amount', 'Total Interest', 'bond_amount', 'total_interest'],
      ['Amount Paid', 'Interest Paid', 'amount_paid', 'interest_paid'],
      ['Remaining Balance', 'Interest Left', 'remaining_balance', 'interest_left'],
    ].map(([h, l, aKey, vKey], i) => (
      <div key={i} className="col-lg-4 col-md-6">
        <div className="card shadow-sm border-0 h-100">
          <div className="card-body py-3 px-3 d-flex flex-column h-100">
            <small className="text-secondary mb-1">{h}</small>
            <h4 className="fw-bold mb-2">{money(summary[aKey], currency)}</h4>
            <div className="mb-3 d-flex align-items-center">
              <small className="me-2 text-secondary">{l}</small>
              <span className="badge bg-light text-dark">
                {money(summary[vKey], currency)}
              </span>
            </div>

            {h === 'Amount Paid' && (
              <div className="mt-auto text-center">
                <span className="badge bg-primary text-white mb-1">
                  You saved {money(totalActualSaved, currency)}
                </span>
              </div>
            )}

            {h === 'Remaining Balance' && (
              <div className="mt-auto text-center">
                <span className="badge bg-success text-white mb-1">
                  You could save {money(totalGoalSaved, currency)}
                </span>
              </div>
            )}

            {h === 'Bond Amount' && (
              <div className="mt-auto text-center">
                <button
                  className="btn btn-sm btn-outline-primary"
                  onClick={onSetup}
                >
                  Setup
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    ))}
  </div>
);

/* ─────────── Timeline ─────────── */
const BondTimeline = ({ events, onItemClick }) => {
  if (!BondTimeline._css) {
    const style = document.createElement('style');
    style.textContent = `
      .timeline{position:relative}
      .timeline .item{display:flex;cursor:pointer;margin-bottom:1rem}
      .timeline .sq{width:18px;height:18px;border-radius:3px;flex-shrink:0}
      .timeline .dot{width:2px;flex-grow:1;
        background-image:linear-gradient(#d0d7de 30%,transparent 0);
        background-size:2px 6px;margin:2px 0 0}`;
    document.head.appendChild(style);
    BondTimeline._css = true;
  }
  return (
    <div className="timeline">
      {events.map(({ label, color, main, sub, row }, idx) => (
        <div key={idx} className="item" onClick={() => onItemClick?.(row)}>
          <div className="d-flex flex-column align-items-center me-3">
            <span className="sq" style={{ backgroundColor: color }} />
            {idx !== events.length - 1 && <div className="dot" />}
          </div>
          <div>
            <span className="badge bg-light text-muted mb-1">{`Month ${label}`}</span>
            <h6 className="mb-1">{main}</h6>
            <p className="small text-muted mb-0">{sub}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

/* ─────────── Full SetupBondModal ─────────── */
const SetupBondModal = ({
  show,
  onClose,
  bondDetail = {},
  summaryData,
  currency,
  propertyId,
  unitId,
}) => {
  const [manageBond, { isLoading: saving }] = useManageBondMutation();
  const [manageGoal, { isLoading: savingGoal }] = useManageGoalMutation();

  const empty = {
    principal: '',
    down_payment: '',
    annual_rate: '',
    rate_change_date: null,
    term_months: '',
    start_date: null,
    payment_frequency: 'Monthly',
    bond_reference: '',
    notes: '',
  };

  const [tab, setTab] = useState('details');
  const [edit, setEdit] = useState(false);
  const [details, setDetails] = useState(empty);

  const [goalType, setGType] = useState('extra_per_month');
  const [goal, setGoal] = useState({ extra: '', target: null, note: '' });

  const [errors, setErrors] = useState({});
  const [savings, setSave] = useState({
    annual: '0',
    total: '0',
    reduce: '0 months',
    monthly: '0',
    payoff: '',
    extraComputed: '0',
    monthlyPayment: '0',
  });

  // initialize form
  useEffect(() => {
    if (!show) return;
    setEdit(!bondDetail.bond_id);
    setDetails({
      principal:          bondDetail.bond_amount      || '',
      down_payment:       bondDetail.deposit_amount   ?? '0',
      annual_rate:        bondDetail.interest_rate    || '',
      rate_change_date:   safeDate(bondDetail.rate_change_date),
      start_date:         safeDate(bondDetail.start_date),
      term_months:        bondDetail.term_months      || '',
      payment_frequency:  bondDetail.payment_frequency|| 'Monthly',
      bond_reference:     bondDetail.bond_reference   || '',
      notes:              bondDetail.notes            || '',
    });
    const g = summaryData?.goals?.[0] || {};
    setGType(g.goal_type ?? 'extra_per_month');
    setGoal({
      extra:  g.goal_type === 'extra_per_month' ? g.target_amount || '' : '',
      target: g.goal_type === 'payoff_by' && g.target_date ? safeDate(g.target_date) : null,
      note:   g.note || '',
    });
  }, [show, bondDetail, summaryData]);

  // live savings calculation matching DB logic
  useEffect(() => {
    const Pgross  = +details.principal;
    const deposit = +details.down_payment;
    const P       = Pgross - deposit;
    const rAnn    = +details.annual_rate / 100;
    const N       = +details.term_months;
    const start   = details.start_date || new Date();
    if (!P || !rAnn || !N) return;

    const r  = rAnn / 12;
    const P0 = round2(r ? (P * r) / (1 - Math.pow(1 + r, -N)) : P / N);

    // determine extra & payoff month count
    const monthsBetween = (d1, d2) =>
      (d2.getFullYear() - d1.getFullYear()) * 12 +
      (d2.getMonth() - d1.getMonth());

    let usedExtra = 0;
    let Mnew      = N;

    if (goalType === 'extra_per_month' && +goal.extra) {
      usedExtra = +goal.extra;
    } else if (goalType === 'payoff_by' && goal.target) {
      Mnew = Math.max(1, monthsBetween(start, goal.target));
      usedExtra = r
        ? (P * r) / (1 - Math.pow(1 + r, -Mnew)) - P0
        : P / Mnew - P0;
      usedExtra = Math.max(0, round2(usedExtra));
    }

    // amortisation loop
    let baseBal = P, goalBal = P, totalSaved = 0, m = 0;
    while (goalBal > 0 && m < 1200) {
      m++;
      const intBase = round2(baseBal * r);
      const intNew  = round2(goalBal * r);
      totalSaved   += round2(intBase - intNew);

      const prinBase = round2(P0 - intBase);
      baseBal -= prinBase;

      let prinNew = prinBase + usedExtra;
      if (prinNew > goalBal) prinNew = goalBal;
      goalBal -= prinNew;
    }
    Mnew = m;

    const payoff = new Date(start);
    payoff.setMonth(payoff.getMonth() + Mnew);

    setSave({
      annual:         (totalSaved * 12 / Mnew).toFixed(2),
      total:          totalSaved.toFixed(2),
      reduce:         `${N - Mnew} months`,
      monthly:        (totalSaved / Mnew).toFixed(2),
      payoff:         payoff.toLocaleString('default', { month: 'short', year: 'numeric' }),
      extraComputed:  usedExtra.toFixed(2),
      monthlyPayment: (P0 + usedExtra).toFixed(2),
    });
  }, [details, goal, goalType]);

  const validate = () => {
    const e = {};
    const req = (k, msg, cond) =>
      (!details[k] || (cond && cond())) && (e[k] = msg);
    req('principal', 'Bond amount required', () => +details.principal <= 0);
    req('down_payment', 'Deposit required', () => +details.down_payment < 0);
    req('annual_rate', 'Rate required', () => +details.annual_rate <= 0 || +details.annual_rate > 100);
    if (!details.rate_change_date) e.rate_change_date = 'Rate change date required';
    req('term_months', 'Term required', () => +details.term_months <= 0 || +details.term_months > 600);
    if (!details.start_date) e.start_date = 'Start date required';
    if (!details.payment_frequency) e.payment_frequency = 'Frequency required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const buildBondPayload = () => ({
    action: bondDetail.bond_id ? 'update' : 'create',
    bond_id: bondDetail.bond_id,
    property_id: propertyId,
    unit_id: unitId,
    principal: +details.principal,
    down_payment: +details.down_payment || 0,
    annual_rate: +details.annual_rate,
    term_months: +details.term_months,
    payment_frequency: details.payment_frequency,
    start_date: details.start_date?.toISOString().split('T')[0] || null,
    annual_rate_date: details.rate_change_date?.toISOString().split('T')[0] || null,
    bond_reference: details.bond_reference || null,
    notes: details.notes || null,
  });

  const onSaveBond = async () => {
    if (!validate()) return;
    try {
      await manageBond(buildBondPayload()).unwrap();
      toast.success('Bond saved!');
      onClose?.();
    } catch (err) {
      console.error(err);
      toast.error(err?.data?.message || 'Unable to save bond');
    }
  };

  const onSaveGoal = async () => {
    const extras = {
      'Estimated Annual Savings': money(savings.annual, currency),
      'Total Savings to Goal':    money(savings.total,  currency),
      'New Reduction':            savings.reduce,
      'Monthly Savings':          money(savings.monthly, currency),
      'New Pay-off Date':         savings.payoff,
      'New Monthly Payment':      money(savings.monthlyPayment, currency),
    };
    try {
      const payload = {
        action: 'create_goal',
        bond_id: bondDetail.bond_id,
        goal_type: goalType,
        note: goal.note,
        extras,
      };
      if (goalType === 'extra_per_month') {
        payload.target_amount = +goal.extra;
      } else if (goalType === 'payoff_by' && goal.target) {
        payload.target_date = goal.target.toISOString().split('T')[0];
      }
      await manageGoal(payload).unwrap();
      toast.success('Goal saved!');
      onClose?.();
    } catch (err) {
      console.error(err);
      toast.error(err?.data?.message || 'Unable to save goal');
    }
  };

  // render modal
  if (!show) return null;
  return (
    <>
      <div className="modal-backdrop fade show" />
      <div className="modal show d-block" style={{ zIndex: 2000 }} tabIndex={-1}>
        <div className="modal-dialog modal-lg modal-dialog-centered">
          <div className="modal-content" style={{ minHeight: 540 }}>
            <div className="modal-header border-bottom">
              <h5 className="modal-title fw-bold">Bond Settings</h5>
              <button className="btn-close" onClick={onClose} />
            </div>
            <div className="modal-body overflow-auto p-4">
              <ul className="nav nav-tabs mb-4">
                {['details', 'goals'].map((t) => (
                  <li key={t} className="nav-item">
                    <button
                      className={`nav-link ${
                        tab === t ? 'active fw-medium' : 'text-secondary'
                      }`}
                      onClick={() => setTab(t)}
                    >
                      {t === 'details' ? 'Bond Details' : 'Bond Goals'}
                    </button>
                  </li>
                ))}
              </ul>

              {tab === 'details' ? (
                <form onSubmit={(e) => { e.preventDefault(); onSaveBond(); }}>
                  <div className="row g-4">
                    <Field
                      label="Bond Amount"
                      prepend="R"
                      required
                      value={details.principal}
                      error={errors.principal}
                      readOnly={!edit}
                      onChange={(e) =>
                        setDetails((d) => ({ ...d, principal: e.target.value }))
                      }
                      placeholder="e.g. 1000000"
                    />
                    <Field
                      label="Deposit Amount"
                      prepend="R"
                      required
                      value={details.down_payment}
                      error={errors.down_payment}
                      readOnly={!edit}
                      onChange={(e) =>
                        setDetails((d) => ({ ...d, down_payment: e.target.value }))
                      }
                      placeholder="0 is allowed"
                    />
                    <Field
                      label="Interest Rate (%)"
                      type="number"
                      required
                      value={details.annual_rate}
                      error={errors.annual_rate}
                      readOnly={!edit}
                      onChange={(e) =>
                        setDetails((d) => ({ ...d, annual_rate: e.target.value }))
                      }
                      placeholder="e.g. 11.5"
                      step="0.01"
                    />
                    <div className="col-md-6">
                      <label className="form-label fw-medium">
                        Rate Change Date<span className="text-danger"> *</span>
                      </label>
                      <DatePicker
                        wrapperClassName="w-100"
                        className={`form-control w-100 ${errors.rate_change_date && 'is-invalid'}`}
                        selected={details.rate_change_date}
                        readOnly={!edit}
                        onChange={(date) =>
                          setDetails((d) => ({ ...d, rate_change_date: date }))
                        }
                        dateFormat="yyyy-MM-dd"
                        placeholderText="YYYY-MM-DD"
                      />
                      {errors.rate_change_date && (
                        <div className="invalid-feedback">{errors.rate_change_date}</div>
                      )}
                    </div>
                    <Field
                      label="Term (months)"
                      type="number"
                      required
                      value={details.term_months}
                      error={errors.term_months}
                      readOnly={!edit}
                      onChange={(e) =>
                        setDetails((d) => ({ ...d, term_months: e.target.value }))
                      }
                      placeholder="e.g. 240"
                    />
                    <div className="col-md-6">
                      <label className="form-label fw-medium">
                        Start Date<span className="text-danger"> *</span>
                      </label>
                      <DatePicker
                        wrapperClassName="w-100"
                        className={`form-control w-100 ${errors.start_date && 'is-invalid'}`}
                        selected={details.start_date}
                        readOnly={!edit}
                        onChange={(date) =>
                          setDetails((d) => ({ ...d, start_date: date }))
                        }
                        dateFormat="yyyy-MM-dd"
                        placeholderText="YYYY-MM-DD"
                      />
                      {errors.start_date && (
                        <div className="invalid-feedback">{errors.start_date}</div>
                      )}
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-medium">
                        Payment Frequency<span className="text-danger"> *</span>
                      </label>
                      <select
                        className={`form-select ${errors.payment_frequency && 'is-invalid'}`}
                        value={details.payment_frequency}
                        readOnly={!edit}
                        onChange={(e) =>
                          setDetails((d) => ({
                            ...d,
                            payment_frequency: e.target.value,
                          }))
                        }
                      >
                        {['Monthly', 'Quarterly', 'Yearly'].map((opt) => (
                          <option key={opt}>{opt}</option>
                        ))}
                      </select>
                      {errors.payment_frequency && (
                        <div className="invalid-feedback">{errors.payment_frequency}</div>
                      )}
                    </div>
                    <Field
                      label="Bond Reference"
                      value={details.bond_reference}
                      error={errors.bond_reference}
                      readOnly={!edit}
                      onChange={(e) =>
                        setDetails((d) => ({ ...d, bond_reference: e.target.value }))
                      }
                      placeholder="e.g. REF123"
                    />
                    <div className="col-12 mt-2">
                      <label className="form-label fw-medium">Notes</label>
                      <textarea
                        className="form-control"
                        rows={2}
                        value={details.notes}
                        readOnly={!edit}
                        onChange={(e) =>
                          setDetails((d) => ({ ...d, notes: e.target.value }))
                        }
                        placeholder="Additional notes about the bond"
                      />
                    </div>
                  </div>
                  <div className="d-flex justify-content-between mt-5">
                    <button
                      type="button"
                      className="btn btn-outline-primary px-4"
                      onClick={() => setEdit(true)}
                    >
                      Edit Bond
                    </button>
                    <button className="btn btn-primary px-4" disabled={saving}>
                      {saving ? 'Saving…' : 'Save Setup'}
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={(e) => { e.preventDefault(); onSaveGoal(); }}>
                  <p className="fw-medium">
                    <strong>Total Bond Amount:</strong> {money(details.principal, currency)}
                  </p>
                  <div className="form-check form-switch mb-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      checked={goalType === 'extra_per_month'}
                      onChange={() =>
                        setGType((t) =>
                          t === 'extra_per_month' ? 'payoff_by' : 'extra_per_month'
                        )
                      }
                    />
                    <label className="form-check-label fw-medium">
                      {goalType === 'extra_per_month' ? 'Extra Per Month' : 'Target Date'}
                    </label>
                  </div>

                  {goalType === 'extra_per_month' ? (
                    <Field
                      label="Extra per Month (R)"
                      type="number"
                      value={goal.extra}
                      onChange={(e) =>
                        setGoal((g) => ({ ...g, extra: e.target.value }))
                      }
                      required
                      col12
                      placeholder="e.g. 1000"
                    />
                  ) : (
                    <div className="row g-3 mb-3">
                      <div className="col-md-6 d-flex flex-column">
                        <label className="form-label fw-medium mb-1">Target Date</label>
                        <DatePicker
                          className="form-control"
                          selected={goal.target}
                          onChange={(date) =>
                            setGoal((g) => ({ ...g, target: date }))
                          }
                          dateFormat="yyyy-MM"
                          showMonthYearPicker
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label fw-medium">
                          Computed Extra per Month (R)
                        </label>
                        <input
                          className="form-control"
                          value={money(savings.extraComputed, currency)}
                          readOnly
                        />
                      </div>
                    </div>
                  )}

                  <div className="mb-4">
                    <label className="form-label fw-medium">Note</label>
                    <textarea
                      className="form-control"
                      rows={4}
                      value={goal.note}
                      onChange={(e) =>
                        setGoal((g) => ({ ...g, note: e.target.value }))
                      }
                      placeholder="Goal description"
                    />
                  </div>

                  <div className="row mb-4">
                    {[
                      [
                        ['Estimated Annual Savings', 'annual'],
                        ['Total Savings to Goal', 'total'],
                        ['New Reduction', 'reduce'],
                      ],
                      [
                        ['Monthly Savings', 'monthly'],
                        ['New Pay-off Date', 'payoff'],
                        ['New Monthly Payment', 'monthlyPayment'],
                      ],
                    ].map((col, i) => (
                      <div key={i} className="col-md-6">
                        {col.map(([lbl, key]) => (
                          <p key={key} className="mb-2">
                            <strong className="fw-medium">{lbl}:</strong><br/>
                            {lbl === 'Total Savings to Goal'
                              ? money(savings.total, currency)
                              : key === 'payoff'
                                ? savings[key]
                                : key === 'reduce'
                                  ? savings[key]
                                  : money(savings[key], currency)}
                          </p>
                        ))}
                      </div>
                    ))}
                  </div>

                  <div className="text-end">
                    <button className="btn btn-primary px-4" disabled={savingGoal}>
                      {savingGoal ? 'Saving…' : 'Save Payment Goal'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

/* ─────────── UpdatePaymentModal ─────────── */
const UpdatePaymentModal = ({
  show,
  payment,
  availableExtra,
  currentInterest,
  onClose,
  onSave,
}) => {
  const [mode, setMode] = useState('add');
  const [newAmount, setNewAmount] = useState('0');
  const [newExtra, setNewExtra] = useState(String(availableExtra || 0));
  const [rate, setRate] = useState(String(currentInterest || ''));
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!show) return;
    setMode('add');
    setNewAmount('0');
    setNewExtra(String(availableExtra || 0));
    setRate(String(currentInterest || ''));
    setNotes('');
  }, [show, availableExtra, currentInterest]);

  if (!show || !payment) return null;

  return (
    <>
      <div className="modal-backdrop fade show" />
      <div className="modal show d-block" style={{ zIndex: 3000 }} tabIndex={-1}>
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content p-4">
            <div className="mb-3">
              <strong>
                Apply Payment Adjustment from{' '}
                {payment?.month_label || payment?.period_no}
              </strong>
              <br/><br/>
              <div className="form-check form-check-inline mt-2">
                <input
                  className="form-check-input"
                  type="radio"
                  id="addMoney"
                  checked={mode === 'add'}
                  onChange={() => setMode('add')}
                />
                <label className="form-check-label" htmlFor="addMoney">
                  Add Money
                </label>
              </div>
              <div className="form-check form-check-inline">
                <input
                  className="form-check-input"
                  type="radio"
                  id="withdrawMoney"
                  checked={mode === 'withdraw'}
                  onChange={() => setMode('withdraw')}
                />
                <label className="form-check-label" htmlFor="withdrawMoney">
                  Withdraw Money
                </label>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">
                {mode === 'add'
                  ? 'Deposit Lump-sum Amount'
                  : 'Withdraw from Available Funds'}
              </label>
              <div className="input-group">
                <span className="input-group-text">R</span>
                <input
                  type="number"
                  className="form-control"
                  value={newAmount}
                  onChange={(e) => setNewAmount(e.target.value)}
                  min="0"
                />
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">Pay Extra Monthly</label>
              <div className="input-group">
                <span className="input-group-text">R</span>
                <input
                  type="number"
                  className="form-control"
                  value={newExtra}
                  onChange={(e) => setNewExtra(e.target.value)}
                  min="0"
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="form-label">Interest Rate (%)</label>
              <input
                type="number"
                className="form-control"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                min="0"
                step="0.01"
              />
            </div>

            <div className="mb-4">
              <label className="form-label">Notes</label>
              <textarea
                className="form-control"
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>

            <div className="d-flex justify-content-end">
              <button
                className="btn btn-outline-secondary me-2"
                onClick={onClose}
              >
                Cancel
              </button>
              <button
                className="btn btn-primary"
                onClick={() =>
                  onSave({
                    ...payment,
                    mode,
                    newAmount: Number(newAmount),
                    newExtra: Number(newExtra),
                    interest_rate: Number(rate),
                    notes,
                  })
                }
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

/* ─────────── Parent: BondTrackSection ─────────── */
const BondTrackSection = ({ unitId, propertyId }) => {
  const { data, isLoading, error } = useGetBondQuery(
    { property_id: propertyId, unit_id: unitId },
    { skip: !propertyId || !unitId }
  );

  const [
    fetchGoals,
    { data: goalsData, isFetching: goalsLoading, error: goalsError },
  ] = useLazyGetGoalsQuery();

  useEffect(() => {
    if (data?.summary?.bond_id) {
      fetchGoals({
        bond_id: data.summary.bond_id,
        property_id: propertyId,
        unit_id: unitId,
      });
    }
  }, [data, propertyId, unitId, fetchGoals]);

  const [showSetup, setShowSetup] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [timeline, setTimeline] = useState('actual');
  const [visible, setVisible] = useState(12);

  const demoSummary = {
    bond_amount: 0,
    total_interest: 0,
    amount_paid: 0,
    interest_paid: 0,
    remaining_balance: 0,
    interest_left: 0,
    extra_per_month: 0,
    interest_rate: 0,
  };
  const demoEvents = [
    {
      label: '1',
      color: '#CCCCCC',
      main: 'No bond data available',
      sub: 'Set up your bond to start tracking payments',
      row: { period_no: 1, month_label: 'Month 1' }
    }
  ];

  const summary = data?.summary || demoSummary;
  const baseTimeline = data?.timeline || [];
  const goalTimeline = goalsData?.timeline || [];
  const availableExtra = summary?.extra_per_month || 0;
  const currentInterest = summary?.interest_rate || 0;
  const currency = 'R';

  const actualRows = baseTimeline.filter((t) => t.goal_id === null);
  const goalRows = goalTimeline.length
    ? goalTimeline
    : baseTimeline.filter((t) => t.goal_id !== null);

  // actual saved and goal saved sums
  const totalActualSaved = actualRows.reduce((sum, r) => sum + (r.saved || 0), 0);
  const totalGoalSaved   = goalRows.reduce((sum, r) => sum + (r.savings || 0), 0);

  const buildEvents = (rows, isGoal) =>
    rows.map((r, i) => ({
      label: r.month_label?.replace(/^Month\s*/i, '') ?? r.period_no,
      color: palette[i % palette.length],
      main: isGoal
        ? `If you pay ${money(r.extra ?? r.expected_extra ?? 0, currency)} Extra`
        : `You paid ${money(r.actual_payment, currency)}`,
      sub: isGoal
        ? `Monthly Payment: ${money(r.projected_payment ?? 0, currency)} | You will save ${money(r.savings ?? 0, currency)}`
        : `Saved: ${money(r.saved, currency)}`,
      row: r,
    }));

  const actualEvents = buildEvents(actualRows, false);
  const goalEvents   = buildEvents(goalRows,   true);
  const events       = timeline === 'actual' ? actualEvents : goalEvents;
  const currentEvents = data?.summary ? events.slice(0, visible) : demoEvents;

  const onScroll = useCallback(
    (e) => {
      if (!data?.summary) return;
      const { scrollTop, scrollHeight, clientHeight } = e.target;
      if (scrollTop + clientHeight >= scrollHeight - 100) {
        setVisible((v) => Math.min(v + 12, events.length));
      }
    },
    [events.length, data?.summary]
  );

  if (isLoading) return <div>Loading bond data…</div>;
  if (error)     return <div>Error loading bond data.</div>;

  const handleSavePayment = async (updated) => {
    console.log('Saving payment update:', updated);
    toast.success(`Payment for month ${updated.period_no} updated!`);
    setShowUpdateModal(false);
  };

  return (
    <div className="px-3 pt-3">
      <BondCards
        summary={summary}
        currency={currency}
        onSetup={() => setShowSetup(true)}
        totalActualSaved={totalActualSaved}
        totalGoalSaved={totalGoalSaved}
      />

      {data?.summary && (
        <div className="d-flex align-items-center mb-2">
          <span
            className={`badge me-2 ${
              timeline === 'actual' ? 'bg-primary text-white' : 'bg-light text-dark'
            }`}
            style={{ cursor: 'pointer' }}
            onClick={() => {
              setTimeline('actual');
              setVisible(12);
            }}
          >
            Actual Payments
          </span>
          <span
            className={`badge me-2 ${
              timeline === 'goal' ? 'bg-primary text-white' : 'bg-light text-dark'
            }`}
            style={{ cursor: 'pointer' }}
            onClick={() => {
              setTimeline('goal');
              setVisible(12);
            }}
          >
            Goal Projection
          </span>
        </div>
      )}

      <h6 className="mb-3">Bond Payment Timeline</h6>
      <div
        className="p-3 mb-4"
        style={{ maxHeight: 400, overflowY: 'auto' }}
        onScroll={onScroll}
      >
        {currentEvents.length ? (
          <BondTimeline
            events={currentEvents}
            onItemClick={data?.summary ? (row) => {
              setSelectedPayment(row);
              setShowUpdateModal(true);
            } : undefined}
          />
        ) : (
          <div className="text-center text-muted py-5">
            <em>No {timeline} data.</em>
          </div>
        )}

        {data?.summary && currentEvents.length < events.length && (
          <div className="text-center py-2 text-primary">
            <small>Scroll down to load more</small>
          </div>
        )}
      </div>

      {showSetup && (
        <SetupBondModal
          show={showSetup}
          onClose={() => setShowSetup(false)}
          bondDetail={summary}
          summaryData={summary}
          currency={currency}
          propertyId={propertyId}
          unitId={unitId}
        />
      )}

      {showUpdateModal && selectedPayment && (
        <UpdatePaymentModal
          show={showUpdateModal}
          payment={selectedPayment}
          availableExtra={availableExtra}
          currentInterest={currentInterest}
          onClose={() => setShowUpdateModal(false)}
          onSave={handleSavePayment}
        />
      )}
    </div>
  );
};

export default BondTrackSection;