import React, { useCallback, useEffect, useState } from 'react';
import { FaFileCsv, FaSearch } from 'react-icons/fa';
import { ArrowUpRight } from 'lucide-react';
import {
  useManageTenantMutation,
  useManageTenantAddressMutation,
  useManageTenantContractMutation,
  useManageTenantDocumentMutation,
  useManageTenantInvitationMutation,
} from '../../api/propertyApi';
import { toast } from 'react-toastify';
import {
  TenantPersonalDetails,
  TenantDocuments,
  TenantRentals,
  TenantPayments,
} from '../TenantDetails';

/* -------------------------------------------------------------------------- */
/* HELPERS                                                                   */
/* -------------------------------------------------------------------------- */
const useSave = (mutation) =>
  useCallback(
    async (payload, successMsg = 'Saved') => {
      try {
        const { status, message } = await mutation(payload).unwrap();
        status === 'success'
          ? toast.success(successMsg)
          : toast.error(message);
        return status === 'success';
      } catch (e) {
        toast.error(e?.data?.error || 'Request failed');
        return false;
      }
    },
    [mutation],
  );


/* -------------------------------------------------------------------------- */
/* MAIN COMPONENT                                                            */
/* -------------------------------------------------------------------------- */
export const UnitTenants = ({
  propertyId,
  unitId,
  userId: uid,
  subTab,
  unit,
}) => {
  const {
    tenant: tenantData,
    contract: contractData,
    address: addressesData,
    documents: documentsData,
  } = unit;

  const [tenant, setTenant] = useState(tenantData ?? {});
  const [contract, setContract] = useState(contractData ?? {});
  const [form, setForm] = useState({});

  useEffect(() => {
    const initialForm = { ...(tenantData ?? {}) };
    const typeLabels = { alt: 'Alternative Contact', office: 'Office Details' };

    if (addressesData?.length) {
      const alt = addressesData.find((a) => a.address_type === 'alt');
      if (alt) {
        initialForm.altLabel = typeLabels.alt;
        initialForm.alt_name = alt.name;
        initialForm.alt_phone = alt.phone_number;
        initialForm.alt_address = alt.street;
        initialForm.alt_city = alt.city;
        initialForm.alt_state = alt.state;
        initialForm.alt_zip_code = alt.zip_code;
        initialForm.alt_country = alt.country;
      }
      const off = addressesData.find((a) => a.address_type === 'office');
      if (off) {
        initialForm.officeLabel = typeLabels.office;
        initialForm.office_name = off.name;
        initialForm.office_phone = off.phone_number;
        initialForm.office_address = off.street;
        initialForm.office_city = off.city;
        initialForm.office_state = off.state;
        initialForm.office_zip_code = off.zip_code;
        initialForm.office_country = off.country;
      }
    }

    setForm(initialForm);
  }, [tenantData, addressesData]);

  useEffect(() => setTenant(tenantData ?? {}), [tenantData]);
  useEffect(() => setContract(contractData ?? {}), [contractData]);

  const [mutTenant] = useManageTenantMutation();
  const [mutAddr] = useManageTenantAddressMutation();
  const [mutDoc] = useManageTenantDocumentMutation();
  const [mutContract] = useManageTenantContractMutation();
  const [mutInvite] = useManageTenantInvitationMutation();

  const saveTenant = useSave(mutTenant);
  const saveAddr = useSave(mutAddr);
  const saveDoc = useSave(mutDoc);
  const saveContract = useSave(mutContract);
  const doInvite = useSave(mutInvite);

  const tabs = {
    'personal details': (
      <TenantPersonalDetails
        tenant={tenant}
        form={form}
        setForm={setForm}
        saveTenant={saveTenant}
        saveAddr={saveAddr}
        propertyId={propertyId}
        unitId={unitId}
        uid={uid}
      />
    ),
    document: (
      <TenantDocuments
        documents={documentsData ?? []}
        onUpload={(d) =>
          saveDoc({
            action: 'insert',
            tenant_id: tenant.id,
            unit_id: unitId,
            uid,
            ...d,
          })
        }
      />
    ),
    rentals: (
      <TenantRentals
        rentalContract={contract}
        onSave={(d) =>
          saveContract({
            action: contract.id ? 'update' : 'insert',
            id: contract.id,
            property_id: propertyId,
            unit_id: unitId,
            tenant_id: tenant.id,
            uid,
            ...d,
          })
        }
      />
    ),
    payments: <TenantPayments tenantId={tenant.id} />,
  };

  const active = (subTab || '').toLowerCase();
  return tabs[active] ?? <div className="text-muted">Invalid tab</div>;
};
