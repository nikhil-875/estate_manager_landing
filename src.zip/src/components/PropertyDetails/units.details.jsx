import React, { useState, useEffect, useRef, useMemo } from 'react';
import Select from 'react-select';
import { Modal, Button } from 'react-bootstrap';
import { EditableField, LABEL_COLOR } from '../EditableField';
import { toast } from 'react-toastify';
import {
  useGetUnitDetailsQuery,
  useManageUnitMutation,
  useSetPropertyAmenitiesMutation,
  useManagePropertyImageMutation,
  useGetAllAmenitiesQuery,
} from '../../api/propertyApi';
import {
  useGetS3UploadUrlMutation,
  useUploadFileToS3Mutation,
  useGetS3DownloadUrlQuery,
} from '../../api/uploadApi';

const nohouse = 'https://placehold.co/120x120/e1e1e1/777777?text=No+Unit+Photo';

// Reusable component for showing either a local preview or an S3 image
const PropertyImageDisplay = ({ s3key, localPreviewUrl, altText, fallbackIcon, ...imgProps }) => {
  const { data, isLoading, isError } = useGetS3DownloadUrlQuery(s3key, { skip: !s3key || !!localPreviewUrl });
  const onError = (e) => {
    e.target.onerror = null;
    e.target.src = nohouse;
  };
  if (localPreviewUrl) return <img src={localPreviewUrl} alt={altText} {...imgProps} onError={onError} />;
  if (isLoading)
    return (
      <div
        style={{ ...imgProps.style, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e9ecef', color: '#6c757d' }}
        title="Loading..."
      >
        {fallbackIcon || <i className="fa fa-spinner fa-spin" />}
      </div>
    );
  if (isError || !data?.data?.url)
    return (
      <div
        style={{ ...imgProps.style, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e9ecef', color: '#dc3545' }}
        title="Error"
      >
        {fallbackIcon || <i className="fa fa-exclamation-triangle" />}
      </div>
    );
  return <img src={data.data.url} alt={altText || s3key} {...imgProps} onError={onError} />;
};

export const UnitDetails = ({ propertyId, unitId, userId, userType, subTab, isNewMode, onUnitSaved, parentId }) => {
  // -----------------------------------
  //  Data fetching & mutations
  // -----------------------------------
  const {
    data: fetched,
    isLoading: loadingUnit,
    isError: fetchError,
    error,
    refetch,
  } = useGetUnitDetailsQuery({ unit_id: unitId, property_id: propertyId, uid: userId }, { skip: !unitId || isNewMode });
  const [manageUnit, { isLoading: savingUnit, error: saveUnitError }] = useManageUnitMutation();
  const [setAmenities, { isLoading: savingAmenities, error: saveAmenitiesError }] = useSetPropertyAmenitiesMutation();
  const [manageImage, { isLoading: managingImage }] = useManagePropertyImageMutation();
  const [getUploadUrl, { isLoading: gettingUploadUrl }] = useGetS3UploadUrlMutation();
  const [uploadToS3, { isLoading: uploadingToS3 }] = useUploadFileToS3Mutation();
  const [processingImages, setProcessingImages] = useState(false);
  const { data: amenitiesResp, isLoading: loadingAllAmenities } = useGetAllAmenitiesQuery();

  // -----------------------------------
  //  Local state
  // -----------------------------------
  const defaultFields = {
    name: '',
    type: 'Apartment',
    bedrooms: '',
    kitchen: '',
    bath: '',
    livingRoom: '',
    description: '',
    rentType: 'Monthly',
    rentAmount: '',
    rentDuration: '1',
    depositType: 'Fixed',
    depositAmount: '',
    lateFeeType: 'Fixed',
    lateFeeAmount: '',
    incidentReceiptAmount: '',
    notes: '',
  };
  const [unitData, setUnitData] = useState(defaultFields);
  const [selectedAmenities, setSelectedAmenities] = useState([]);
  const [unitImages, setUnitImages] = useState([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
  const [initialUnitData, setInitialUnitData] = useState(defaultFields);
  const [initialAmenities, setInitialAmenities] = useState([]);
  const [initialImages, setInitialImages] = useState([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
  const [showModal, setShowModal] = useState(false);
  const [focusedIdx, setFocusedIdx] = useState(0);
  const [coverIdx, setCoverIdx] = useState(null);
  const fileInputRef = useRef(null);

  // -----------------------------------
  //  Prepare amenity options
  // -----------------------------------
  const allAmenities = useMemo(() => {
    if (amenitiesResp?.status === 'success' && amenitiesResp.amenities) {
      return amenitiesResp.amenities.map((a) => ({
        value: a.id,
        label: a.name,
      }));
    }
    return [];
  }, [amenitiesResp]);

  const [firstCol, secondCol, otherAmenities] = useMemo(() => {
    const arr = allAmenities;
    return [arr.slice(0, 8), arr.slice(8, 16), arr.slice(16)];
  }, [allAmenities]);

  // -----------------------------------
  //  Populate form when fetched arrives
  // -----------------------------------
  useEffect(() => {
    if (isNewMode) {
      setUnitData(defaultFields);
      setSelectedAmenities([]);
      setUnitImages([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
      setInitialUnitData(defaultFields);
      setInitialAmenities([]);
      setInitialImages([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
      setFocusedIdx(0);
      setCoverIdx(null);
    } else if (fetched?.unit) {
      const u = fetched.unit;
      const fields = {
        name: u.name || '',
        type: u.type || 'Apartment',
        bedrooms: u.bedrooms?.toString() || '',
        kitchen: u.kitchen?.toString() || '',
        bath: u.baths?.toString() || '',
        livingRoom: u.living_room?.toString() || '',
        description: u.description || '',
        rentType: u.rent_type || 'Monthly',
        rentAmount: u.rent?.toString() || u.rent_amount?.toString() || '',
        rentDuration: u.rent_duration?.toString() || '1',
        depositType: u.deposit_type || 'Fixed',
        depositAmount: u.deposit_amount?.toString() || '',
        lateFeeType: u.late_fee_type || 'Fixed',
        lateFeeAmount: u.late_fee_amount?.toString() || '',
        incidentReceiptAmount: u.incident_receipt_amount?.toString() || '',
        notes: u.notes || '',
      };
      setUnitData(fields);
      setInitialUnitData(fields);

      // Map existing amenities → option values
      if (allAmenities.length) {
        let ids = u.amenities
          ?.map((a) => {
            const lower = a.name.toLowerCase();
            let opt = allAmenities.find((o) => o.label.toLowerCase() === lower);
            if (!opt && lower === 'swimming pool')
              opt = allAmenities.find((o) => o.label.toLowerCase() === 'pool');
            return opt?.value ?? null;
          })
          .filter((v) => v !== null);
        const washerDryer = u.amenities.find((a) => a.name.toLowerCase() === 'washer/dryer');
        if (washerDryer) {
          const wOpt = allAmenities.find((o) => o.label.toLowerCase() === 'washer');
          const dOpt = allAmenities.find((o) => o.label.toLowerCase() === 'dryer');
          if (wOpt && !ids.includes(wOpt.value)) ids.push(wOpt.value);
          if (dOpt && !ids.includes(dOpt.value)) ids.push(dOpt.value);
        }
        const uniqueIds = [...new Set(ids)];
        setSelectedAmenities(uniqueIds);
        setInitialAmenities(uniqueIds);
      } else {
        setSelectedAmenities([]);
        setInitialAmenities([]);
      }

      // Build image entries array
      const imgs = u.images?.map((img) => ({
        id: img.id,
        s3key: img.image,
        type: img.type,
        isStaged: false,
      })) || [];
      const finalImages = imgs.length ? imgs : [{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }];
      setUnitImages(finalImages);
      setInitialImages(finalImages);
      setFocusedIdx(0);
      const cEntry = finalImages.find((i) => i.type === 'cover');
      setCoverIdx(cEntry ? finalImages.findIndex((i) => i.id === cEntry.id) : null);
    }
  }, [fetched, isNewMode, allAmenities]);

  // Revoke object URLs on unmount or when images change
  useEffect(() => {
    return () => {
      unitImages.forEach((img) => {
        if (img.isStaged && img.previewUrl) URL.revokeObjectURL(img.previewUrl);
      });
    };
  }, [unitImages]);

  // -----------------------------------
  //  Show loading only if no fetched yet
  // -----------------------------------
  if (!isNewMode && loadingUnit && !fetched?.unit)
    return <div className="text-center py-5">Loading unit details...</div>;
  if (!isNewMode && fetchError && !fetched?.unit)
    return (
      <div className="text-center py-5 text-danger">
        Error loading unit: {error?.data?.message || error?.status}
      </div>
    );
  if (!isNewMode && !fetched?.unit && unitId)
    return <div className="text-center py-5">Unit not found.</div>;

  // -----------------------------------
  //  Handlers
  // -----------------------------------
  const handleFieldChange = (key, v) => setUnitData((p) => ({ ...p, [key]: v }));

  const handleSave = async (section) => {
    if (isNewMode && (section === 'description' || section === 'rent') && !unitData.name.trim()) {
      toast.warn('Unit Name is required to create a new unit.');
      return;
    }
    let payload = {},
      actionFn,
      successMsg = '',
      currentId = unitId;

    if (section === 'description' || section === 'rent' || (isNewMode && section !== 'amenities')) {
      actionFn = manageUnit;
      payload = {
        action: isNewMode ? 'insert' : 'update',
        ...(isNewMode ? {} : { unit_id: currentId }),
        property_id: propertyId,
        parent_id: fetched?.unit?.parent_id || parentId,
        uid: userId,
        name: unitData.name,
        type: unitData.type,
        bedroom: parseInt(unitData.bedrooms, 10) || 0,
        baths: parseInt(unitData.bath, 10) || 0,
        kitchen: parseInt(unitData.kitchen, 10) || 0,
        living_room: parseInt(unitData.livingRoom, 10) || 0,
        description: unitData.description,
        rent: parseFloat(unitData.rentAmount) || 0,
        deposit_amount: parseFloat(unitData.depositAmount) || 0,
        deposit_type: unitData.depositType,
        late_fee_type: unitData.lateFeeType,
        late_fee_amount: parseFloat(unitData.lateFeeAmount) || 0,
        incident_receipt_amount: parseFloat(unitData.incidentReceiptAmount) || 0,
        rent_type: unitData.rentType,
        rent_duration: parseInt(unitData.rentDuration, 10) || 0,
        notes: unitData.notes,
      };
      successMsg = isNewMode ? 'Unit created!' : 'Unit updated!';
    } else if (section === 'amenities') {
      if (!unitId) {
        toast.warn('Save description first before adding amenities.');
        return;
      }
      actionFn = setAmenities;
      payload = { property_id: propertyId, unit_id: currentId, amenity_ids: selectedAmenities, uid: userId };
      successMsg = 'Amenities updated!';
    }

    if (!actionFn) return;
    let ok = false;
    try {
      const res = await actionFn(payload).unwrap();
      toast.success(successMsg);
      if (isNewMode && (section === 'description' || section === 'rent') && res?.unit_id) {
        currentId = res.unit_id;
      }
      if (section !== 'amenities') setInitialUnitData({ ...unitData });
      else setInitialAmenities([...selectedAmenities]);
      ok = true;
    } catch (err) {
      console.error(err);
      toast.error(`Error saving ${section}: ${err.data?.message || err.message}`);
      return;
    }

    if (
      ok &&
      currentId &&
      (section === 'description' || section === 'rent' || (isNewMode && section !== 'amenities'))
    ) {
      const staged = unitImages.filter((i) => i.isStaged && i.file);
      if (staged.length) {
        setProcessingImages(true);
        toast.info(`Uploading ${staged.length} image(s)...`);
        let allOk = true;
        for (const img of staged) {
          try {
            const key = `uploads/unit_images/unit_${currentId}/property_${propertyId}/${Date.now()}_${img.file.name}`;
            const s3res = await getUploadUrl({ key, fileName: img.file.name, fileType: img.file.type }).unwrap();
            const url = s3res.data?.url || s3res.url;
            const returnedKey = s3res.data?.key || s3res.key;
            if (!url || !returnedKey) throw new Error('No upload params');
            await uploadToS3({ url, file: img.file }).unwrap();
            const existing = unitImages.filter((i) => !i.isStaged && !i.isPlaceholder);
            const type = existing.length === 0 && staged.length === 1 ? 'cover' : 'gallery';
            await manageImage({
              action: 'insert',
              property_id: propertyId,
              unit_id: currentId,
              image: returnedKey,
              type,
            }).unwrap();
          } catch (ie) {
            allOk = false;
            console.error(ie);
            toast.error(`Error uploading ${img.file.name}: ${ie.data?.message || ie.message}`);
          }
        }
        setProcessingImages(false);
        toast[allOk ? 'success' : 'warn'](allOk ? 'All uploaded!' : 'Some uploads failed.');
      }
      refetch();
      onUnitSaved?.(currentId);
    } else if (ok && (section === 'description' || section === 'rent')) {
      refetch();
      onUnitSaved?.(currentId);
    } else if (ok && section === 'amenities') {
      refetch();
      onUnitSaved?.(currentId);
    }
  };

  const handleCancel = (section) => {
    if (section !== 'amenities') setUnitData(initialUnitData);
    else setSelectedAmenities(initialAmenities);

    setUnitImages(initialImages);
    setFocusedIdx(0);
    const cEntry = initialImages.find((i) => i.type === 'cover' && !i.isStaged);
    setCoverIdx(cEntry ? initialImages.findIndex((i) => i.id === cEntry.id) : null);

    if (isNewMode) onUnitSaved?.(null);
  };

  const handleAddUnitImage = (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    if ((isNewMode && !unitId) || (!unitId && !isNewMode)) {
      toast.warn('Save unit details first.');
      e.target.value = '';
      return;
    }
    const newEntries = files.map((f) => ({
      id: `staged-${Date.now()}-${f.name}-${Math.random().toString(36).substr(2, 5)}`,
      file: f,
      previewUrl: URL.createObjectURL(f),
      isStaged: true,
    }));
    setUnitImages((prev) => {
      const base = prev.filter((i) => !i.isPlaceholder);
      const updated = [...base, ...newEntries];
      if (updated.length) {
        setFocusedIdx(base.length);
        return updated;
      }
      return [{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }];
    });
    e.target.value = '';
  };

  const handleDeleteUnitImage = async (idx) => {
    const img = unitImages[idx];
    if (!img || img.isPlaceholder) return;
    const oldImgs = [...unitImages],
      oldCover = coverIdx,
      oldFocus = focusedIdx;
    if (img.isStaged) {
      if (img.previewUrl) URL.revokeObjectURL(img.previewUrl);
      const arr = unitImages.filter((_, i) => i !== idx);
      setUnitImages(arr.length ? arr : [{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
      if (focusedIdx === idx) setFocusedIdx(Math.max(0, arr.length - 1));
      else if (focusedIdx > idx) setFocusedIdx((f) => f - 1);
      if (coverIdx === idx) setCoverIdx(null);
      else if (coverIdx !== null && coverIdx > idx) setCoverIdx((c) => (c !== null ? c - 1 : null));
      toast.info('Removed staged image.');
      return;
    }
    if (!img.s3key || !img.id) {
      toast.error('Incomplete image data.');
      return;
    }
    const optimistic = unitImages.filter((_, i) => i !== idx);
    setUnitImages(optimistic.length ? optimistic : [{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
    let newFocus = focusedIdx,
      newCover = coverIdx;
    if (focusedIdx === idx) newFocus = Math.max(0, optimistic.length - 1);
    else if (focusedIdx > idx) newFocus = focusedIdx - 1;
    if (coverIdx === idx) newCover = null;
    else if (coverIdx !== null && coverIdx > idx) newCover = coverIdx - 1;
    setFocusedIdx(newFocus);
    setCoverIdx(newCover);

    try {
      await manageImage({ action: 'delete', property_id: propertyId, unit_id: unitId, image_id: img.id }).unwrap();
      toast.success('Deleted image from server!');
      refetch();
    } catch (err) {
      console.error(err);
      toast.error(`Error deleting image: ${err.data?.message || err.message}`);
      setUnitImages(oldImgs);
      setFocusedIdx(oldFocus);
      setCoverIdx(oldCover);
    }
  };

  const handleSetCoverUnitImage = async (idx) => {
    const img = unitImages[idx];
    if (!unitId || img.isPlaceholder || img.isStaged || coverIdx === idx) return;
    if (!img.s3key || !img.id) {
      toast.error('Incomplete image data.');
      return;
    }
    const oldCover = coverIdx;
    setCoverIdx(idx);
    try {
      await manageImage({ action: 'update', property_id: propertyId, unit_id: unitId, image_id: img.id, type: 'cover' }).unwrap();
      if (oldCover !== null && oldCover !== idx && unitImages[oldCover]?.id && unitImages[oldCover].id !== img.id) {
        await manageImage({ action: 'update', property_id: propertyId, unit_id: unitId, image_id: unitImages[oldCover].id, type: 'gallery' }).unwrap();
      }
      toast.success('Cover updated!');
      refetch();
    } catch (err) {
      console.error(err);
      toast.error(`Error setting cover: ${err.data?.message || err.message}`);
      setCoverIdx(oldCover);
    }
  };

  // -----------------------------------
  //  If still fetching first time, show loader
  // -----------------------------------
  if (!isNewMode && loadingUnit && !fetched?.unit)
    return <div className="text-center py-5">Loading unit details...</div>;
  if (!isNewMode && fetchError && !fetched?.unit)
    return (
      <div className="text-center py-5 text-danger">
        Error loading unit: {error?.data?.message || error?.status}
      </div>
    );
  if (!isNewMode && !fetched?.unit && unitId) return <div className="text-center py-5">Unit not found.</div>;

  // -----------------------------------
  //  Save/Cancel buttons
  // -----------------------------------
  const renderSaveButtons = (section) => {
    const disabledAll = savingUnit || savingAmenities;
    return (
      <div className="row mt-4">
        <div className="col-12 d-flex justify-content-end">
          <Button variant="outline-secondary" className="me-2" onClick={() => handleCancel(section)} disabled={disabledAll}>
            Cancel
          </Button>
          <Button variant="primary" onClick={() => handleSave(section)} disabled={disabledAll}>
            {disabledAll
              ? 'Saving...'
              : isNewMode && section !== 'amenities'
              ? 'Create Unit'
              : 'Save Changes'}
          </Button>
        </div>
      </div>
    );
  };

  // -----------------------------------
  //  Build content based on subTab
  // -----------------------------------
  let content = null;

  if (subTab === 'description') {
    // Pick which image to show on tab
    const coverImg =
      coverIdx !== null && unitImages[coverIdx] && !unitImages[coverIdx].isPlaceholder
        ? unitImages[coverIdx]
        : null;
    let imageToDisplay = coverImg;
    if (!imageToDisplay) {
      imageToDisplay = unitImages.find((i) => !i.isPlaceholder && !i.isStaged && i.s3key);
      if (!imageToDisplay) {
        imageToDisplay = unitImages.find((i) => !i.isPlaceholder && i.isStaged && i.previewUrl);
      }
    }

    content = (
      <div className="text-start px-md-2">
        <h5 style={{ color: LABEL_COLOR }} className="fw-semibold">
          {isNewMode ? 'New Unit Description' : 'Unit Description'}
        </h5>
        <div className="row align-items-center">
          <div className="col-md-8">
            <EditableField
              icon="fa-font"
              label="Unit Name/Number"
              placeholder="e.g., Apt 101"
              value={unitData.name}
              onChange={(v) => handleFieldChange('name', v)}
            />
          </div>
          <div className="col-md-4 d-flex justify-content-center align-items-start">
            <div style={{ textAlign: 'center', cursor: 'pointer' }} onClick={() => setShowModal(true)} title="Manage Photos">
              <PropertyImageDisplay
                s3key={imageToDisplay && !imageToDisplay.isStaged ? imageToDisplay.s3key : null}
                localPreviewUrl={imageToDisplay && imageToDisplay.isStaged ? imageToDisplay.previewUrl : null}
                altText="Unit Preview"
                style={{ width: 150, height: 100, objectFit: 'cover', border: '1px solid #ccc', borderRadius: 4 }}
                fallbackIcon={
                  <img
                    src={nohouse}
                    alt="No unit"
                    style={{ width: 150, height: 100, objectFit: 'cover', border: '1px solid #ccc', borderRadius: 4 }}
                  />
                }
              />
            </div>
          </div>
        </div>
        <EditableField
          icon="fa-th-large"
          label="Unit Type"
          isSelect
          options={['Studio', 'Apartment', 'Townhouse', 'Flat', 'Duplex', 'Other']}
          value={unitData.type}
          onChange={(v) => handleFieldChange('type', v)}
        />
        <div className="row gx-3">
          <div className="col-md-6">
            <EditableField
              icon="fa-bed"
              label="Bedrooms"
              type="number"
              value={unitData.bedrooms}
              onChange={(v) => handleFieldChange('bedrooms', v)}
            />
          </div>
          <div className="col-md-6">
            <EditableField
              icon="fa-bath"
              label="Bathrooms"
              type="number"
              value={unitData.bath}
              onChange={(v) => handleFieldChange('bath', v)}
            />
          </div>
        </div>
        <div className="row gx-3">
          <div className="col-md-6">
            <EditableField
              icon="fa-utensils"
              label="Kitchens"
              type="number"
              value={unitData.kitchen}
              onChange={(v) => handleFieldChange('kitchen', v)}
            />
          </div>
          <div className="col-md-6">
            <EditableField
              icon="fa-couch"
              label="Living Rooms"
              type="number"
              value={unitData.livingRoom}
              onChange={(v) => handleFieldChange('livingRoom', v)}
            />
          </div>
        </div>
        <EditableField
          icon="fa-align-left"
          type="textarea"
          label="Unit Description"
          value={unitData.description}
          onChange={(v) => handleFieldChange('description', v)}
          textareaRows={3}
        />
        {renderSaveButtons('description')}
        {saveUnitError && <div className="alert alert-danger mt-2">{saveUnitError.data?.message || 'Failed to save.'}</div>}
      </div>
    );
  } else if (subTab === 'amenities') {
    content = (
      <div className="text-start px-md-2">
        <h5 style={{ color: LABEL_COLOR }} className="mb-3 fw-semibold">
          Unit Amenities
        </h5>
        {loadingAllAmenities && !allAmenities.length ? (
          <div className="text-center text-muted p-3">Loading amenities...</div>
        ) : !allAmenities.length && !loadingAllAmenities ? (
          <div className="text-center text-muted p-3">No amenities available.</div>
        ) : (
          <>
            <div className="row gy-2 mb-3">
              <div className="col-md-6">
                {firstCol.map((amen) => (
                  <div key={amen.value} className="form-check mb-2">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={`amen-${amen.value}`}
                      checked={selectedAmenities.includes(amen.value)}
                      onChange={() =>
                        setSelectedAmenities((p) =>
                          p.includes(amen.value) ? p.filter((id) => id !== amen.value) : [...p, amen.value]
                        )
                      }
                      disabled={savingAmenities || (isNewMode && !unitId) || loadingAllAmenities}
                    />
                    <label htmlFor={`amen-${amen.value}`} className="form-check-label" style={{ color: LABEL_COLOR, fontSize: '0.9rem' }}>
                      {amen.label}
                    </label>
                  </div>
                ))}
              </div>
              <div className="col-md-6">
                {secondCol.map((amen) => (
                  <div key={amen.value} className="form-check mb-2">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={`amen-${amen.value}`}
                      checked={selectedAmenities.includes(amen.value)}
                      onChange={() =>
                        setSelectedAmenities((p) =>
                          p.includes(amen.value) ? p.filter((id) => id !== amen.value) : [...p, amen.value]
                        )
                      }
                      disabled={savingAmenities || (isNewMode && !unitId) || loadingAllAmenities}
                    />
                    <label htmlFor={`amen-${amen.value}`} className="form-check-label" style={{ color: LABEL_COLOR, fontSize: '0.9rem' }}>
                      {amen.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>
            {otherAmenities.length > 0 && (
              <div className="mt-3">
                <label style={{ color: LABEL_COLOR, fontSize: '0.9rem' }} className="form-label fw-semibold">
                  Other Amenities
                </label>
                <Select
                  isMulti
                  options={otherAmenities}
                  value={otherAmenities.filter((opt) => selectedAmenities.includes(opt.value))}
                  onChange={(opts) => {
                    const vals = opts ? opts.map((o) => o.value) : [];
                    const baseCheckbox = [...firstCol, ...secondCol].map((o) => o.value).filter((id) => selectedAmenities.includes(id) && !otherAmenities.find((x) => x.value === id));
                    setSelectedAmenities([...baseCheckbox, ...vals]);
                  }}
                  isDisabled={savingAmenities || (isNewMode && !unitId) || loadingAllAmenities}
                  className="mb-3"
                  classNamePrefix="select"
                  placeholder={loadingAllAmenities ? 'Loading...' : 'Select or type...'}
                  styles={{ menu: (base) => ({ ...base, zIndex: 9999 }) }}
                />
              </div>
            )}
          </>
        )}
        {renderSaveButtons('amenities')}
        {saveAmenitiesError && <div className="alert alert-danger mt-2">{saveAmenitiesError.data?.message || 'Failed to save.'}</div>}
      </div>
    );
  } else if (subTab === 'rent') {
    content = (
      <div className="text-start px-md-2">
        <h5 style={{ color: LABEL_COLOR }} className="mb-2 fw-semibold">
          Rent Information
        </h5>
        <div className="row gx-3 gy-1">
          <div className="col-md-6">
            <EditableField
              icon="fa-credit-card"
              label="Rent Type"
              isSelect
              options={['Monthly', 'Weekly', 'Daily', 'Yearly']}
              value={unitData.rentType}
              onChange={(v) => handleFieldChange('rentType', v)}
            />
            <EditableField
              icon="fa-dollar-sign"
              type="number"
              label="Rent Amount"
              value={unitData.rentAmount}
              onChange={(v) => handleFieldChange('rentAmount', v)}
            />
            <EditableField
              icon="fa-calendar-day"
              type="number"
              label="Rent Due Day"
              value={unitData.rentDuration}
              onChange={(v) => handleFieldChange('rentDuration', v)}
            />
          </div>
          <div className="col-md-6">
            <EditableField
              icon="fa-coins"
              type="number"
              label="Deposit Amount"
              value={unitData.depositAmount}
              onChange={(v) => handleFieldChange('depositAmount', v)}
            />
            <EditableField
              icon="fa-file-invoice-dollar"
              label="Late Fee Type"
              isSelect
              options={['Fixed', 'Percentage', 'None']}
              value={unitData.lateFeeType}
              onChange={(v) => handleFieldChange('lateFeeType', v)}
            />
            <EditableField
              icon="fa-exclamation-triangle"
              type="number"
              label="Late Fee Amount"
              value={unitData.lateFeeAmount}
              onChange={(v) => handleFieldChange('lateFeeAmount', v)}
            />
          </div>
          <div className="col-md-12">
            <EditableField
              icon="fa-receipt"
              type="number"
              label="Incident Receipt Amount"
              value={unitData.incidentReceiptAmount}
              onChange={(v) => handleFieldChange('incidentReceiptAmount', v)}
            />
          </div>
        </div>
        {renderSaveButtons('rent')}
        {saveUnitError && <div className="alert alert-danger mt-2">{saveUnitError.data?.message || 'Failed to save.'}</div>}
      </div>
    );
  }

  // -----------------------------------
  //  Figure out which image is currently focused (or fallback)
  // -----------------------------------
  const currentImg = unitImages[focusedIdx] || unitImages.find((i) => !i.isPlaceholder) || {
    id: 'placeholder',
    previewUrl: nohouse,
    isPlaceholder: true,
  };

  return (
    <div style={{ overflow: 'hidden' }}>
      {content || <div className="p-4 text-center">Select a sub-tab to view details.</div>}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Unit Photos</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div
            className="position-relative mb-3 bg-light d-flex justify-content-center align-items-center"
            style={{ width: '100%', minHeight: 300, paddingTop: '56.25%', borderRadius: 8, overflow: 'hidden' }}
          >
            <PropertyImageDisplay
              s3key={currentImg.isStaged ? null : currentImg.s3key}
              localPreviewUrl={currentImg.isStaged ? currentImg.previewUrl : null}
              altText="Focused Unit"
              style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
              fallbackIcon={
                <img src={nohouse} alt="No unit" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
              }
            />
            {unitImages[focusedIdx] && !unitImages[focusedIdx].isPlaceholder && !unitImages[focusedIdx].isStaged && unitImages[focusedIdx].s3key && (
              <>
                <Button
                  variant="light"
                  className="position-absolute"
                  style={{ top: 10, right: 60, zIndex: 10 }}
                  onClick={() => handleSetCoverUnitImage(focusedIdx)}
                  title="Set as Cover"
                  disabled={managingImage || coverIdx === focusedIdx || processingImages || (isNewMode && !unitId)}
                >
                  <i className={`fa ${coverIdx === focusedIdx ? 'fa-star text-warning' : 'fa-star-o'}`} />
                </Button>
                <Button
                  variant="light"
                  className="position-absolute text-danger"
                  style={{ top: 10, right: 10, zIndex: 10 }}
                  onClick={() => handleDeleteUnitImage(focusedIdx)}
                  title="Delete"
                  disabled={managingImage || processingImages || (isNewMode && !unitId)}
                >
                  <i className="fa fa-trash" />
                </Button>
              </>
            )}
            {unitImages[focusedIdx] && unitImages[focusedIdx].isStaged && (
              <Button
                variant="light"
                className="position-absolute text-danger"
                style={{ top: 10, right: 10, zIndex: 10 }}
                onClick={() => handleDeleteUnitImage(focusedIdx)}
                title="Remove Staged"
                disabled={processingImages}
              >
                <i className="fa fa-times-circle" />
              </Button>
            )}
          </div>
          <div className="d-flex flex-wrap mb-3" style={{ gap: 8 }}>
            {unitImages.map((img, idx) => {
              if (img.isPlaceholder) return null;
              return (
                <div
                  key={img.id || idx}
                  style={{
                    border: idx === focusedIdx ? '3px solid #6366f1' : '3px solid transparent',
                    borderRadius: 8,
                    cursor: 'pointer',
                    width: 75,
                    height: 75,
                    overflow: 'hidden',
                    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                    position: 'relative',
                  }}
                  onClick={() => setFocusedIdx(idx)}
                >
                  <PropertyImageDisplay
                    s3key={img.isStaged ? null : img.s3key}
                    localPreviewUrl={img.isStaged ? img.previewUrl : null}
                    altText={`Thumbnail ${idx + 1}`}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    fallbackIcon={<i className="fa fa-image" style={{ fontSize: '2em' }} />}
                  />
                  {img.isStaged && (
                    <span className="badge bg-info position-absolute bottom-0 end-0 m-1" style={{ fontSize: '0.6rem' }}>
                      Staged
                    </span>
                  )}
                  {coverIdx === idx && !img.isStaged && (
                    <i className="fa fa-star text-warning position-absolute top-0 start-0 m-1" style={{ fontSize: '0.8rem' }}></i>
                  )}
                </div>
              );
            })}
            {(unitId || (isNewMode && unitData.name.trim())) && (
              <div
                style={{
                  border: '2px dashed #6366f1',
                  borderRadius: 8,
                  cursor: processingImages || savingUnit || gettingUploadUrl || uploadingToS3 ? 'not-allowed' : 'pointer',
                  width: 75,
                  height: 75,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#6366f1',
                  backgroundColor: '#f8f9fa',
                  opacity: processingImages || savingUnit || gettingUploadUrl || uploadingToS3 ? 0.5 : 1,
                }}
                onClick={() => !(processingImages || savingUnit || gettingUploadUrl || uploadingToS3) && fileInputRef.current.click()}
                title="Add Photos"
              >
                <i className="fa fa-plus fa-2x" />
              </div>
            )}
          </div>
          <input
            type="file"
            accept="image/*"
            multiple
            style={{ display: 'none' }}
            ref={fileInputRef}
            onChange={handleAddUnitImage}
            disabled={processingImages || savingUnit || gettingUploadUrl || uploadingToS3 || (!unitId && !isNewMode) || (isNewMode && !unitData.name.trim())}
          />
          {(processingImages || gettingUploadUrl || uploadingToS3 || managingImage) && (
            <div className="text-center small text-muted mt-2">
              {processingImages
                ? 'Processing images...'
                : gettingUploadUrl
                ? 'Getting upload URL...'
                : uploadingToS3
                ? 'Uploading to S3...'
                : 'Finalizing in DB...'}
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};
