import React, { useState, useRef, useEffect } from 'react';
import { FaPaperclip, FaArrowUp, FaDatabase, FaTrash, FaEye, FaInfoCircle, FaTimes, FaFileAlt, FaSearch } from 'react-icons/fa';
import { useManagePropertyDocumentMutation } from '../../api/propertyApi';
import { env } from '../../config/env';
import {
  useGetS3UploadUrlMutation,
  useUploadFileToS3Mutation,
  useGetS3DownloadUrlQuery,
} from '../../api/uploadApi';
import { useAskAIDatabaseMutation, useGetAIDocumentsQuery } from '../../api/aiApi';


export function PropertyAI({ propertyId, userId, onUnitSaved }) {
  const [file, setFile] = useState(null);
  const [question, setQuestion] = useState('');
  const [qaHistory, setQaHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fileLoading, setFileLoading] = useState(false);
  const [error, setError] = useState(null);
  const [uploadedMsg, setUploadedMsg] = useState(false);
  const [knowledgeBase, setKnowledgeBase] = useState([]);
  const [showKnowledgeBase, setShowKnowledgeBase] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState(null); // For modal view
  const [scopedDocument, setScopedDocument] = useState(null); // For scoped chat
  const [searchTerm, setSearchTerm] = useState(''); // For filtering documents
  const [showDocSearch, setShowDocSearch] = useState(false);
  const [pendingConfirmation, setPendingConfirmation] = useState(null);
  const [chatWithKnowledgeBase, setChatWithKnowledgeBase] = useState(true); // Default to true

  // RTK Query Hooks
  const { data: aiDocuments, isLoading: isLoadingDocuments, refetch: refetchDocuments } = useGetAIDocumentsQuery(
    { property_id: propertyId, uid: userId },
    { skip: !propertyId || !userId }
  );
  const [manageDocument] = useManagePropertyDocumentMutation();
  const [getS3UploadUrl] = useGetS3UploadUrlMutation();
  const [uploadFileToS3] = useUploadFileToS3Mutation();
  const [askAIDatabase] = useAskAIDatabaseMutation();
  const { data: downloadData, isLoading: loadingUrl } = useGetS3DownloadUrlQuery(
    selectedDoc?.s3_key,
    { skip: !selectedDoc?.s3_key }
  );

  const fileInputRef = useRef(null);
  const chatEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [qaHistory, fileLoading, error, uploadedMsg, pendingConfirmation]);

  useEffect(() => {
    if (aiDocuments) {
      setKnowledgeBase(aiDocuments || []);
    }
  }, [aiDocuments]);

  useEffect(() => {
    if (propertyId && userId) {
      refetchDocuments();
    }
  }, [propertyId, userId, refetchDocuments]);

  // Main file upload handler
  const handleFileUpload = async (fileToUpload) => {
    if (!fileToUpload) return;
    
    setScopedDocument(null);
    setFileLoading(true);
    setLoading(true);
    setError(null);

    try {
        if (fileToUpload.size > 50 * 1024 * 1024) {
            throw new Error("File too large. Please upload a document less than 50MB.");
        }

        // Step 1: Get S3 presigned URL
        const s3Response = await getS3UploadUrl({
            key: `uploads/property_${propertyId}/docs/${Date.now()}_${fileToUpload.name}`,
            fileType: fileToUpload.type,
            fileName: fileToUpload.name,
        }).unwrap();

        // Step 2: Upload file to S3
        await uploadFileToS3({
            url: s3Response.data.url,
            file: fileToUpload,
        }).unwrap();

        // Step 3: Perform OCR
        const fd = new FormData();
        fd.append('file', fileToUpload);
        fd.append('s3Key', s3Response.data.key);
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 60000);
        const ocrRes = await fetch('/ocr', {
            method: 'POST',
            headers: { Accept: 'application/json' },
            body: fd,
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!ocrRes.ok) throw new Error(`OCR Service Error: ${ocrRes.status} ${await ocrRes.text()}`);
        
        const contentType = ocrRes.headers.get('content-type') || '';
        let ocrData, txt;
        if (contentType.includes('application/json')) {
            ocrData = await ocrRes.json();
            txt = ocrData.text || (ocrData.results?.[0]?.extracted_text ? ocrData.results[0].extracted_text.map(l => l.line).join('\n') : JSON.stringify(ocrData));
        } else {
            txt = await ocrRes.text();
        }

        if (!txt?.trim()) throw new Error("No text could be extracted.");

        // Step 4: Call backend to manage document (insert, classify, add to Chroma)
        const payload = {
            action: 'insert',
            uid: userId,
            property_id: propertyId,
            s3_bucket: env.S3_BUCKET,
            s3_key: s3Response.data.key,
            file_name: fileToUpload.name,
            file_size_bytes: fileToUpload.size,
            mime_type: fileToUpload.type,
            extracted_text: txt,
            add_to_chroma: true,
        };
        
        await manageDocument(payload).unwrap();
        await refetchDocuments(); // Ensure knowledge base is refreshed after upload
        setKnowledgeBase(aiDocuments => Array.isArray(aiDocuments) ? [...aiDocuments] : []); // force update

        setUploadedMsg(true);
        appendQA(`Uploaded ${fileToUpload.name}`, "Document processed and added to your knowledge base. You can now ask questions about it.");

    } catch (e) {
        console.error("Error during file processing:", e);
        setError(e.message || "Failed to process document.");
    } finally {
        setFile(null);
        setFileLoading(false);
        setLoading(false);
        if(fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDeleteDocument = async (docId, chromaId) => {
    if (!window.confirm("Are you sure you want to delete this document? This action cannot be undone.")) {
      return;
    }
    try {
      await manageDocument({
        action: 'delete',
        doc_id: docId,
        chroma_id: chromaId,
        property_id: propertyId,
        uid: userId,
      }).unwrap();
      setKnowledgeBase(docs => docs.filter(doc => doc.doc_id !== docId));
      setSelectedDoc(null);
      if (scopedDocument?.doc_id === docId) {
        setScopedDocument(null);
      }
      setError(null);
    } catch (e) {
      console.error("Error deleting document:", e);
      setError("Failed to delete document. Please try again.");
    }
  };

  const closeViewModal = () => setSelectedDoc(null);

  const appendQA = (q, a) => setQaHistory(prev => [...prev, { q, a }]);

  function formatBoldMarkdown(text) {
    if (!text) return '';
    return text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  }

  function formatDate(iso) {
    if (!iso) return 'Unknown date';
    try {
      return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
    } catch (e) {
      return 'Invalid Date';
    }
  }

  async function handleSend() {
    if (loading) return;
    setError(null);
    setUploadedMsg(false);
    if (pendingConfirmation) return;

    // If a file is selected, upload it first
    if (file) {
      await handleFileUpload(file);
      // After upload, clear file and continue to send question if present
      // Wait for fileLoading to finish before allowing next send
      if (!question.trim()) return;
    }
    // Now send the question if present
    if (!question.trim()) return;
    setLoading(true);
    const qTrim = question.trim();
    try {
      appendQA(qTrim, '__TYPING__');
      const payload = {
        question: qTrim,
        uid: userId,
        filters: { propertyId },
        prioritizeDocuments: chatWithKnowledgeBase,
      };
      if (scopedDocument) {
        payload.scopedChromaId = scopedDocument.chroma_id;
      }

      const response = await askAIDatabase(payload).unwrap();
      const data = response;

      if (data.requiresConfirmation) {
        setPendingConfirmation({
          action: data.action,
          entity: data.entityType,
          originalQuestion: qTrim,
          confirmationMessage: data.confirmationMessage,
          confirmationData: data.confirmationData
        });
        setQaHistory(prev => {
          const updated = [...prev];
          updated.pop();
          return updated;
        });
      } else if (data.error) {
        throw new Error(data.error);
      } else {
        setQaHistory(prev => {
          const updated = [...prev];
          updated[updated.length - 1].a = data.answer;
          return updated;
        });
      }
      setQuestion('');
      setSearchTerm('');
      setShowDocSearch(false);
    } catch (e) {
      setError(e.message);
      setQaHistory(prev => {
        const updated = [...prev];
        if (updated.length > 0 && updated[updated.length - 1].a === '__TYPING__') {
          updated[updated.length - 1].a = "Sorry, I couldn't process that request.";
        }
        return updated;
      });
    } finally {
      setLoading(false);
    }
  }
  
  const handleQuestionChange = (e) => {
    const value = e.target.value;
    setQuestion(value);

    if (value.startsWith('@') && !scopedDocument) {
      setShowDocSearch(true);
      setSearchTerm(value.substring(1));
    } else {
      setShowDocSearch(false);
      setSearchTerm('');
    }
  };

  const selectDocumentForScope = (doc) => {
    setScopedDocument(doc);
    setShowDocSearch(false);
    setSearchTerm('');
    setQuestion('');
    appendQA(`Let's talk about ${doc.file_name}`, `I am now ready to answer questions about **${doc.file_name}**. What would you like to know?`);
    inputRef.current?.focus();
  };

  const clearScopedDocument = () => {
    setScopedDocument(null);
    // Do not append 'Exited document chat.' message
  };
  
  const clearFileSelection = () => {
    setFile(null);
    if(fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  }

  const filteredKnowledgeBase = showDocSearch
    ? (searchTerm === ''
        ? knowledgeBase
        : knowledgeBase.filter(doc =>
            doc.file_name && doc.file_name.toLowerCase().includes(searchTerm.toLowerCase())
          )
      )
    : [];

  const toggleKnowledgeBase = () => setShowKnowledgeBase(!showKnowledgeBase);
  const toggleChatWithKnowledgeBase = () => setChatWithKnowledgeBase(!chatWithKnowledgeBase);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files?.[0] || null;
    if(selectedFile) {
      setFile(selectedFile);
      // Do NOT upload here, wait for button click
    }
  };

  return (
    <div className="ai-container" style={ui.shell}>
      <header className="ai-header" style={ui.hero}>
        <h1 style={ui.title}>Property AI Assistant</h1>
        <div style={ui.toolbar}>
          <button onClick={toggleKnowledgeBase} className="toolbar-btn" style={showKnowledgeBase ? ui.activeBtn : ui.toolbarBtn}>
            <FaDatabase style={{ marginRight: '8px' }} /> Knowledge Base
          </button>
          <button onClick={toggleChatWithKnowledgeBase} className="toolbar-btn" style={chatWithKnowledgeBase ? ui.activeBtn : ui.toolbarBtn} title={chatWithKnowledgeBase ? "Prioritizing document knowledge" : "Prioritizing property data"}>
            <FaInfoCircle style={{ marginRight: '8px' }} />
            {chatWithKnowledgeBase ? "Chat with Docs" : "Chat with Data"}
          </button>
        </div>
        {qaHistory.length === 0 && !fileLoading && !uploadedMsg && !error && !showKnowledgeBase && (
          <div style={ui.samples}>
            <p style={ui.samplesHead}>Upload a document, or type <code style={ui.code}>@</code> to search and chat with a specific file.</p>
          </div>
        )}
      </header>

      <div className="ai-content">
        {showKnowledgeBase ? (
          // Knowledge Base View
          <div className="ai-kb-container" style={ui.knowledgeBase}>
            <h2 className="ai-kb-title" style={ui.kbTitle}>Document Knowledge Base</h2>
            {isLoadingDocuments ? <div style={ui.loading}>Loading documents...</div>
             : knowledgeBase.length === 0 ? <div style={ui.emptyKb}>No documents in knowledge base yet.</div>
             : <div className="ai-kb-grid custom-scrollbar" style={ui.docGrid}>
                  {knowledgeBase?.map((doc, idx) => (
                    <div key={idx} className="doc-card" style={ui.docCard}>
                      <div style={ui.docIcon}><FaFileAlt /></div>
                      <div style={ui.docInfo}>
                        <h3 style={ui.docName}>{doc.file_name}</h3>
                        <p style={ui.docType}>{doc.document_type || 'Unknown type'}</p>
                        <p style={ui.docDate}>{formatDate(doc.created_at)}</p>
                        <div style={ui.docActions}>
                          <button style={ui.actionBtn} onClick={() => setSelectedDoc(doc)} title="View document details"><FaEye /></button>
                          <button style={{ ...ui.actionBtn, ...ui.deleteBtn }} onClick={() => handleDeleteDocument(doc.doc_id, doc.chroma_id)} title="Delete document"><FaTrash /></button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
            }
          </div>
        ) : (
          // Chat View
          <div className="ai-chat-container" style={ui.chatContainer}>
            {/* Banner for selected document (scopedDocument) */}
            {scopedDocument && (
              <div style={{
                background: '#e7f1ff',
                color: '#004085',
                padding: '10px 16px',
                borderRadius: '10px',
                marginBottom: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                fontWeight: 500,
                fontSize: '1rem',
              }}>
                <span>
                  Chatting with: <strong>{scopedDocument.file_name}</strong>
                </span>
                <button onClick={clearScopedDocument} style={{
                  background: 'none',
                  border: 'none',
                  color: '#004085',
                  fontSize: '1.2rem',
                  cursor: 'pointer',
                  marginLeft: '12px',
                  display: 'flex',
                  alignItems: 'center',
                }} title="Exit document chat">
                  <FaTimes />
                </button>
              </div>
            )}
            <section className="ai-message-box custom-scrollbar" style={ui.msgBox}>
              {fileLoading && <div style={{ ...ui.bubble, ...ui.sys }}>Please wait, document is being processed...</div>}
              {uploadedMsg && <div style={{ ...ui.bubble, ...ui.sys }}>Document processed and added to knowledge base.</div>}
              {qaHistory.map(({ q, a }, i) => (
                <div key={i} style={{ marginBottom: 12 }}>
                  <div style={{ ...ui.bubble, ...ui.user }}>{q}</div>
                  <div style={{ ...ui.bubble, ...ui.ai }}>
                    {a === '__TYPING__' ? <div className="typing-indicator"><span></span><span></span><span></span></div> : <span dangerouslySetInnerHTML={{ __html: formatBoldMarkdown(a) }} />}
                  </div>
                </div>
              ))}
              {error && <div style={{ ...ui.bubble, ...ui.err }}>Error: {error}</div>}
              <div ref={chatEndRef} />
            </section>
            
            <div style={{position: 'relative', margin: '0 1rem'}}>
              {showDocSearch && (
                <div style={ui.docSearchPopup} className="custom-scrollbar">
                  {filteredKnowledgeBase.length > 0 ? (
                    <ul style={ui.docSearchList}>
                      {filteredKnowledgeBase.map(doc => (
                        <li key={doc.doc_id} className="docSearchItem" onClick={() => selectDocumentForScope(doc)} style={ui.docSearchItem}>
                          <FaFileAlt style={{marginRight: '10px', color: '#6c757d'}}/>
                          <div style={{display: 'flex', flexDirection: 'column'}}>
                            <span style={{fontWeight: 500}}>{doc.file_name}</span>
                            <span style={{fontSize: '0.8em', color: '#6c757d'}}>{doc.document_type}</span>
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <div style={ui.docSearchEmpty}><FaSearch style={{marginRight: '8px'}}/> No documents found for "{searchTerm}"</div>
                  )}
                </div>
              )}

              <div className="ai-input-area" style={ui.tray}>
                <button className="icon-btn" style={ui.iconBtn} onClick={() => fileInputRef.current?.click()} disabled={loading}><FaPaperclip /></button>
                <input type="file" accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg" ref={fileInputRef} style={{ display: 'none' }}
                  onChange={handleFileChange}
                />
                <div style={{ flexGrow: 1, display: 'flex', flexDirection: 'column', position: 'relative' }}>
                  {file && (
                    <div style={{ ...ui.filePreview, background: '#e7f1ff', color: '#004085', marginBottom: 8 }}>
                      <FaFileAlt style={{ marginRight: 4 }} />
                      <span>{file.name}</span>
                      <button onClick={clearFileSelection} style={ui.clearFileBtn}><FaTimes /></button>
                    </div>
                  )}
                  <input ref={inputRef} style={ui.textInput(scopedDocument)} 
                    placeholder={scopedDocument ? `Ask about ${scopedDocument.file_name}...` : "Type a message, or use '@' to search documents..."}
                    value={question} 
                    disabled={loading} 
                    onChange={handleQuestionChange} 
                    onKeyDown={e => e.key === 'Enter' && handleSend()} 
                  />
                </div>
                <button onClick={handleSend} disabled={loading || (!question.trim() && !file)} style={ui.sendBtn(loading || (!question.trim() && !file))}>
                  {loading ? <span style={ui.spinner} /> : <FaArrowUp />}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {selectedDoc && (
        <><div style={ui.modalBackdrop} onClick={closeViewModal} /><div style={ui.modal}><div style={ui.modalContent}><div style={ui.modalHeader}><h3 style={ui.modalTitle}>Document Details</h3><button style={ui.closeBtn} onClick={closeViewModal}>×</button></div><div style={ui.modalBody} className="custom-scrollbar"><div style={{ marginBottom: '16px' }}><p><strong>File Name:</strong> {selectedDoc.file_name}</p><p><strong>Document Type:</strong> {selectedDoc.document_type || 'Unknown'}</p><p><strong>Category:</strong> {selectedDoc.category || 'Uncategorized'}</p><p><strong>Upload Date:</strong> {formatDate(selectedDoc.created_at)}</p><p><strong>Size:</strong> {selectedDoc.file_size ? `${Math.round(selectedDoc.file_size / 1024)} KB` : 'N/A'}</p></div>{selectedDoc.summary && (<div style={ui.summarySection}><h4 style={ui.sectionTitle}>Summary</h4><p style={ui.summary}>{selectedDoc.summary}</p></div>)}{selectedDoc.s3_key && (<div style={ui.downloadSection}>{loadingUrl ? (<p>Loading document link...</p>) : downloadData?.data?.url ? (<a href={downloadData.data.url} target="_blank" rel="noopener noreferrer" style={ui.downloadBtn}>View Document</a>) : (<p>Unable to load document link.</p>)}</div>)}</div><div style={ui.modalFooter}><button style={ui.secondaryBtn} onClick={closeViewModal}>Close</button><button style={ui.dangerBtn} onClick={() => handleDeleteDocument(selectedDoc.doc_id, selectedDoc.chroma_id)}>Delete Document</button></div></div></div></>
      )}
    </div>
  );
}

// Styles 
const ui = {
  shell: { background: '#f8f9fa', maxWidth: '100%', width: '100%', color: '#333', padding: '0', overflow: 'hidden', display: 'flex', flexDirection: 'column', height: '100%', fontFamily: "'Inter', sans-serif" },
  hero: { textAlign: 'center', marginBottom: '1rem', padding: '1rem' },
  title: { fontSize: 'clamp(1.5rem, 4vw, 1.8rem)', fontWeight: 700, margin: 0, color: '#2c3e50' },
  toolbar: { display: 'flex', justifyContent: 'center', marginTop: '1rem', flexWrap: 'wrap', gap: '0.75rem' },
  toolbarBtn: { background: '#fff', border: '1px solid #dee2e6', borderRadius: '20px', padding: '0.6rem 1.2rem', color: '#495057', fontSize: '0.9rem', fontWeight: 500, cursor: 'pointer', display: 'flex', alignItems: 'center' },
  activeBtn: { background: 'linear-gradient(45deg, #0d6efd, #0d6efd)', border: '1px solid #0d6efd', borderRadius: '20px', padding: '0.6rem 1.2rem', color: '#fff', fontSize: '0.9rem', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', boxShadow: '0 4px 12px rgba(0, 123, 255, 0.3)' },
  samples: { marginTop: '1.5rem', fontSize: '0.9rem', color: '#6c757d', padding: '0 1rem' },
  samplesHead: { fontWeight: 500, marginBottom: '0.5rem', color: '#495057' },
  code: { background: '#e9ecef', padding: '2px 6px', borderRadius: '4px', fontFamily: 'monospace', color: '#0d6efd' },
  tray: { display: 'flex', alignItems: 'center', background: '#fff', borderRadius: '24px', padding: '0.5rem', gap: '0.5rem', boxShadow: '0 4px 15px rgba(0,0,0,0.08)', width: '100%', minHeight: '3.5rem', border: '1px solid #e9ecef' },
  iconBtn: { background: 'transparent', border: 'none', fontSize: '1.25rem', color: '#6c757d', cursor: 'pointer', width: '2.5rem', height: '2.5rem', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  textInput: (hasIndicator) => ({ flexGrow: 1, border: 'none', outline: 'none', background: 'transparent', fontSize: '1rem', padding: hasIndicator ? '1.2rem 0.5rem 0.5rem' : '0.5rem', minWidth: '50px' }),
  sendBtn: (disabled) => ({ background: disabled ? '#ced4da' : 'linear-gradient(45deg, #0d6efd, #0d6efd)', color: '#fff', border: 'none', fontSize: '1.25rem', width: '2.75rem', height: '2.75rem', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: disabled ? 'not-allowed' : 'pointer', transition: 'all .2s', flexShrink: 0, boxShadow: disabled ? 'none' : '0 2px 8px rgba(0, 123, 255, 0.4)' }),
  spinner: { width: '1.25rem', height: '1.25rem', border: '2px solid rgba(255,255,255,.5)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 1s linear infinite' },
  msgBox: { background: '#f8f9fa', padding: '1rem', flex: 1, overflow: 'auto', wordWrap: 'break-word', minHeight: '200px', marginBottom: '0.75rem' },
  bubble: { padding: '0.75rem 1rem', borderRadius: '18px', fontSize: '0.95rem', maxWidth: '85%', whiteSpace: 'pre-wrap', lineHeight: '1.5' },
  user: { background: '#0d6efd', color: '#fff', marginLeft: 'auto', borderBottomRightRadius: '4px' },
  ai: { background: '#fff', color: '#343a40', border: '1px solid #e9ecef', marginTop: '0.5rem', borderBottomLeftRadius: '4px' },
  sys: { background: '#e9ecef', color: '#6c757d', fontStyle: 'italic', textAlign: 'center', marginBottom: '0.75rem', padding: '0.5rem 0.75rem', borderRadius: '8px' },
  err: { background: '#f8d7da', border: '1px solid #f5c6cb', color: '#721c24', padding: '0.75rem 1rem', borderRadius: '8px' },
  knowledgeBase: { background: '#fff', padding: '1.25rem', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', flex: 1, display: 'flex', flexDirection: 'column', width: '100%', overflow: 'hidden' },
  kbTitle: { fontSize: '1.25rem', fontWeight: 600, marginBottom: '1rem', color: '#333' },
  loading: { textAlign: 'center', padding: '1.25rem', color: '#666' },
  emptyKb: { textAlign: 'center', padding: '1.875rem 0', color: '#666', fontStyle: 'italic' },
  docGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem', overflowY: 'auto', flex: 1, padding: '0.5rem', },
  docCard: { display: 'flex', padding: '1rem', borderRadius: '12px', border: '1px solid #e9ecef', background: '#fff', transition: 'all 0.2s ease-in-out' },
  docIcon: { fontSize: '1.5rem', marginRight: '1rem', color: '#0d6efd', flexShrink: 0, paddingTop: '4px' },
  docInfo: { flex: 1, overflow: 'hidden', minWidth: 0 },
  docName: { fontSize: '1rem', fontWeight: 600, marginBottom: '0.25rem', color: '#212529', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' },
  docType: { fontSize: '0.8125rem', color: '#6c757d', marginTop: 0, marginBottom: '0.25rem', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' },
  docDate: { fontSize: '0.75rem', color: '#adb5bd', margin: 0 },
  docActions: { display: 'flex', gap: '0.5rem', marginTop: '0.75rem', flexWrap: 'wrap' },
  actionBtn: { background: '#f1f3f5', border: 'none', borderRadius: '50%', width: '32px', height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.875rem', cursor: 'pointer', color: '#495057' },
  deleteBtn: { color: '#dc3545' },
  modalBackdrop: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0, 0, 0, 0.5)', zIndex: 1000, },
  modal: { position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 1001, width: '90%', maxWidth: '520px', },
  modalContent: { background: '#fff', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', overflow: 'hidden', width: '100%', },
  modalHeader: { padding: '1rem 1.25rem', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#f8f9fa', },
  modalTitle: { margin: 0, fontSize: '1.125rem', fontWeight: 600, color: '#212529', },
  closeBtn: { background: 'transparent', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#666', lineHeight: '1', },
  modalBody: { padding: '1.25rem', maxHeight: '60vh', overflowY: 'auto', },
  modalFooter: { padding: '1rem 1.25rem', borderTop: '1px solid #eee', display: 'flex', justifyContent: 'flex-end', background: '#f8f9fa', flexWrap: 'wrap', gap: '0.625rem' },
  summarySection: { marginTop: '1rem', padding: '1rem', background: '#f8f9fa', borderRadius: '6px', },
  sectionTitle: { fontSize: '1rem', fontWeight: 600, marginBottom: '0.5rem', color: '#333', },
  summary: { fontSize: '0.875rem', lineHeight: '1.6', color: '#444', margin: 0, },
  downloadSection: { marginTop: '1.25rem', textAlign: 'center', },
  downloadBtn: { display: 'inline-block', padding: '0.625rem 1.25rem', background: '#0d6efd', color: '#fff', textDecoration: 'none', borderRadius: '5px', fontWeight: 500 },
  secondaryBtn: { padding: '0.625rem 1.25rem', background: '#f8f9fa', border: '1px solid #dee2e6', borderRadius: '4px', color: '#444', fontSize: '0.875rem', fontWeight: 500, cursor: 'pointer', },
  dangerBtn: { padding: '0.625rem 1.25rem', background: '#dc3545', border: 'none', borderRadius: '4px', color: '#fff', fontSize: '0.875rem', fontWeight: 500, cursor: 'pointer', },
  chatContainer: { display: 'flex', flexDirection: 'column', flex: 1, width: '100%', overflow: 'hidden', minHeight: 0, position: 'relative', background: '#f8f9fa' },
  docSearchPopup: { position: 'absolute', bottom: '100%', left: 0, right: 0, background: '#fff', border: '1px solid #e9ecef', borderRadius: '12px', boxShadow: '0 -4px 20px rgba(0,0,0,0.08)', maxHeight: '220px', overflowY: 'auto', zIndex: 10, marginBottom: '0.5rem' },
  docSearchList: { listStyle: 'none', padding: 0, margin: 0 },
  docSearchItem: { display: 'flex', alignItems: 'center', padding: '0.75rem 1rem', cursor: 'pointer', borderBottom: '1px solid #f5f5f5', fontSize: '0.9rem' },
  docSearchEmpty: { padding: '1rem', textAlign: 'center', color: '#6c757d' },
  scopedDocIndicator: { position: 'absolute', top: 0, left: 0, right: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#e7f1ff', padding: '0.2rem 0.75rem', borderBottom: '1px solid #bce8f1', borderRadius: '12px 12px 0 0', fontSize: '0.8rem', color: '#004085' },
  clearScopedBtn: { background: 'none', border: 'none', fontSize: '1rem', color: '#004085', cursor: 'pointer', lineHeight: 1, padding: '0 4px' },
  filePreview: { display: 'flex', alignItems: 'center', gap: '10px', padding: '0.5rem', border: '1px solid #e9ecef', borderRadius: '4px', background: '#fff' },
  clearFileBtn: { background: 'none', border: 'none', fontSize: '1rem', color: '#6c757d', cursor: 'pointer', lineHeight: 1, padding: '0 4px' },
  uploadBtn: { background: 'linear-gradient(45deg, #0d6efd, #0d6efd)', color: '#fff', border: 'none', fontSize: '1rem', padding: '0.5rem 1rem', borderRadius: '4px', cursor: 'pointer', transition: 'all 0.2s', flexShrink: 0 },
};

const styleSheet = document.createElement('style');
styleSheet.textContent = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
  @keyframes spin { to { transform: rotate(360deg); } }
  .typing-indicator span { display: inline-block; width: 6px; height: 6px; background: #7B5FFF; border-radius: 50%; animation: typing-bounce 1s infinite alternate; }
  .typing-indicator span:nth-child(2) { animation-delay: 0.2s; }
  .typing-indicator span:nth-child(3) { animation-delay: 0.4s; }
  @keyframes typing-bounce { to { transform: translateY(-6px); opacity: 0.5; } }
  .custom-scrollbar { scrollbar-width: thin; scrollbar-color: #e0e0e0 #f8f8f8; }
  .custom-scrollbar::-webkit-scrollbar { width: 6px; height: 6px; }
  .custom-scrollbar::-webkit-scrollbar-track { background: #f8f8f8; }
  .custom-scrollbar::-webkit-scrollbar-thumb { background: #e0e0e0; border-radius: 8px; }
  .ai-container, .ai-content, .ai-chat-container, .ai-kb-container { display: flex; flex-direction: column; overflow: hidden; }
  .ai-header, .ai-kb-title, .ai-input-area { flex-shrink: 0; }
  .ai-content, .ai-chat-container, .ai-kb-container, .ai-message-box, .ai-kb-grid { flex: 1; min-height: 0; }
  .ai-message-box { padding-bottom: 6rem; }
  .docSearchItem:hover { background-color: #f0f7ff; }
  .toolbar-btn { transition: all 0.2s ease-in-out; }
  .toolbar-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.05); }
  .clear-btn:hover { opacity: 1; }
  .icon-btn:hover { background-color: #f1f3f5; }
  .doc-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.08); border-color: #ced4da; }
  .action-btn:hover { background-color: #e9ecef; }
  .downloadBtn:hover { background: #0b5ed7; }
  @media (max-width: 768px) {
    .docGrid { grid-template-columns: 1fr !important; }
  }
`;
document.head.appendChild(styleSheet);

export default PropertyAI;
