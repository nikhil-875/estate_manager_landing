import React, { useState } from 'react'

const SendReportModal = ({ show, onClose, onSend, defaultEmails = [], defaultMessage = '', isSending = false }) => {
  const [emails, setEmails] = useState(defaultEmails)
  const [input, setInput] = useState('')
  const [message, setMessage] = useState(defaultMessage)
  const [error, setError] = useState('')

  const addEmail = () => {
    const email = input.trim()
    if (!email) return
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      setError('Invalid email address')
      return
    }
    if (emails.includes(email)) {
      setError('Email already added')
      return
    }
    setEmails([...emails, email])
    setInput('')
    setError('')
  }

  const removeEmail = (email) => {
    setEmails(emails.filter(e => e !== email))
  }

  const handleInputKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === ',' || e.key === ';') {
      e.preventDefault()
      addEmail()
    }
  }

  const handleSend = (e) => {
    e.preventDefault()
    if (emails.length === 0) {
      setError('Please add at least one email address')
      return
    }
    setError('')
    onSend(emails, message)
  }

  if (!show) return null

  return (
    <>
      <div className="modal-backdrop fade show" />
      <div className="modal show d-block" style={{ zIndex: 2100 }} tabIndex="-1">
        <div className="modal-dialog modal-md modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Send Transaction Report</h5>
              <button className="btn-close" onClick={onClose} />
            </div>
            <form onSubmit={handleSend}>
              <div className="modal-body">
                <div className="mb-3">
                  <label className="form-label">Recipient Emails</label>
                  <div className="d-flex flex-wrap gap-2 mb-2">
                    {emails.map(email => (
                      <span key={email} className="badge bg-primary">
                        {email}
                        <button type="button" className="btn-close btn-close-white ms-2" style={{ fontSize: '0.7em' }} onClick={() => removeEmail(email)} />
                      </span>
                    ))}
                  </div>
                  <input
                    type="email"
                    className="form-control"
                    placeholder="Type email and press Enter"
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={handleInputKeyDown}
                  />
                  {error && <div className="text-danger small mt-1">{error}</div>}
                </div>
                {/* <div className="mb-3">
                  <label className="form-label">Message (optional)</label>
                  <textarea
                    className="form-control"
                    rows={3}
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    placeholder="Add a message to include in the email..."
                  />
                </div> */}
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" type="button" onClick={onClose} disabled={isSending}>Cancel</button>
                <button className="btn btn-primary" type="submit" disabled={isSending}>
                  {isSending ? 'Sending...' : 'Send'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  )
}

export default SendReportModal 