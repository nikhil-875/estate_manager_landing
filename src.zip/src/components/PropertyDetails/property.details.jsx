import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Modal, Button } from 'react-bootstrap';
import { EditableField, LABEL_COLOR } from '../EditableField';
import { toast } from 'react-toastify';
import {
  useGetSinglePropertyDetailsQuery,
  useManagePropertyMutation,
  useManagePropertyImageMutation,
} from '../../api/propertyApi';
import { useGetS3UploadUrlMutation, useUploadFileToS3Mutation, useGetS3DownloadUrlQuery } from '../../api/uploadApi';
import { loadGoogleMapsApi, isGoogleMapsLoaded } from '../../utils/googleMapsLoader';
import { env } from '../../config/env';

const nohouse = 'https://placehold.co/120x120/e1e1e1/777777?text=No+Photo';

// Define PropertyImageDisplay sub-component here
const PropertyImageDisplay = ({ s3key, localPreviewUrl, altText, fallbackIcon, propertyId, userId, ...imgProps }) => {
  const { data: downloadUrlData, isLoading: isLoadingUrl, isError: isUrlError } = useGetS3DownloadUrlQuery(s3key, {
    skip: !s3key || !!localPreviewUrl, // Skip if it's a local preview or no s3key
    refetchOnMountOrArgChange: true
  });

  const commonOnError = (e) => {
    e.target.onerror = null;
    e.target.src = nohouse;
  };

  if (localPreviewUrl) {
    return <img src={localPreviewUrl} alt={altText || "local preview"} {...imgProps} onError={commonOnError} />;
  }

  if (isLoadingUrl) {
    return (
      <div style={{ ...imgProps.style, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e9ecef', color: '#6c757d' }} title="Loading image...">
        {fallbackIcon || <i className="fa fa-spinner fa-spin"></i>}
      </div>
    );
  }

  if (isUrlError || !downloadUrlData?.data?.url) {
    return (
      <div style={{ ...imgProps.style, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e9ecef', color: '#dc3545' }} title="Error loading image">
        {fallbackIcon || <i className="fa fa-exclamation-triangle"></i>}
      </div>
    );
  }

  return <img src={downloadUrlData.data.url} alt={altText || s3key} {...imgProps} onError={commonOnError} />;
};

export const PropertyDetails = ({ propertyId, userId, userType, isNewMode, onPropertySaved }) => {
  const {
    data: fetchedPropertyData,
    isLoading,
    isError: isFetchError,
    error: fetchError,
    refetch,
  } = useGetSinglePropertyDetailsQuery(
    { property_id: propertyId, uid: userId },
    {
      skip: !propertyId || isNewMode,
      refetchOnMountOrArgChange: true
    }
  );

  const [manageProperty, { isLoading: isSaving, error: saveError }] = useManagePropertyMutation();
  const [managePropertyImage, { isLoading: isUpdatingDbForImage, error: imageDbError }] = useManagePropertyImageMutation();
  const [getS3UploadUrl, { isLoading: isGettingS3Url, error: _getS3UrlError }] = useGetS3UploadUrlMutation();
  const [uploadFileToS3, { isLoading: isUploadingToS3, error: _uploadToS3Error }] = useUploadFileToS3Mutation();

  const defaultFields = {
    name: '', type: 'House', address: '', description: '',
    country: '', state: '', city: '', zip_code: '', map_link: '',
    latitude: '', longitude: '',
  };

  const [fields, setFields] = useState(defaultFields);
  // images state now holds objects: { id, s3key?, type?, isStaged, file?, previewUrl? }
  // or { id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }
  const [images, setImages] = useState([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
  const [initialFields, setInitialFields] = useState(defaultFields);
  const [initialImages, setInitialImages] = useState([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);


  const [focusIdx, setFocusIdx] = useState(0);
  const [favIdx, setFavIdx] = useState(null); // Stores index of favorite image in 'images' array
  const [showModal, setShowModal] = useState(false);
  const [isProcessingImagesOnSave, setIsProcessingImagesOnSave] = useState(false); // For save button loading state

  const fileInputRef = useRef(null);
  const addressInputRef = useRef(null);
  const autocompleteRef = useRef(null);
  const [isGoogleApiLoaded, setIsGoogleApiLoaded] = useState(false);

  const handlePlaceSelect = useCallback(() => {
    if (autocompleteRef.current) {
      const place = autocompleteRef.current.getPlace();
      console.log("place", place);
      if (place && place.address_components) {
        const addressComponents = place.address_components;
        const getComponent = (type) =>
          addressComponents.find(c => c.types.includes(type))?.long_name || '';

        setFields(prev => ({
          ...prev,
          address: place.formatted_address || prev.address,
          city: getComponent('locality') || prev.city,
          state: getComponent('administrative_area_level_1') || prev.state,
          country: getComponent('country') || prev.country,
          zip_code: getComponent('postal_code') || prev.zip_code,
          map_link: place.url || prev.map_link,
          latitude: place.geometry?.location?.lat() || prev.latitude,
          longitude: place.geometry?.location?.lng() || prev.longitude,
        }));
      }
    }
  }, []);

  const initializeAutocomplete = useCallback(() => {
    if (isGoogleMapsLoaded() && addressInputRef.current) {
      try {
        // Clear any previous autocomplete
        if (autocompleteRef.current && window.google?.maps?.event) {
          window.google.maps.event.clearInstanceListeners(autocompleteRef.current);
          autocompleteRef.current = null;
        }

        console.log("Using legacy Autocomplete API - still supported until March 2025");
        // Use the legacy Autocomplete which is still supported until March 2025
        autocompleteRef.current = new window.google.maps.places.Autocomplete(
          addressInputRef.current, { types: ['address'] }
        );
        autocompleteRef.current.addListener('place_changed', handlePlaceSelect);
      } catch (err) {
        console.error('Error initializing autocomplete:', err);
      }
    }
  }, [handlePlaceSelect]);

  useEffect(() => {
    loadGoogleMapsApi(env.GOOGLE_MAPS_API_KEY, ['places'], () => {
      console.log("Google Maps API loaded");
      setIsGoogleApiLoaded(true);
    });
  }, []);

  useEffect(() => {
    if (isGoogleApiLoaded && addressInputRef.current) {
      console.log("Initializing autocomplete", addressInputRef.current);
      initializeAutocomplete();
    }

    return () => {
      if (autocompleteRef.current) {
        if (typeof autocompleteRef.current.unbindAll === 'function') {
          autocompleteRef.current.unbindAll();
        } else if (window.google?.maps?.event) {
          window.google.maps.event.clearInstanceListeners(autocompleteRef.current);
        }
      }
    };
  }, [isGoogleApiLoaded, initializeAutocomplete]);
  // End Google Places Autocomplete logic

  useEffect(() => {
    // Revoke object URLs on unmount or when images change
    return () => {
      images.forEach(img => {
        if (img.isStaged && img.previewUrl) {
          URL.revokeObjectURL(img.previewUrl);
        }
      });
    };
  }, [images]);

  useEffect(() => {
    if (isNewMode) {
      setFields(defaultFields);
      setImages([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
      setInitialFields(defaultFields);
      setInitialImages([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
      setFocusIdx(0);
      setFavIdx(null);
      if (addressInputRef.current) addressInputRef.current.value = "";
    } else if (fetchedPropertyData?.property) {
      const prop = fetchedPropertyData.property;
      const currentFieldsData = {
        name: prop.name || '', type: prop.type || 'House',
        address: prop.address || '', description: prop.description || '',
        country: prop.country || '', state: prop.state || '', city: prop.city || '',
        zip_code: prop.zip_code || '', map_link: prop.map_link || '',
        latitude: prop.latitude || '', longitude: prop.longitude || '',
      };
      setFields(currentFieldsData);
      setInitialFields(currentFieldsData);
      if (addressInputRef.current) addressInputRef.current.value = prop.address || "";

      let processedImages = [];
      if (prop.images?.length > 0) {
        processedImages = prop.images.map(img => ({
          id: img.id, // DB id of the image record
          s3key: img.image, // S3 key or direct URL from backend
          type: img.type,
          isStaged: false,
        }));
      }

      setImages(processedImages.length > 0 ? processedImages : [{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
      setInitialImages(processedImages.length > 0 ? processedImages : [{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
      setFocusIdx(0);

      const coverImageEntry = processedImages.find(img => img.type === 'cover');
      setFavIdx(coverImageEntry ? processedImages.findIndex(img => img.id === coverImageEntry.id) : null);
    } else {
      // Reset images when property changes but data hasn't loaded yet
      setImages([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
      setInitialImages([{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
      setFocusIdx(0);
      setFavIdx(null);
    }
  }, [fetchedPropertyData, isNewMode, propertyId]);


  const handleFieldChange = (key, value) => {
    setFields(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    if (!fields.name.trim() || !fields.type.trim()) {
      toast.error('Please enter both Property Name and Type.');
      return;
    }
    const payload = { ...fields, is_active: 1, uid: userId };
    let currentPropertyId = propertyId;
    let propertyCreatedOrUpdated = false;

    try {
      if (isNewMode) {
        const result = await manageProperty({ action: 'insert', ...payload }).unwrap();
        toast.success('Property created successfully!');
        currentPropertyId = result?.property_id;
        if (!currentPropertyId) throw new Error("Failed to get new property ID.");
      } else {
        await manageProperty({ action: 'update', property_id: currentPropertyId, ...payload }).unwrap();
        toast.success('Property updated successfully!');
      }
      setInitialFields(fields); // Update initial fields to current fields after successful save
      propertyCreatedOrUpdated = true;
    } catch (err) {
      console.error('Failed to save property details:', err);
      toast.error(`Error saving property: ${err.data?.message || err.message || 'Could not save property.'}`);
      return; // Stop if property details fail to save
    }

    // Image Upload Logic - only if property details were saved/created and there's a valid property ID
    if (propertyCreatedOrUpdated && currentPropertyId) {
      const stagedImageEntries = images.filter(img => img.isStaged && img.file);
      if (stagedImageEntries.length > 0) {
        setIsProcessingImagesOnSave(true);
        toast.info(`Uploading ${stagedImageEntries.length} image(s)...`);

        let allUploadsSuccessful = true;
        for (const imageEntry of stagedImageEntries) {
          try {
            const s3ObjectKey = `uploads/property_images/property_${currentPropertyId}/${Date.now()}_${imageEntry.file.name}`;
            const s3UploadUrlResponse = await getS3UploadUrl({
              key: s3ObjectKey,
              fileName: imageEntry.file.name,
              fileType: imageEntry.file.type,
            }).unwrap();

            const uploadURL = s3UploadUrlResponse.data?.url || s3UploadUrlResponse.url;
            const returnedKey = s3UploadUrlResponse.data?.key || s3UploadUrlResponse.key;

            if (!uploadURL || !returnedKey) {
              throw new Error("Failed to get S3 upload parameters for " + imageEntry.file.name);
            }

            await uploadFileToS3({ url: uploadURL, file: imageEntry.file }).unwrap();

            // Determine if it's the first *actual* image being uploaded (after placeholder is gone or if db was empty)
            const existingDbImages = images.filter(img => !img.isStaged && !img.isPlaceholder);
            const imageType = existingDbImages.length === 0 ? 'cover' : 'gallery';

            await managePropertyImage({
              action: 'insert',
              property_id: currentPropertyId,
              image: returnedKey,
              type: imageType,
            }).unwrap();
            // No individual success toast here, one at the end if all good.
          } catch (imgErr) {
            allUploadsSuccessful = false;
            console.error('Failed to upload image:', imageEntry.file.name, imgErr);
            toast.error(`Error uploading ${imageEntry.file.name}: ${imgErr.data?.message || imgErr.message || 'Upload failed.'}`);
            // Continue to try uploading other images
          }
        }
        setIsProcessingImagesOnSave(false);
        if (allUploadsSuccessful) {
          toast.success('All new images uploaded successfully!');
        } else {
          toast.warn('Some images failed to upload. Please check details.');
        }
        refetch(); // Refetch property data to get all images including new ones with DB IDs
      }
    }
    if (onPropertySaved && currentPropertyId) onPropertySaved(currentPropertyId);
  };


  const handleCancel = () => {
    setFields(initialFields);
    setImages(initialImages); // This should revert to images loaded from DB or initial placeholder
    if (addressInputRef.current) addressInputRef.current.value = initialFields.address || "";

    // Recalculate focus and fav based on initialImages
    const currentFocusIdx = initialImages.length > 0 ? 0 : 0;
    setFocusIdx(currentFocusIdx);
    const coverImageEntry = initialImages.find(img => img.type === 'cover' && !img.isStaged);
    setFavIdx(coverImageEntry ? initialImages.findIndex(img => img.id === coverImageEntry.id) : null);

    if (isNewMode && onPropertySaved) onPropertySaved(null); // Notify parent if new mode is cancelled
  };

  const handleImageClick = () => setShowModal(true);
  const handleThumbnailClick = idx => setFocusIdx(idx);

  const handleAddImage = (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    if (isNewMode && !propertyId) { // Technically propertyId might not exist yet even if fields are filled
      toast.warn("Please save the property details first before adding images.");
      if (e.target) e.target.value = '';
      return;
    }

    const newImageEntries = files.map(file => ({
      id: `staged-${Date.now()}-${file.name}-${Math.random().toString(36).substring(2, 9)}`,
      file: file,
      previewUrl: URL.createObjectURL(file),
      isStaged: true,
    }));

    setImages(prevImages => {
      const nonPlaceholderImages = prevImages.filter(img => !img.isPlaceholder);
      const updatedImages = [...nonPlaceholderImages, ...newImageEntries];
      if (updatedImages.length > 0) {
        // Set focus to the first of the newly added images
        setFocusIdx(nonPlaceholderImages.length);
        return updatedImages;
      }
      // This case should ideally not be hit if newImageEntries is populated
      return newImageEntries.length > 0 ? newImageEntries : [{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }];
    });

    if (e.target) e.target.value = ''; // Reset file input
  };

  const deleteImage = async (idxToDelete) => {
    const imageToDelete = images[idxToDelete];
    if (!imageToDelete || imageToDelete.isPlaceholder) return;

    const oldImages = [...images];
    const oldFavIdx = favIdx;

    if (imageToDelete.isStaged) {
      if (imageToDelete.previewUrl) URL.revokeObjectURL(imageToDelete.previewUrl);
      const newImagesArray = images.filter((_, i) => i !== idxToDelete);
      setImages(newImagesArray.length ? newImagesArray : [{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);

      if (focusIdx === idxToDelete) {
        setFocusIdx(Math.max(0, newImagesArray.length - 1));
      } else if (focusIdx > idxToDelete) {
        setFocusIdx(prev => prev - 1);
      }

      if (favIdx === idxToDelete) setFavIdx(null);
      else if (favIdx !== null && favIdx > idxToDelete) setFavIdx(prev => prev !== null ? prev - 1 : null);
      toast.info("Image removed from staging.");
      return;
    }

    // If it's an uploaded image (has s3key and id from DB)
    if (!imageToDelete.s3key || !imageToDelete.id) {
      toast.error("Cannot delete: Image data incomplete.");
      return;
    }

    // UI update optimistically
    const optimisticImages = images.filter((_, i) => i !== idxToDelete);
    setImages(optimisticImages.length ? optimisticImages : [{ id: 'placeholder', previewUrl: nohouse, isPlaceholder: true }]);
    if (focusIdx === idxToDelete) setFocusIdx(Math.max(0, optimisticImages.length - 1));
    else if (focusIdx > idxToDelete) setFocusIdx(prev => prev - 1);

    let newFavIdx = favIdx;
    if (favIdx === idxToDelete) newFavIdx = null;
    else if (favIdx !== null && favIdx > idxToDelete) newFavIdx = favIdx - 1;
    setFavIdx(newFavIdx);

    try {
      await managePropertyImage({ action: 'delete', property_id: propertyId, id: imageToDelete.id }).unwrap();
      toast.success('Image deleted successfully from server!');
      refetch(); // Refetch to get the true state from server
    } catch (imgErr) {
      console.error('Failed to delete image from server:', imgErr);
      toast.error(`Error deleting image: ${imgErr.data?.message || imgErr.message}`);
      setImages(oldImages); // Revert UI on error
      setFocusIdx(focusIdx); // Revert focus
      setFavIdx(oldFavIdx); // Revert fav
    }
  };

  const toggleFavorite = async (idx) => {
    const imageToFavorite = images[idx];
    if (isNewMode || !propertyId || imageToFavorite.isPlaceholder || imageToFavorite.isStaged || favIdx === idx) return;
    if (!imageToFavorite.s3key || !imageToFavorite.id) {
      toast.error("Cannot set as cover: Image data incomplete or not saved yet.");
      return;
    }

    const oldFavIdx = favIdx;
    setFavIdx(idx); // Optimistic update

    try {
      // Set new cover
      await managePropertyImage({ action: 'update', property_id: propertyId, id: imageToFavorite.id, type: 'cover' }).unwrap();

      // If there was an old cover, set it to gallery
      if (oldFavIdx !== null && oldFavIdx !== idx && images[oldFavIdx] && images[oldFavIdx].id) {
        const oldFavImageEntry = images[oldFavIdx];
        if (oldFavImageEntry.id !== imageToFavorite.id) { // Ensure it's not the same image
          await managePropertyImage({ action: 'update', property_id: propertyId, id: oldFavImageEntry.id, type: 'gallery' }).unwrap();
        }
      }
      toast.success('Cover photo updated successfully!');
      refetch(); // Refresh data to ensure consistency
    } catch (err) {
      console.error('Failed to set cover photo:', err);
      toast.error(`Error setting cover photo: ${err.data?.message || err.message}`);
      setFavIdx(oldFavIdx); // Revert on error
    }
  };


  if (!isNewMode && isLoading) return <div className="text-center p-5">Loading property details...</div>;
  if (!isNewMode && isFetchError) return <div className="text-center p-5 text-danger">Error loading property: {fetchError?.data?.message || fetchError?.status || 'Unknown error'}</div>;
  if (!isNewMode && !fetchedPropertyData?.property && propertyId) {
    return <div className="text-center p-5">Property with ID {propertyId} not found or you do not have access.</div>;
  }

  const currentFocusedImage = images[focusIdx] || images.find(img => !img.isPlaceholder) || { id: 'placeholder', previewUrl: nohouse, isPlaceholder: true };

  const topPropertyPreviewImage = images.find(img => !img.isPlaceholder && !img.isStaged && img.type === 'cover') ||
    images.find(img => !img.isPlaceholder && !img.isStaged) ||
    images.find(img => !img.isPlaceholder) || // Could be a staged image if no uploaded ones
    { id: 'placeholder', previewUrl: nohouse, isPlaceholder: true };


  return (
    <div style={{ overflowY: 'auto', padding: '0px' }}>
      <div className="container py-2">
        <h5 style={{ color: LABEL_COLOR }} className="fw-semibold">
          {isNewMode ? 'New Property Details' : 'Property Details'}
        </h5>

        <div className="row align-items-center">
          <div className="col-md-8">
            <EditableField icon="fa-font" label="Name" placeholder="Enter Property Name" value={fields.name} onChange={val => handleFieldChange('name', val)} />
          </div>
          <div className="col-md-4 d-flex justify-content-center align-items-center">
            <div style={{ textAlign: 'center', cursor: 'pointer' }} onClick={handleImageClick} title="Click to manage photos">
              <PropertyImageDisplay
                s3key={topPropertyPreviewImage.isStaged ? null : topPropertyPreviewImage.s3key}
                localPreviewUrl={topPropertyPreviewImage.isStaged ? topPropertyPreviewImage.previewUrl : null}
                altText="Property Preview"
                style={{ width: 150, height: 100, objectFit: 'cover', border: '1px solid #ddd', borderRadius: '8px' }}
                fallbackIcon={<img src={nohouse} alt="preview" width={150} height={100} style={{ objectFit: 'cover', border: '1px solid #ddd', borderRadius: '8px' }} />}
                propertyId={propertyId}
                key={`property-preview-${propertyId}-${topPropertyPreviewImage.s3key || 'placeholder'}`}
              />
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-md-12">
            <EditableField icon="fa-building" label="Type" placeholder="Select Property Type" value={fields.type} onChange={val => handleFieldChange('type', val)} isSelect options={['Apartment', 'House', 'Office', 'Shop', 'Warehouse', 'Villa', 'Other']} />

            <EditableField
              icon="fa-map-marker-alt"
              label="Address"
              placeholder="Enter full address (Google Places)"
              value={fields.address}
              onChange={(newValue) => {
                handleFieldChange('address', newValue);
              }}
              externalRef={addressInputRef}
              // isEditing={true}
              onRefAttached={() => {
                if (isGoogleApiLoaded && addressInputRef.current) {
                  initializeAutocomplete();
                }
              }}
            />

            {/* <div className="row">
              <div className="col-md-6">
                <EditableField icon="fa-map-pin" label="Latitude" placeholder="Enter latitude" value={fields.latitude} onChange={val => handleFieldChange('latitude', val)} />
              </div>
              <div className="col-md-6">
                <EditableField icon="fa-map-pin" label="Longitude" placeholder="Enter longitude" value={fields.longitude} onChange={val => handleFieldChange('longitude', val)} />
              </div>
            </div> */}

            <EditableField icon="fa-file-alt" label="Description" type="textarea" placeholder="Enter property description" value={fields.description} onChange={val => handleFieldChange('description', val)} />
          </div>
        </div>
        <br></br> <br></br>
        <div className="row">
          <div className="col-md-12 d-flex justify-content-end">
            <Button variant="outline-secondary" className="me-2" onClick={handleCancel} disabled={isSaving || isProcessingImagesOnSave}>Cancel</Button>
            <Button variant="primary" onClick={handleSave} disabled={isSaving || isProcessingImagesOnSave || isLoading}>
              {isSaving ? 'Saving Details...' : (isProcessingImagesOnSave ? 'Processing Images...' : (isNewMode ? 'Create Property' : 'Save Changes'))}
            </Button>
          </div>
        </div>
        {saveError && <div className="alert alert-danger mt-2 col-md-12">Error saving: {saveError.data?.message || saveError.message || "An unknown error occurred"}</div>}
        {imageDbError && <div className="alert alert-danger mt-2 col-md-12">Image DB error: {imageDbError.data?.message || imageDbError.message || "An unknown error occurred"}</div>}
      </div>

      <Modal show={showModal} onHide={() => setShowModal(false)} centered size="lg">
        <Modal.Header closeButton><Modal.Title>Property Photos</Modal.Title></Modal.Header>
        <Modal.Body>
          <div className="position-relative mb-3 bg-light d-flex justify-content-center align-items-center" style={{ width: '100%', minHeight: '300px', paddingTop: '56.25%', borderRadius: 8, overflow: 'hidden' }}>
            <PropertyImageDisplay
              s3key={currentFocusedImage.isStaged ? null : currentFocusedImage.s3key}
              localPreviewUrl={currentFocusedImage.isStaged ? currentFocusedImage.previewUrl : null}
              altText="Focused Property"
              style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
              fallbackIcon={<img src={nohouse} alt="focused" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />}
              propertyId={propertyId}
              key={`modal-preview-${propertyId}-${currentFocusedImage.s3key || 'placeholder'}-${focusIdx}`}
            />
            {(images[focusIdx] && !images[focusIdx].isPlaceholder && !images[focusIdx].isStaged && images[focusIdx].s3key) && (
              <>
                <Button variant="light" className="position-absolute" style={{ top: 10, right: 60, zIndex: 10 }} onClick={() => toggleFavorite(focusIdx)} title="Set as Cover Photo" disabled={isUpdatingDbForImage || favIdx === focusIdx || isProcessingImagesOnSave}>
                  <i className={`fa ${favIdx === focusIdx ? 'fa-star text-warning' : 'fa-star-o'}`} />
                </Button>
                <Button variant="light" className="position-absolute text-danger" style={{ top: 10, right: 10, zIndex: 10 }} onClick={() => deleteImage(focusIdx)} title="Delete Photo" disabled={isUpdatingDbForImage || isProcessingImagesOnSave}>
                  <i className="fa fa-trash" />
                </Button>
              </>
            )}
            {(images[focusIdx] && images[focusIdx].isStaged) && ( // Delete for staged images
              <Button variant="light" className="position-absolute text-danger" style={{ top: 10, right: 10, zIndex: 10 }} onClick={() => deleteImage(focusIdx)} title="Remove Staged Photo" disabled={isProcessingImagesOnSave}>
                <i className="fa fa-times-circle" />
              </Button>
            )}
          </div>
          <div className="d-flex flex-wrap mb-3" style={{ gap: '8px' }}>
            {images.map((imgEntry, idx) => {
              if (imgEntry.isPlaceholder) return null; // Don't render placeholder in thumbnail list
              return (
                <div key={imgEntry.id || idx} style={{ border: idx === focusIdx ? '3px solid #6366f1' : '3px solid transparent', borderRadius: 8, cursor: 'pointer', width: 75, height: 75, overflow: 'hidden', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', position: 'relative' }} onClick={() => handleThumbnailClick(idx)}>
                  <PropertyImageDisplay
                    s3key={imgEntry.isStaged ? null : imgEntry.s3key}
                    localPreviewUrl={imgEntry.isStaged ? imgEntry.previewUrl : null}
                    altText={`Thumbnail ${idx + 1}`}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    fallbackIcon={<i className="fa fa-image" style={{ fontSize: '2em' }}></i>}
                    propertyId={propertyId}
                    key={`thumbnail-${propertyId}-${imgEntry.s3key || imgEntry.id || 'placeholder'}-${idx}`}
                  />
                  {imgEntry.isStaged && <span className="badge bg-info position-absolute bottom-0 end-0 m-1" style={{ fontSize: '0.6rem' }}>Staged</span>}
                  {favIdx === idx && !imgEntry.isStaged && <i className="fa fa-star text-warning position-absolute top-0 start-0 m-1" style={{ fontSize: '0.8rem' }}></i>}
                </div>
              );
            })}
            {(!isNewMode || propertyId) && ( // Allow adding if not new mode, OR if new mode but property has been created (propertyId exists)
              <div style={{ border: '2px dashed #6366f1', borderRadius: 8, cursor: (isProcessingImagesOnSave || isSaving) ? 'not-allowed' : 'pointer', width: 75, height: 75, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#6366f1', backgroundColor: '#f8f9fa', opacity: (isProcessingImagesOnSave || isSaving) ? 0.5 : 1 }} onClick={() => !(isProcessingImagesOnSave || isSaving) && fileInputRef.current?.click()} title="Add Photos">
                <i className="fa fa-plus fa-2x"></i>
              </div>
            )}
          </div>
          <input type="file" accept="image/*" multiple style={{ display: 'none' }} ref={fileInputRef} onChange={handleAddImage} disabled={isProcessingImagesOnSave || isSaving} />
          {(isGettingS3Url || isUploadingToS3 || isUpdatingDbForImage || isProcessingImagesOnSave) && <div className="text-center small text-muted mt-2">
            {isProcessingImagesOnSave ? "Processing images with save..." : (isGettingS3Url ? "Getting upload URL..." : (isUploadingToS3 ? "Uploading to S3..." : (isUpdatingDbForImage ? "Finalizing image in DB..." : "")))}
          </div>}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>Close</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};
