/* ─────────────────────────────────────────────────────────────
   src/components/PropertyDetails/TransactionsSection.jsx
   – Full transactions route (summary, table, CRUD, email)
───────────────────────────────────────────────────────────── */
import React, {
  useState, useEffect, useMemo, useRef,
} from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { ArrowUpRight } from 'lucide-react';
import { FaEllipsisV, FaPlus } from 'react-icons/fa';
import {
  useManagePropertyTransactionMutation,
  useSendTransactionEmailMutation,
} from '../../api/propertyApi';
import SendReportModal from './SendReportModal';
import { toast } from 'react-toastify';

/* ─────────── Constants & helpers ─────────── */
const PAGE_SIZES = [10, 20, 30, 50, 100];

const money = (n, c = 'R') =>
  `${c}${Number(n).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;

const normalize = t => ({
  id: t.id,
  date: t.txn_date,
  description: t.description,
  reference: t.reference,
  categoryName: t.category_name || '',
  type: t.transaction_type === 'Credited' ? 'Credit' : 'Debit',
  amount: t.transaction_type === 'Debited' ? -t.amount : t.amount,
  currency: t.currency || 'R',
});

/* ─────────── Tiny component ─────────── */
const CalendarBtn = React.forwardRef(({ onClick }, ref) => (
  <i
    className="fa fa-calendar text-secondary"
    style={{ cursor: 'pointer', fontSize: '1.25rem' }}
    onClick={onClick}
    ref={ref}
  />
));

/* ─────────── Summary cards ─────────── */
const SummaryCards = ({ txns, fromDate, toDate, onSend }) => {
  const s = useMemo(() => {
    const credits = txns.filter(t => t.type === 'Credit');
    const debits  = txns.filter(t => t.type === 'Debit');
    const income  = credits.reduce((sum, t) => sum + t.amount, 0);
    const expense = debits.reduce((sum, t) => sum + Math.abs(t.amount), 0);
    return {
      income,
      expense,
      net: income - expense,
      currency: txns[0]?.currency || 'R',
      counts: [credits.length, debits.length, txns.length],
    };
  }, [txns]);

  const cards = ['Revenue', 'Expense', 'Net Profit'].map((title, i) => ({
    title,
    value: [s.income, s.expense, s.net][i],
    count: s.counts[i],
  }));

  return (
    <>
      {fromDate && toDate && (
        <small className="text-muted d-block mb-2">
          Showing transactions {fromDate.toLocaleDateString()}–{toDate.toLocaleDateString()} —{' '}
          <span style={{ cursor: 'pointer', color: '#0d6efd' }} onClick={onSend}>
            Send this report as email
          </span>
        </small>
      )}
      <div className="row mb-2">
        {cards.map(c => (
          <div key={c.title} className="col-xl-4 col-sm-6 mb-2">
            <div className="card h-100">
              <div className="card-body py-2 px-3 d-flex flex-column">
                <div className="d-flex justify-content-between">
                  <small className="text-secondary">{c.title}</small>
                  <ArrowUpRight size={16} className="text-secondary" />
                </div>
                <h5 className="mt-1 mb-1">{money(c.value, s.currency)}</h5>
                <small className="text-muted">{c.count} transactions</small>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

/* ─────────── Transactions table ─────────── */
const TransactionsTable = ({
  txns, query, setQuery,
  onCreate, onQuick, onDetails, onDelete,
  fromDate, toDate, range, setRange, dpRef,
}) => (
  <div className="overflow-auto bg-white rounded shadow-sm mb-3">
    <table className="table table-hover mb-0">
      <thead className="bg-light">
        <tr>
          <th>Date</th>
          <th>Description</th>
          <th colSpan={2}>
            <div className="d-flex align-items-center gap-2">
              <DatePicker
                ref={dpRef}
                selectsRange
                startDate={fromDate}
                endDate={toDate}
                onChange={upd => { setRange(upd || [null, null]); setQuery(''); }}
                isClearable
                customInput={<CalendarBtn />}
              />
              <input
                className="form-control form-control-sm"
                style={{ maxWidth: 180 }}
                placeholder="Search…"
                value={query}
                onChange={e => setQuery(e.target.value)}
              />
              <FaPlus
                style={{ cursor: 'pointer', color: '#0d6efd', fontSize: '1.2rem' }}
                onClick={onCreate}
              />
            </div>
          </th>
        </tr>
      </thead>
      <tbody>
        {txns.map(t => (
          <tr key={t.id}>
            <td>{new Date(t.date).toLocaleDateString('en-ZA', {
              year: 'numeric', month: 'long', day: 'numeric'
            })}</td>
            <td style={{ cursor: 'pointer' }} onClick={() => onDetails(t)}>
              {t.description}
            </td>
            <td>
              <span className="badge bg-secondary text-white">
                {t.categoryName.length > 7
                  ? `${t.categoryName.slice(0, 7)}…`
                  : t.categoryName || '—'}
              </span>
            </td>
            <td className="text-end">
              <div className="d-inline-flex align-items-center gap-2">
                <span style={{ color: t.amount < 0 ? 'darkred' : 'darkgreen' }}>
                  {t.amount < 0 ? '-' : ''}{money(Math.abs(t.amount), t.currency)}
                </span>
                <div className="dropdown">
                  <FaEllipsisV
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    style={{
                      cursor: 'pointer',
                      color: '#6c757d',
                      width: '1rem',
                      height: '1rem'
                    }}
                  />
                  <ul className="dropdown-menu dropdown-menu-end">
                    <li>
                      <button className="dropdown-item" onClick={() => onQuick(t)}>
                        Create
                      </button>
                    </li>
                    <li>
                      <button className="dropdown-item text-danger" onClick={() => onDelete(t)}>
                        Delete
                      </button>
                    </li>
                  </ul>
                </div>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

/* ─────────── Main Transactions Section ─────────── */
const TransactionsSection = ({
  unitId, propertyId, userId,
}) => {
  /* modal/selection state */
  const [showSend,    setShowSend]    = useState(false);
  const [showCreate,  setShowCreate]  = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [showDelete,  setShowDelete]  = useState(false);

  const [selectedTxn, setSelectedTxn] = useState(null);
  const [delTxn,      setDelTxn]      = useState(null);

  /* create form state */
  const [addingCat, setAddingCat] = useState(false);
  const [newCat,    setNewCat]    = useState('');
  const [newTxn,    setNewTxn]    = useState({
    date: '', description: '', reference: '', amount: '', type: 'Credit', category: '',
  });

  /* filters/paging */
  const [query,    setQuery]    = useState('');
  const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
  const [page,     setPage]     = useState(1);
  const [range,    setRange]    = useState([null, null]);
  const dpRef              = useRef(null);
  const [fromDate, toDate] = range;

  /* email sending state */
  const [isSendingMail, setIsSendingMail] = useState(false);

  /* API hooks */
  const [manageTxn, { data: raw, isLoading, isError, error }] = useManagePropertyTransactionMutation();
  const [fetchCats, { data: catData }] = useManagePropertyTransactionMutation();
  const [sendTxnEmail] = useSendTransactionEmailMutation();

  /* load transactions */
  useEffect(() => {
    if (!unitId) return;
    manageTxn({
      action: 'get', unit_id: unitId,
      property_id: propertyId, user_id: userId,
      limit: pageSize, offset: (page - 1) * pageSize,
    });
  }, [unitId, propertyId, userId, pageSize, page]);

  /* load categories */
  useEffect(() => {
    fetchCats({ action: 'get_category', user_id: userId, unit_id: unitId });
  }, [fetchCats, userId, unitId]);

  const txns = useMemo(() => raw?.transactions?.map(normalize) || [], [raw]);
  const cats = useMemo(() => catData?.categories?.map(c => c.category_name) || [], [catData]);

  const filtered = useMemo(() => {
    let arr = [...txns];
    if (fromDate && toDate) {
      arr = arr.filter(t => {
        const d = new Date(t.date);
        return d >= fromDate && d <= toDate;
      });
    }
    const q = query.trim().toLowerCase();
    if (q) {
      arr = arr.filter(t =>
        [t.description, t.reference || '', t.categoryName, `${t.amount}`]
          .some(x => x.toLowerCase().includes(q))
      );
    }
    return arr;
  }, [txns, fromDate, toDate, query]);

  /* ───── transaction handlers ───── */
  const handleCreateSubmit = async e => {
    e.preventDefault();
    const catName = addingCat ? newCat.trim() : newTxn.category.trim();
    const { date, description, reference, amount } = newTxn;
    if (!date || !description || !reference || !catName || !amount) {
      alert('Fill all fields.');
      return;
    }
    await manageTxn({
      action: 'insert',
      txn_date: date,
      description,
      reference,
      category_name: catName,
      property_id: propertyId,
      unit_id: unitId,
      amount: +amount,
      transaction_type: newTxn.type === 'Credit' ? 'Credited' : 'Debited',
    });
    setShowCreate(false);
    setAddingCat(false);
    setNewCat('');
    setNewTxn({ date: '', description: '', reference: '', amount: '', type: 'Credit', category: '' });
    manageTxn({ action: 'get', unit_id: unitId, property_id: propertyId, user_id: userId });
  };

  const openDetails   = t => { setSelectedTxn(t); setShowDetails(true); };
  const requestDelete = t => { setDelTxn(t);     setShowDelete(true);  };

  const confirmDelete = async () => {
    if (!delTxn) return;
    await manageTxn({
      action: 'delete',
      id: delTxn.id,
      property_id: propertyId,
      unit_id: unitId,
      user_id: userId,
    });
    setShowDelete(false);
    setDelTxn(null);
    manageTxn({ action: 'get', unit_id: unitId, property_id: propertyId, user_id: userId });
  };

  /* ───── render ───── */
  return (
    <div className="px-3 pt-3">
      <SummaryCards
        txns={filtered}
        fromDate={fromDate}
        toDate={toDate}
        onSend={() => setShowSend(true)}
      />

      {isLoading && <p>Loading…</p>}
      {isError   && <p className="text-danger">{error?.message}</p>}

      {!isLoading && !isError && (
        <TransactionsTable
          txns={filtered}
          query={query}
          setQuery={setQuery}
          onCreate={() => setShowCreate(true)}
          onQuick={t => {
            setNewTxn({
              date: t.date,
              description: t.description,
              reference: '',
              amount: Math.abs(t.amount),
              type: t.type,
              category: t.categoryName,
            });
            setShowCreate(true);
          }}
          onDetails={openDetails}
          onDelete={requestDelete}
          {...{ fromDate, toDate, range, setRange, dpRef }}
        />
      )}

      {/* pagination */}
      <div className="d-flex justify-content-between align-items-center mt-2">
        <div>
          Show&nbsp;
          <select
            className="form-select form-select-sm d-inline-block w-auto"
            value={pageSize}
            onChange={e => { setPageSize(+e.target.value); setPage(1); }}
          >
            {PAGE_SIZES.map(n => <option key={n}>{n}</option>)}
          </select>&nbsp;entries
        </div>
        <nav>
          <ul className="pagination pagination-sm mb-0">
            <li className={`page-item ${page === 1 ? 'disabled' : ''}`}>
              <button className="page-link" onClick={() => setPage(p => p - 1)}>Prev</button>
            </li>
            {Array.from({ length: Math.max(1, Math.ceil(filtered.length / pageSize)) }, (_, i) => (
              <li key={i} className={`page-item ${page === i + 1 ? 'active' : ''}`}>
                <button className="page-link" onClick={() => setPage(i + 1)}>{i + 1}</button>
              </li>
            ))}
            <li className={`page-item ${page >= Math.ceil(filtered.length / pageSize) ? 'disabled' : ''}`}>
              <button className="page-link" onClick={() => setPage(p => p + 1)}>Next</button>
            </li>
          </ul>
        </nav>
      </div>

      {/* Create Transaction Modal */}
      {showCreate && (
        <>
          <div className="modal-backdrop fade show" />
          <div className="modal show d-block" style={{ zIndex: 2000 }} tabIndex="-1">
            <div className="modal-dialog modal-lg modal-dialog-centered">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Create Transaction</h5>
                  <button className="btn-close" onClick={() => setShowCreate(false)} />
                </div>
                <form onSubmit={handleCreateSubmit}>
                  <div className="modal-body">
                    {/* Date */}
                    <div className="mb-3">
                      <label className="form-label">Date</label>
                      <input
                        type="date"
                        className="form-control"
                        required
                        value={newTxn.date}
                        onChange={e => setNewTxn({ ...newTxn, date: e.target.value })}
                      />
                    </div>
                    {/* Description */}
                    <div className="mb-3">
                      <label className="form-label">Description</label>
                      <input
                        className="form-control"
                        required
                        value={newTxn.description}
                        onChange={e => setNewTxn({ ...newTxn, description: e.target.value })}
                      />
                    </div>
                    {/* Reference */}
                    <div className="mb-3">
                      <label className="form-label">Reference</label>
                      <input
                        className="form-control"
                        required
                        value={newTxn.reference}
                        onChange={e => setNewTxn({ ...newTxn, reference: e.target.value })}
                      />
                    </div>
                    {/* Amount */}
                    <div className="mb-3">
                      <label className="form-label">Amount</label>
                      <input
                        type="number"
                        min="0.01"
                        step="0.01"
                        className="form-control"
                        required
                        value={newTxn.amount}
                        onChange={e => setNewTxn({ ...newTxn, amount: e.target.value })}
                      />
                    </div>
                    {/* Type */}
                    <div className="mb-3">
                      <label className="form-label">Type</label>
                      <select
                        className="form-select"
                        value={newTxn.type}
                        onChange={e => setNewTxn({ ...newTxn, type: e.target.value })}
                      >
                        <option>Credit</option>
                        <option>Debit</option>
                      </select>
                    </div>
                    {/* Category */}
                    <div className="mb-3">
                      <label className="form-label">Category</label>
                      <select
                        className="form-select"
                        value={addingCat ? '__add__' : newTxn.category}
                        onChange={e => {
                          if (e.target.value === '__add__') {
                            setAddingCat(true);
                            setNewCat('');
                          } else {
                            setAddingCat(false);
                            setNewTxn({ ...newTxn, category: e.target.value });
                          }
                        }}
                      >
                        <option value="">Select category…</option>
                        {cats.map(c => <option key={c}>{c}</option>)}
                        <option value="__add__">➕ Add new category…</option>
                      </select>
                      {addingCat && (
                        <input
                          className="form-control mt-2"
                          placeholder="New category name"
                          value={newCat}
                          onChange={e => setNewCat(e.target.value)}
                          autoFocus
                        />
                      )}
                    </div>
                  </div>
                  <div className="modal-footer">
                    <button
                      className="btn btn-secondary"
                      type="button"
                      onClick={() => setShowCreate(false)}
                    >
                      Cancel
                    </button>
                    <button className="btn btn-primary" type="submit">Save</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Details Modal */}
      {showDetails && selectedTxn && (
        <>
          <div className="modal-backdrop fade show" />
          <div className="modal show d-block" style={{ zIndex: 2000 }} tabIndex="-1">
            <div className="modal-dialog modal-lg modal-dialog-centered">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Transaction Details</h5>
                  <button className="btn-close" onClick={() => setShowDetails(false)} />
                </div>
                <div className="modal-body">
                  {[
                    ['Date',        new Date(selectedTxn.date).toLocaleDateString()],
                    ['Description', selectedTxn.description],
                    ['Reference',   selectedTxn.reference || '—'],
                  ].map(([l, v]) => (
                    <div key={l} className="mb-3 row">
                      <label className="col-sm-3 col-form-label">{l}</label>
                      <div className="col-sm-9 pt-2">{v}</div>
                    </div>
                  ))}
                  <div className="mb-3">
                    <label className="form-label">Category</label>
                    <input className="form-control" readOnly value={selectedTxn.categoryName} />
                  </div>
                  <div className="mb-3 row">
                    <label className="col-sm-3 col-form-label">Amount</label>
                    <div className="col-sm-9 pt-2">
                      <span style={{ color: selectedTxn.amount < 0 ? 'darkred' : 'darkgreen' }}>
                        {selectedTxn.amount < 0 ? '-' : ''}{money(Math.abs(selectedTxn.amount), selectedTxn.currency)}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="modal-footer d-flex justify-content-between">
                  <button
                    className="btn btn-danger"
                    onClick={() => { setShowDetails(false); requestDelete(selectedTxn); }}
                  >
                    Delete
                  </button>
                  <button className="btn btn-secondary" onClick={() => setShowDetails(false)}>
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Delete Confirmation Modal */}
      {showDelete && delTxn && (
        <>
          <div className="modal-backdrop fade show" />
          <div className="modal show d-block" style={{ zIndex: 2000 }} tabIndex="-1">
            <div className="modal-dialog modal-sm modal-dialog-centered">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Delete Transaction</h5>
                  <button className="btn-close" onClick={() => setShowDelete(false)} />
                </div>
                <div className="modal-body">
                  <ul className="list-unstyled mb-0">
                    <li><strong>Date:</strong> {new Date(delTxn.date).toLocaleDateString()}</li>
                    <li><strong>Description:</strong> {delTxn.description}</li>
                    <li><strong>Amount:</strong> {money(Math.abs(delTxn.amount), delTxn.currency)}</li>
                  </ul>
                </div>
                <div className="modal-footer">
                  <button className="btn btn-secondary" onClick={() => setShowDelete(false)}>
                    Cancel
                  </button>
                  <button className="btn btn-danger" onClick={confirmDelete}>
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Send Report Modal (always mounted; visibility via show prop) */}
      <SendReportModal
        show={showSend}
        isSending={isSendingMail}
        onClose={() => { if (!isSendingMail) setShowSend(false); }}
        onSend={async (emails, message) => {
          setIsSendingMail(true);
          try {
            await sendTxnEmail({
              emails,
              message,
              transactions: filtered,
              fromDate: fromDate?.toISOString() || null,
              toDate:   toDate?.toISOString()   || null,
              propertyId,
              unitId,
              userId,
            }).unwrap();
            toast.success('Transaction report sent successfully!');
            setShowSend(false);
          } catch (err) {
            toast.error(err?.data?.message || 'Failed to send transaction report');
          } finally {
            setIsSendingMail(false);
          }
        }}
      />
    </div>
  );
};

export default TransactionsSection;
