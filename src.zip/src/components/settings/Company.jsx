// ─────────────────────────────────────────────────────────────
// src/components/Company.jsx
// ─────────────────────────────────────────────────────────────
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { FaCamera } from 'react-icons/fa';
import {
  useGetCompanyDetailsMutation,
  useUpdateCompanyMutation,
} from '../../api/company';
import {
  useGetS3DownloadUrlQuery,
  useGetS3UploadUrlMutation,
  useUploadFileToS3Mutation,
} from '../../api/uploadApi';
import { getFallbackImage } from '../../utils/fallbackImage';
import logoIcon from '../../assets/logo/favicon.png';

export const Company = () => {
  // ── Get logged-in user & company ID ─────────────────────
  const user = useSelector((state) => state.auth.user);
  const companyId =
    user?.company_id || user?.companyId || user?.company?.id;

  // ── RTK-Query: GET /api/v1/company/manage with { action: 'get' }
  const [
    getCompanyDetails,
    { data: companyResp, isLoading: isFetching, error: fetchError },
  ] = useGetCompanyDetailsMutation();

  // ── RTK-Query: UPDATE /api/v1/company/manage with { action: 'update', ... }
  const [
    updateCompany,
    { isLoading: isUpdating, error: updateError, isSuccess: updateOK },
  ] = useUpdateCompanyMutation();

  // ── RTK-Query: Logo upload/download ─────────────────────
  const [uploadFileToS3] = useUploadFileToS3Mutation();
  const [getS3UploadUrl] = useGetS3UploadUrlMutation();

  const { data: downloadData } = useGetS3DownloadUrlQuery(
    companyResp?.data?.logo,
    { skip: !companyResp?.data?.logo }
  );

  // ── Local form state ─────────────────────────────────────
  const [form, setForm] = useState({
    company_name: '',
    email:        '',
    phone_number: '',
    website:      '',
    registration: '',
    tax_no:       '',
  });

  // ── Logo state ───────────────────────────────────────────
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreview, setLogoPreview] = useState();
  const [logoError, setLogoError] = useState(false);

  // ── Fetch details on mount ───────────────────────────────
  useEffect(() => {
    getCompanyDetails();  // sends: { action: 'get' }
  }, [getCompanyDetails]);

  // ── Populate form when GET returns ───────────────────────
  useEffect(() => {
    if (!companyResp?.data) return;
    const d = companyResp.data;
    setForm({
      company_name: d.company_name || '',
      email:        d.email        || '',
      phone_number: d.phone_number || '',
      website:      d.website      || '',
      registration: d.registration_number || '',
      tax_no:       d.tax_number   || '',
    });

    // Set logo preview
    setLogoError(false);
    if (d.logo && downloadData?.data?.url) {
      setLogoPreview(downloadData.data.url);
    } else {
      setLogoPreview(getFallbackImage(d.company_name));
    }
  }, [companyResp, downloadData]);

  // ── Handle input changes ─────────────────────────────────
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  // ── Handle logo file change ──────────────────────────────
  const handleLogoChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLogoFile(file);
    setLogoPreview(URL.createObjectURL(file));
  };

  // ── Submit update ────────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // ── Upload logo if selected ──
      let logoPath = companyResp?.data?.logo;
      if (logoFile) {
        const uploadKey = `uploads/company/company_${companyId}/${Date.now()}_${logoFile.name}`;

        const { data: presigned } = await getS3UploadUrl({
          key: uploadKey,
          fileType: logoFile.type,
          fileName: logoFile.name,
        }).unwrap();

        await uploadFileToS3({ url: presigned.url, file: logoFile }).unwrap();
        logoPath = presigned.key;
      }

      // ── Update company details including logo ──
      await updateCompany({
        company_id:   companyId,
        company_name: form.company_name.trim(),
        email:        form.email.trim(),
        phone_number: form.phone_number.trim(),
        website:      form.website.trim(),
        registration: form.registration.trim(),
        tax_no:       form.tax_no.trim(),
        logo:         logoPath,
      }).unwrap();
      
      // Refresh after save
      await getCompanyDetails().unwrap();
    } catch {
      // Errors will show below
    }
  };

  // ── Loading state before first fetch completes ───────────
  if (isFetching && !companyResp) {
    return <div>Loading…</div>;
  }

  // ── Render form ──────────────────────────────────────────
  return (
    <form className="p-4" onSubmit={handleSubmit}>
      {/* Company Logo */}
      <div className="d-flex mb-4 align-items-center gap-3 position-relative">
        {logoPreview && !logoError ? (
          <img
            src={logoPreview}
            alt="company logo"
            onError={() => setLogoError(true)}
            className="rounded"
            width={72}
            height={72}
            style={{ objectFit: "cover" }}
          />
        ) : (
          <div
            className="rounded bg-secondary text-white d-flex align-items-center justify-content-center"
            style={{ width: 72, height: 72, fontSize: 24 }}
          >
            {form.company_name?.charAt(0)?.toUpperCase() || 'C'}
          </div>
        )}
        <label
          htmlFor="logoUpload"
          className="position-absolute"
          style={{ bottom: -10, left: 60, cursor: "pointer" }}
          title="Edit Company Logo"
        >
          <FaCamera size={16} color="#000" />
        </label>
        <input
          id="logoUpload"
          type="file"
          accept="image/*"
          hidden
          onChange={handleLogoChange}
        />
      </div>

      <div className="row g-4">
        {/* Company Name */}
        <div className="col-md-6">
          <label className="form-label fw-semibold">Company Name</label>
          <input
            name="company_name"
            type="text"
            value={form.company_name}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter company name"
            required
          />
        </div>

        {/* Email */}
        <div className="col-md-6">
          <label className="form-label fw-semibold">Email</label>
          <input
            name="email"
            type="email"
            value={form.email}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter email address"
            required
          />
        </div>

        {/* Phone Number */}
        <div className="col-md-6">
          <label className="form-label fw-semibold">Phone Number</label>
          <input
            name="phone_number"
            type="tel"
            value={form.phone_number}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter phone number"
          />
        </div>

        {/* Website */}
        <div className="col-md-6">
          <label className="form-label fw-semibold">Website</label>
          <input
            name="website"
            type="text"
            value={form.website}
            onChange={handleChange}
            className="form-control"
            placeholder="https://example.com"
          />
        </div>

        {/* Registration Number (optional) */}
        <div className="col-md-6">
          <label className="form-label fw-semibold">
            Registration Number <small className="text-muted">(optional)</small>
          </label>
          <input
            name="registration"
            type="text"
            value={form.registration}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter registration number"
          />
        </div>

        {/* Tax Number (optional) */}
        <div className="col-md-6">
          <label className="form-label fw-semibold">
            Tax Number <small className="text-muted">(optional)</small>
          </label>
          <input
            name="tax_no"
            type="text"
            value={form.tax_no}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter tax number"
          />
        </div>
      </div>

      {/* Error & Success Messages */}
      {(fetchError || updateError) && (
        <p className="text-danger mt-3">
          {fetchError?.data?.message || updateError?.data?.message}
        </p>
      )}
      {updateOK && <p className="text-success mt-3">Settings saved!</p>}

      <div className="text-end mt-4">
        <button
          type="submit"
          className="btn btn-primary px-5"
          disabled={isUpdating}
        >
          {isUpdating ? 'Saving…' : 'Save'}
        </button>
      </div>
    </form>
  );
};
