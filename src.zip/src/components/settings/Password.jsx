import { useState } from "react";
import { useChangePasswordMutation } from "../../api/settingsApi";

export const Password = () => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmNewPassword, setConfirmNewPassword] = useState('');
    const [message, setMessage] = useState({ text: '', type: '' }); // type: 'success' or 'error'

    const [changePassword, { isLoading }] = useChangePasswordMutation();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage({ text: '', type: '' });
        if (newPassword !== confirmNewPassword) {
            setMessage({ text: "New passwords do not match.", type: 'error' });
            return;
        }
        if (newPassword.length < 8) { // Basic validation
            setMessage({ text: "New password must be at least 8 characters.", type: 'error' });
            return;
        }

        try {
            await changePassword({
                current_password_text: currentPassword,
                new_password_text: newPassword,
            }).unwrap();
            setMessage({ text: 'Password changed successfully!', type: 'success' });
            setCurrentPassword('');
            setNewPassword('');
            setConfirmNewPassword('');
        } catch (err) {
            console.error('Failed to change password:', err);
            setMessage({ text: err.data?.message || 'Failed to change password.', type: 'error' });
        }
    };

    return (
        <form className="p-4" onSubmit={handleSubmit}>
            {message.text && <div className={`alert alert-${message.type === 'error' ? 'danger' : 'success'}`}>{message.text}</div>}
            <div className="mb-4">
                <label className="form-label fw-semibold">Current Password</label>
                <input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} className="form-control" placeholder="Enter your current password" required />
            </div>
            <div className="mb-4">
                <label className="form-label fw-semibold">New Password</label>
                <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="form-control" placeholder="Enter your new password" required />
            </div>
            <div className="mb-4">
                <label className="form-label fw-semibold">Confirm New Password</label>
                <input type="password" value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} className="form-control" placeholder="Confirm new password" required />
            </div>
            <div className="text-end">
                <button type="submit" className="btn btn-primary px-5" disabled={isLoading}>
                    {isLoading ? 'Saving...' : 'Save'}
                </button>
            </div>
        </form>
    );
};