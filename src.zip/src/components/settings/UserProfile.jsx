import { useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { FaCamera } from "react-icons/fa";
import {
  useGetS3DownloadUrlQuery,
  useGetS3UploadUrlMutation,
  useUploadFileToS3Mutation,
} from "../../api/uploadApi";
import {
  useGetUserProfileQuery,
  useUpdateUserProfileMutation,
} from "../../api/settingsApi";
import { getFallbackImage } from "../../utils/fallbackImage";

export const UserProfile = () => {
  const loggedInUser = useSelector((state) => state.auth.user);

  /* ─────────── DATA  ─────────── */
  const {
    data: userProfileData,
    isLoading: isLoadingProfile,
    refetch: refetchUserProfile,
  } = useGetUserProfileQuery()

  const [uploadFileToS3] = useUploadFileToS3Mutation();
  const [getS3UploadUrl]  = useGetS3UploadUrlMutation();

  const { data: downloadData } = useGetS3DownloadUrlQuery(
    loggedInUser?.profile,
    { skip: !loggedInUser?.profile }
  );

  const [
    updateUserProfile,
    { isLoading: isUpdatingProfile, error: updateProfileError, isSuccess: updateProfileSuccess },
  ] = useUpdateUserProfileMutation();

  /* ─────────── STATE ─────────── */
  const [formData, setFormData] = useState({
    first_name: "",
    last_name : "",
    email     : "",
    phone_numbers: [],   // [{ value, label }]
    profile_image_file: null,
    profile  : "",
  });

  const [newPhone, setNewPhone]       = useState("");
  const [avatarPreview, setAvatarPreview] = useState();
  const [imageError, setImageError]   = useState(false);
  const [showPhoneDropdown, setShowPhoneDropdown] = useState(false);

  /* ─────────── LOAD PROFILE ─────────── */
  useEffect(() => {
    setImageError(false);

    if (userProfileData?.data) {
      const { first_name, last_name, email, phone_number, profile } =
        userProfileData.data;

      // Parse phone array
      let parsedPhones = [];
      try {
        const parsed = typeof phone_number === "string"
          ? JSON.parse(phone_number)
          : phone_number;

        if (Array.isArray(parsed?.phoneNumbers)) {
          parsedPhones = parsed.phoneNumbers.map((p) => ({
            value: p.phoneNumber,
            label: p.phoneNumber,
          }));
        }
      } catch (err) {
        console.warn("Failed to parse phone numbers:", err);
      }

      setFormData((prev) => ({
        ...prev,
        first_name,
        last_name,
        email,
        phone_numbers: parsedPhones,
        profile,
      }));

      if (profile && downloadData?.data?.url) {
        setAvatarPreview(downloadData.data.url);
      } else {
        setAvatarPreview(getFallbackImage(first_name));
      }
    }
  }, [userProfileData, downloadData]);

  /* ─────────── DERIVED INITIAL ─────────── */
  const initialChar = (() => {
    const n = formData.first_name?.trim() || "";
    const c = n.charAt(0).toUpperCase();
    return /^[A-Z]$/.test(c) ? c : "O";
  })();

  /* ─────────── EVENT HANDLERS ─────────── */
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddPhone = () => {
    const trimmed = newPhone.trim();
    if (!trimmed) return;
    if (formData.phone_numbers.some((p) => p.value === trimmed)) {
      setNewPhone("");
      return;
    }
    setFormData((prev) => ({
      ...prev,
      phone_numbers: [...prev.phone_numbers, { value: trimmed, label: trimmed }],
    }));
    setNewPhone("");
  };

  const handlePhoneToggle = (phone) => {
    const exists = formData.phone_numbers.some((p) => p.value === phone);
    setFormData((prev) => ({
      ...prev,
      phone_numbers: exists
        ? prev.phone_numbers.filter((p) => p.value !== phone)
        : [...prev.phone_numbers, { value: phone, label: phone }],
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFormData((prev) => ({ ...prev, profile_image_file: file }));
    setAvatarPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let s3Path = formData.profile;

    try {
      // ── upload new avatar if chosen ──
      if (formData.profile_image_file) {
        const uploadKey = `uploads/profile/user_${loggedInUser?.id}/${Date.now()}_${formData.profile_image_file.name}`;

        const { data: presigned } = await getS3UploadUrl({
          key: uploadKey,
          fileType: formData.profile_image_file.type,
          fileName: formData.profile_image_file.name,
        }).unwrap();

        await uploadFileToS3({ url: presigned.url, file: formData.profile_image_file }).unwrap();
        s3Path = presigned.key;
      }

      // ── update profile ──
      await updateUserProfile({
        first_name: formData.first_name,
        last_name : formData.last_name,
        email     : formData.email,
        profile   : s3Path,
        phoneNumbers: formData.phone_numbers.map((p) => p.value),
      }).unwrap();

      await refetchUserProfile();
    } catch (err) {
      console.error("Updating profile failed:", err);
    }
  };

  if (isLoadingProfile && !userProfileData) return <p>Loading profile...</p>;

  /* ─────────── RENDER ─────────── */
  return (
    <form className="p-4" onSubmit={handleSubmit}>
      {/* Avatar + camera icon */}
      <div className="d-flex mb-4 align-items-center gap-3 position-relative">
        {avatarPreview && !imageError ? (
          <img
            src={avatarPreview}
            alt="avatar"
            onError={() => setImageError(true)}
            className="rounded-circle"
            width={72}
            height={72}
            style={{ objectFit: "cover" }}
          />
        ) : (
          <div
            className="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center"
            style={{ width: 72, height: 72, fontSize: 24 }}
          >
            {initialChar}
          </div>
        )}
        <label
          htmlFor="profileUpload"
          className="position-absolute"
          style={{ bottom: -10, left: 60, cursor: "pointer" }}
          title="Edit Profile Picture"
        >
          <FaCamera size={16} color="#000" />
        </label>
        <input
          id="profileUpload"
          type="file"
          accept="image/*"
          hidden
          onChange={handleFileChange}
        />
      </div>

      {/* Main fields */}
      <div className="row g-4">
        <div className="col-md-6">
          <label className="form-label fw-semibold">First Name</label>
          <input
            name="first_name"
            value={formData.first_name}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter first name"
            type="text"
          />
        </div>
        <div className="col-md-6">
          <label className="form-label fw-semibold">Last Name</label>
          <input
            name="last_name"
            value={formData.last_name}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter last name"
            type="text"
          />
        </div>

        {/* Phone numbers */}
        <div className="col-md-6">
          <label className="form-label fw-semibold">Phone Numbers</label>
          <div className="dropdown">
            <button
              type="button"
              className="form-control text-start"
              onClick={() => setShowPhoneDropdown((p) => !p)}
            >
              {formData.phone_numbers.length
                ? formData.phone_numbers.map((p) => p.value).join(", ")
                : "Select or add phone numbers"}
            </button>

            {showPhoneDropdown && (
              <div
                className="border rounded p-2 mt-1 bg-white position-absolute"
                style={{ width: "100%", zIndex: 10 }}
              >
                <div className="d-flex mb-2">
                  <input
                    className="form-control me-2"
                    placeholder="Enter new number"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    onKeyDown={(e) =>
                      e.key === "Enter" && (e.preventDefault(), handleAddPhone())
                    }
                  />
                  <button type="button" className="btn btn-outline-secondary" onClick={handleAddPhone}>
                    Add
                  </button>
                </div>

                {formData.phone_numbers.map((p) => (
                  <div key={p.value} className="form-check">
                    <input
                      id={`ph-${p.value}`}
                      type="checkbox"
                      className="form-check-input"
                      checked={formData.phone_numbers.some((ph) => ph.value === p.value)}
                      onChange={() => handlePhoneToggle(p.value)}
                    />
                    <label htmlFor={`ph-${p.value}`} className="form-check-label">
                      {p.value}
                    </label>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Email (read-only) */}
        <div className="col-md-6">
          <label className="form-label fw-semibold">Email Address</label>
          <input
            name="email"
            type="email"
            value={formData.email}
            disabled
            className="form-control"
          />
        </div>
      </div>

      {/* Alerts */}
      {updateProfileError && (
        <p className="text-danger mt-3">
          {updateProfileError.data?.message || "Failed to update profile."}
        </p>
      )}
      {updateProfileSuccess && !isUpdatingProfile && (
        <p className="text-success mt-3">Profile updated successfully!</p>
      )}

      {/* Save button */}
      <div className="text-end mt-4">
        <button className="btn btn-primary px-5" type="submit" disabled={isUpdatingProfile}>
          {isUpdatingProfile ? "Saving..." : "Save"}
        </button>
      </div>
    </form>
  );
};
