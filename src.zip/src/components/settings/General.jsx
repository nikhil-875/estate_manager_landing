import { useGetGeneralSettingsQuery, useUpdateGeneralSettingsMutation } from "../../api/settingsApi";
import { useEffect, useState } from "react";
import logoIcon from "../../assets/logo/favicon.png"; // ✅ fixed path

export const General = () => {
    const { data: settingsData, isLoading, refetch } = useGetGeneralSettingsQuery();

    const [updateGeneralSettings, { isLoading: isUpdating, error: updateError, isSuccess }] =
        useUpdateGeneralSettingsMutation();

    const [formData, setFormData] = useState({
        application_name: '',
        copyright: '',
        logo_file: null,
        favicon_file: null,
    });

    const [currentImagePaths, setCurrentImagePaths] = useState({
        logo_path: '',
        favicon_path: '',
    });

    const [fallbackImages, setFallbackImages] = useState({
        logo: false,
        favicon: false,
    });

    useEffect(() => {
        if (settingsData?.data) {
            setFormData(prev => ({
                ...prev,
                application_name: settingsData.data.application_name || '',
                copyright: settingsData.data.copyright || '',
            }));
            setCurrentImagePaths({
                logo_path: settingsData.data.logo_path || '',
                favicon_path: settingsData.data.favicon_path || '',
            });
        }
    }, [settingsData]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleFileChange = (e) => {
        const { name, files } = e.target;
        if (files && files[0]) {
            setFormData(prev => ({ ...prev, [`${name}_file`]: files[0] }));
        }
    };

    const handleImageError = (key) => {
        setFallbackImages(prev => ({ ...prev, [key]: true }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const updatePayload = {
            application_name: formData.application_name,
            copyright: formData.copyright,
        };

        try {
            await updateGeneralSettings(updatePayload).unwrap();
            refetch();
        } catch (err) {
            console.error('Failed to update general settings:', err);
        }
    };

    if (isLoading) return <div>Loading</div>;

    return (
        <form className="p-4" onSubmit={handleSubmit}>
            <div className="row g-4">
                <div className="col-md-6">
                    <label className="form-label fw-semibold">Application Name</label>
                    <input
                        name="application_name"
                        type="text"
                        value={formData.application_name}
                        onChange={handleChange}
                        className="form-control"
                    />
                </div>
                <div className="col-md-6">
                    <label className="form-label fw-semibold">Copyright</label>
                    <input
                        name="copyright"
                        type="text"
                        value={formData.copyright}
                        onChange={handleChange}
                        className="form-control"
                        placeholder="Enter copyright"
                    />
                </div>

                {Object.entries({ logo: 'Logo', favicon: 'Favicon' }).map(([key, label]) => (
                    <div key={key} className="col-md-6">
                        <label className="form-label fw-semibold">{label}</label>
                        <input
                            name={key}
                            type="file"
                            onChange={handleFileChange}
                            className="form-control"
                            accept="image/*"
                        />
                        {currentImagePaths[`${key}_path`] && (
                            <img
                                src={
                                    fallbackImages[key]
                                        ? logoIcon
                                        : currentImagePaths[`${key}_path`]
                                }
                                onError={() => handleImageError(key)}
                                alt={`Current ${label}`}
                                style={{ maxWidth: '30px', marginTop: '10px' }}
                            />
                        )}
                    </div>
                ))}
            </div>

            {updateError && <p className="text-danger mt-2">{updateError.data?.message || 'Update failed'}</p>}
            {isSuccess && <p className="text-success mt-2">Settings saved!</p>}

            <div className="text-end mt-4">
                <button type="submit" className="btn btn-primary px-5" disabled={isUpdating}>
                    {isUpdating ? 'Saving...' : 'Save'}
                </button>
            </div>
        </form>
    );
};
