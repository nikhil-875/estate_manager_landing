import { useGetPaymentSettingsQuery, useUpdatePaymentSettingsMutation } from "../../api/settingsApi";
import { useEffect, useState } from "react";

export const Payment = () => {
  const { data: settingsData, isLoading, refetch } = useGetPaymentSettingsQuery();

  const [
    updatePaymentSettings,
    { isLoading: isUpdating, error: updateError, isSuccess }
  ] = useUpdatePaymentSettingsMutation();

  const initialFormData = {
    bank_transfer_enabled: true,
    bank_name: "",
    bank_holder_name: "",
    bank_account_number: "",
    bank_ifsc: "",             // optional
    bank_other_details: "",    // optional
    currency_icon: "R",
    currency_code: "ZAR",
    stripe_payment_enabled: false,
    stripe_account_key: "",
    stripe_account_secret_key: "",
  };

  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (settingsData?.data) {
      setFormData(prev => ({
        ...prev,
        bank_transfer_enabled: settingsData.data.bank_transfer_enabled ?? true,
        bank_name: settingsData.data.bank_name || "",
        bank_holder_name: settingsData.data.bank_holder_name || "",
        bank_account_number: settingsData.data.bank_account_number || "",
        bank_ifsc: settingsData.data.bank_ifsc || "",
        bank_other_details: settingsData.data.bank_other_details || "",
        currency_icon: settingsData.data.currency_icon || "R",
        currency_code: settingsData.data.currency_code || "ZAR",
        stripe_payment_enabled: settingsData.data.stripe_payment_enabled || false,
        stripe_account_key: settingsData.data.stripe_account_key || "",
        stripe_account_secret_key: settingsData.data.stripe_account_secret_key || "",
      }));
    }
  }, [settingsData]);

  const handleChange = e => {
    const { name, value, type, checked } = e.target;

    let formattedValue = value;

    if (name === "bank_account_number") {
      // Remove all non-digit characters
      const digitsOnly = value.replace(/\D/g, "");
      // Insert space every 4 digits
      formattedValue = digitsOnly.replace(/(.{4})/g, "$1 ").trim();
    }

    setFormData(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : formattedValue
    }));

    setErrors(prev => ({ ...prev, [name]: "" })); // clear error on change
  };

  const validate = () => {
    const errs = {};

    // If bank transfer is enabled, require these
    if (formData.bank_transfer_enabled) {
      if (!formData.bank_name.trim()) errs.bank_name = "Bank Name is required";
      if (!formData.bank_holder_name.trim()) errs.bank_holder_name = "Holder Name is required";
      if (!formData.bank_account_number.trim()) errs.bank_account_number = "Account Number is required";
      // bank_ifsc is optional
    }

    // Currency always required
    if (!formData.currency_icon.trim()) errs.currency_icon = "Currency Icon is required";
    if (!formData.currency_code.trim()) errs.currency_code = "Currency Code is required";

    // If Stripe enabled, require keys
    if (formData.stripe_payment_enabled) {
      if (!formData.stripe_account_key.trim()) errs.stripe_account_key = "Stripe Key is required";
      if (!formData.stripe_account_secret_key.trim()) errs.stripe_account_secret_key = "Stripe Secret is required";
    }

    return errs;
  };

  const handleSubmit = async e => {
    e.preventDefault();

    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }

    try {
      await updatePaymentSettings(formData).unwrap();
      refetch();
    } catch (err) {
      console.error("Failed to update payment settings:", err);
    }
  };

  if (isLoading) return <div>Loading...</div>;

  return (
    <form className="p-4" onSubmit={handleSubmit}>


      {formData.bank_transfer_enabled && (
        <div className="row g-4 mb-4">
          {[
            { name: "bank_name", label: "Bank Name", placeholder: "Name of Bank" },
            { name: "bank_holder_name", label: "Bank Holder Name", placeholder: "Holder" },
            { name: "bank_account_number", label: "Bank Account Number", placeholder: "0000 0000 0000 0000" },
            { name: "bank_ifsc", label: "Bank IFSC (Optional)", placeholder: "IFSC Code" }
          ].map(({ name, label, placeholder }) => (
            <div key={name} className="col-md-6">
              <label className="form-label fw-semibold">{label}</label>
              <input
                name={name}
                type="text"
                value={formData[name]}
                onChange={handleChange}
                className={`form-control ${errors[name] ? "is-invalid" : ""}`}
                placeholder={placeholder}
              />
              {errors[name] && <div className="invalid-feedback">{errors[name]}</div>}
            </div>
          ))}
          <div className="col-12">
            <label className="form-label fw-semibold">Other Details (Optional)</label>
            <textarea
              name="bank_other_details"
              rows={1}
              value={formData.bank_other_details}
              onChange={handleChange}
              className="form-control"
              placeholder="Enter any additional details"
            />
          </div>
        </div>
      )}


      {formData.stripe_payment_enabled && (
        <div className="row g-4 mb-4">
          {[
            { name: "stripe_account_key", label: "Stripe Account Key", placeholder: "Publishable Key" },
            { name: "stripe_account_secret_key", label: "Stripe Secret Key", placeholder: "Secret Key" }
          ].map(({ name, label, placeholder }) => (
            <div key={name} className="col-md-6">
              <label className="form-label fw-semibold">{label}</label>
              <input
                name={name}
                type="text"
                value={formData[name]}
                onChange={handleChange}
                className={`form-control ${errors[name] ? "is-invalid" : ""}`}
                placeholder={placeholder}
              />
              {errors[name] && <div className="invalid-feedback">{errors[name]}</div>}
            </div>
          ))}
        </div>
      )}

      <div className="row g-4 mb-4">
        <div className="col-md-6">
          <label className="form-label fw-semibold">Currency Icon</label>
          <input
            name="currency_icon"
            type="text"
            value={formData.currency_icon}
            onChange={handleChange}
            className={`form-control ${errors.currency_icon ? "is-invalid" : ""}`}
          />
          {errors.currency_icon && <div className="invalid-feedback">{errors.currency_icon}</div>}
        </div>
        <div className="col-md-6">
          <label className="form-label fw-semibold">Currency Code</label>
          <input
            name="currency_code"
            type="text"
            value={formData.currency_code}
            onChange={handleChange}
            className={`form-control ${errors.currency_code ? "is-invalid" : ""}`}
          />
          {errors.currency_code && <div className="invalid-feedback">{errors.currency_code}</div>}
        </div>
      </div>

      {updateError && (
        <p className="text-danger mt-2">
          {updateError.data?.message || "Update failed"}
        </p>
      )}
      {isSuccess && <p className="text-success mt-2">Payment settings saved!</p>}

      <div className="text-end">
        <button type="submit" className="btn btn-primary px-5" disabled={isUpdating}>
          {isUpdating ? "Saving..." : "Save"}
        </button>
      </div>
    </form>
  );
};
