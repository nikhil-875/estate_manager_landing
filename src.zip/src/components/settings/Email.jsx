import { useSelector } from "react-redux";
import {
  useGetEmailSettingsQuery,
  useTestEmailSettingsMutation,
  useUpdateEmailSettingsMutation,
} from "../../api/settingsApi";
import { useEffect, useState } from "react";

export const Email = () => {
  const user = useSelector(state => state.auth.user);

  const { data: settingsData, isLoading, refetch } = useGetEmailSettingsQuery();
  const [updateEmailSettings, { isLoading: isUpdating, error: updateError, isSuccess: updateSuccess }] =
    useUpdateEmailSettingsMutation();
  const [testEmail, { isLoading: isTestingMail, error: testMailError, isSuccess: testMailSuccess }] =
    useTestEmailSettingsMutation();

  const [formData, setFormData] = useState({
    sender_name: "",
    sender_email: "",
    smtp_driver: "",
    smtp_host: "",
    smtp_username: "",
    smtp_password: "",
    smtp_encryption: "",
    smtp_port: "",
  });
  const [smtpPasswordIsSet, setSmtpPasswordIsSet] = useState(false);
  const [validationErrors, setValidationErrors] = useState([]);

  useEffect(() => {
    if (settingsData?.data) {
      setFormData({
        sender_name: settingsData.data.sender_name || "",
        sender_email: settingsData.data.sender_email || "",
        smtp_driver: settingsData.data.smtp_driver || "",
        smtp_host: settingsData.data.smtp_host || "",
        smtp_username: settingsData.data.smtp_username || "",
        smtp_password: "",
        smtp_encryption: settingsData.data.smtp_encryption || "",
        smtp_port: settingsData.data.smtp_port?.toString() || "",
      });
      setSmtpPasswordIsSet(settingsData.data.smtp_password_is_set || false);
    }
  }, [settingsData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // check required fields
    const required = [
      { key: "sender_name", label: "Sender Name" },
      { key: "sender_email", label: "Sender Email" },
      { key: "smtp_driver", label: "SMTP Driver" },
      { key: "smtp_host", label: "SMTP Host" },
      { key: "smtp_username", label: "SMTP Username" },
      { key: "smtp_password", label: "SMTP Password" },
      { key: "smtp_encryption", label: "SMTP Encryption" },
      { key: "smtp_port", label: "SMTP Port" },
    ];
    const missing = required
      .filter((f) => !formData[f.key]?.toString().trim())
      .map((f) => f.label);
    if (missing.length) {
      setValidationErrors(missing);
      return;
    }
    setValidationErrors([]);

    try {
      await updateEmailSettings({formData }).unwrap();
      setFormData((prev) => ({ ...prev, smtp_password: "" }));
      refetch();
    } catch (err) {
      console.error("Failed to update email settings:", err);
    }
  };

  const handleTestMail = async () => {
    try {
      await testEmail({test_recipient: user?.email }).unwrap();
    } catch (err) {
      console.error("Failed to send test email:", err);
    }
  };

  if (isLoading) return <div>Loading…</div>;

  return (
    <form className="p-4" onSubmit={handleSubmit}>
      {validationErrors.length > 0 && (
        <div className="alert alert-danger">
          Required: {validationErrors.join(", ")}
        </div>
      )}

      <div className="row g-4">
        <div className="col-md-6">
          <label className="form-label fw-semibold">Sender Name</label>
          <input
            name="sender_name"
            type="text"
            value={formData.sender_name}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter sender name"
          />
        </div>
        <div className="col-md-6">
          <label className="form-label fw-semibold">Sender Email</label>
          <input
            name="sender_email"
            type="email"
            value={formData.sender_email}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter sender email"
          />
        </div>
        <div className="col-md-6">
          <label className="form-label fw-semibold">SMTP Driver</label>
          <input
            name="smtp_driver"
            type="text"
            value={formData.smtp_driver}
            onChange={handleChange}
            className="form-control"
            placeholder="e.g., smtp"
          />
        </div>
        <div className="col-md-6">
          <label className="form-label fw-semibold">SMTP Host</label>
          <input
            name="smtp_host"
            type="text"
            value={formData.smtp_host}
            onChange={handleChange}
            className="form-control"
            placeholder="e.g., smtp.example.com"
          />
        </div>
        <div className="col-md-6">
          <label className="form-label fw-semibold">SMTP Username</label>
          <input
            name="smtp_username"
            type="text"
            value={formData.smtp_username}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter SMTP username"
          />
        </div>
        <div className="col-md-6">
          <label className="form-label fw-semibold">SMTP Password</label>
          <input
            name="smtp_password"
            type="password"
            value={formData.smtp_password}
            onChange={handleChange}
            className="form-control"
            placeholder={
              smtpPasswordIsSet
                ? "Enter new password to change"
                : "Enter SMTP password"
            }
          />
          {smtpPasswordIsSet && (
            <small className="form-text text-muted">
              Password is set; leave blank to keep unchanged.
            </small>
          )}
        </div>
        <div className="col-md-6">
          <label className="form-label fw-semibold">SMTP Encryption</label>
          <input
            name="smtp_encryption"
            type="text"
            value={formData.smtp_encryption}
            onChange={handleChange}
            className="form-control"
            placeholder="e.g., tls, ssl, none"
          />
        </div>
        <div className="col-md-6">
          <label className="form-label fw-semibold">SMTP Port</label>
          <input
            name="smtp_port"
            type="number"
            value={formData.smtp_port}
            onChange={handleChange}
            className="form-control"
            placeholder="e.g., 587, 465"
          />
        </div>
      </div>

      {updateError && (
        <p className="text-danger mt-2">
          {updateError.data?.message || "Update failed"}
        </p>
      )}
      {updateSuccess && (
        <p className="text-success mt-2">Email settings saved!</p>
      )}
      {testMailError && (
        <p className="text-danger mt-2">
          {testMailError.data?.message || "Test mail failed"}
        </p>
      )}
      {testMailSuccess && (
        <p className="text-success mt-2">Test mail initiated!</p>
      )}

      <div className="d-flex justify-content-end gap-3 mt-4">
        <button
          type="button"
          onClick={handleTestMail}
          className="btn btn-dark"
          disabled={isTestingMail || isUpdating}
        >
          {isTestingMail ? "Testing…" : "Test Mail"}
        </button>
        <button
          type="submit"
          className="btn btn-primary px-4"
          disabled={isUpdating || isTestingMail}
        >
          {isUpdating ? "Saving…" : "Save"}
        </button>
      </div>
    </form>
  );
};
