import React, { useEffect } from 'react';
import { FaPaperclip, FaCheck, FaCheckDouble, FaSpinner } from 'react-icons/fa'; // Added FaSpinner

// ChatMessages component: Renders the list of messages in a conversation.
export function ChatMessages({
  messages: msgsArray = [], // Array of message objects
  currentUserId, // ID of the current user to determine message alignment and sender
  downloadedUrls = {}, // Object mapping attachment URLs to their S3 signed URLs
  attachmentStatus = {}, // Object mapping attachment URLs to their loading status ('loading', 'success', 'error')
  onContextMenu, // Function (event, message) => void, for message context menu
  onImageClick, // Function (url, type) => void, when an image attachment is clicked
  formatDateSeparator, // Function (dateString) => string, for formatting date separators
  scrollToMessage, // Function (messageId) => void, to scroll to a specific message (e.g., a replied-to message)
  messagesEndRef, // Ref to the end of the messages list for auto-scrolling
  selectedConversationName, // Name of the other user in the conversation (for replies)
  primaryColor = '#7B5FFF', // Primary theme color
  isLoading, // Boolean: true if messages are initially loading
}) {

  // Effect to scroll to the bottom of the messages list when new messages arrive.
  useEffect(() => {
    if (messagesEndRef?.current) {
      // Use 'auto' for initial load or when not focused, 'smooth' for new messages if desired
      messagesEndRef.current.scrollIntoView({ behavior: 'auto' });
    }
  }, [msgsArray, messagesEndRef]);

  // Inline styles for the component.
  const componentStyles = {
    container: { flex: 1, overflowY: 'auto', padding: '20px 30px 10px 30px', backgroundColor: '#F6F7FB' },
    dateSeparator: { textAlign: 'center', margin: '20px 0 25px 0', color: '#707070', fontSize: '0.8rem' },
    dateSeparatorInner: { background: '#E8E8E8', padding: '5px 12px', borderRadius: 12 },
    messageRow: (isMe) => ({
      display: 'flex',
      justifyContent: isMe ? 'flex-end' : 'flex-start',
      marginBottom: 18,
      position: 'relative'
    }),
    messageBubble: (isMe) => ({
      maxWidth: '70%',
      minWidth: '80px', // Minimum width for small messages (e.g., just timestamp)
      background: isMe ? primaryColor : '#FFFFFF',
      color: isMe ? '#fff' : '#303030',
      borderRadius: isMe ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
      padding: '10px 15px',
      lineHeight: 1.5,
      boxShadow: `0 1px 2px rgba(0,0,0,0.08)`,
      wordBreak: 'break-word',
      position: 'relative', // For context menu positioning or other absolute elements if needed
    }),
    senderNameText: { // Only shown for messages from others if needed (e.g., group chats)
      fontWeight: 600, marginBottom: 4, fontSize: '0.8em', color: primaryColor,
    },
    replyContainer: (isMe) => ({
      background: isMe ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.03)',
      borderLeft: `3px solid ${isMe ? 'rgba(255,255,255,0.3)' : primaryColor}`,
      padding: '6px 10px', borderRadius: 6, marginBottom: 8, fontSize: '0.8em', cursor: 'pointer',
      transition: 'background-color 0.15s ease',
    }),
    replySender: (isMe) => ({
      fontWeight: 'bold', color: isMe ? 'rgba(255,255,255,0.8)' : primaryColor, display: 'block',
    }),
    replyText: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block', marginTop: 2 },
    attachmentWrapper: (hasMessageText) => ({ marginTop: hasMessageText ? 8 : 0 }),
    attachmentImage: { maxWidth: '100%', maxHeight: '250px', borderRadius: 8, cursor: 'pointer', display: 'block', backgroundColor: '#E9E9E9' },
    attachmentFileLink: (isMe) => ({
      color: isMe ? '#D6CCFF' : primaryColor, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0',
      fontWeight: 500,
    }),
    attachmentLoadingText: (isMe) => ({ fontSize: '0.85em', color: isMe ? 'rgba(255,255,255,0.7)' : '#777', display: 'flex', alignItems: 'center', gap: '5px'}),
    deletedItalic: { fontStyle: 'italic', opacity: 0.75, fontSize: '0.95em' },
    timeAndStatus: (isMe) => ({
      fontSize: '0.7rem', marginTop: 6, opacity: isMe ? 0.8 : 0.7, textAlign: 'right',
      display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 5,
    }),
    editedText: { fontSize: '0.65rem', fontStyle: 'italic', opacity: 0.9 },
    statusIconStyle: (status, isMe) => ({
      color: status === 'seen' ? (isMe ? '#A7FFB4': '#4CAF50') : (isMe ? 'rgba(255,255,255,0.7)' : '#a0a0a0'),
      fontSize: '13px'
    }),
    failedStatusText: (isMe) => ({ color: isMe ? '#FFCDD2' : '#D32F2F', fontWeight: 'bold', fontSize: '0.7rem' }),
    loadingContainer: { display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%', color: '#555', fontSize: '1em', flexDirection: 'column', gap: '10px' },
    emptyChatContainer: { display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%', color: '#777', fontSize: '0.95em', textAlign: 'center', padding: '20px' },
  };


  if (isLoading) {
    return <div style={componentStyles.loadingContainer}><FaSpinner className="animate-spin" /> Loading messages...</div>;
  }
  if (!msgsArray || msgsArray.length === 0) {
    return <div style={componentStyles.emptyChatContainer}>No messages in this conversation yet. <br/>Be the first to say something!</div>;
  }

  return (
    <div style={componentStyles.container}>
      {msgsArray.map((msg, index) => {
        if (!msg || (!msg.id && !msg.tempId)) return null;

        const isMe = String(msg.senderId) === String(currentUserId);
        const prevMsg = msgsArray[index - 1];
        const showDate = index === 0 || !prevMsg || (new Date(msg.createdAt).toDateString() !== new Date(prevMsg.createdAt).toDateString());

        const repliedToMessage = msg.replyToMessageId ? msgsArray.find(m => m.id === msg.replyToMessageId) : null;
        let repliedToSenderName = 'User';
        if (repliedToMessage) {
          repliedToSenderName = String(repliedToMessage.senderId) === String(currentUserId) ? "You" : (selectedConversationName || "Them");
        }

        return (
          <React.Fragment key={msg.id || msg.tempId || `msg-idx-${index}`}>
            {showDate && formatDateSeparator && (
              <div style={componentStyles.dateSeparator}>
                <span style={componentStyles.dateSeparatorInner}>{formatDateSeparator(msg.createdAt)}</span>
              </div>
            )}
            <div
              id={`message-${msg.id || msg.tempId}`}
              style={componentStyles.messageRow(isMe)}
              onContextMenu={(e) => onContextMenu && onContextMenu(e, msg)}
            >
              <div style={componentStyles.messageBubble(isMe)}>
                {/* {!isMe && selectedConversationName && <div style={componentStyles.senderNameText}>{selectedConversationName}</div>} */}
                {repliedToMessage && scrollToMessage && (
                  <div
                    style={componentStyles.replyContainer(isMe)}
                    onClick={() => scrollToMessage(repliedToMessage.id)}
                    title={`Reply to: ${repliedToMessage.message?.substring(0,50)}...`}
                  >
                    <strong style={componentStyles.replySender(isMe)}>
                      {repliedToSenderName}
                    </strong>
                    <span style={componentStyles.replyText}>
                      {repliedToMessage.message || (repliedToMessage.attachmentType ? `[${repliedToMessage.attachmentType.split('/')[0]} File]` : 'Original Message')}
                    </span>
                  </div>
                )}

                {msg.attachmentUrl && (
                  <div style={componentStyles.attachmentWrapper(!!msg.message)}>
                    {attachmentStatus[msg.attachmentUrl] === 'loading' && <div style={componentStyles.attachmentLoadingText(isMe)}><FaSpinner className="animate-spin" size={12}/> Loading...</div>}
                    {attachmentStatus[msg.attachmentUrl] === 'error' && <small style={{ color: isMe ? '#FFCDD2' : 'red' }}>Error loading attachment.</small>}
                    {attachmentStatus[msg.attachmentUrl] === 'success' && downloadedUrls[msg.attachmentUrl] && (
                      msg.attachmentType?.startsWith('image/') ? (
                        <img
                          src={downloadedUrls[msg.attachmentUrl]}
                          alt={msg.fileName || "Attachment"}
                          style={componentStyles.attachmentImage}
                          onClick={() => onImageClick && onImageClick(downloadedUrls[msg.attachmentUrl], msg.attachmentType)}
                        />
                      ) : (
                        <a
                          href={downloadedUrls[msg.attachmentUrl]}
                          download={msg.fileName || msg.attachmentUrl.split('/').pop()}
                          target="_blank" rel="noopener noreferrer"
                          style={componentStyles.attachmentFileLink(isMe)}
                          title={`Download ${msg.fileName || 'file'}`}
                        >
                          <FaPaperclip size={14} /> {msg.fileName || msg.attachmentType?.split('/').pop()?.toUpperCase() || 'File'}
                        </a>
                      )
                    )}
                  </div>
                )}

                {msg.isDeleted ? (
                  <em style={componentStyles.deletedItalic}>{msg.message || "This message was deleted."}</em>
                ) : (
                  <div>{msg.message}</div>
                )}

                <div style={componentStyles.timeAndStatus(isMe)}>
                  {msg.createdAt ? new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }) : ''}
                  {isMe && !msg.isDeleted && (
                    <>
                      {msg.status === 'sending' && <FaCheck style={componentStyles.statusIconStyle(msg.status, isMe)} />}
                      {msg.status === 'sent' && <FaCheck style={componentStyles.statusIconStyle(msg.status, isMe)} />}
                      {msg.status === 'delivered' && <FaCheckDouble style={componentStyles.statusIconStyle(msg.status, isMe)} />}
                      {msg.status === 'seen' && <FaCheckDouble style={componentStyles.statusIconStyle(msg.status, isMe)} />}
                      {msg.status === 'failed' && <span style={componentStyles.failedStatusText(isMe)}>!</span>}
                    </>
                  )}
                  {msg.isEdited && !msg.isDeleted && (<span style={componentStyles.editedText}>(edited)</span>)}
                </div>
              </div>
            </div>
          </React.Fragment>
        );
      })}
      <div ref={messagesEndRef} style={{ height: 1 }} />
    </div>
  );
}
