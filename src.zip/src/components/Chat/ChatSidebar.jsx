import React, { useMemo, useRef } from 'react';
import { FaSearch, FaUserPlus, FaChevronUp, FaChevronDown } from 'react-icons/fa';

// ChatSidebar component: Displays list of chats or contacts.
export function ChatSidebar({
  tab, // Current active tab ('chats' or 'contacts')
  setTab, // Function to change the active tab
  conversations = [], // Array of conversation objects
  contacts = [], // Array of contact objects
  selectedId, // ID of the currently selected conversation
  onSelectConversation, // Function called when a conversation is selected
  onSelectContact, // Function called when a contact is selected
  onNewChat, // Function called to initiate a new chat
  listRef: externalListRef, // Optional ref for the scrollable list
  primaryColor = '#7B5FFF', // Primary theme color
  searchQuery = '', // Current search query
  onSearchChange, // Function to handle changes in search input
  handleImageError
}) {
  const internalListRef = useRef(null);
  const listReference = externalListRef || internalListRef;

  // Determines which item selection handler to use based on the current tab.
  const handleSelectItem = (item) => {
    if (tab === 'chats') {
      onSelectConversation(item);
    } else if (tab === 'contacts') {
      onSelectContact(item);
    }
  };

  // Memoized list of items to display based on the active tab and search query.
  const itemsToDisplay = useMemo(() => {
    const sourceItems = tab === 'chats' ? conversations : contacts;

    if (!searchQuery.trim()) {
      return sourceItems;
    }
    return sourceItems?.filter(item =>
      item.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (tab === 'chats' && item.lastMessage?.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (tab === 'contacts' && item.description?.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [tab, conversations, contacts, searchQuery]);

  // Inline styles for the component.
  const sidebarStyles = {
    container: { width: 320, background: '#fff', boxShadow: '0 0 3px rgba(0,0,0,.05)', display: 'flex', flexDirection: 'column', height: '100%' },
    searchBox: { padding: '16px' },
    searchInner: { position: 'relative', background: '#ECEFF1', borderRadius: 8 },
    searchIcon: { position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#9E9E9E', fontSize: '14px' },
    searchInput: { width: '100%', padding: '10px 12px 10px 40px', border: 'none', borderRadius: 8, background: 'transparent', outline: 'none', fontSize: '14px' },
    tabs: { display: 'flex', borderBottom: '1px solid #E0E0E0' },
    tabButton: (isActive) => ({
      flex: 1, padding: '12px 0', border: 'none', background: 'transparent',
      fontWeight: isActive ? 600 : 500,
      color: isActive ? primaryColor : '#575757',
      borderBottom: `2px solid ${isActive ? primaryColor : 'transparent'}`,
      cursor: 'pointer', fontSize: '15px'
    }),
    headerRow: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px' },
    headerText: { color: '#777', fontSize: 13, fontWeight: 500 },
    newChatButton: { width: 32, height: 32, borderRadius: 8, border: 'none', background: '#F1F1F9', fontSize: 16, color: primaryColor, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' },
    scrollButton: { textAlign: 'center', cursor: 'pointer', color: '#C4C4C4', padding: '6px 0', height: '24px', display: 'flex', alignItems: 'center', justifyContent: 'center' },
    list: { flex: 1, overflowY: 'hidden', padding: '0 8px 8px 8px' },
    listItem: (isActive) => ({
      listStyle: 'none', cursor: 'pointer', borderRadius: 10, padding: '10px 12px', marginBottom: 6, display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      background: isActive ? '#EEF0F8' : 'transparent',
      transition: 'background-color 0.15s ease',
    }),
    itemLeft: { display: 'flex', gap: 12, alignItems: 'center', overflow: 'hidden', flex: 1 },
    avatar: { borderRadius: '50%', width: 40, height: 40, objectFit: 'cover', backgroundColor: '#e0e0e0' },
    textBlock: { lineHeight: 1.3, overflow: 'hidden', flex: 1 },
    name: { fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontSize: '14px', color: '#333' },
    snippet: { color: '#666', fontSize: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', display: 'block', maxWidth: '170px' },
    meta: { textAlign: 'right', fontSize: 12, color: '#888', flexShrink: 0, marginLeft: 8, display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '3px' },
    timeText: { fontSize: '11px' },
    unreadBadge: { display: 'inline-block', background: primaryColor, color: '#fff', borderRadius: 10, padding: '2px 7px', fontSize: 11, fontWeight: 500 },
    description: { fontSize: '12px', color: '#777', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' },
    emptyListText: { textAlign: 'center', color: '#999', marginTop: 30, fontSize: '14px', padding: '0 20px' }
  };

  return (
    <aside style={sidebarStyles.container}>
      <div style={sidebarStyles.searchBox}>
        <div style={sidebarStyles.searchInner}>
          <FaSearch style={sidebarStyles.searchIcon} />
          <input
            type="search"
            placeholder="Search..."
            style={sidebarStyles.searchInput}
            value={searchQuery}
            onChange={onSearchChange}
          />
        </div>
      </div>

      <div style={sidebarStyles.tabs}>
        {['chats', 'contacts'].map((t) => (
          <button key={t} onClick={() => setTab(t)} style={sidebarStyles.tabButton(t === tab)}>
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      <div style={sidebarStyles.headerRow}>
        <div style={sidebarStyles.headerText}>{tab === 'chats' ? 'Recent Chats' : 'My Contacts'}</div>
        <button onClick={onNewChat} style={sidebarStyles.newChatButton} title="Start new chat or add contact">
          <FaUserPlus />
        </button>
      </div>

      <div style={sidebarStyles.scrollButton} onClick={() => listReference.current?.scrollBy({ top: -120, behavior: 'smooth' })} title="Scroll Up">
        <FaChevronUp />
      </div>

      <ul ref={listReference} style={sidebarStyles.list}>
        {itemsToDisplay.length === 0 && (
          <li style={sidebarStyles.emptyListText}>
            No {tab === 'chats' ? 'chats' : 'contacts'} to display.
            {searchQuery.trim() && ' matching your search.'}
          </li>
        )}
        {itemsToDisplay.map((item) => (
          <li key={item.id} onClick={() => handleSelectItem(item)} style={sidebarStyles.listItem(String(item.id) === String(selectedId))}>
            <div style={sidebarStyles.itemLeft}>
              <img
                src={item.avatarUrl}
                alt={item.name}
                style={sidebarStyles.avatar}
                onError={(e) => handleImageError(e, item.name)}
              />
              <div style={sidebarStyles.textBlock}>
                <div style={sidebarStyles.name} title={item.name}>{item.name}</div>
                {tab === 'chats' && item.lastMessage && (
                  <small style={sidebarStyles.snippet} title={item.lastMessage}>{item.lastMessage}</small>
                )}
                {tab === 'contacts' && item.description && (
                  <small style={sidebarStyles.description} title={item.description}>{item.description}</small>
                )}
              </div>
            </div>
            {tab === 'chats' && (
              <div style={sidebarStyles.meta}>
                {item.time && <div style={sidebarStyles.timeText}>{item.time}</div>}
                {item.unread > 0 && <span style={sidebarStyles.unreadBadge}>{item.unread}</span>}
              </div>
            )}
          </li>
        ))}
      </ul>

      <div style={sidebarStyles.scrollButton} onClick={() => listReference.current?.scrollBy({ top: 120, behavior: 'smooth' })} title="Scroll Down">
        <FaChevronDown />
      </div>
    </aside>
  );
}
