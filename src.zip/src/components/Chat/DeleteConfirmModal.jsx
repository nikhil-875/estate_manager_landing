import React from 'react';
import { FaExclamationTriangle, FaTimes } from 'react-icons/fa';

// DeleteConfirmModal component: Asks user for confirmation before deleting an item.
export function DeleteConfirmModal({
  show, // Boolean: true if the modal should be visible
  onConfirm, // Function () => void, called when deletion is confirmed
  onCancel, // Function () => void, called when deletion is cancelled
  itemName = "message", // String: name of the item being deleted (e.g., "message", "contact")
  // primaryColor is not typically used for delete confirmation, which often uses red/warning colors.
}) {
  if (!show) return null;

  // Inline styles for the component.
  const modalStyles = {
    backdrop: {
      position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
      background: 'rgba(0,0,0,0.65)', display: 'flex', justifyContent: 'center',
      alignItems: 'center', zIndex: 10000, padding: '20px', boxSizing: 'border-box',
    },
    box: {
      background: '#fff', padding: '25px 30px', borderRadius: 12,
      boxShadow: '0 6px 20px rgba(0,0,0,0.2)',
      textAlign: 'center', maxWidth: 380, width: '100%',
      position: 'relative',
    },
    iconContainer: {
      marginBottom: '15px',
    },
    warningIcon: {
      fontSize: '30px', color: '#D9534F', // Standard warning red
    },
    title: {
      fontSize: '1.2em', fontWeight: 600, color: '#333', marginBottom: '8px'
    },
    messageText: {
      fontSize: '0.95em', color: '#555', marginBottom: '25px', lineHeight: 1.6
    },
    actionsContainer: {
      display: 'flex', gap: 12, justifyContent: 'center' // Can use 'flex-end' for right-aligned buttons
    },
    button: (isConfirmButton) => ({
      flexGrow: 1, // Allow buttons to grow and share space
      maxWidth: '160px',
      padding: '10px 15px', borderRadius: 8, border: 'none',
      fontWeight: 500, fontSize: '0.9em', cursor: 'pointer',
      transition: 'opacity 0.15s ease, background-color 0.15s ease',
      background: isConfirmButton ? '#D9534F' : '#E9ECEF', // Red for confirm, light grey for cancel
      color: isConfirmButton ? 'white' : '#495057',
      // border: isConfirmButton ? 'none' : '1px solid #CED4DA',
    }),
  };

  return (
    <div style={modalStyles.backdrop} onClick={onCancel}> {/* Allow closing by clicking backdrop */}
      <div style={modalStyles.box} onClick={(e) => e.stopPropagation()}>
        <div style={modalStyles.iconContainer}>
          <FaExclamationTriangle style={modalStyles.warningIcon} />
        </div>
        <h3 style={modalStyles.title}>Confirm Deletion</h3>
        <p style={modalStyles.messageText}>
          Are you sure you want to delete this {itemName}? This action cannot be undone.
        </p>
        <div style={modalStyles.actionsContainer}>
          <button onClick={onCancel} style={modalStyles.button(false)} className="modal-button-hover">
            Cancel
          </button>
          <button onClick={onConfirm} style={modalStyles.button(true)} className="modal-button-hover-confirm">
            Delete
          </button>
        </div>
      </div>
      <style>{`
        .modal-button-hover:hover { opacity: 0.85; }
        .modal-button-hover-confirm:hover { background-color: #C82333 !important; }
      `}</style>
    </div>
  );
}
