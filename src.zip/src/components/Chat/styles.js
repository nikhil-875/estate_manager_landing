export const global = {
  fontFamily: 'Outfit, sans-serif',
  bg: '#F6F7FB',
  primary: '#7B5FFF',
};

export const sidebar = {
  container: {
    width: 320,
    background: '#fff',
    boxShadow: '0 0 3px rgba(0,0,0,.05)',
    display: 'flex',
    flexDirection: 'column',
  },
  searchBox: { padding: 16 },
  searchInner: { position: 'relative', background: '#ECEFF1', borderRadius: 8 },
  searchIcon: {
    position: 'absolute',
    left: 10,
    top: '50%',
    transform: 'translateY(-50%)',
    color: '#9E9E9E',
  },
  searchInput: {
    width: '100%',
    padding: '10px 12px 10px 36px',
    border: 'none',
    borderRadius: 8,
    background: 'transparent',
    outline: 'none',
  },

  // Tabs container keeps a light grey line underneath
  tabs: {
    display: 'flex',
    borderBottom: '1px solid #E0E0E0',
  },

  // Inactive tab: no underline (transparent)
  tab: {
    flex: 1,
    padding: '12px 0',
    border: 'none',
    background: 'transparent',
    fontWeight: 500,
    color: '#575757',
    cursor: 'pointer',
    borderBottom: '2px solid transparent',
  },

  // Active tab: purple underline
  tabActive: isActive => ({
    flex: 1,
    padding: '12px 0',
    border: 'none',
    background: 'transparent',
    fontWeight: 600,
    color: global.primary,
    borderBottom: `2px solid ${global.primary}`,
    cursor: 'pointer',
  }),

  headerRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '12px 16px',
  },
  headerText: { color: '#9E9E9E', fontSize: 14 },

  newBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    border: 'none',
    background: '#F1F1F9',
    fontSize: 18,
    color: global.primary,
    cursor: 'pointer',
  },

  scrollBtn: {
    textAlign: 'center',
    cursor: 'pointer',
    color: '#C4C4C4',
    padding: '4px 0',
  },

  list: { flex: 1, overflowY: 'auto', padding: '0 16px' },

  item: isActive => ({
    listStyle: 'none',
    cursor: 'pointer',
    borderRadius: 12,
    padding: '10px 12px',
    marginBottom: 8,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    background: isActive ? '#EEF0F8' : 'transparent',
  }),

  avatar: { borderRadius: '50%' },
  itemLeft: { display: 'flex', gap: 10, alignItems: 'center' },
  textBlock: { lineHeight: 1.2 },
  name: { fontWeight: 600 },
  snippet: { color: '#787878' },
  meta: { textAlign: 'right', fontSize: 12 },

  unread: {
    display: 'inline-block',
    background: global.primary,
    color: '#fff',
    borderRadius: 12,
    padding: '2px 8px',
    fontSize: 12,
    marginTop: 4,
  },
};

export const header = {
  container: {
    background: '#fff',
    padding: 20,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottom: '1px solid #E0E0E0',
  },
  left: { display: 'flex', gap: 14, alignItems: 'center' },
  avatar: { borderRadius: '50%' },
  name: { fontWeight: 600 },
  infoBtn: {
    width: 36,
    height: 36,
    borderRadius: 8,
    border: '1px solid #C4C4C4',
    background: '#fff',
    cursor: 'pointer',
    fontSize: 16,
    color: '#575757',
  },
};

export const messages = {
  container: { flex: '0.85 auto', overflowY: 'auto', padding: '24px 40px 0' },
  dateSep: { textAlign: 'center', margin: '20px 0', color: '#7f7f7f', fontSize: '0.9em' },
  dateInner: { background: '#E0E0E0', padding: '5px 10px', borderRadius: 15 },
  bubble: (isMe, primary) => ({
    maxWidth: '65%',
    background: isMe ? primary : '#fff',
    color: isMe ? '#fff' : '#303030',
    borderRadius: 18,
    padding: '14px 18px',
    lineHeight: 1.45,
    boxShadow: isMe ? 'none' : '0 0 2px rgba(0,0,0,0.1)',
  }),
  replyBox: (isMe, primary) => ({
    background: isMe ? 'rgba(255,255,255,0.2)' : '#f0f0f0',
    borderLeft: `3px solid ${isMe ? 'rgba(255,255,255,0.5)' : primary}`,
    padding: '8px 12px',
    borderRadius: 8,
    marginBottom: 10,
    fontSize: '0.85em',
    color: isMe ? 'rgba(255,255,255,0.8)' : '#575757',
    cursor: 'pointer',
  }),
  timeStatus: {
    fontSize: 12,
    marginTop: 8,
    opacity: 0.6,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 5,
  },
};

export const input = {
  footer: { background: '#fff', padding: '12px 20px', borderTop: '1px solid #E0E0E0' },
  replyBanner: primary => ({
    background: '#f0f0f0',
    borderLeft: `3px solid ${primary}`,
    padding: '8px 12px',
    borderRadius: 8,
    marginBottom: 10,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  }),
  preview: {
    marginBottom: 10,
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    padding: 8,
    border: '1px solid #E0E0E0',
    borderRadius: 8,
    background: '#f9f9f9',
  },
  previewImg: { width: 50, height: 50, objectFit: 'cover', borderRadius: 4 },
  form: { display: 'flex', gap: 12 },
  uploadLabel: {
    width: 42,
    height: 42,
    borderRadius: 12,
    border: 'none',
    background: '#F1F1F9',
    fontSize: 22,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  textInput: primary => ({
    flex: 1,
    borderRadius: 22,
    border: '1px dashed #C4C4C4',
    padding: '0 16px',
    height: 42,
    outline: 'none',
  }),
  sendBtn: primary => ({
    background: primary,
    color: '#fff',
    border: 'none',
    borderRadius: 10,
    padding: '0 26px',
    cursor: 'pointer',
  }),
};

export const context = {
  menu: {
    position: 'fixed',
    background: '#fff',
    boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
    listStyle: 'none',
    padding: 8,
    borderRadius: 4,
    zIndex: 1000,
  },
  item: { padding: '4px 8px', cursor: 'pointer' },
};

export const modal = {
  backdrop: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '90vh',
    background: 'rgba(0,0,0,0.6)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10000,
  },
  box: {
    background: '#fff',
    padding: 30,
    borderRadius: 12,
    boxShadow: '0 5px 15px rgba(0,0,0,0.3)',
    textAlign: 'center',
    maxWidth: 400,
    width: '90%',
  },
  closeBtn: primary => ({
    position: 'absolute',
    top: 20,
    right: 20,
    background: 'white',
    color: primary,
    border: 'none',
    borderRadius: '50%',
    width: 40,
    height: 40,
    fontSize: 24,
    cursor: 'pointer',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
  }),
  image: { maxWidth: '90%', maxHeight: '90%', objectFit: 'contain', borderRadius: 8 },
  downloadLink: primary => ({
    marginTop: 20,
    padding: '10px 20px',
    background: primary,
    color: 'white',
    borderRadius: 8,
    textDecoration: 'none',
    display: 'flex',
    alignItems: 'center',
    gap: 8,
  }),
};
