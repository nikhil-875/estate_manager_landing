import React from 'react';
import { FaPaperclip, FaTimes, FaReply } from 'react-icons/fa'; // Added FaReply
// import { input as inputStyles, global as globalStyles } from './styles'; // Assuming styles

export function ChatInput({
  message,
  setMessage,
  file, // The actual file object
  // setFile, // Parent will manage file state via onFileChange and onRemoveFile
  previewUrl,    // URL for image previews or indicator for file
  onFileChange,  // (event) => void
  onRemoveFile,  // () => void
  onSend,        // (event) => void
  disabled,      // Boolean, true if sending or not connected
  replyingTo,    // Object: { id, message, senderName (or similar) }
  onClearReply,  // () => void
  primaryColor = '#7B5FFF'
}) {

  const inputStyles = {
    footer: { background: '#fff', padding: '12px 20px', borderTop: '1px solid #E0E0E0', flexShrink: 0 },
    replyBanner: {
      background: '#f0f0f0', borderLeft: `3px solid ${primaryColor}`, padding: '8px 12px',
      borderRadius: 8, marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    },
    replyBannerTextContainer: { overflow: 'hidden', flexGrow: 1, marginRight: '10px' },
    replyBannerIcon: { marginRight: '8px', color: primaryColor, flexShrink: 0 },
    replyBannerSender: { fontWeight: 600, color: primaryColor, fontSize: '0.9em' },
    replyBannerMessage: { fontSize: '0.85em', color: '#575757', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
    replyBannerClose: { background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.1em', color: '#7f7f7f', padding: '5px', flexShrink: 0 },
    previewContainer: {
      marginBottom: 10, display: 'flex', alignItems: 'center', gap: 10,
      padding: '8px 12px', border: '1px solid #E0E0E0', borderRadius: 8, background: '#f9f9f9',
    },
    previewImage: { width: 40, height: 40, objectFit: 'cover', borderRadius: 4 },
    previewIcon: { color: primaryColor, fontSize: '20px' },
    previewFileName: { flex: 1, fontSize: '0.9em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' },
    previewRemoveButton: { background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.1em', color: '#7f7f7f', padding: '5px' },
    form: { display: 'flex', gap: 12, alignItems: 'center' },
    uploadLabel: {
      width: 42, height: 42, borderRadius: '50%', background: '#F1F1F9', fontSize: 18, // Adjusted for better icon fit
      cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: primaryColor,
      border: 'none', flexShrink: 0
    },
    textInput: {
      flex: 1, borderRadius: 21, border: '1px solid #D0D0D0', padding: '0 18px', height: 42,
      outline: 'none', fontSize: '14px',
      '&:focus': { borderColor: primaryColor, boxShadow: `0 0 0 2px ${primaryColor}30` }
    },
    sendButton: {
      background: primaryColor, color: '#fff', border: 'none', borderRadius: 21, padding: '0 22px', cursor: 'pointer',
      height: 42, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px', fontWeight: 500,
      flexShrink: 0,
      '&:disabled': { background: '#B0A0FF', cursor: 'not-allowed' }
    },
  };


  const handleSubmit = (e) => {
    e.preventDefault();
    if (!disabled && (message.trim() || file)) {
      onSend(e);
    }
  };

  return (
    <footer style={inputStyles.footer}>
      {replyingTo && (
        <div style={inputStyles.replyBanner}>
          <FaReply style={inputStyles.replyBannerIcon} />
          <div style={inputStyles.replyBannerTextContainer}>
            <strong style={inputStyles.replyBannerSender}>
              Replying to {replyingTo.senderName || 'User'}
            </strong>
            <span style={inputStyles.replyBannerMessage}>
              {replyingTo.message || (replyingTo.attachmentType ? `[${replyingTo.attachmentType.split('/')[0]}]` : 'Original Message')}
            </span>
          </div>
          <button onClick={onClearReply} style={inputStyles.replyBannerClose} title="Cancel reply">
            <FaTimes />
          </button>
        </div>
      )}

      {previewUrl && file && (
        <div style={inputStyles.previewContainer}>
          {file.type?.startsWith('image/') ? (
            <img src={previewUrl} alt="Preview" style={inputStyles.previewImage} />
          ) : (
            <FaPaperclip style={inputStyles.previewIcon} />
          )}
          <span style={inputStyles.previewFileName} title={file.name}>{file.name}</span>
          <button onClick={onRemoveFile} style={inputStyles.previewRemoveButton} title="Remove file">
            <FaTimes />
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} style={inputStyles.form}>
        <label htmlFor="file-upload" style={inputStyles.uploadLabel} title="Attach file">
          <FaPaperclip />
          <input
            id="file-upload"
            type="file"
            onChange={onFileChange}
            style={{ display: 'none' }}
            disabled={disabled}
          />
        </label>
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          style={inputStyles.textInput}
          disabled={disabled}
          onKeyPress={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              handleSubmit(e);
            }
          }}
        />
        <button
          type="submit"
          style={inputStyles.sendButton}
          disabled={disabled || (!message.trim() && !file)}
        >
          {disabled && !file && !message.trim() ? 'Send' : (disabled ? 'Sending...' : 'Send')}
        </button>
      </form>
    </footer>
  );
}
