import React from 'react';
import { FaTimes, FaDownload, FaFileAlt } from 'react-icons/fa'; // Added FaFileAlt

// AttachmentModal component: Displays image attachments or provides download for other files.
export function AttachmentModal({
  file, // Object: { type: 'image/png', name: 'attachment.png' (optional) }
  url,  // URL of the attachment to display or download
  onClose, // Function to close the modal
  primaryColor = '#7B5FFF', // Primary theme color
}) {
  if (!url || !file) return null;

  // Inline styles for the component.
  const modalStyles = {
    backdrop: {
      position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
      background: 'rgba(0,0,0,0.8)', display: 'flex', justifyContent: 'center',
      alignItems: 'center', zIndex: 9999, padding: '20px', boxSizing: 'border-box',
    },
    box: {
      background: '#fff', padding: '15px', borderRadius: 10, // Reduced padding, slightly smaller radius
      boxShadow: '0 8px 25px rgba(0,0,0,0.2)',
      textAlign: 'center',
      maxWidth: '90vw',
      maxHeight: '90vh',
      display: 'flex', flexDirection: 'column',
      position: 'relative',
      overflow: 'hidden', // Important for image fitting
    },
    closeButton: {
      position: 'absolute', top: 8, right: 8, // Closer to edge
      background: 'rgba(40,40,40,0.6)', color: '#fff', border: 'none', borderRadius: '50%',
      width: 30, height: 30, fontSize: 14, cursor: 'pointer', // Smaller button
      display: 'flex', justifyContent: 'center', alignItems: 'center',
      boxShadow: '0 1px 3px rgba(0,0,0,0.3)', zIndex: 10,
      transition: 'background-color 0.15s ease',
    },
    image: {
      display: 'block', // Prevents extra space below image
      maxWidth: '100%', // Takes full width of its container (box padding considered by parent)
      maxHeight: 'calc(90vh - 30px)', // Adjusted to consider padding of .box
      objectFit: 'contain', borderRadius: 6, // Slightly smaller radius for image
      margin: '0 auto', // Center image if it's smaller than container
    },
    fileInfoContainer: {
      padding: '25px 20px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '15px',
      color: '#333',
    },
    fileIcon: {
      fontSize: '42px', color: primaryColor, marginBottom: '5px', // Slightly smaller icon
    },
    fileName: {
      fontSize: '1.05em', fontWeight: 500, wordBreak: 'break-all',
      maxWidth: '100%', // Ensure it doesn't overflow
    },
    fileTypeInfo: {
      fontSize: '0.85em', color: '#666',
    },
    downloadLink: {
      marginTop: '15px', padding: '10px 22px', background: primaryColor, color: 'white',
      borderRadius: 8, textDecoration: 'none', display: 'inline-flex',
      alignItems: 'center', gap: 10, fontSize: '0.95em',
      transition: 'background-color 0.2s ease, transform 0.1s ease',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    }
  };

  const isImage = file.type?.startsWith('image/');
  const attachmentName = file.name || (isImage ? "Image Attachment" : "File Attachment");

  return (
    <div style={modalStyles.backdrop} onClick={onClose}>
      <div style={modalStyles.box} onClick={(e) => e.stopPropagation()}>
        <button
          onClick={onClose}
          style={{...modalStyles.closeButton, '&:hover': {backgroundColor: 'rgba(0,0,0,0.8)'}}} // Example hover
          title="Close preview"
        >
          <FaTimes />
        </button>
        {isImage ? (
          <img src={url} alt={attachmentName} style={modalStyles.image} />
        ) : (
          <div style={modalStyles.fileInfoContainer}>
            <FaFileAlt style={modalStyles.fileIcon} />
            <p style={modalStyles.fileName} title={attachmentName}>
              {attachmentName}
            </p>
            <p style={modalStyles.fileTypeInfo}>
              Type: {file.type || 'Unknown'}
            </p>
            <a
              href={url}
              download={file.name || 'download'} // Use original name for download if available
              style={{...modalStyles.downloadLink, '&:hover': {transform: 'scale(1.03)'}}} // Example hover
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaDownload /> Download File
            </a>
          </div>
        )}
      </div>
       {/* Basic hover styles - better to use a CSS solution for pseudo-classes */}
      <style>{`
        button:hover { opacity: 0.8; }
        a:hover { opacity: 0.8; }
      `}</style>
    </div>
  );
}
