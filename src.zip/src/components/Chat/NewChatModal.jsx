import React, { useState, useEffect } from 'react';
import { FaTimes, FaUserPlus } from 'react-icons/fa';
import { useManageContactsMutation } from '../../api/chatApi'; 

// Component to create a new chat or contact.
export function NewChatModal({
  show, // Boolean to control modal visibility
  onClose, // Function to close the modal
  onSuccess, // Callback when a chat is successfully created/found: (conversationData) => void
  primaryColor = '#7B5FFF' // Primary theme color
}) {
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [formError, setFormError] = useState('');
  const [needsNameFields, setNeedsNameFields] = useState(false); // True if API requires names for a new contact

  const [manageContactOrConversation, { isLoading, error: mutationError }] = useManageContactsMutation();


  // Effect to reset form state when the modal is shown or relevant props change.
  useEffect(() => {
    if (show) {
      setEmail('');
      setFirstName('');
      setLastName('');
      setFormError('');
      setNeedsNameFields(false);
    }
  }, [show]);

  // Effect to handle errors from the mutation, such as needing additional fields.
  useEffect(() => {
    if (mutationError) {
      if (mutationError.data?.status_code === 400 && mutationError.data?.error?.toLowerCase().includes("name is required")) {
        setNeedsNameFields(true);
        setFormError("Please provide the contact's first and last name.");
      } else {
        setFormError(mutationError.data?.message || mutationError.data?.error || 'An unexpected error occurred.');
      }
    }
  }, [mutationError]);

  // Do not render if 'show' prop is false.
  if (!show) return null;

  // Handles the submission for creating or finding a chat.
  const handleCreateOrFindChat = async () => {
    if (!email.trim()) {
      setFormError('Email address is required.');
      return;
    }
    // If name fields are shown and required, validate them.
    if (needsNameFields && (!firstName.trim() || !lastName.trim())) {
      setFormError('First and Last name are required for this contact.');
      return;
    }
    setFormError(''); // Clear previous errors before new attempt.

    try {
      const payload = {
        email: email.trim(),
        // Conditionally add names if the fields are visible and filled.
        ...(needsNameFields && firstName.trim() && { firstName: firstName.trim() }),
        ...(needsNameFields && lastName.trim() && { lastName: lastName.trim() }),
        // actingUserContactId: currentUserId, // Example: if API needs current user's contact ID
      };

      const result = await manageContactOrConversation(payload).unwrap();

      // Check for a successful response indicating a conversation was created or found.
      if (result && (result.data?.conversationId || result.conversationId)) {
        if (onSuccess) {
          onSuccess(result.data || result); // Pass the relevant conversation data back to parent.
        }
        onClose(); // Close modal on successful operation.
      } else if (result && result.message && result.status_code && result.status_code !== 200 && result.status_code !== 201) {
        // Handle cases where API returns a non-200/201 status with a message.
        setFormError(result.message);
        if (result.message.toLowerCase().includes("name")) { // If message indicates names are needed.
          setNeedsNameFields(true);
        }
      } else if (!result || (!result.data?.conversationId && !result.conversationId)) {
        // Fallback error if response structure is unexpected after a non-erroring call.
        setFormError(result?.message || "Could not create or find chat. Additional info might be required.");
      }

    } catch (err) {
      // Errors from unwrap() are typically handled by the mutationError useEffect.
      // This catch block can set a generic error if one isn't already set.
      if (!formError && !needsNameFields) {
        setFormError(err.data?.message || err.data?.error || 'Failed to start chat. Please try again.');
      }
    }
  };

  // Internal styles for the modal.
  const modalStyles = {
    backdrop: { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.65)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 10000, padding: '20px' },
    box: { background: 'white', padding: '25px 30px', borderRadius: 12, boxShadow: '0 5px 20px rgba(0,0,0,0.25)', textAlign: 'left', maxWidth: 420, width: '100%', position: 'relative' },
    header: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' },
    title: { fontSize: '1.3em', fontWeight: 600, color: primaryColor, display: 'flex', alignItems: 'center', gap: '10px' },
    closeButton: { background: 'transparent', border: 'none', fontSize: '1.2em', color: '#777', cursor: 'pointer', padding: '5px' },
    formGroup: { marginBottom: '15px' },
    label: { display: 'block', marginBottom: '6px', fontWeight: 500, fontSize: '0.9em', color: '#444' },
    input: { width: '100%', padding: '10px 12px', borderRadius: 8, border: '1px solid #ccc', boxSizing: 'border-box', fontSize: '1em' },
    errorText: { color: '#D9534F', fontSize: '0.85em', textAlign: 'center', marginBottom: '15px', minHeight: '1.2em' },
    actions: { display: 'flex', gap: '15px', justifyContent: 'flex-end', marginTop: '20px' },
    button: (isPrimary) => ({
      padding: '10px 20px', borderRadius: 8, border: 'none', fontWeight: 500, fontSize: '0.95em', cursor: 'pointer',
      background: isPrimary ? primaryColor : '#f0f0f0',
      color: isPrimary ? 'white' : '#333',
      // border: isPrimary ? 'none' : '1px solid #ccc',
      opacity: isLoading ? 0.7 : 1,
      transition: 'opacity 0.2s ease, background-color 0.2s ease',
    }),
  };

  return (
    <div style={modalStyles.backdrop} onClick={onClose}>
      <div style={modalStyles.box} onClick={(e) => e.stopPropagation()}>
        <div style={modalStyles.header}>
          <h2 style={modalStyles.title}><FaUserPlus /> Start New Chat</h2>
          <button onClick={onClose} style={modalStyles.closeButton} title="Close"><FaTimes /></button>
        </div>

        <div style={modalStyles.formGroup}>
          <label htmlFor="newChatEmailModal" style={modalStyles.label}>Contact's Email *</label>
          <input
            id="newChatEmailModal" type="email" placeholder="Enter user's email address"
            value={email} onChange={(e) => setEmail(e.target.value)}
            style={modalStyles.input}
            autoFocus
          />
        </div>

        {needsNameFields && (
          <>
            <div style={modalStyles.formGroup}>
              <label htmlFor="newChatFirstNameModal" style={modalStyles.label}>First Name *</label>
              <input
                id="newChatFirstNameModal" type="text" placeholder="Contact's first name"
                value={firstName} onChange={(e) => setFirstName(e.target.value)}
                style={modalStyles.input}
              />
            </div>
            <div style={modalStyles.formGroup}>
              <label htmlFor="newChatLastNameModal" style={modalStyles.label}>Last Name *</label>
              <input
                id="newChatLastNameModal" type="text" placeholder="Contact's last name"
                value={lastName} onChange={(e) => setLastName(e.target.value)}
                style={modalStyles.input}
              />
            </div>
          </>
        )}

        <div style={modalStyles.errorText}>
          {formError}
        </div>

        <div style={modalStyles.actions}>
          <button
            onClick={onClose}
            style={modalStyles.button(false)}
            disabled={isLoading}
          >
            Cancel
          </button>
          <button
            onClick={handleCreateOrFindChat}
            style={modalStyles.button(true)}
            disabled={isLoading || !email.trim() || (needsNameFields && (!firstName.trim() || !lastName.trim()))}
          >
            {isLoading ? "Processing..." : (needsNameFields ? "Add Contact & Chat" : "Start Chat")}
          </button>
        </div>
      </div>
    </div>
  );
}
