import React, { useEffect, useRef } from 'react';
import { FaReply, FaTrashAlt } from 'react-icons/fa';

// ContextMenu component: Displays a context menu for message actions.
export function ContextMenu({
  x, // x-coordinate for menu position
  y, // y-coordinate for menu position
  visible, // Boolean: true if the menu should be visible
  onReply, // Function () => void, called for "Reply" action
  onDelete, // Function () => void, called for "Delete" action (null if delete is not allowed for the message)
  onClose, // Function () => void, called to close the context menu
  primaryColor = '#7B5FFF', // Primary theme color (used for reply icon)
}) {
  const menuRef = useRef(null);

  // Effect to handle clicks outside the menu to close it.
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        onClose();
      }
    };
    if (visible) {
      document.addEventListener('mousedown', handleClickOutside);
      // Adjust position if menu overflows viewport
      if (menuRef.current) {
        const menuRect = menuRef.current.getBoundingClientRect();
        const newPos = { top: y, left: x };
        if (window.innerHeight < y + menuRect.height) {
          newPos.top = y - menuRect.height;
        }
        if (window.innerWidth < x + menuRect.width) {
          newPos.left = x - menuRect.width;
        }
        // This direct DOM manipulation for position is okay for this specific case,
        // but for more complex scenarios, consider state-driven positioning.
        menuRef.current.style.top = `${newPos.top}px`;
        menuRef.current.style.left = `${newPos.left}px`;
      }
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [visible, onClose, x, y]);


  if (!visible) return null;

  // Inline styles for the component.
  const menuStyle = {
    position: 'fixed', // Uses fixed position based on x, y from click event.
    top: y, left: x, // Initial position, might be adjusted by useEffect.
    background: 'white',
    borderRadius: 8,
    boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
    zIndex: 1000,
    padding: '6px 0',
    minWidth: '140px',
    listStyle: 'none', // Remove default ul styling
    margin: 0, // Remove default ul styling
  };

  const itemStyle = (isDeleteAction = false, isDisabled = false) => ({
    padding: '9px 16px',
    cursor: isDisabled ? 'not-allowed' : 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    fontSize: '14px',
    color: isDisabled ? '#a0a0a0' : (isDeleteAction ? '#E53E3E' : '#333'),
    transition: 'background-color 0.1s ease-out',
  });

  // Handler to perform action and then close the menu.
  const handleAction = (actionFn) => {
    if (actionFn) {
      actionFn();
    }
    onClose();
  };

  return (
    <ul ref={menuRef} style={menuStyle} onClick={(e) => e.stopPropagation()}>
      {onReply && (
        <li style={itemStyle()} onClick={() => handleAction(onReply)} className="context-menu-item hover-bg">
          <FaReply size={13} style={{ color: primaryColor }} /> Reply
        </li>
      )}
      <li
        style={itemStyle(true, !onDelete)}
        onClick={() => onDelete && handleAction(onDelete)}
        className={onDelete ? "context-menu-item hover-bg-delete" : "context-menu-item-disabled"}
        title={!onDelete ? "Cannot delete this message" : "Delete message"}
      >
        <FaTrashAlt size={13} style={{ color: !onDelete ? '#a0a0a0' : '#E53E3E' }} /> Delete
      </li>
      {/* CSS for hover effects (could be in a global CSS or styled-components) */}
      <style>{`
        .context-menu-item.hover-bg:hover { background-color: #f0f0f0; }
        .context-menu-item.hover-bg-delete:hover { background-color: #FFF5F5; }
        .context-menu-item-disabled { /* Already styled by itemStyle(true, true) or itemStyle(false, true) */ }
      `}</style>
    </ul>
  );
}
