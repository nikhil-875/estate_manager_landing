import React from 'react';
import { FaInfoCircle } from 'react-icons/fa';

// ChatHeader component: Displays the header for the active chat window.
export function ChatHeader({
  user,
  statusText, // String: e.g., "Online", "Last seen..."
  statusColor = '#9E9E9E', // Color for the status text
  onInfoClick, // Function to call when the info button is clicked
  // primaryColor = '#7B5FFF', // Primary theme color (if needed for styles not directly applied)
  handleImageError
}) {
  // Inline styles for the component.
  const headerStyles = {
    container: {
      background: '#fff', padding: '12px 20px', display: 'flex', justifyContent: 'space-between',
      alignItems: 'center', borderBottom: '1px solid #E0E0E0', flexShrink: 0, height: '73px', // Fixed height
    },
    left: { display: 'flex', gap: 14, alignItems: 'center', overflow: 'hidden', flexGrow: 1 },
    avatar: { borderRadius: '50%', width: 48, height: 48, objectFit: 'cover', backgroundColor: '#e0e0e0' },
    nameAndStatus: { overflow: 'hidden', display: 'flex', flexDirection: 'column', justifyContent: 'center' },
    name: { fontWeight: 600, color: '#333', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontSize: '16px', lineHeight: '1.3' },
    status: { fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', lineHeight: '1.3', color: statusColor },
    infoBtn: {
      width: 36, height: 36, borderRadius: 8, border: '1px solid #D0D0D0',
      background: '#fff', cursor: 'pointer', fontSize: 16, color: '#575757',
      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      transition: 'background-color 0.15s ease, border-color 0.15s ease',
    },
    placeholderContainer: {
      background: '#fff', padding: '12px 20px', display: 'flex',
      alignItems: 'center', borderBottom: '1px solid #E0E0E0', flexShrink: 0, height: '73px',
      color: '#7f7f7f', fontSize: '15px',
    }
  };

  // If no user is selected, render a placeholder.
  if (!user || !user.name) {
    return (
      <header style={headerStyles.placeholderContainer}>
        Select a chat to view messages.
      </header>
    );
  }

  return (
    <header style={headerStyles.container}>
      <div style={headerStyles.left}>
        <img
          src={user.avatarUrl}
          alt={user.name}
          style={headerStyles.avatar}
          onError={(e) => handleImageError(e, user.name)}
        />
        <div style={headerStyles.nameAndStatus}>
          <div style={headerStyles.name} title={user.name}>{user.name}</div>
          {statusText && <small style={headerStyles.status}>{statusText}</small>}
        </div>
      </div>
      {onInfoClick && (
        <button onClick={onInfoClick} style={headerStyles.infoBtn} title="View contact info">
          <FaInfoCircle />
        </button>
      )}
    </header>
  );
}
