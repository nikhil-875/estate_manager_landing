// src/components/maintenance/OwnerContractors.jsx

import React, { useState, useEffect, useMemo } from 'react';
import AsyncSelect from 'react-select/async';
import { FaSpinner } from 'react-icons/fa';
import { useSelector } from 'react-redux';
import { Modal, Button } from 'react-bootstrap';
import {
  useFetchServicesQuery,
  useManageContractorMutation,
  useGetUserContractorsQuery,
} from '../../api/maintenance';

export default function OwnerContractors({ requestId }) {
  const reportedBy = useSelector((s) => s.auth?.user?.id) ?? 0;

  /* ─────────────────────── fetch contractors ─────────────────────── */
  const {
    data: contractorsData = [],
    isLoading: contractorsLoading,
    error: contractorsError,
  } = useGetUserContractorsQuery({
    user_id: reportedBy,
    user_type: 'manager',
    company_id: 7,
  });

  /* ─────────────────────── local contractor state ────────────────── */
  const [contractors, setContractors] = useState([]);
  useEffect(() => {
    if (Array.isArray(contractorsData)) {
      setContractors(
        contractorsData.map((c) => ({
          id:        c.contractor_id,
          name:      c.company_name,
          email:     c.email,
          phone:     c.phone,
          services:  Array.isArray(c.services)
                       ? c.services.map((s) => s.service_id)
                       : [],
          invited:   false,
        }))
      );
    }
  }, [contractorsData]);
  useEffect(() => {
    if (contractorsError) console.error('Contractors load error', contractorsError);
  }, [contractorsError]);

  /* ───────────────────────── fetch services ───────────────────────── */
  const {
    data: servicesData = [],
    isLoading: servicesLoading,
    error: servicesError,
  } = useFetchServicesQuery({
    user_id: reportedBy,
    user_type: 'manager',
    company_id: 5,
  });
  const SERVICE_OPTIONS = useMemo(
    () =>
      Array.isArray(servicesData)
        ? servicesData.map((svc) => ({
            value: svc.service_id,
            label: svc.services,
          }))
        : [],
    [servicesData]
  );
  useEffect(() => {
    if (servicesError) console.error('Services load error', servicesError);
  }, [servicesError]);

  const filterServices = (input) =>
    SERVICE_OPTIONS.filter((opt) =>
      opt.label.toLowerCase().includes(input.toLowerCase())
    );
  const loadOptions = (input, cb) => {
    if (input.length < 2) return cb([]);
    setTimeout(() => cb(filterServices(input)), 200);
  };

  /* ──────────────────────── mutation hook ────────────────────────── */
  const [manageContractor, { isLoading: isSaving }] =
    useManageContractorMutation();

  /* ───────────────────────── UI state ─────────────────────────────── */
  const [detailTarget, setDetailTarget]   = useState(null);
  const [deleteTarget, setDeleteTarget]   = useState(null);
  const [deleteErrorMsg, setDeleteErrorMsg] = useState(null);
  const [expandedId, setExpandedId]       = useState(null);
  const [editServices, setEditServices]   = useState([]);
  const [alertMsg, setAlertMsg]           = useState(null);
  const [alertVariant, setAlertVariant]   = useState('success');
  const hideAlert = () => setAlertMsg(null);

  /* new-contractor form */
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [newServices, setNewServices] = useState([]);

  const toggleNew = () => {
    setShowNew((f) => !f);
    setNewName('');
    setNewEmail('');
    setNewPhone('');
    setNewMessage('');
    setNewServices([]);
    hideAlert();
  };

  /* ───────────────────── create contractor ───────────────────────── */
  const createContractor = async () => {
    if (!newName.trim() || !newEmail.trim() || newServices.length === 0) return;
    try {
      const resp = await manageContractor({
        action:        'insert',
        invited_by:    reportedBy,
        invited_email: newEmail.trim(),
        company_name:  newName.trim(),
        phone:         newPhone.trim(),
        message:       newMessage.trim(),
        services:      newServices.map((o) => o.value),
      }).unwrap();

      if (resp.status_code === 200) {
        setContractors((list) => [
          ...list,
          {
            id:        resp.contractor_id ?? Date.now(),
            name:      newName.trim(),
            email:     newEmail.trim(),
            phone:     newPhone.trim(),
            services:  newServices.map((o) => o.value),
            invited:   true,
          },
        ]);
        setAlertVariant('success');
        setAlertMsg('Contractor invited successfully!');
        setTimeout(toggleNew, 2000);
      } else {
        setAlertVariant('danger');
        setAlertMsg(resp.message || 'Unknown error');
      }
    } catch (e) {
      setAlertVariant('danger');
      setAlertMsg(e?.data?.message || 'Failed to invite contractor.');
    }
  };

  /* ───────────────────── update services ─────────────────────────── */
  const saveServices = async (id) => {
    const svcIds = editServices.map((o) => o.value);
    try {
      const resp = await manageContractor({
        action:        'update',
        invited_by:    reportedBy,
        contractor_id: id,
        services:      svcIds,
      }).unwrap();

      if (resp.status_code === 200) {
        setContractors((list) =>
          list.map((c) => (c.id === id ? { ...c, services: svcIds } : c))
        );
      } else {
        setAlertVariant('danger');
        setAlertMsg(resp.message || 'Failed to update services.');
      }
    } catch (err) {
      setAlertVariant('danger');
      setAlertMsg(err?.data?.message || 'Failed to update services.');
    } finally {
      setExpandedId(null);
    }
  };

  /* ───────────────────── delete contractor link ─────────────────── */
  const confirmDelete = (c) => {
    setDeleteTarget(c);
    setDeleteErrorMsg(null);
  };
  const cancelDelete = () => {
    setDeleteTarget(null);
    setDeleteErrorMsg(null);
  };
  const doDelete = async () => {
    try {
      const resp = await manageContractor({
        action:        'delete',
        invited_by:    reportedBy,
        contractor_id: deleteTarget.id,
      }).unwrap();

      if (resp.status_code === 200) {
        setContractors((list) => list.filter((c) => c.id !== deleteTarget.id));
        cancelDelete();
      } else {
        setDeleteErrorMsg(resp.message || 'Failed to delete contractor.');
      }
    } catch (err) {
      setDeleteErrorMsg(err?.data?.message || 'Failed to delete contractor.');
    }
  };

  /* ───────────────────── invite contractor ───────────────────────── */
  const handleInvite = async (contractorId) => {
    try {
      const resp = await manageContractor({
        action:        'invite',
        request_id:    requestId,
        contractor_id: contractorId,
        invited_by:    reportedBy,
      }).unwrap();

      if (resp.status_code !== 200) throw new Error(resp.message);

      setContractors((list) =>
        list.map((c) =>
          c.id === contractorId ? { ...c, invited: true } : c
        )
      );
    } catch (err) {
      // setAlertVariant('danger');
      // setAlertMsg(err?.data?.message || 'Failed to invite contractor.');
    }
  };

  /* ───────────────────── helpers ───────────────────────── */
  const toggleExpand = (id) => {
    if (expandedId === id) return setExpandedId(null);
    const c = contractors.find((x) => x.id === id);
    setEditServices(SERVICE_OPTIONS.filter((o) => c.services.includes(o.value)));
    setExpandedId(id);
  };
  const id2label = (id) =>
    (SERVICE_OPTIONS.find((o) => o.value === id) || {}).label || '';
  const truncate = (str, max = 10) =>
    str.length > max ? str.slice(0, max) + '…' : str;

  /* ─────────────────────── render ───────────────────────── */
  return (
    <>
      {alertMsg && (
        <div className={`alert alert-${alertVariant} alert-dismissible`}>
          {alertMsg}
          <button type="button" className="btn-close" onClick={hideAlert} />
        </div>
      )}

      <div className="d-flex justify-content-end mb-2">
        <button className="btn btn-outline-primary" onClick={toggleNew}>
          New Contractor
        </button>
      </div>

      {/* ─────────── new-contractor form ─────────── */}
      {showNew && (
        <div className="card card-body mb-3">
          <input
            className="form-control mb-2"
            placeholder="Company name"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
          />
          <input
            className="form-control mb-2"
            type="email"
            placeholder="Email"
            value={newEmail}
            onChange={(e) => setNewEmail(e.target.value)}
          />
          <input
            className="form-control mb-2"
            placeholder="Phone"
            value={newPhone}
            onChange={(e) => setNewPhone(e.target.value)}
          />
          <textarea
            className="form-control mb-2"
            rows={2}
            placeholder="Invitation message"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
          />
          <div className="mb-3">
            {servicesLoading ? (
              <div className="text-center">
                <FaSpinner className="spin" /> Loading…
              </div>
            ) : (
              <AsyncSelect
                isMulti
                cacheOptions
                loadOptions={loadOptions}
                defaultOptions={false}
                onChange={setNewServices}
                value={newServices}
                placeholder="Type ≥2 chars to search services…"
                noOptionsMessage={({ inputValue }) =>
                  inputValue.length < 2
                    ? 'Type at least 2 characters…'
                    : 'No services match'
                }
              />
            )}
          </div>
          <button
            className="btn btn-primary"
            onClick={createContractor}
            disabled={isSaving}
          >
            {isSaving && <FaSpinner className="me-2 spin" />} Create
          </button>
        </div>
      )}

      {/* ─────────── contractors table ─────────── */}
      <table className="table table-borderless">
        <thead>
          <tr style={{ borderBottom: '1px dashed #dee2e6' }}>
            <th style={{ width: 40 }} />
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            {/* <th>Services</th> */}
            <th>Invite</th>
            <th style={{ width: 40 }} />
          </tr>
        </thead>
        <tbody>
          {(contractorsLoading ? [] : contractors).map((c) => (
            <React.Fragment key={c.id}>
              <tr>
                <td>
                  <button
                    className="btn btn-sm btn-link"
                    onClick={() => toggleExpand(c.id)}
                  >
                    {expandedId === c.id ? '▼' : '▶'}
                  </button>
                </td>
                <td
                  style={{ cursor: 'pointer', color: '#0d6efd' }}
                  onClick={() => setDetailTarget(c)}
                >
                  {c.name}
                </td>
                <td>{c.email}</td>
                <td>{c.phone}</td>
                {/* <td>{truncate(c.services.map(id2label).join(', ')) || '—'}</td> */}
                <td>
                  <span
                    style={{
                      backgroundColor: '#48A3D7',
                      color: 'white',
                      padding: '0.25em 0.5em',
                      borderRadius: '0.25rem',
                      cursor: c.invited ? 'default' : 'pointer',
                      userSelect: 'none',
                    }}
                    onClick={() => !c.invited && handleInvite(c.id)}
                  >
                    {c.invited ? 'Invited' : 'Invite'}
                  </span>
                </td>
                <td>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => confirmDelete(c)}
                    disabled={isSaving}
                  >
                    🗑
                  </button>
                </td>
              </tr>

              {expandedId === c.id && (
                <tr>
                  <td />
                  <td colSpan={6}>
                    {servicesLoading ? (
                      <div className="text-center">
                        <FaSpinner className="spin" /> Loading…
                      </div>
                    ) : (
                      <AsyncSelect
                        isMulti
                        cacheOptions
                        loadOptions={loadOptions}
                        defaultOptions={false}
                        onChange={setEditServices}
                        value={editServices}
                        placeholder="Type ≥2 chars…"
                        noOptionsMessage={({ inputValue }) =>
                          inputValue.length < 2
                            ? 'Type at least 2 characters…'
                            : 'No services match'
                        }
                      />
                    )}
                    <div className="mt-2">
                      <Button
                        size="sm"
                        variant="primary"
                        className="me-2"
                        onClick={() => saveServices(c.id)}
                        disabled={isSaving}
                      >
                        {isSaving && <FaSpinner className="me-2 spin" />}
                        Save
                      </Button>
                      <Button
                        size="sm"
                        variant="outline-secondary"
                        onClick={() => setExpandedId(null)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>

      {/* ─────────── details modal ─────────── */}
      <Modal show={!!detailTarget} onHide={() => setDetailTarget(null)}>
        <Modal.Header closeButton>
          <Modal.Title>Contractor Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p><strong>Name:</strong> {detailTarget?.name}</p>
          <p><strong>Email:</strong> {detailTarget?.email}</p>
          <p><strong>Phone:</strong> {detailTarget?.phone}</p>
          <p><strong>Services:</strong> {detailTarget?.services.map(id2label).join(', ')}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setDetailTarget(null)}>
            Close
          </Button>
          <Button
            variant="primary"
            onClick={() => {
              handleInvite(detailTarget.id);
              setDetailTarget(null);
            }}
            disabled={detailTarget?.invited}
          >
            Invite
          </Button>
        </Modal.Footer>
      </Modal>

      {/* ─────────── delete confirm ─────────── */}
      <Modal show={!!deleteTarget} onHide={cancelDelete}>
        <Modal.Header closeButton>
          <Modal.Title>Remove Contractor</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {deleteErrorMsg && (
            <div className="alert alert-danger">{deleteErrorMsg}</div>
          )}
          Are you sure you want to remove <strong>{deleteTarget?.name}</strong>?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={cancelDelete}>
            Cancel
          </Button>
          <Button variant="danger" onClick={doDelete} disabled={isSaving}>
            {isSaving && <FaSpinner className="me-2 spin" />} Yes, remove
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
