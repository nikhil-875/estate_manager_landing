import React, {
  useMemo,
  useState,
  useRef,
  useEffect,
} from 'react';
import Select from 'react-select';
import { FaSpinner } from 'react-icons/fa';
import { useSelector } from 'react-redux';

/* RTK-Query hooks */
import {
  useManageRequestMutation,
  useFetchPropertyUnitsQuery,
  useFetchServicesQuery,
} from '../../api/maintenance';

/* ─────────────────── HELPERS ─────────────────── */
const titleCase = (str) =>
  str
    ? str
        .split(' ')
        .map((w) => w[0].toUpperCase() + w.slice(1))
        .join(' ')
    : '';

const statusVariant = {
  open: 'success',
  'in progress': 'warning',
  closed: 'dark',
};

/* ═══════════════════════════════════════════════ */
/*                 OwnerRequests                  */
/* ═══════════════════════════════════════════════ */
export default function OwnerRequests({
  requests,
  selectedId,
  onSelect,
  search,
  onSearch,
  onNewRequest,
}) {
  // ───────── current user ─────────
  const reportedBy = useSelector((s) => s.auth?.user?.id) ?? 0;

  // ───────── form & filter state ─────────
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [services, setServices] = useState([]);
  const [propertyId, setPropertyId] = useState(null);
  const [unitId, setUnitId] = useState(null);
  const [description, setDescription] = useState('');
  const [file, setFile] = useState(null);
  const fileRef = useRef(null);

  const [alertMsg, setAlertMsg] = useState(null);
  const [alertVariant, setAlertVariant] = useState('danger');
  const hideAlert = () => setAlertMsg(null);

  // ───────── fetch services from API ─────────
  const {
    data: servicesData = [],
    isLoading: servicesLoading,
    error: servicesError,
  } = useFetchServicesQuery({
    user_id: reportedBy,
    user_type: 'manager',
    company_id: 5,
  });

  const SERVICE_OPTIONS = useMemo(() => {
    if (!Array.isArray(servicesData)) return [];
    return servicesData.map((svc) => ({
      value: svc.service_id,
      label: svc.services,
    }));
  }, [servicesData]);

  useEffect(() => {
    if (servicesError) {
      console.error('Failed to load services:', servicesError);
    }
  }, [servicesError]);

  // ───────── fetch & group properties/units ─────────
  const {
    data: rawProps,
    isLoading: propsLoading,
    error: propsError,
  } = useFetchPropertyUnitsQuery({ user_id: reportedBy });

  const PROPERTIES = useMemo(() => {
    if (!Array.isArray(rawProps)) return [];
    const map = new Map();
    rawProps.forEach((item) => {
      const r = item.results;
      if (!r) return;
      if (!map.has(r.property_id)) {
        map.set(r.property_id, {
          id: r.property_id,
          name: r.property_name,
          units: [],
        });
      }
      map.get(r.property_id).units.push({
        id: r.unit_id,
        label: r.unit_name,
      });
    });
    const arr = Array.from(map.values());
    arr.forEach((p) =>
      p.units.sort((a, b) => a.label.localeCompare(b.label))
    );
    return arr.sort((a, b) => a.name.localeCompare(b.name));
  }, [rawProps]);

  const unitsForSelectedProp =
    PROPERTIES.find((p) => p.id === Number(propertyId))?.units ?? [];

  // ───────── search/filter requests ─────────
  const filtered = useMemo(() => {
    if (!search.trim()) return requests;
    const q = search.toLowerCase();
    return requests.filter((r) =>
      [r.title, r.property, r.unitName, r.tenantName, r.status].some((f) =>
        (f ?? '').toLowerCase().includes(q)
      )
    );
  }, [search, requests]);

  // ───────── create mutation ─────────
  const [createRequest, { isLoading: isSaving }] =
    useManageRequestMutation();

  const resetForm = () => {
    setTitle('');
    setServices([]);
    setPropertyId(null);
    setUnitId(null);
    setDescription('');
    setFile(null);
    if (fileRef.current) fileRef.current.value = '';
    hideAlert();
  };

  const handleCreate = async () => {
    if (!title.trim() || !unitId || services.length === 0) return;

    const payload = {
      action: 'insert',
      unit_id: unitId,
      reported_by: reportedBy,
      title: title.trim(),
      description: description.trim(),
      priority_id: 2,
      status_id: 2,
      issue_type_ids: services.map((s) => s.value),
      rating: 0,
    };

    try {
      const serverRecord = await createRequest(payload).unwrap();
      if (serverRecord.status_code === 200) {
        setAlertVariant('success');
        setAlertMsg('Request Created');
        onNewRequest?.(serverRecord);
        setTimeout(() => {
          setShowForm(false);
          resetForm();
        }, 2000);
        return;
      }
      setAlertVariant('danger');
      setAlertMsg(serverRecord.message || 'Unknown error');
    } catch (e) {
      setAlertVariant('danger');
      setAlertMsg(
        e?.data?.message || 'Failed to create request – please try again.'
      );
    }
  };

  return (
    <>
      {/* ───────── request list ───────── */}
      <div className="card h-100">
        <div className="card-header bg-white d-flex align-items-center">
          <input
            style={{ width: '170px' }}
            className="form-control me-2"
            placeholder="Search requests…"
            value={search}
            onChange={(e) => onSearch(e.target.value)}
          />
          <button
            className="btn btn-success"
            onClick={() => setShowForm(true)}
          >
            Request
          </button>
        </div>
        <div className="list-group overflow-auto" style={{ maxHeight: '60vh' }}>
          {filtered.map((r) => (
            <button
              key={r.id}
              className="list-group-item list-group-item-action"
              style={r.id === selectedId ? { backgroundColor: '#E6E6FA' } : {}}
              onClick={() => onSelect(r.id)}
            >
              <div className="d-flex justify-content-between">
                <div>
                  <strong>{r.title || 'Untitled'}</strong>
                  <div className="small text-muted">
                    {r.property} • {r.unitName} • {r.tenantName}
                  </div>
                </div>
                <span className={`badge bg-${statusVariant[r.status] ?? 'secondary'} text-uppercase`}>
                  {titleCase(r.status)}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ───────── new-request modal ───────── */}
      {showForm && (
        <div className="modal fade show d-block" style={{ backgroundColor: 'rgba(0,0,0,.5)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              {/* header */}
              <div className="modal-header">
                <h5 className="modal-title">Create Maintenance Request</h5>
                <button
                  className="btn-close"
                  onClick={() => {
                    setShowForm(false);
                    resetForm();
                  }}
                />
              </div>
              {/* alert */}
              {alertMsg && (
                <div className={`alert alert-${alertVariant} alert-dismissible m-3`} role="alert">
                  {alertMsg}
                  <button type="button" className="btn-close" onClick={hideAlert} />
                </div>
              )}
              {/* body */}
              <div className="modal-body">
                {propsLoading || servicesLoading ? (
                  <div className="text-center my-4">
                    <FaSpinner className="spin" /> Loading…
                  </div>
                ) : (
                  <>
                    {/* Title */}
                    <div className="mb-3">
                      <label className="form-label fw-bold">Title</label>
                      <input
                        className="form-control"
                        placeholder="Enter a short title"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                      />
                    </div>
                    {/* Issue Type */}
                    <div className="mb-3">
                      <label className="form-label fw-bold">Issue Type</label>
                      <Select
                        isMulti
                        options={SERVICE_OPTIONS}
                        value={services}
                        onChange={setServices}
                        placeholder="Select service(s)…"
                      />
                    </div>
                    {/* Property & Unit */}
                    <div className="mb-3">
                      <label className="form-label fw-bold d-block">Property & Unit</label>
                      <div className="d-flex gap-2">
                        <select
                          className="form-select"
                          style={{ flex: 1 }}
                          value={propertyId ?? ''}
                          onChange={(e) => {
                            setPropertyId(e.target.value || null);
                            setUnitId(null);
                          }}
                        >
                          <option value="">Select property…</option>
                          {PROPERTIES.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name}
                            </option>
                          ))}
                        </select>
                        <select
                          className="form-select"
                          style={{ flex: 1 }}
                          value={unitId ?? ''}
                          onChange={(e) => setUnitId(Number(e.target.value) || null)}
                          disabled={!propertyId}
                        >
                          <option value="">Select unit…</option>
                          {unitsForSelectedProp.map((u) => (
                            <option key={u.id} value={u.id}>
                              {u.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    {/* Description */}
                    <div className="mb-3">
                      <label className="form-label fw-bold">Description</label>
                      <textarea
                        rows={3}
                        className="form-control"
                        placeholder="Describe the issue"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                      />
                    </div>
                    {/* Attachment */}
                    <div className="mb-3">
                      <label className="form-label fw-bold d-block">Attachment</label>
                      <input
                        type="file"
                        ref={fileRef}
                        onChange={(e) => setFile(e.target.files[0])}
                        className="form-control w-auto"
                      />
                      {file && <small className="text-muted d-block mt-1">Selected: {file.name}</small>}
                    </div>
                  </>
                )}
              </div>
              {/* footer */}
              <div className="modal-footer">
                <button className="btn btn-secondary" disabled={isSaving} onClick={() => setShowForm(false)}>
                  Cancel
                </button>
                <button
                  className="btn btn-primary d-flex align-items-center"
                  disabled={
                    isSaving ||
                    propsLoading ||
                    servicesLoading ||
                    !title.trim() ||
                    !unitId ||
                    services.length === 0
                  }
                  onClick={handleCreate}
                >
                  {isSaving && <FaSpinner className="me-2 spin" />}
                  Create Request
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
