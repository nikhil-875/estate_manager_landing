import React, { useRef, useState } from 'react';

/* Helpers */
const timeAgo = iso => {
  const diff = Date.now() - new Date(iso).getTime();
  const h = Math.floor(diff / 36e5);
  return h < 24 ? `${h}h ago` : `${Math.floor(diff / 864e5)}d ago`;
};

export default function OwnerTask({ request, owner, onAddComment }) {
  const [comment, setComment] = useState('');
  const [file, setFile] = useState(null);
  const fileRef = useRef(null);

  if (!request) return null;

  return (
    <>
      <h5>Task Discussion</h5>
      <ul className="list-group mb-3">
        {request.comments.map(c => (
          <li key={c.id} className="list-group-item">
            <strong>{c.author}</strong>{' '}
            <small className="text-muted">{timeAgo(c.created_at)}</small>
            <br />
            {c.text}
            {c.file && (
              <div className="mt-1">
                <em>Attached:</em> {c.file.name}
              </div>
            )}
          </li>
        ))}
        {!request.comments.length && (
          <li className="list-group-item text-muted">No comments yet.</li>
        )}
      </ul>

      <div className="input-group mb-4">
        <button className="btn btn-outline-secondary" onClick={() => fileRef.current.click()}>
          📎
        </button>
        <input
          type="file"
          ref={fileRef}
          style={{ display: 'none' }}
          onChange={e => setFile(e.target.files[0])}
        />
        <input
          className="form-control"
          placeholder="Add comment…"
          value={comment}
          onChange={e => setComment(e.target.value)}
        />
        <button
          className="btn btn-primary"
          onClick={() => {
            if (!comment.trim() && !file) return;
            onAddComment({
              id: Date.now(),
              author: owner,
              text: comment.trim(),
              file,
              created_at: new Date().toISOString(),
            });
            setComment('');
            setFile(null);
            fileRef.current.value = '';
          }}
        >
          Submit
        </button>
      </div>
      {file && <div className="mb-2 small text-muted">📎 Attached: {file.name}</div>}
    </>
  );
}
