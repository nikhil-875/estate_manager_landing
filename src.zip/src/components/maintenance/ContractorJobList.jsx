import React from 'react';
import { Form, ListGroup, Badge } from 'react-bootstrap';

export default function ContractorJobList({
  placeholder,
  searchValue,
  onSearch,
  showStatus = false,
  statusValue,
  onStatus,
  items,
  selectedId,
  onSelect,
  highlightBg,
  getBadge
}) {
  return (
    <>
      {/* ── SEARCH ROW ───────────────────────────────── */} 
      <div className="d-flex mb-2">
        <Form.Control
          className={showStatus ? 'me-2' : ''}
          placeholder={placeholder}
          value={searchValue}
          onChange={e => onSearch(e.target.value)}
        />
        {showStatus && (
          <Form.Select
            style={{ width: 'auto' }}
            value={statusValue}
            onChange={e => onStatus(e.target.value)}
          >
            <option value="all">All</option>
            <option value="apply">Apply</option>
            <option value="applied">Applied</option>
          </Form.Select>
        )}
      </div>

      {/* ── LIST ────────────────────────────────────── */}
      <ListGroup style={{ maxHeight: '65vh', overflowY: 'auto' }}>
        {items.map(job => {
          const badge = getBadge(job);
          return (
            <ListGroup.Item
              key={job.id}
              action
              onClick={() => onSelect(job)}
              style={{
                backgroundColor: job.id === selectedId ? highlightBg : undefined
              }}
            >
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <strong>{job.title}</strong>
                  <br />
                  <small className="text-muted">{job.property}</small>
                </div>
                {badge && (
                  <Badge bg={badge.variant} pill>
                    {badge.text}
                  </Badge>
                )}
              </div>
            </ListGroup.Item>
          );
        })}
      </ListGroup>
    </>
  );
}
