// src/components/maintenance/subcomponents/HeaderBlock.jsx

import React from 'react';
import { Row, Col, Form, Image } from 'react-bootstrap';

export default function HeaderBlock({
  editing,
  draft,
  setDraft,
  errors,
  propertyName,
  address,
  requestStatus,
  serviceOffer,
  handleEdit,
  handleCancel,
  refNumber,
  todayStr,
}) {
  return (
    <Row className="mb-3">
      <Col md={6}>
        {editing ? (
          <Form.Control
            className="mb-2"
            style={{ borderStyle: 'dashed' }}
            value={draft.jobType}
            onChange={(e) =>
              setDraft({ ...draft, jobType: e.target.value })
            }
            placeholder="Job Type"
          />
        ) : (
          <h4 className="fw-bold">{serviceOffer || '—'} Quotation</h4>
        )}
        <br />
        {/* Bill To Section */}
        {editing ? (
          <>
            <Form.Control
              className="mb-2"
              style={{ borderStyle: 'dashed' }}
              value={draft.billToName}
              onChange={(e) =>
                setDraft({ ...draft, billToName: e.target.value })
              }
              placeholder="Bill To Name"
            />
            <Form.Control
              as="textarea"
              rows={2}
              style={{ borderStyle: 'dashed' }}
              value={draft.billToAddress}
              onChange={(e) =>
                setDraft({ ...draft, billToAddress: e.target.value })
              }
              placeholder="Bill To Address"
            />
          </>
        ) : (
          <>
            <p className="mt-2 mb-0">
              <strong>Bill To:</strong> {propertyName}
            </p>
            <p className="mb-2">{address}</p>
          </>
        )}

        {/* Reference / Dates */}
        <p className="mb-0">
          <strong>Reference:</strong> {refNumber}
        </p>
        <p className="mb-0">
          <strong>Quote Date:</strong> {todayStr}
        </p>
        {!editing && (
          <p className="mb-0">
            <strong>Status:</strong> {requestStatus}
          </p>
        )}
      </Col>

      {/* Company Logo / Details */}
      <Col md={6} className="text-md-end">
        {draft.company.logo && (
          <Image
            src={draft.company.logo}
            style={{ maxHeight: 60 }}
            className="mb-2"
          />
        )}
        {editing && (
          <Form.Control
            type="file"
            size="sm"
            accept="image/*"
            className="mb-2"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              const reader = new FileReader();
              reader.onload = () => {
                setDraft({
                  ...draft,
                  company: { ...draft.company, logo: reader.result },
                });
              };
              reader.readAsDataURL(f);
            }}
          />
        )}
        {editing ? (
          <>
            {/* Company Name */}
            <Form.Control
              className="mb-1"
              style={{ borderStyle: 'dashed' }}
              value={draft.company.name || ''}
              onChange={(e) => {
                setDraft({
                  ...draft,
                  company: {
                    ...draft.company,
                    name: e.target.value,
                  },
                });
                setDraft((prev) => ({
                  ...prev,
                  company: {
                    ...prev.company,
                    name: e.target.value,
                  },
                }));
                errors.companyName && 
                  setDraft((prev) => ({
                    ...prev,
                    company: {
                      ...prev.company,
                      name: e.target.value,
                    },
                  }));
              }}
              placeholder="Company Name"
            />
            {errors.companyName && (
              <div className="text-danger" style={{ fontSize: '0.85em' }}>
                {errors.companyName}
              </div>
            )}

            {/* Company Address */}
            <Form.Control
              className="mb-1"
              style={{ borderStyle: 'dashed' }}
              value={draft.company.address || ''}
              onChange={(e) => {
                setDraft({
                  ...draft,
                  company: {
                    ...draft.company,
                    address: e.target.value,
                  },
                });
                errors.companyAddress && 
                  setDraft((prev) => ({
                    ...prev,
                    company: {
                      ...prev.company,
                      address: e.target.value,
                    },
                  }));
              }}
              placeholder="Address"
            />
            {errors.companyAddress && (
              <div className="text-danger" style={{ fontSize: '0.85em' }}>
                {errors.companyAddress}
              </div>
            )}

            {/* Company Phone */}
            <Form.Control
              className="mb-1"
              style={{ borderStyle: 'dashed' }}
              value={draft.company.phone || ''}
              onChange={(e) => {
                setDraft({
                  ...draft,
                  company: {
                    ...draft.company,
                    phone: e.target.value,
                  },
                });
                errors.companyPhone && 
                  setDraft((prev) => ({
                    ...prev,
                    company: {
                      ...prev.company,
                      phone: e.target.value,
                    },
                  }));
              }}
              placeholder="Phone Number"
            />
            {errors.companyPhone && (
              <div className="text-danger" style={{ fontSize: '0.85em' }}>
                {errors.companyPhone}
              </div>
            )}

            {/* Company Email */}
            <Form.Control
              className="mb-1"
              style={{ borderStyle: 'dashed' }}
              value={draft.company.email || ''}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  company: {
                    ...draft.company,
                    email: e.target.value,
                  },
                })
              }
              placeholder="Email"
            />

            {/* Website, Registration, VAT */}
            {['website', 'registration', 'vat'].map((key, idx) => (
              <Form.Control
                key={key}
                className={idx < 2 ? 'mb-1' : undefined}
                style={{ borderStyle: 'dashed' }}
                value={draft.company[key] || ''}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    company: {
                      ...draft.company,
                      [key]: e.target.value,
                    },
                  })
                }
                placeholder={
                  key === 'registration'
                    ? 'Registration No.'
                    : key === 'vat'
                    ? 'VAT / Tax No.'
                    : 'Website'
                }
              />
            ))}
          </>
        ) : (
          <>
            <p className="mb-0 fw-bold">{draft.company.name || '—'}</p>
            <p className="mb-0">{draft.company.address || '—'}</p>
            <p className="mb-0">
              Phone: {draft.company.phone || '—'}
            </p>
            <p className="mb-0">
              Email: {draft.company.email || '—'}
            </p>
            <p className="mb-0">
              Website: {draft.company.website || '—'}
            </p>
          </>
        )}
      </Col>
    </Row>
  );
}
