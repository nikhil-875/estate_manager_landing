// ──────────────────────────────────────────────────────────────────────────────
//                           QUOTATION-RELATED UTILITIES
// Place this file at: 
//   src/components/maintenance/sub/quotationUtils.jsx
// ──────────────────────────────────────────────────────────────────────────────

import React from 'react';
import { Form, Spinner, Row, Col, Button } from 'react-bootstrap';
import { FaEnvelope, FaDownload } from 'react-icons/fa';

/**
 * 1) toBase64(file):
 *    - Helper for uploading/previewing images (returns a Promise<string>).
 */
export const toBase64 = (file) =>
  new Promise((res, rej) => {
    const reader = new FileReader();
    reader.onload = () => res(reader.result);
    reader.onerror = rej;
    reader.readAsDataURL(file);
  });

/**
 * 2) emptyDraft:
 *    - The “skeleton” of a brand-new quotation (initial state shape).
 */
export const emptyDraft = {
  company: {
    logo: '',
    name: '',
    address: '',
    phone: '',
    email: '',
    website: '',
    registration: '',
    vat: '',
  },
  jobType: '',
  baseFee: 0,
  laborRate: 0,
  laborUnit: 'per hour',
  estQty: 0,
  materialCost: 0,
  travelCost: 0,
  markup: 0,
  taxRate: 0,
  vatIncluded: false,
  quoteValidity: 0,
  paymentMethod: '',
  paymentDetails: {
    bank: {
      accountName: '',
      bankName: '',
      accountNo: '',
      branchCode: '',
    },
    mobile: '',
    paypal: '',
    cash: '',
  },
  billToName: '',
  billToAddress: '',
};

/**
 * 3) calcTotals(draft):
 *    - Pure function to compute all derived costs (labor, markup, VAT, grandTotal).
 */
export const calcTotals = (d) => {
  const labor      = Number(d.laborRate) * Number(d.estQty);
  const subTotal   =
    Number(d.baseFee) +
    labor +
    Number(d.travelCost) +
    Number(d.materialCost);
  const markupAmt  = (subTotal * Number(d.markup)) / 100;
  const subPlusMk  = subTotal + markupAmt;
  const vatAmt     = d.vatIncluded ? (subPlusMk * Number(d.taxRate)) / 100 : 0;
  return {
    labor,
    markupAmt,
    vatAmt,
    subPlusMk,
    grandTotal: subPlusMk + vatAmt,
  };
};

/**
 * 4) NumberInput:
 *    - A tiny wrapper around <Form.Control type="number"> with dashed border.
 */
export const NumberInput = ({ value, onChange, style, ...props }) => (
  <Form.Control
    type="number"
    size="sm"
    value={value}
    style={style}
    onChange={(e) => onChange(Number(e.target.value))}
    {...props}
  />
);

/**
 * 5) TextInput:
 *    - A small wrapper around <Form.Control> for text inputs.
 */
export const TextInput = ({ value, onChange, ...props }) => (
  <Form.Control
    size="sm"
    value={value}
    onChange={(e) => onChange(e.target.value)}
    {...props}
  />
);

/**
 * 6) TextArea:
 *    - A small <textarea> wrapper (rows default to 3).
 */
export const TextArea = ({ value, onChange, rows = 3, ...props }) => (
  <Form.Control
    as="textarea"
    rows={rows}
    value={value}
    onChange={(e) => onChange(e.target.value)}
    {...props}
  />
);

/**
 * 7) CostRow:
 *    - Renders a <tr> with a label and either:
 *      • a dashed-border <input> (when editing)
 *      • or a “R xx.xx” string (when not editing).
 *
 *    Props:
 *      - editing: boolean
 *      - label: string
 *      - value: number    // the numeric value to display/modify
 *      - onChange: (newNumber: number) => void
 */
export const CostRow = ({ editing, label, value, onChange }) => (
  <tr>
    <td>{label}</td>
    <td className="text-end">
      {editing ? (
        <NumberInput
          value={value}
          onChange={onChange}
          style={{ borderStyle: 'dashed' }}
        />
      ) : (
        `R ${Number(value).toFixed(2)}`
      )}
    </td>
  </tr>
);


export const ContractorToolbar = ({
  editing,
  saving,
  onEdit,
  onCancel,
  onSave,
  onEmail,
  onPDF,
}) => (
  <div className="d-flex gap-2 justify-content-end flex-wrap">
    {editing ? (
      <>
        <Button size="sm" variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button size="sm" variant="primary" disabled={saving} onClick={onSave}>
          {saving && <Spinner animation="border" size="sm" className="me-2" />}
          Save&nbsp;Quotation
        </Button>
      </>
    ) : (
      <>
        <Button size="sm" variant="outline-primary" onClick={onEdit}>
          Edit&nbsp;Quotation
        </Button>
        <Button size="sm" variant="outline-info" onClick={onEmail}>
          <FaEnvelope className="me-1" />
          e-Mail
        </Button>
        <Button size="sm" variant="outline-secondary" onClick={onPDF}>
          <FaDownload className="me-1" />
          PDF
        </Button>
      </>
    )}
  </div>
);
