// src/components/maintenance/subcomponents/TaskTable.jsx

import React from 'react';
import { Table } from 'react-bootstrap';

export default function TaskTable({ tasks, friendlyReq }) {
  return (
    <Table bordered size="sm" className="mb-4">
      <thead className="table-light">
        <tr>
          <th style={{ width: '30%' }}>Request Date</th>
          <th>Description</th>
          <th style={{ width: '15%', textAlign: 'center' }}>Qty</th>
        </tr>
      </thead>
      <tbody>
        {tasks.length ? (
          tasks.map((t) => (
            <tr key={t.id}>
              <td>
                {friendlyReq || <span className="text-muted">—</span>}
              </td>
              <td>{t.description}</td>
              <td className="text-center">{t.qty}</td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan={3} className="text-center text-muted">
              No tasks listed
            </td>
          </tr>
        )}
      </tbody>
    </Table>
  );
}
