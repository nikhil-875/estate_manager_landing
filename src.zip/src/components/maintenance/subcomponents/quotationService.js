import { useEffect, useState, useCallback } from 'react';
import { useManageQuotationMutation } from '../../../api/maintenance';
import { emptyDraft } from './quotationUtils';

export const useQuotationService = (
  contractorId,
  requestId,
  incomingQId,
  requestStatus
) => {
  const [draft, setDraft] = useState(emptyDraft);
  const [quotationId, setQuotationId] = useState(incomingQId);
  const [manageQuotation, { isLoading }] = useManageQuotationMutation();

  // Helper: map “resp.data” → local “draft” shape
  const mapResponseToDraft = useCallback((q) => ({
    company: {
      logo: '',
      name: q.contractor?.company_name || '',
      address: q.contractor?.address || '',
      phone: q.contractor?.phone || '',
      email: q.contractor?.email || '',
      website: '',
      registration: q.contractor?.registration || '',
      vat: q.contractor?.tax_number || '',
    },
    jobType: q.job_type || '',
    baseFee: q.base_fee ?? 0,
    laborRate: q.labor_rate ?? 0,
    laborUnit: q.labor_unit || 'per hour',
    estQty: q.est_qty ?? 0,
    materialCost: q.material_cost ?? 0,
    travelCost: q.travel_cost ?? 0,
    markup: q.markup_pct ?? 0,
    taxRate: q.tax_rate_pct ?? 0,
    vatIncluded: q.vat_included ?? false,
    quoteValidity: q.quote_validity_days ?? 0,
    amount: q.amount ?? 0,
    paymentMethod: q.account?.payment_method || '',
    paymentDetails: {
      bank: {
        accountName: q.account?.payment_details?.bank?.accountName || '',
        bankName: q.account?.payment_details?.bank?.bankName || '',
        accountNo: q.account?.payment_details?.bank?.accountNo || '',
        branchCode: q.account?.payment_details?.bank?.branchCode || '',
      },
      mobile: q.account?.payment_details?.mobile || '',
      paypal: q.account?.payment_details?.paypal || '',
      cash: q.account?.payment_details?.cash || '',
    },
    billToName: q.account?.bill_to_name || '',
    billToAddress: q.account?.bill_to_address || '',
  }), []);

  // ── EFFECT: On mount or when contractorId/requestId/requestStatus changes ──
  useEffect(() => {
    if (!contractorId) {
      // Skip fetching if we don't have a contractorId
      setDraft(emptyDraft);
      return;
    }

    // If requestStatus is 'New', override requestId to 0, otherwise use the real requestId
    const effectiveRequestId = requestStatus === 'New' ? 0 : requestId;

    // Fetch existing quotation (or attempt to) for this requestId (possibly 0)
    manageQuotation({
      action: 'get_quotation',
      contractor_id: contractorId,
      request_id: effectiveRequestId,
    })
      .unwrap()
      .then((resp) => {
        if (resp?.data) {
          setDraft(mapResponseToDraft(resp.data));
          setQuotationId(resp.data.quotation_id);
        } else {
          // No data returned: reset to empty draft
          setDraft(emptyDraft);
        }
      })
      .catch(() => {
        // On error (or no existing quotation), stay with emptyDraft
        setDraft(emptyDraft);
      });
  }, [
    contractorId,
    requestId,
    requestStatus,
    manageQuotation,
    mapResponseToDraft,
  ]);

  const getQuotationComments = async (quotationId) => {
  try {
    const response = await manageQuotation({
      action: 'get_comments',
      quotation_id: quotationId,
    }).unwrap();

    // Ensure it's always an array
    return Array.isArray(response) ? response : [];
  } catch (error) {
    console.error('Failed to fetch comments:', error);
    return [];
  }
};

const addQuotationComment = async ({
    quotation_id,
    author_id,
    body,
    parent_comment_id = null,
  }) => {
    try {
      const response = await manageQuotation({
        action: 'add_comment',
        quotation_id,
        author_id,
        body,
        parent_comment_id,
      }).unwrap();

      return response;
    } catch (error) {
      console.error('Failed to add comment:', error);
      throw error;
    }
  };


  const saveQuotation = async (payload) => {
    const response = await manageQuotation({
      action: quotationId ? 'update' : 'insert',
      quotation_id: quotationId,
      contractor_id: contractorId,
      request_id: requestId,
      ...payload,
    }).unwrap();

    if (response?.data?.quotation_id) {
      setQuotationId(response.data.quotation_id);
    }
    return response;
  };

  return {
    draft,
    setDraft,
    quotationId,
    saving: isLoading,
    saveQuotation,
    getQuotationComments,
    addQuotationComment,
  };
};
