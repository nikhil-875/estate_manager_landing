// src/components/maintenance/subcomponents/PaymentDetails.jsx

import React from 'react';
import { Form, Row, Col } from 'react-bootstrap';

export default function PaymentDetails({ editing, draft, setDraft }) {
  return (
    <>
      <h6 className="mt-4">Payment Details</h6>
      {editing ? (
        <>
          <Form.Select
            className="mb-2"
            style={{ borderStyle: 'dashed' }}
            value={draft.paymentMethod}
            onChange={(e) =>
              setDraft({ ...draft, paymentMethod: e.target.value })
            }
          >
            {[
              'Electronic Funds Transfer',
              'Mobile',
              'PayPal',
              'Cash',
            ].map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </Form.Select>

          {/* Electronic Funds Transfer */}
          {draft.paymentMethod === 'Electronic Funds Transfer' && (
            <Row className="g-2">
              {['accountName', 'bankName', 'accountNo', 'branchCode'].map(
                (f) => (
                  <Col md={6} key={f}>
                    <Form.Label className="fw-semibold">
                      {f === 'accountName'
                        ? 'Account Name'
                        : f === 'bankName'
                        ? 'Bank'
                        : f === 'accountNo'
                        ? 'Account No'
                        : 'Branch Code'}
                    </Form.Label>
                    <Form.Control
                      style={{ borderStyle: 'dashed' }}
                      value={draft.paymentDetails.bank[f]}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          paymentDetails: {
                            ...draft.paymentDetails,
                            bank: {
                              ...draft.paymentDetails.bank,
                              [f]: e.target.value,
                            },
                          },
                        })
                      }
                    />
                  </Col>
                )
              )}
            </Row>
          )}

          {/* Mobile */}
          {draft.paymentMethod === 'Mobile' && (
            <Form.Control
              className="mb-2"
              style={{ borderStyle: 'dashed' }}
              placeholder="Mobile number"
              value={draft.paymentDetails.mobile}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  paymentDetails: {
                    ...draft.paymentDetails,
                    mobile: e.target.value,
                  },
                })
              }
            />
          )}

          {/* PayPal */}
          {draft.paymentMethod === 'PayPal' && (
            <Form.Control
              className="mb-2"
              style={{ borderStyle: 'dashed' }}
              placeholder="PayPal e-mail"
              value={draft.paymentDetails.paypal}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  paymentDetails: {
                    ...draft.paymentDetails,
                    paypal: e.target.value,
                  },
                })
              }
            />
          )}

          {/* Cash */}
          {draft.paymentMethod === 'Cash' && (
            <Form.Control
              as="textarea"
              rows={2}
              style={{ borderStyle: 'dashed' }}
              placeholder="Cash instructions"
              value={draft.paymentDetails.cash}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  paymentDetails: {
                    ...draft.paymentDetails,
                    cash: e.target.value,
                  },
                })
              }
            />
          )}
        </>
      ) : (
        <>
          <p className="mb-1 fw-semibold">
            {draft.paymentMethod || '—'}
          </p>

          {draft.paymentMethod === 'Electronic Funds Transfer' && (
            <p className="mb-0">
              {draft.paymentDetails.bank.accountName}
              <br />
              {draft.paymentDetails.bank.bankName} – Acc{' '}
              {draft.paymentDetails.bank.accountNo}
              <br />
              Branch Code: {draft.paymentDetails.bank.branchCode}
            </p>
          )}

          {draft.paymentMethod === 'Mobile' && (
            <p className="mb-0">
              <strong>Mobile:</strong>{' '}
              {draft.paymentDetails.mobile || '—'}
            </p>
          )}

          {draft.paymentMethod === 'PayPal' && (
            <p className="mb-0">
              <strong>PayPal:</strong>{' '}
              {draft.paymentDetails.paypal || '—'}
            </p>
          )}

          {draft.paymentMethod === 'Cash' && (
            <p className="mb-0">
              <strong>Cash:</strong> {draft.paymentDetails.cash || '—'}
            </p>
          )}
        </>
      )}
    </>
  );
}
