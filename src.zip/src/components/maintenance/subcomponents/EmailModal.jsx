// src/components/maintenance/subcomponents/EmailModal.jsx

import React from 'react';
import { Modal, Button, Form } from 'react-bootstrap';

export default function EmailModal({
  showMail,
  setShowMail,
  emailTo,
  setEmailTo,
  emailMsg,
  setEmailMsg,
  sendEmail,
}) {
  return (
    <Modal show={showMail} onHide={() => setShowMail(false)}>
      <Modal.Header closeButton>
        <Modal.Title>Email Quotation</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form.Group className="mb-3">
          <Form.Label>Email address(es)</Form.Label>
          <Form.Control
            type="text"
            placeholder="alice@example.com, bob@example.com"
            value={emailTo}
            onChange={(e) => setEmailTo(e.target.value)}
          />
          <Form.Text muted>
            Separate multiple addresses with commas.
          </Form.Text>
        </Form.Group>
        <Form.Group>
          <Form.Label>Optional message</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            value={emailMsg}
            onChange={(e) => setEmailMsg(e.target.value)}
          />
        </Form.Group>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={() => setShowMail(false)}>
          Cancel
        </Button>
        <Button variant="primary" disabled={!emailTo.trim()} onClick={sendEmail}>
          Send
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
