// src/components/maintenance/subcomponents/ZeroAmountModal.jsx

import React from 'react';
import { Modal, Button } from 'react-bootstrap';

export default function ZeroAmountModal({
  showZeroModal,
  setShowZeroModal,
}) {
  return (
    <Modal show={showZeroModal} onHide={() => setShowZeroModal(false)}>
      <Modal.Header closeButton>
        <Modal.Title>Zero-Amount Quote</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>You can save a quote with 0 amount.</p>
      </Modal.Body>
      <Modal.Footer>
        <Button
          variant="primary"
          onClick={() => setShowZeroModal(false)}
        >
          Ok
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
