// src/components/maintenance/subcomponents/CostBreakdown.jsx

import React from 'react';
import { Table, Form, Button } from 'react-bootstrap';

export default function CostBreakdown({
  editing,
  draft,
  setDraft,
  labor,      // precomputed number (e.g. draft.laborRate * draft.estQty)
  markupAmt,  // precomputed number
  vatAmt,     // precomputed number
  subPlusMk,  // precomputed number
  grandTotal, // precomputed number
}) {
  return (
    <Table bordered size="sm">
      <tbody>
        {/* ─── Base Call‐Out Fee ─── */}
        <tr>
          <td>Base Call‐Out Fee</td>
          <td className="text-end">
            {editing ? (
              <div className="d-flex align-items-center justify-content-end">
                <Form.Control
                  type="number"
                  size="sm"
                  style={{ borderStyle: 'dashed', width: 100 }}
                  value={draft.baseFee === '' ? '' : draft.baseFee}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      baseFee: e.target.value === '' ? '' : Number(e.target.value),
                    })
                  }
                />
                <Button
                  variant="link"
                  size="sm"
                  onClick={() => setDraft({ ...draft, baseFee: '' })}
                  style={{
                    marginLeft: 4,
                    color: 'grey',
                    textDecoration: 'none',
                    padding: '0 4px',
                  }}
                >
                  &times;
                </Button>
              </div>
            ) : (
              `R ${Number(draft.baseFee || 0).toFixed(2)}`
            )}
          </td>
        </tr>

        {/* ─── Labor ─── */}
        <tr>
          <td>
            Labor{' '}
            <small className="text-muted">
              ({draft.estQty === '' ? 0 : draft.estQty}{' '}
              {draft.laborUnit === 'per hour' ? 'hrs' : 'days'} @ R
              {draft.laborRate === '' ? 0 : draft.laborRate})
            </small>
          </td>
          <td className="text-end">
            {editing ? (
              <div className="d-flex gap-2 justify-content-end align-items-center">
                <Form.Control
                  size="sm"
                  style={{ borderStyle: 'dashed', width: 80 }}
                  value={draft.laborRate === '' ? '' : draft.laborRate}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      laborRate: e.target.value === '' ? '' : Number(e.target.value),
                    })
                  }
                />
                <Button
                  variant="link"
                  size="sm"
                  onClick={() => setDraft({ ...draft, laborRate: '' })}
                  style={{
                    marginLeft: 4,
                    color: 'grey',
                    textDecoration: 'none',
                    padding: '0 4px',
                  }}
                >
                  &times;
                </Button>

                <Form.Control
                  size="sm"
                  style={{ borderStyle: 'dashed', width: 70 }}
                  value={draft.estQty === '' ? '' : draft.estQty}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      estQty: e.target.value === '' ? '' : Number(e.target.value),
                    })
                  }
                />
                <Button
                  variant="link"
                  size="sm"
                  onClick={() => setDraft({ ...draft, estQty: '' })}
                  style={{
                    marginLeft: 4,
                    color: 'grey',
                    textDecoration: 'none',
                    padding: '0 4px',
                  }}
                >
                  &times;
                </Button>

                <Form.Select
                  size="sm"
                  style={{ borderStyle: 'dashed', width: 100, marginLeft: 4 }}
                  value={draft.laborUnit}
                  onChange={(e) =>
                    setDraft({ ...draft, laborUnit: e.target.value })
                  }
                >
                  <option value="per hour">per hour</option>
                  <option value="per day">per day</option>
                </Form.Select>
              </div>
            ) : (
              `R ${labor.toFixed(2)}`
            )}
          </td>
        </tr>

        {/* ─── Travel / Distance ─── */}
        <tr>
          <td>Travel / Distance</td>
          <td className="text-end">
            {editing ? (
              <div className="d-flex align-items-center justify-content-end">
                <Form.Control
                  type="number"
                  size="sm"
                  style={{ borderStyle: 'dashed', width: 100 }}
                  value={draft.travelCost === '' ? '' : draft.travelCost}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      travelCost: e.target.value === '' ? '' : Number(e.target.value),
                    })
                  }
                />
                <Button
                  variant="link"
                  size="sm"
                  onClick={() => setDraft({ ...draft, travelCost: '' })}
                  style={{
                    marginLeft: 4,
                    color: 'grey',
                    textDecoration: 'none',
                    padding: '0 4px',
                  }}
                >
                  &times;
                </Button>
              </div>
            ) : (
              `R ${Number(draft.travelCost || 0).toFixed(2)}`
            )}
          </td>
        </tr>

        {/* ─── Material Cost ─── */}
        <tr>
          <td>Material Cost</td>
          <td className="text-end">
            {editing ? (
              <div className="d-flex align-items-center justify-content-end">
                <Form.Control
                  type="number"
                  size="sm"
                  style={{ borderStyle: 'dashed', width: 100 }}
                  value={draft.materialCost === '' ? '' : draft.materialCost}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      materialCost: e.target.value === '' ? '' : Number(e.target.value),
                    })
                  }
                />
                <Button
                  variant="link"
                  size="sm"
                  onClick={() => setDraft({ ...draft, materialCost: '' })}
                  style={{
                    marginLeft: 4,
                    color: 'grey',
                    textDecoration: 'none',
                    padding: '0 4px',
                  }}
                >
                  &times;
                </Button>
              </div>
            ) : (
              `R ${Number(draft.materialCost || 0).toFixed(2)}`
            )}
          </td>
        </tr>

        {/* ─── Quote Validity (days) ─── */}
        <tr>
          <td>Quote Validity (days)</td>
          <td className="text-end">
            {editing ? (
              <div className="d-flex align-items-center justify-content-end">
                <Form.Control
                  type="number"
                  size="sm"
                  style={{ borderStyle: 'dashed', width: 80 }}
                  value={
                    draft.quoteValidityDays === ''
                      ? ''
                      : draft.quoteValidityDays == null
                      ? 30
                      : draft.quoteValidityDays
                  }
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      quoteValidityDays:
                        e.target.value === '' ? '' : Number(e.target.value),
                    })
                  }
                />
                <Button
                  variant="link"
                  size="sm"
                  onClick={() => setDraft({ ...draft, quoteValidityDays: '' })}
                  style={{
                    marginLeft: 4,
                    color: 'grey',
                    textDecoration: 'none',
                    padding: '0 4px',
                  }}
                >
                  &times;
                </Button>
              </div>
            ) : (
              `${draft.quoteValidityDays ?? 30} days`
            )}
          </td>
        </tr>

        {/* ─── Markup Percentage ─── */}
        <tr>
          <td>
            Markup{' '}
            {editing && (
              <small className="text-muted">({draft.markup ?? 0}%)</small>
            )}
          </td>
          <td className="text-end">
            {editing ? (
              <div className="d-flex align-items-center justify-content-end">
                <Form.Control
                  type="number"
                  size="sm"
                  style={{ borderStyle: 'dashed', width: 80 }}
                  value={draft.markup === '' ? '' : draft.markup}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      markup: e.target.value === '' ? '' : Number(e.target.value),
                    })
                  }
                />
                <Button
                  variant="link"
                  size="sm"
                  onClick={() => setDraft({ ...draft, markup: '' })}
                  style={{
                    marginLeft: 4,
                    color: 'grey',
                    textDecoration: 'none',
                    padding: '0 4px',
                  }}
                >
                  &times;
                </Button>
              </div>
            ) : (
              `R ${markupAmt.toFixed(2)}`
            )}
          </td>
        </tr>

        {/* ─── Subtotal + Markup Row ─── */}
        <tr className="table-light">
          <th>Subtotal</th>
          <th className="text-end">R {subPlusMk.toFixed(2)}</th>
        </tr>

        {/* ─── VAT ─── */}
        {draft.vatIncluded && (
          <tr>
            <td>
              VAT{' '}
              {editing && (
                <small className="text-muted">({draft.taxRate ?? 0}%)</small>
              )}
            </td>
            <td className="text-end">
              {editing ? (
                <div className="d-flex align-items-center justify-content-end">
                  <Form.Control
                    type="number"
                    size="sm"
                    style={{ borderStyle: 'dashed', width: 80 }}
                    value={draft.taxRate === '' ? '' : draft.taxRate}
                    onChange={(e) =>
                      setDraft({
                        ...draft,
                        taxRate: e.target.value === '' ? '' : Number(e.target.value),
                      })
                    }
                  />
                  <Button
                    variant="link"
                    size="sm"
                    onClick={() => setDraft({ ...draft, taxRate: '' })}
                    style={{
                      marginLeft: 4,
                      color: 'grey',
                      textDecoration: 'none',
                      padding: '0 4px',
                    }}
                  >
                    &times;
                  </Button>
                </div>
              ) : (
                `R ${vatAmt.toFixed(2)}`
              )}
            </td>
          </tr>
        )}

        {/* ─── VAT Checkbox (when editing) ─── */}
        {editing && (
          <tr>
            <td colSpan={2}>
              <Form.Check
                type="checkbox"
                label="Include VAT line"
                checked={draft.vatIncluded}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    vatIncluded: e.target.checked,
                  })
                }
              />
            </td>
          </tr>
        )}

        {/* ─── Grand Total ─── */}
        <tr className="table-primary">
          <th>Total Due</th>
          <th className="text-end">R {grandTotal.toFixed(2)}</th>
        </tr>
      </tbody>
    </Table>
  );
}
