import React from 'react';
import { Card, Form, Button, ListGroup } from 'react-bootstrap';
import { FaPaperclip } from 'react-icons/fa';

/** Comment list + add form (shown once quotation exists). */
export default function ContractorComment({
  comments,
  newComment,
  setNewComment,
  fileAttachment,
  onAttachClick,
  onFileChange,
  onAddComment,
  fileInputRef
}) {
  return (
    <Card style={{ minHeight: 400 }}>
      <Card.Header>Comments on Quotation</Card.Header>
      <Card.Body>
        <ListGroup className="mb-3">
          {(comments || []).map((c, i) => (
            <ListGroup.Item key={i}>
              {c.text}
              {c.file && (
                <div className="mt-1">
                  <em>Attached:</em> {c.file.name}
                </div>
              )}
            </ListGroup.Item>
          ))}
        </ListGroup>

        <Form onSubmit={onAddComment}>
          <input
            type="file"
            ref={fileInputRef}
            style={{ display: 'none' }}
            onChange={onFileChange}
          />
          <div className="d-flex mb-2">
            <Button variant="light" onClick={onAttachClick} className="me-2">
              <FaPaperclip />
            </Button>
            <Form.Control
              type="text"
              placeholder="Add a comment..."
              value={newComment}
              onChange={e => setNewComment(e.target.value)}
            />
            <Button
              type="submit"
              variant="secondary"
              disabled={!newComment.trim() && !fileAttachment}
              className="ms-2"
            >
              Add
            </Button>
          </div>
          {fileAttachment && (
            <small className="text-muted">📎 {fileAttachment.name}</small>
          )}
        </Form>
      </Card.Body>
    </Card>
  );
}
