// src/components/maintenance/OwnerQuotations.jsx
import React, { useState, useRef, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useManageRequestApplyMutation } from '../../api/maintenance';
import { useQuotationService } from './subcomponents/quotationService';

const formatDate = (iso) =>
  new Date(iso).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

export default function OwnerQuotations({ request }) {
  const userId   = useSelector((s) => s.auth.user?.id);
  const userType = useSelector((s) => s.auth.user?.type);

  const [showModal, setShowModal]               = useState(false);
  const [currentQuotation, setCurrentQuotation] = useState(null);
  const [quotations, setQuotations]             = useState([]);

  const [commentsList, setCommentsList]         = useState([]);
  const [newComment, setNewComment]             = useState('');
  const [fileAttachment, setFileAttachment]     = useState(null);
  const fileRef = useRef(null);

  const [getApplication] = useManageRequestApplyMutation();

  const {
    getQuotationComments,
    addQuotationComment,
  } = useQuotationService(
    currentQuotation?.contractor_id ?? 0,
    request?.id ?? 0,
    currentQuotation?.quotation_id ?? 0,
    userType
  );

  useEffect(() => {
    if (!request?.id || !userId || !userType) return;

    const fetchApplications = async () => {
      const payload = {
        action:      'get_application',
        request_id:  request.id,
        user_id:     userId,
        user_type:   userType,
      };

      console.log('CALL   ➜  payload:', payload);

      try {
        const data = await getApplication(payload).unwrap();
        console.log('RESOLVE ➜  data:', data);
        setQuotations(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error('REJECT  ➜  error:', err);
        setQuotations([]);
      } finally {
        console.log('DONE   ➜  finished fetchApplications()');
      }
    };

    fetchApplications();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [request?.id, userId, userType]);

  useEffect(() => {
    if (showModal && currentQuotation?.quotation_id) {
      getQuotationComments(currentQuotation.quotation_id)
        .then((list) => setCommentsList(list))
        .catch(() => setCommentsList([]));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showModal, currentQuotation]);

  if (!request) {
    return null;
  }

  const handleAddComment = async () => {
    if (!newComment.trim() && !fileAttachment) return;

    const payload = {
      quotation_id:      currentQuotation.quotation_id,
      author_id:         userId,
      body:              newComment.trim(),
      parent_comment_id: null,
    };
    if (fileAttachment) {
      payload.file_name = fileAttachment.name;
      payload.file_url  = '';
    }

    try {
      await addQuotationComment(payload);
      const updated = await getQuotationComments(currentQuotation.quotation_id);
      setCommentsList(updated);
      setNewComment('');
      setFileAttachment(null);
      fileRef.current.value = '';
    } catch {
      // Optionally handle error
    }
  };

  return (
    <>
      {/* ─── Quotation List ──────────────────────────────────────────────────── */}
      <ul className="list-group mb-3">
        {quotations.map((q) => (
          <li
            key={q.apply_id}
            className="list-group-item d-flex justify-content-between"
            style={{ cursor: 'pointer' }}
            onClick={() => {
              setCurrentQuotation(q);
              setShowModal(true);
            }}
          >
            <div>
              <strong>{q.company_name}</strong>
              <div className="small text-muted">
                {formatDate(q.applied_at)}
              </div>
            </div>
            <span>
              {q.currency}
              {Number(q.amount).toLocaleString(undefined, {
                minimumFractionDigits: 2,
              })}
            </span>
          </li>
        ))}

        {!quotations.length && (
          <li className="list-group-item text-muted">
            No quotations submitted yet.
          </li>
        )}
      </ul>

      {/* ─── Quotation Details & Comments Modal ─────────────────────────────── */}
      {showModal && currentQuotation && (
        <div
          className="modal fade show d-block"
          style={{ backgroundColor: 'rgba(0,0,0,.5)' }}
        >
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Quotation Details</h5>
                <button
                  className="btn-close"
                  onClick={() => {
                    setShowModal(false);
                    setCommentsList([]);
                    setNewComment('');
                    setFileAttachment(null);
                  }}
                />
              </div>

              <div className="modal-body">
                <p>
                  <strong>Contractor:</strong> {currentQuotation.company_name}
                </p>
                <p>
                  <strong>Amount:</strong> {currentQuotation.currency}
                  {Number(currentQuotation.amount).toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                  })}
                </p>
                <p>
                  <strong>Submitted:</strong>{' '}
                  {formatDate(currentQuotation.applied_at)}
                </p>

                <hr />
                <h6>Discussion</h6>
                <ul className="list-group mb-3">
                  {commentsList.length > 0 ? (
                    commentsList.map((c) => (
                      <li key={c.comment_id} className="list-group-item">
                        <div className="d-flex justify-content-between">
                          <strong>{c.author_name}</strong>
                          <small className="text-muted">
                            {new Date(c.created_at).toLocaleString()}
                          </small>
                        </div>
                        <div>{c.body}</div>
                        {c.file_name && (
                          <div className="mt-1">
                            <em>Attached:</em>{' '}
                            <a
                              href={c.file_url || '#'}
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              {c.file_name}
                            </a>
                          </div>
                        )}
                      </li>
                    ))
                  ) : (
                    <li className="list-group-item text-muted">
                      No discussion yet.
                    </li>
                  )}
                </ul>

                {/* Add new comment */}
                <div className="input-group mb-2">
                  <button
                    className="btn btn-outline-secondary"
                    onClick={() => fileRef.current.click()}
                    title="Attach a file"
                  >
                    📎
                  </button>
                  <input
                    type="file"
                    ref={fileRef}
                    style={{ display: 'none' }}
                    onChange={(e) => setFileAttachment(e.target.files[0])}
                  />

                  <input
                    className="form-control"
                    placeholder="Add a comment…"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                  />

                  <button
                    className="btn btn-primary"
                    onClick={handleAddComment}
                    disabled={!newComment.trim() && !fileAttachment}
                  >
                    Send
                  </button>
                </div>
                {fileAttachment && (
                  <div className="mb-2">
                    <small className="text-muted">
                      📎 {fileAttachment.name}
                    </small>
                  </div>
                )}
              </div>

              <div className="modal-footer">
                {/* New "Accept Quotation" button */}
                <button
                  className="btn btn-success"
                  onClick={() => {
                    // TODO: implement accept-quotation logic here
                    console.log('Accept Quotation clicked:', currentQuotation.quotation_id);
                  }}
                >
                  Accept Quotation
                </button>

                <button
                  className="btn btn-secondary"
                  onClick={() => {
                    setShowModal(false);
                    setCommentsList([]);
                    setNewComment('');
                    setFileAttachment(null);
                  }}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
