// src/components/maintenance/ContractorJobDetails.jsx

import React, { useState, useRef, useEffect } from 'react';
import {
  Card,
  Button,
  Modal,
  Form,
  ListGroup,
  Alert,
  Spinner,
  Badge,
} from 'react-bootstrap';
import { FaPaperclip, FaEnvelope, FaComments } from 'react-icons/fa';
import {
  useGetQuotationAmountsQuery,
  useManageRequestApplyMutation,
} from '../../api/maintenance';
import { useQuotationService } from './subcomponents/quotationService'; // ← your service hook

/**
 * CommentsModal
 *
 * Renders a modal that shows previous comments on a quotation and allows
 * submitting a new comment (with optional attachment).
 */
function CommentsModal({
  show,
  onHide,
  commentsList,
  newCommentValue,
  setNewCommentValue,
  fileAttachmentValue,
  fileInputRef,
  onAttachClickHandler,
  onFileChangeHandler,
  onSubmitHandler,
  isSubmitting,
}) {
  const handleSubmit = () => {
    onSubmitHandler({ preventDefault: () => {} });
  };

  // Utility to render initials from a full name (e.g. "John Doe" → "JD")
  const renderInitials = (fullName) => {
    const parts = fullName.trim().split(/\s+/);
    const first = parts[0]?.[0] || '';
    const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
    return (first + last).toUpperCase();
  };

  return (
    <Modal
      show={show}
      onHide={onHide}
      size="md"
      centered
      dialogClassName="mw-75"
    >
      <Modal.Header closeButton>
        <Modal.Title>
          <FaComments className="me-2" />
          Quotation Comments
        </Modal.Title>
      </Modal.Header>

      <Modal.Body style={{ minHeight: '400px' }}>
        <h6>Previous Comments:</h6>
        <ListGroup variant="flush" className="mb-4">
          {commentsList.length > 0 ? (
            commentsList.map((c, idx) => {
              const initials = renderInitials(c.author_name);
              return (
                <ListGroup.Item key={idx}>
                  <div className="d-flex justify-content-between align-items-center mb-1">
                    <div className="d-flex align-items-center">
                      <div
                        style={{
                          width: '32px',
                          height: '32px',
                          borderRadius: '50%',
                          backgroundColor: '#6c757d',
                          color: 'white',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '0.9rem',
                          marginRight: '8px',
                          textTransform: 'uppercase',
                        }}
                      >
                        {initials}
                      </div>
                      <strong>{c.author_name}</strong>
                    </div>
                    <small className="text-muted">
                      {new Date(c.created_at).toLocaleString()}
                    </small>
                  </div>
                  <div style={{ marginLeft: '45px' }}>{c.body}</div>
                  {c.file_name && (
                    <div className="mt-2" style={{ marginLeft: '45px' }}>
                      <em>Attached:</em>{' '}
                      <a
                        href={c.file_url || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {c.file_name}
                      </a>
                    </div>
                  )}
                </ListGroup.Item>
              );
            })
          ) : (
            <div className="text-muted">No comments yet.</div>
          )}
        </ListGroup>

        <Form.Group controlId="commentText" className="mb-3">
          <Form.Control
            as="textarea"
            rows={3}
            placeholder="Type your comment..."
            value={newCommentValue}
            onChange={(e) => setNewCommentValue(e.target.value)}
          />
        </Form.Group>

        <div className="mb-3">
          <input
            type="file"
            ref={fileInputRef}
            onChange={onFileChangeHandler}
            style={{ display: 'none' }}
          />
          <Button variant="light" onClick={onAttachClickHandler}>
            <FaPaperclip /> Attach Document
          </Button>
          {fileAttachmentValue && (
            <div className="mt-2">
              <small className="text-muted">📎 {fileAttachmentValue.name}</small>
            </div>
          )}
        </div>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
        <Button
          variant="primary"
          onClick={handleSubmit}
          disabled={
            (!newCommentValue.trim() && !fileAttachmentValue) || isSubmitting
          }
        >
          {isSubmitting ? <Spinner animation="border" size="sm" /> : 'Submit'}
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

/**
 * ContractorJobDetails
 *
 * This component displays:
 *  • A preview card showing the job title, property name, current quoted amount,
 *    and either a "Send Quotation" button or a "Messages" button (if already applied).
 *  • If quotation statusId === 6, it instead displays a "Congratulations! Your Quote Was Accepted"
 *    card with details and a "Set Up Contract" button.
 *  • A modal for viewing job details and existing comments.
 *  • A modal for creating a new invoice.
 *  • A confirmation modal before sending a quotation.
 *  • A CommentsModal (above) to view/post comments to the quotation.
 */
export default function ContractorJobDetails({
  job,
  showModal,
  onHide,
  newComment,
  setNewComment,
  fileAttachment,
  setFileAttachment,
  fileInputRef,
  onAttachClick,
  onFileChange,
  onCreateInvoice,
  onSend,
  invoiceAmount = 0,
  contractorId,
  requestId,
  requestStatus,
}) {
  // 1) Fetch quotation amount and ID from backend
  const { data: quotationData, isLoading: isLoadingAmounts } =
    useGetQuotationAmountsQuery({
      contractor_id: contractorId,
      request_id: requestId,
    });

  // 2) Mutation to apply/manage request (status change to “Applied”)
  const [manageRequestApply, { isLoading: isApplying }] =
    useManageRequestApplyMutation();

  // 3) Derived & local state
  const currentAmount = Number(quotationData?.amount ?? 0);
  const quotationId = Number(quotationData?.quotation_id ?? 0);
  const statusId = Number(quotationData?.status ?? 0);
  const invAmtNum = Number(invoiceAmount) || 0;

  // Invoice-creation state
  const [showCreate, setShowCreate] = useState(false);
  const [invName, setInvName] = useState('');
  const [invAddress, setInvAddress] = useState('');
  const [invDesc, setInvDesc] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [applyErrorMsg, setApplyErrorMsg] = useState(null);

  // Comments logic
  const [showCommentsModal, setShowCommentsModal] = useState(false);
  const [commentsList, setCommentsList] = useState([]);
  const [isPostingComment, setIsPostingComment] = useState(false);

  const invoiceRef = useRef(null);
  if (!job) return null;

  // 4) Service hook to fetch/add comments for this quotation
  const {
    getQuotationComments,
    addQuotationComment,
  } = useQuotationService(
    contractorId,
    requestId,
    quotationId,
    requestStatus
  );

  // Fetch comments once when the CommentsModal opens
  useEffect(() => {
    if (showCommentsModal && quotationId) {
      getQuotationComments(quotationId)
        .then((list) => setCommentsList(list))
        .catch(() => setCommentsList([]));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showCommentsModal, quotationId]);

  // 5) Helpers
  const formattedCurrentAmt = currentAmount.toLocaleString(undefined, {
    style: 'currency',
    currency: 'ZAR',
  });

  // Close the "Create Invoice" modal and reset its fields
  const closeCreate = () => {
    setInvName('');
    setInvAddress('');
    setInvDesc('');
    setShowCreate(false);
  };

  // Handle creation of a new invoice
  const handleCreateInvoice = () => {
    onCreateInvoice?.({
      name: invName,
      address: invAddress,
      description: invDesc,
      amount: invAmtNum,
    });
    closeCreate();
  };

  // 6) When user clicks to send a quotation or open comments
  const handleSendClick = () => {
    if (requestStatus === 'Applied') {
      // Already applied: show the comments modal instead
      setShowCommentsModal(true);
      return;
    }
    // If still loading amounts or applying, do nothing
    if (isLoadingAmounts || isApplying) return;
    // Otherwise ask for confirmation
    setShowConfirmModal(true);
  };

  // Confirm and send quotation (changes status to 5 = “Applied”)
  const confirmAndSend = async () => {
    setShowConfirmModal(false);
    setApplyErrorMsg(null);

    try {
      const payload = {
        action: 'insert',
        request_id: requestId,
        contractor_id: contractorId,
        applied_by: contractorId,
        status: 5,
      };

      const resp = await manageRequestApply(payload).unwrap();
      if (resp?.status_code !== 200) {
        setApplyErrorMsg(resp?.message ?? 'Error applying to request');
        return;
      }
      onSend?.();
    } catch (err) {
      setApplyErrorMsg(err?.data?.message ?? 'Failed to apply to request');
    }
  };

  // 7) Post a new comment using addQuotationComment
  const handleAddComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim() && !fileAttachment) return;

    setIsPostingComment(true);
    try {
      const payload = {
        quotation_id: quotationId,
        author_id: contractorId,
        body: newComment.trim(),
        parent_comment_id: null,
      };

      if (fileAttachment) {
        payload.file_name = fileAttachment.name;
        // You can replace this with your real upload URL logic:
        payload.file_url = '';
      }

      await addQuotationComment(payload);
      const updatedList = await getQuotationComments(quotationId);
      setCommentsList(updatedList);

      setNewComment('');
      setFileAttachment(null);
    } catch {
      // Optionally handle error here
    } finally {
      setIsPostingComment(false);
    }
  };

  // Utility to render initials from a full name for the avatar circles
  const renderInitials = (fullName) => {
    const parts = fullName.trim().split(/\s+/);
    const first = parts[0]?.[0] || '';
    const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
    return (first + last).toUpperCase();
  };

  return (
    <>
      {/* Global error banner for any “apply to request” errors */}
      {applyErrorMsg && (
        <Alert
          variant="danger"
          dismissible
          onClose={() => setApplyErrorMsg(null)}
        >
          {applyErrorMsg}
        </Alert>
      )}

      <div ref={invoiceRef}>
        {/*
          === CONDITIONAL: If statusId === 6, show “Congratulations!” card ===
        */}
        {statusId === 6 ? (
          <Card className="mb-4" style={{ borderRadius: '1rem' }}>
            <Card.Body>
              {/* ─── Top row: three columns ─── */}
              <div
                className="d-flex justify-content-between align-items-center mb-4"
                style={{ gap: '1rem' }}
              >
                {/* ── LEFT: Property Name ── */}
                <div style={{ flex: 1, fontSize: '1rem', fontWeight: 500 }}>
                  {/* {job.property} */}
                </div>

                {/* ── CENTER: “Congratulations!” heading ── */}
                <div style={{ flex: 1, textAlign: 'center' }}>
                  <h2 style={{ margin: 0, fontWeight: 'bold' }}>
                    Congratulations!
                  </h2>
                  <div style={{ fontSize: '1rem', color: '#555' }}>
                    Your Quote Was Accepted
                  </div>
                </div>

                {/* ── RIGHT: Amount + Start Date ── */}
                <div
                  style={{
                    flex: 1,
                    textAlign: 'right',
                    fontSize: '1.25rem',
                    fontWeight: 600,
                    lineHeight: 1.2,
                  }}
                >
                  {/* {formattedCurrentAmt} */}
                  <div
                    style={{
                      marginTop: '0.25rem',
                      fontSize: '0.875rem',
                      fontWeight: 400,
                      color: '#777',
                    }}
                  >
                    {/* Start&nbsp;|&nbsp; */}
                    {/* {quotationData?.quote_date
                      ? new Date(quotationData.quote_date).toLocaleDateString()
                      : new Date().toLocaleDateString()} */}
                  </div>
                </div>
              </div>

              {/* ─── “Set Up Contract” button centered underneath ─── */}
              <div className="d-flex justify-content-center">
                <Button variant="primary" size="lg">
                  Set Up Contract
                </Button>
              </div>
            </Card.Body>
          </Card>
        ) : (
          <>
            {/*
              === ORIGINAL: Quotation preview + Send/Messages button ===
            */}
            <Card className="mb-4">
              <Card.Body>
                <div className="d-flex justify-content-between align-items-start mb-2">
                  <div>
                    <Card.Title>{job.title}</Card.Title>
                    <Card.Subtitle className="text-muted">
                      {job.property}
                    </Card.Subtitle>
                  </div>

                  <div className="text-end">
                    <div className="h5 mb-1">{formattedCurrentAmt}</div>
                    {requestStatus === 'Applied' ? (
                      <Button
                        size="sm"
                        variant="secondary"
                        style={{ whiteSpace: 'nowrap', position: 'relative' }}
                        onClick={handleSendClick}
                      >
                        <FaComments className="me-1" />
                        Messages
                        <Badge
                          bg="danger"
                          pill
                          style={{
                            position: 'absolute',
                            top: '-6px',
                            right: '-6px',
                            fontSize: '0.6rem',
                          }}
                        >
                          {commentsList.length}
                        </Badge>
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="primary"
                        style={{ whiteSpace: 'nowrap' }}
                        onClick={handleSendClick}
                        disabled={isLoadingAmounts || isApplying}
                      >
                        {isLoadingAmounts || isApplying ? (
                          <>
                            <Spinner
                              as="span"
                              animation="border"
                              size="sm"
                              className="me-1"
                            />
                            Sending…
                          </>
                        ) : (
                          <>
                            <FaEnvelope className="me-1" />
                            Send Quotation
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
                <Card.Text>{job.description}</Card.Text>
              </Card.Body>
            </Card>
          </>
        )}
      </div>

      {/*
        === Job-Details Modal ===
        Shows job.property, job.description, existing comments + quick-add form
      */}
      <Modal
        show={showModal}
        onHide={onHide}
        size="md"
        centered
        dialogClassName="mw-75"
      >
        <Modal.Header closeButton>
          <Modal.Title>{job.title} — Details</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ minHeight: '400px' }}>
          <p>
            <strong>Property:</strong> {job.property}
          </p>
          <p>{job.description}</p>

          <h6>Comments</h6>
          <ListGroup className="mb-3">
            {commentsList.length ? (
              commentsList.map((c, idx) => {
                const initials = renderInitials(c.author_name);
                return (
                  <ListGroup.Item key={idx}>
                    <div className="d-flex justify-content-between align-items-center mb-1">
                      <div className="d-flex align-items-center">
                        <div
                          style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '50%',
                            backgroundColor: '#6c757d',
                            color: 'white',
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '0.9rem',
                            marginRight: '8px',
                            textTransform: 'uppercase',
                          }}
                        >
                          {initials}
                        </div>
                        <strong>{c.author_name}</strong>
                      </div>
                      <small className="text-muted">
                        {new Date(c.created_at).toLocaleString()}
                      </small>
                    </div>
                    <div>{c.body}</div>
                    {c.file_name && (
                      <div className="mt-2">
                        <em>Attached:</em>{' '}
                        <a
                          href={c.file_url || '#'}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {c.file_name}
                        </a>
                      </div>
                    )}
                  </ListGroup.Item>
                );
              })
            ) : (
              <ListGroup.Item className="text-muted">
                No comments yet.
              </ListGroup.Item>
            )}
          </ListGroup>

          {/* Quick add-comment form */}
          <Form onSubmit={handleAddComment}>
            <Form.Group controlId="quickComment" className="mb-3">
              <Form.Control
                type="text"
                placeholder="Add a quick comment…"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
              />
            </Form.Group>

            <div className="d-flex mb-2">
              <input
                type="file"
                ref={fileInputRef}
                onChange={onFileChange}
                style={{ display: 'none' }}
              />
              <Button variant="light" className="me-2" onClick={onAttachClick}>
                <FaPaperclip />
              </Button>
              <Button
                type="submit"
                variant="secondary"
                disabled={
                  (!newComment.trim() && !fileAttachment) || isPostingComment
                }
              >
                {isPostingComment ? (
                  <Spinner as="span" animation="border" size="sm" />
                ) : (
                  'Add'
                )}
              </Button>
            </div>
            {fileAttachment && (
              <small className="text-muted">📎 {fileAttachment.name}</small>
            )}
          </Form>
        </Modal.Body>
      </Modal>

      {/*
        === Create-Invoice Modal ===
      */}
      <Modal
        show={showCreate}
        onHide={closeCreate}
        size="md"
        centered
        dialogClassName="mw-75"
      >
        <Modal.Header closeButton>
          <Modal.Title>Create New Invoice</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ minHeight: '300px' }}>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Invoice Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Customer or Job Name"
                value={invName}
                onChange={(e) => setInvName(e.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Address</Form.Label>
              <Form.Control
                as="textarea"
                rows={2}
                placeholder="Billing Address"
                value={invAddress}
                onChange={(e) => setInvAddress(e.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Invoice details or notes"
                value={invDesc}
                onChange={(e) => setInvDesc(e.target.value)}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeCreate}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={handleCreateInvoice}
            disabled={!invName.trim() || !invAddress.trim()}
          >
            Create Invoice
          </Button>
        </Modal.Footer>
      </Modal>

      {/*
        === Confirm-Send Modal ===
      */}
      <Modal
        show={showConfirmModal}
        onHide={() => setShowConfirmModal(false)}
        size="md"
        centered
        dialogClassName="mw-75"
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Before Sending</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ minHeight: '200px' }}>
          <p>
            You’re about to send a quotation for{' '}
            <strong>{formattedCurrentAmt} </strong>.<br />
            Are you sure you want to proceed?
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowConfirmModal(false)}>
            Not Yet
          </Button>
          <Button variant="danger" disabled={isApplying} onClick={confirmAndSend}>
            {isApplying ? (
              <>
                <Spinner as="span" animation="border" size="sm" className="me-1" />
                Sending…
              </>
            ) : (
              'Yes, Send Quotation'
            )}
          </Button>
        </Modal.Footer>
      </Modal>

      {/*
        === CommentsModal (invoked when clicking “Messages”) ===
      */}
      <CommentsModal
        show={showCommentsModal}
        onHide={() => setShowCommentsModal(false)}
        commentsList={commentsList}
        newCommentValue={newComment}
        setNewCommentValue={setNewComment}
        fileAttachmentValue={fileAttachment}
        fileInputRef={fileInputRef}
        onAttachClickHandler={onAttachClick}
        onFileChangeHandler={onFileChange}
        onSubmitHandler={handleAddComment}
        isSubmitting={isPostingComment}
      />
    </>
  );
}
