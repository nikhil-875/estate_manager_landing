// src/components/maintenance/ContractorQuotation.jsx

import React, { useState, useRef, useMemo, useEffect } from 'react';
import {
  Card,
  Row,
  Col,
  Form,
  Button,
  Spinner,
} from 'react-bootstrap';
import html2pdf from 'html2pdf.js';
import { FaEnvelope, FaDownload, FaPlus } from 'react-icons/fa';
import {
  toBase64,
  calcTotals,
} from './subcomponents/quotationUtils';
import { useQuotationService } from './subcomponents/quotationService';
import HeaderBlock from './subcomponents/HeaderBlock';
import TaskTable from './subcomponents/TaskTable';
import CostBreakdown from './subcomponents/CostBreakdown';
import PaymentDetails from './subcomponents/PaymentDetails';
import EmailModal from './subcomponents/EmailModal';
import ZeroAmountModal from './subcomponents/ZeroAmountModal';

export default function ContractorQuotation({
  requestId = 0,
  propertyName = '',
  address = '',
  requestStatus = 'New',
  quotesaved,
  quotationId: incomingQId = null,
  requestTitle = '',
  requestDescription = '',
  requestDate = '',
  serviceOffer = '',
  tasks = [],
  onSave = () => { },
  onEmail = () => { },
  onAmountChange = () => { },
}) {

  const [editing, setEditing] = useState(false);
  const {
    draft,
    setDraft,
    quotationId,
    saving,
    saveQuotation,
  } = useQuotationService(requestId, incomingQId, quotesaved);

  const [setSavedQuotation] = useState(null);
  const [showMail, setShowMail] = useState(false);
  const [emailTo, setEmailTo] = useState('');
  const [emailMsg, setEmailMsg] = useState('');
  const originalDraftRef = useRef(draft);
  const invoiceRef = useRef();
  const [refNumber] = useState(
    () => `QT-${Math.floor(10000 + Math.random() * 90000)}`
  );

  const { labor, markupAmt, vatAmt, subPlusMk, grandTotal } = useMemo(
    () => calcTotals(draft),
    [draft]
  );

  useEffect(() => {
    onAmountChange(grandTotal);
  }, [grandTotal]);


  const expiryDate = useMemo(() => {
    const base = requestDate ? new Date(requestDate) : new Date();
    const d = new Date(base);
    d.setDate(d.getDate() + (draft.quoteValidity || 0));
    return d;
  }, [requestDate, draft.quoteValidity]);

  const friendlyExpiry = expiryDate.toLocaleDateString();
  const friendlyReq = requestDate
    ? new Date(requestDate).toLocaleDateString()
    : '';
  const todayStr = useMemo(() => new Date().toLocaleDateString(), []);

  const [errors, setErrors] = useState({
    companyName: '',
    companyAddress: '',
    companyPhone: '',
  });

  const [showZeroModal, setShowZeroModal] = useState(false);
  const uploadLogo = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const base64 = await toBase64(f);
    setDraft({
      ...draft,
      company: { ...draft.company, logo: base64 },
    });
  };

  const downloadPDF = () => {
    html2pdf()
      .from(invoiceRef.current)
      .set({
        margin: 10,
        filename: `${serviceOffer || 'quotation'}-quotation.pdf`,
        jsPDF: { unit: 'pt', format: 'a4' },
        html2canvas: {
          scale: 2,
          ignoreElements: (el) => el.classList?.contains('no-pdf'),
        },
      })
      .save();
  };

  const handleEdit = () => {
    originalDraftRef.current = { ...draft };
    setErrors({ companyName: '', companyAddress: '', companyPhone: '' });
    setEditing(true);
  };

  const handleCancel = () => {
    setDraft({ ...originalDraftRef.current });
    setErrors({ companyName: '', companyAddress: '', companyPhone: '' });
    setShowZeroModal(false);
    setEditing(false);
  };

  const validateBeforeSave = () => {
    const newErrors = {
      companyName: '',
      companyAddress: '',
      companyPhone: '',
    };

    if (!draft.company.name.trim()) {
      newErrors.companyName = 'Please provide a company name.';
    }
    if (!draft.company.address.trim()) {
      newErrors.companyAddress = 'Please provide an address.';
    }
    if (!draft.company.phone.trim()) {
      newErrors.companyPhone = 'Please provide a phone number.';
    }

    setErrors(newErrors);
    return !(
      newErrors.companyName ||
      newErrors.companyAddress ||
      newErrors.companyPhone
    );
  };

  const persistQuotation = async () => {
    const payload = {
      reference: refNumber,
      request_title: requestTitle,
      request_description: requestDescription,
      request_date: requestDate || null,

      amount: grandTotal,
      currency_code: 'ZAR',

      job_type: draft.jobType,
      base_fee: Number(draft.baseFee),
      labor_rate: Number(draft.laborRate),
      labor_unit: draft.laborUnit,
      est_qty: Number(draft.estQty),
      material_cost: Number(draft.materialCost),
      travel_cost: Number(draft.travelCost),
      markup_pct: Number(draft.markup),
      tax_rate_pct: Number(draft.taxRate),
      vat_included: draft.vatIncluded,
      quote_validity_days: Number(draft.quoteValidity),

      phone: draft.company.phone || null,
      email: draft.company.email || null,
      registration: draft.company.registration || null,
      tax_number: draft.company.vat || null,
      address: draft.company.address || null,

      bill_to_name: draft.billToName,
      bill_to_address: draft.billToAddress,
      payment_method: draft.paymentMethod,
      payment_details: draft.paymentDetails,
    };

    try {
      const response = await saveQuotation(payload);
      setSavedQuotation(response);

      if (response?.data?.quotation_id) {
        onSave({ ...draft, quotationId: response.data.quotation_id });
      } else {
        onSave({ ...draft, quotationId });
      }

      setEditing(false);
      setShowZeroModal(false);
    } catch (err) {
      const msg = err?.data?.message
        ? `Unable to save quotation: ${err.data.message}`
        : 'Unable to save quotation – network/server error';
      alert(msg);
    }
  };

  const handleSaveClick = () => {
    if (!validateBeforeSave()) return;
    if (grandTotal === 0) {
      setShowZeroModal(true);
      return;
    }
    persistQuotation();
  };

  const sendEmail = () => {
    onEmail({
      emails: emailTo
        .split(',')
        .map((e) => e.trim())
        .filter((e) => !!e),
      comment: emailMsg,
      invoiceNode: invoiceRef,
    });
    setShowMail(false);
    setEmailTo('');
    setEmailMsg('');
  };

  return (
    <>
      {/* =========== QUOTATION / INVOICE AREA =========== */}
      <div ref={invoiceRef}>
        <Card className="mb-4">
          <Card.Body>
            {/* ── action buttons ── */}
            <Row className="align-items-center mb-3 no-pdf">
              <Col />
              <Col className="d-flex justify-content-end flex-wrap gap-2">
                {editing ? (
                  <>
                    <Button size="sm" variant="secondary" onClick={handleCancel}>
                      Cancel
                    </Button>
                    <Button
                      size="sm"
                      variant="primary"
                      disabled={saving}
                      onClick={handleSaveClick}
                    >
                      {saving && <Spinner animation="border" size="sm" className="me-2" />}
                      Save Quotation
                    </Button>
                  </>
                ) : (
                  <>
                    {requestStatus === 'New' && (
                      <Button size="sm" variant="outline-primary" onClick={handleEdit}>
                        <FaPlus style={{ marginRight: '5px' }} />
                        Create
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="outline-info"
                      onClick={() => setShowMail(true)}
                    >
                      <FaEnvelope className="me-1" />
                      e-Mail
                    </Button>
                    <Button
                      size="sm"
                      variant="outline-secondary"
                      onClick={downloadPDF}
                    >
                      <FaDownload className="me-1" />
                      PDF
                    </Button>
                  </>
                )}
              </Col>
            </Row>

            {/* ── Header Block ── */}
            <HeaderBlock
              editing={editing}
              draft={draft}
              setDraft={setDraft}
              errors={errors}
              propertyName={propertyName}
              address={address}
              requestStatus={requestStatus}
              serviceOffer={serviceOffer}
              handleEdit={handleEdit}
              handleCancel={handleCancel}
              refNumber={refNumber}
              todayStr={todayStr}
            />

            {/* ── Task Table ── */}
            <TaskTable tasks={tasks} friendlyReq={friendlyReq} />

            {/* ── Cost Breakdown ── */}
            <CostBreakdown
              editing={editing}
              draft={draft}
              setDraft={setDraft}
              labor={labor}
              markupAmt={markupAmt}
              vatAmt={vatAmt}
              subPlusMk={subPlusMk}
              grandTotal={grandTotal}
            />

            {/* ── Validity Row ── */}
            <Row className="mb-3">
              <Col>
                {editing ? (
                  <div className="d-flex align-items-center">
                    <Form.Label className="me-2 mb-0 fw-semibold">
                      Quote Validity:
                    </Form.Label>
                    <Form.Control
                      type="number"
                      size="sm"
                      style={{ borderStyle: 'dashed', width: 80 }}
                      value={
                        draft.quoteValidity === '' ? '' : draft.quoteValidity
                      }
                      onChange={(e) => {
                        const raw = e.target.value;
                        setDraft({
                          ...draft,
                          quoteValidity: raw === '' ? '' : Number(raw),
                        });
                      }}
                    />
                    <span className="ms-1">days</span>
                  </div>
                ) : (
                  <>
                    <br />
                    <p className="mb-0">
                      <em>Valid through {friendlyExpiry}</em>
                    </p>
                  </>
                )}
              </Col>
            </Row>

            {/* ── Payment Details ── */}
            <PaymentDetails editing={editing} draft={draft} setDraft={setDraft} />
          </Card.Body>
        </Card>
      </div>

      {/* =========== EMAIL MODAL =========== */}
      <EmailModal
        showMail={showMail}
        setShowMail={setShowMail}
        emailTo={emailTo}
        setEmailTo={setEmailTo}
        emailMsg={emailMsg}
        setEmailMsg={setEmailMsg}
        sendEmail={sendEmail}
      />
      {/* =========== ZERO‐AMOUNT CONFIRMATION MODAL =========== */}
      <ZeroAmountModal
        showZeroModal={showZeroModal}
        setShowZeroModal={setShowZeroModal}
        persistQuotation={persistQuotation}
      />

    </>
  );
}
