import React, { useState, useRef, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import profileIcon from "../assets/user.png";
import { clearUser } from "../redux/authSlice";
import { clearCompany } from "../redux/companySlice";
import { authApi, useEndImpersonationMutation } from "../api/authApi";
import { companyApi } from "../api/company";
import { toast } from "react-toastify";

export const Header = ({ isSidebarCollapsed, onToggleSidebar, onToggleTheme, currentTheme }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const dropdownRef = useRef(null);
  const profileRef = useRef(null);
  const notificationRef = useRef(null);

  const user = useSelector((state) => state.auth.user);
  const userCredits = user.userCredits;
  const userName =
    user?.first_name || user?.last_name
      ? `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim()
      : "User";
  const userRole = user?.type
    ? user.type
      .split(" ")
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ")
    : "Member";
  const isImpersonating = user?.impersonated; // Check if user is being impersonated

  // End impersonation mutation hook
  const [endImpersonation, { isLoading: isEndingImpersonation }] = useEndImpersonationMutation();

  const handleLogout = () => {
    dispatch(clearUser());
    dispatch(clearCompany());
    dispatch(authApi.util.resetApiState());
    dispatch(companyApi.util.resetApiState());
    navigate("/");
  };

  const handleSwitchAccount = () => navigate("/account");
  const handleSupport = () => navigate("/support");
  const handleSettings = () => navigate("/settings");

  // Handle end impersonation
  const handleEndImpersonation = async () => {
    try {
      const { data } = await endImpersonation();
      if (data.status === 'success' && data.token) {
        localStorage.setItem('token', data.token);
        toast.success('Returned to original user account');
        navigate('/');
        window.location.reload();
      }
    } catch (error) {
      console.error('End impersonation error:', error);
      const errorMsg = error.data?.message || 'Failed to end impersonation';
      toast.error(errorMsg);
    }
  };

  const formatPath = (path) => {
    const segments = path.split("/").filter(Boolean);
    if (segments.length === 0) return "Dashboard";
    return segments
      .map((seg) => seg.charAt(0).toUpperCase() + seg.slice(1))
      .join(" ");
  };
  const formattedPath = formatPath(location.pathname);

  const [showDropdown, setShowDropdown] = useState(false);
  const [hideTimeout, setHideTimeout] = useState(null);
  const [notificationCount, setNotificationCount] = useState(3);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        profileRef.current &&
        !profileRef.current.contains(event.target)
      ) {
        setShowDropdown(false);
      }

      if (
        notificationRef.current &&
        !notificationRef.current.contains(event.target)
      ) {
        setShowNotifications(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleMouseEnter = () => {
    if (hideTimeout) {
      clearTimeout(hideTimeout);
      setHideTimeout(null);
    }
    setShowDropdown(true);
  };

  const handleMouseLeave = () => {
    const timeout = setTimeout(() => setShowDropdown(false), 300);
    setHideTimeout(timeout);
  };

  const toggleNotifications = (e) => {
    e.preventDefault();
    setShowNotifications(!showNotifications);
  };

  return (
    <header className={`header ${isSidebarCollapsed ? "collapsed" : ""}`}>
      <div className="mobile-toggle" onClick={onToggleSidebar}>
        <svg viewBox="0 0 24 24">
          <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z" />
        </svg>
      </div>

      <div className="page-title-container">
        <h4 className="page-title">{formattedPath}</h4>
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
            <li className="breadcrumb-item">
              <a href="/">Home</a>
            </li>
            <li className="breadcrumb-item active" aria-current="page">{formattedPath}</li>
          </ol>
        </nav>
      </div>

      <div className="header-actions">
        {/* Notifications */}
        <div className="notification-dropdown" ref={notificationRef}>
          <button className="notification-btn" onClick={toggleNotifications}>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
            </svg>
            {notificationCount > 0 && (
              <span className="notification-badge">{notificationCount}</span>
            )}
          </button>

          {showNotifications && (
            <div className="notification-menu">
              <div className="notification-header">
                <h6>Notifications</h6>
                <button className="mark-all-read">Mark all read</button>
              </div>
              <div className="notification-list">
                <div className="notification-item unread">
                  <div className="notification-icon maintenance">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                    </svg>
                  </div>
                  <div className="notification-content">
                    <p>New maintenance request from Unit 301</p>
                    <span className="notification-time">10 minutes ago</span>
                  </div>
                </div>
                <div className="notification-item unread">
                  <div className="notification-icon payment">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="2" y="5" width="20" height="14" rx="2"></rect>
                      <line x1="2" y1="10" x2="22" y2="10"></line>
                    </svg>
                  </div>
                  <div className="notification-content">
                    <p>Payment received from John Doe</p>
                    <span className="notification-time">1 hour ago</span>
                  </div>
                </div>
                <div className="notification-item">
                  <div className="notification-icon message">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                    </svg>
                  </div>
                  <div className="notification-content">
                    <p>New message from tenant Sarah Johnson</p>
                    <span className="notification-time">Yesterday</span>
                  </div>
                </div>
              </div>
              <div className="notification-footer">
                <a href="/notifications">View all notifications</a>
              </div>
            </div>
          )}
        </div>

        {/* Language Dropdown */}
        <div className="language-dropdown">
          <button className="language-btn">
            <span>EN</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </button>
          <div className="language-menu">
            <a href="#" className="language-item active">English</a>
            <a href="#" className="language-item">Arabic</a>
            <a href="#" className="language-item">Danish</a>
          </div>
        </div>

        {/* Profile Dropdown */}
        <div
          className={`profile-dropdown ${isImpersonating ? 'impersonation-mode' : ''}`}
          ref={profileRef}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
          style={isImpersonating ? {
            background: 'rgba(118, 101, 216, 0.15)',
            borderRadius: '8px',
            boxShadow: '0 0 0 2px rgba(118, 101, 216, 0.5)'
          } : {}}
        >
          <div className="profile-trigger" onClick={() => setShowDropdown(!showDropdown)}>
            <img
              className="profile-img"
              src={profileIcon}
              alt="Profile"
              width={36}
              height={36}
            />
            <div className="profile-info">
              <span className="profile-name">{userName}</span>
              <span className="profile-role" style={isImpersonating ? { color: '#7665d8', fontWeight: 600 } : {}}>
                {isImpersonating ? '(Impersonating) ' : ''}{userRole}
              </span>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>

          {showDropdown && (
            <div className="profile-menu" ref={dropdownRef}>
              {/* Display credits at the top of the dropdown */}
              {user && (
                <div className="profile-menu-credits">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M16 8h-6a2 2 0 100 4h4a2 2 0 110 4H8"></path>
                    <line x1="12" y1="6" x2="12" y2="8"></line>
                    <line x1="12" y1="16" x2="12" y2="18"></line>
                  </svg>
                  <div>
                    <span>API Credits</span>
                    <span>{userCredits}</span>
                  </div>
                </div>
              )}

              <div className="profile-menu-divider"></div>

              <a href="#" className="profile-menu-item" onClick={handleSettings}>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3"></circle>
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                </svg>
                Settings
              </a>

              {/* Only show Switch Account when NOT impersonating */}
              {!isImpersonating && (
                <a href="#" className="profile-menu-item" onClick={handleSwitchAccount}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                  </svg>
                  Switch Account
                </a>
              )}

              <a href="#" className="profile-menu-item" onClick={handleSupport}>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                  <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
                Support
              </a>

              <div className="profile-menu-divider"></div>

              {/* Show Leave User in red when impersonating, otherwise show normal Logout */}
              {isImpersonating ? (
                <div
                  className="profile-menu-item logout"
                  onClick={handleEndImpersonation}
                  disabled={isEndingImpersonation}
                  style={{ color: '#dc3545' }}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                  </svg>
                  {isEndingImpersonation ? 'Leaving...' : 'Leave User'}
                </div>
              ) : (
                <div className="profile-menu-item logout" onClick={handleLogout}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                  </svg>
                  Logout
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
