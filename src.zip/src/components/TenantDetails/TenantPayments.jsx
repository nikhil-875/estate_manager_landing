import React, { useState, useEffect, useMemo } from 'react';
import { useGetTenantPaymentStatusMutation } from '../../api/tenantApi';

const PAGE_SIZES = [5, 10, 20, 50];

// Dummy payments data for example purposes
const DUMMY_PAYMENTS = Array.from({ length: 37 }, (_, i) => {
  const d = new Date(2024, 2, 1);
  d.setDate(d.getDate() - i * 30);
  const pretty = d.toLocaleDateString('en-US', {
    month: 'short',
    day: '2-digit',
    year: 'numeric',
  });
  const status = i < 2 ? 'Upcoming' : i < 4 ? 'Overdue' : 'Paid';
  return {
    date: pretty,
    amount: 1000,
    status,
    receipt: status === 'Paid' ? 'view' : null,
  };
});

const money = (n) => `$${n.toLocaleString()}`;
const badgeClass = (s) =>
({
  Paid: 'badge bg-success-subtle text-success fw-semibold',
  Upcoming: 'badge bg-primary-subtle text-primary fw-semibold',
  Overdue: 'badge bg-danger-subtle text-danger fw-semibold',
}[s] || 'badge bg-secondary-subtle');

export const TenantPayments = ({ tenantId}) => {
  const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
  const [currentPage, setCurrentPage] = useState(1);
  const [getPaymentStatus, { data, isLoading, isError, error }] = useGetTenantPaymentStatusMutation();

  // Fetch payment status on mount or when tenantId changes
  useEffect(() => {
    console.log('Fetching payment status for tenant:', tenantId);
    if (tenantId) {
      getPaymentStatus({ tenant_id: tenantId });
    }
  }, [tenantId, getPaymentStatus]);

  // Map API data to payments array
  const payments = useMemo(() => {
    if (data && Array.isArray(data)) {
      return data.map((item) => ({
        date: item.latest_payment_date || '—',
        amount: 1000, // TODO: Replace with real amount if available
        status:
          item.final_status === 'paid'
            ? 'Paid'
            : item.final_status === 'overdue'
            ? 'Overdue'
            : 'Upcoming',
        receipt: item.final_status === 'paid' ? 'view' : null,
      }));
    }
    return [];
  }, [data]);

  const { totalDue, lastPaid, nextDue, nextStatus } = useMemo(() => {
    const paid = payments.filter((p) => p.status === 'Paid');
    const due = payments.filter((p) => p.status !== 'Paid');
    return {
      totalDue: due.reduce((s, p) => s + p.amount, 0),
      lastPaid: paid.length ? paid[0].date : '—',
      nextDue: due.length ? due[0].date : '—',
      nextStatus: due.length ? due[0].status : '',
    };
  }, [payments]);

  const pageCount = Math.ceil(payments.length / pageSize);
  useEffect(() => {
    if (currentPage > pageCount) setCurrentPage(pageCount || 1);
  }, [pageCount, currentPage]);

  const pagedRows = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return payments.slice(start, start + pageSize);
  }, [pageSize, currentPage, payments]);

  if (isLoading) return <div className="p-4">Loading payment status...</div>;
  if (isError) return <div className="p-4 text-danger">Error loading payment status.</div>;

  return (
    <div className="p-4">
      {/* Summary cards */}
      <div className="row g-3 mb-2">
        <div className="col-md-4">
          <div
            className="card shadow-sm"
            style={{ minHeight: 140, display: 'flex', flexDirection: 'column' }}
          >
            <div className="card-body py-3 flex-grow-1">
              <h4 className="mb-1">{money(totalDue)}</h4>
              <p className="small text-muted mb-2">Total Due</p>
              <button className="btn btn-primary btn-sm w-100">Pay Now</button>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div
            className="card shadow-sm"
            style={{ minHeight: 140, display: 'flex', flexDirection: 'column' }}
          >
            <div className="card-body py-3 flex-grow-1">
              <p className="small text-muted mb-1">Last Payment</p>
              <h6 className="mb-1">{lastPaid}</h6>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div
            className="card shadow-sm"
            style={{ minHeight: 140, display: 'flex', flexDirection: 'column' }}
          >
            <div className="card-body py-3 flex-grow-1">
              <p className="small text-muted mb-1">Next Due Date</p>
              <h6 className="mb-1">{nextDue}</h6>
              {nextDue !== '—' && (
                <span className={badgeClass(nextStatus)}>{nextStatus}</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Payments table */}
      <div
        className="table-responsive bg-white shadow-sm rounded"
        style={{ marginTop: -16 }}
      >
        <table className="table table-hover mb-0">
          <thead className="bg-light">
            <tr>
              <th>Payment Date</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Receipt</th>
            </tr>
          </thead>
          <tbody>
            {pagedRows.map((p, i) => (
              <tr key={i}>
                <td>{p.date}</td>
                <td>{money(p.amount)}</td>
                <td>
                  <span className={badgeClass(p.status)}>{p.status}</span>
                </td>
                <td>{p.receipt ? <a href="#!">View</a> : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination footer */}
      <div className="d-flex justify-content-end align-items-center p-3">
        <div className="me-3">
          Show&nbsp;
          <select
            className="form-select form-select-sm d-inline-block w-auto"
            value={pageSize}
            onChange={(e) => {
              setPageSize(+e.target.value);
              setCurrentPage(1);
            }}
          >
            {PAGE_SIZES.map((n) => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
          &nbsp;entries
        </div>
        <nav>
          <ul className="pagination pagination-sm mb-0">
            <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
              <button className="page-link" onClick={() => setCurrentPage(p => p - 1)}>Prev</button>
            </li>
            {Array.from({ length: pageCount }, (_, i) => i + 1).map((n) => (
              <li key={n} className={`page-item ${currentPage === n ? 'active' : ''}`}>
                <button className="page-link" onClick={() => setCurrentPage(n)}>{n}</button>
              </li>
            ))}
            <li className={`page-item ${currentPage === pageCount ? 'disabled' : ''}`}>
              <button className="page-link" onClick={() => setCurrentPage(p => p + 1)}>Next</button>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
};
