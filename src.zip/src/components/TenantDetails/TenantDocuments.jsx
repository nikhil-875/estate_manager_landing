import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { useGetS3UploadUrlMutation, useUploadFileToS3Mutation, useGetS3DownloadUrlQuery } from '../../api/uploadApi';

const LABEL_COLOR = '#2C3E50';

export const TenantDocuments = ({ documents = [], onUpload }) => {
  const [term, setTerm] = useState('');
  const [meta, setMeta] = useState({ type: '', desc: '' });
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [modal, setModal] = useState(false);
  const [keyWantDownload, setKeyWantDownload] = useState(null);

  const [getUrl] = useGetS3UploadUrlMutation();
  const [upload] = useUploadFileToS3Mutation();
  const { data: dl } = useGetS3DownloadUrlQuery(keyWantDownload, {
    skip: !keyWantDownload,
  });

  useEffect(() => {
    if (dl?.data?.url) {
      window.open(dl.data.url, '_blank');
      setKeyWantDownload(null);
    }
  }, [dl]);

  const choose = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    setFile(f);
    setPreview(f.type.startsWith('image/') ? URL.createObjectURL(f) : null);
    setModal(true);
  };

  const doUpload = async () => {
    try {
      const S3_KEY = `upload/tenants_docs/${Date.now()}_${file.name}`;
      const { data } = await getUrl({
        key: S3_KEY,
        fileType: file.type,
        fileName: file.name,
      });

      if (!data?.url) {
        toast.error('Upload URL error');
        return;
      }

      await upload({ url: data.url, file });
      onUpload({
        key: data.key,
        file_type: file.type,
        file_name: file.name,
        file_size: file.size,
        document_type: meta.type,
        description: meta.desc,
      });

      setFile(null);
      setMeta({ type: '', desc: '' });
      setModal(false);
      toast.success('Document uploaded successfully');
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload document');
    }
  };

  const closeModal = () => {
    setModal(false);
    setFile(null);
    setPreview(null);
    setMeta({ type: '', desc: '' });
  };

  const icon = (ft) =>
    !ft
      ? 'fa-file-o'
      : /pdf/.test(ft)
        ? 'fa-file-pdf-o text-danger'
        : /image/.test(ft)
          ? 'fa-file-image-o text-info'
          : /word/.test(ft)
            ? 'fa-file-word-o text-primary'
            : /(excel|sheet)/.test(ft)
              ? 'fa-file-excel-o text-success'
              : /(zip|rar)/.test(ft)
                ? 'fa-file-archive-o text-warning'
                : 'fa-file-o';

  return (
    <div className="file-content px-0">
      <div className="card">
        <div className="card-header d-flex justify-content-between">
          <div className="d-flex align-items-center">
            <i className="fa fa-search me-2" />
            <input
              placeholder="Search documents..."
              className="form-control-plaintext"
              value={term}
              onChange={(e) => setTerm(e.target.value)}
            />
          </div>
          <label className="btn btn-outline-primary m-0">
            <i className="fa fa-upload me-1" /> Upload
            <input hidden type="file" onChange={choose} />
          </label>
        </div>
        <div className="card-body">
          <h5 style={{ color: LABEL_COLOR }} className="mb-3">
            Files
          </h5>
          <ul className="files-content d-flex flex-wrap">
            {documents.length ? (
              documents
                .filter(
                  (d) =>
                    !term ||
                    d.file_name.toLowerCase().includes(term.toLowerCase()),
                )
                .map((d, i) => (
                  <li
                    key={i}
                    className="folder-box me-3 mb-3"
                    onClick={() => setKeyWantDownload(d.document)}
                  >
                    <div className="d-flex align-items-center">
                      <i className={`f-22 fa ${icon(d.file_type)} me-3`} />
                      <div>
                        <h6 style={{ color: LABEL_COLOR }}>{d.file_name}</h6>
                        <p className="text-muted small mb-1">
                          {d.document_type && (
                            <span className="badge bg-info me-2">
                              {d.document_type}
                            </span>
                          )}
                          {d.created_at
                            ? new Date(d.created_at).toLocaleDateString()
                            : 'Recently'}
                          , {Math.round(d.file_size / 1024)} KB
                        </p>
                        {d.description && (
                          <p className="text-muted small mb-0">
                            {d.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </li>
                ))
            ) : (
              <li className="text-muted w-100 text-center">No documents</li>
            )}
          </ul>
        </div>
      </div>

      {/* Upload Document Modal - Fixed implementation */}
      {modal && (
        <>
          <div className="modal-backdrop fade show" onClick={closeModal} />
          <div className="modal fade show d-block" role="dialog" tabIndex={-1}>
            <div className="modal-dialog modal-lg">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Upload Document</h5>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={closeModal} 
                    aria-label="Close"
                  />
                </div>
                <div className="modal-body row">
                  <div className="col-md-6">
                    <div className="mb-3">
                      <label className="form-label">Document Type</label>
                      <input
                        className="form-control"
                        value={meta.type}
                        onChange={(e) =>
                          setMeta({ ...meta, type: e.target.value })
                        }
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Description</label>
                      <textarea
                        className="form-control"
                        rows={3}
                        value={meta.desc}
                        onChange={(e) =>
                          setMeta({ ...meta, desc: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <div className="col-md-6 text-center">
                    <h6>Preview</h6>
                    <div
                      className="border rounded p-3"
                      style={{ minHeight: 200 }}
                    >
                      {preview ? (
                        <img
                          src={preview}
                          alt="preview"
                          className="img-fluid"
                          style={{ maxHeight: 180 }}
                        />
                      ) : (
                        <i className={`fa ${icon(file?.type)} fa-4x`} />
                      )}
                      <p className="mt-2 mb-0 small">{file?.name}</p>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={closeModal}
                  >
                    Cancel
                  </button>
                  <button 
                    type="button"
                    className="btn btn-primary" 
                    onClick={doUpload}
                  >
                    <i className="fa fa-upload me-1" /> Upload
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
