import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { EditableField } from '../EditableField';

const LABEL_COLOR = '#2C3E50';

export const TenantRentals = ({ rentalContract = {}, onSave }) => {
  const [f, set] = useState({
    rent_amount: rentalContract.rent_amount ?? '',
    rental_period_start: rentalContract.start_date ?? '',
    rental_period_end: rentalContract.end_date ?? '',
    reference: rentalContract.reference ?? '',
    description: rentalContract.description ?? '',
  });

  useEffect(() => {
    set((p) => ({ ...p, ...rentalContract }));
  }, [rentalContract]);

  const fields = [
    ['rent_amount', 'Rent Amount', 'fa-money', 'number'],
    ['reference', 'Reference', 'fa-hashtag'],
    ['rental_period_start', 'Start Date', 'fa-calendar-o', 'date'],
    ['rental_period_end', 'End Date', 'fa-calendar-o', 'date'],
    ['description', 'Description', 'fa-align-left', 'textarea'],
  ];

  return (
    <div className="text-start px-md-3">
      <h5 style={{ color: LABEL_COLOR }} className="fw-semibold mb-3">
        <i data-feather="calendar" className="me-2" /> Rental Contract
      </h5>
      <div className="row gx-3 gy-3">
        {fields.map(([k, lbl, ic, type = 'text']) => (
          <div
            key={k}
            className={`col-md-${k === 'description' ? 12 : 6}`}
          >
            <EditableField
              icon={ic}
              label={lbl}
              type={type}
              placeholder={`Enter ${lbl.toLowerCase()}`}
              value={f[k]}
              onChange={(v) => set((p) => ({ ...p, [k]: v }))}
            />
          </div>
        ))}
      </div>
      <div className="row mt-3">
        <div className="col-md-6 offset-md-6 d-flex justify-content-end">
          <button
            className="btn btn-secondary me-2"
            onClick={() =>
              set({
                rent_amount: rentalContract.rent_amount ?? '',
                rental_period_start: rentalContract.start_date ?? '',
                rental_period_end: rentalContract.end_date ?? '',
                reference: rentalContract.reference ?? '',
                description: rentalContract.description ?? '',
              })
            }
          >
            Cancel
          </button>
          <button
            className="btn btn-primary"
            onClick={() => {
              if (
                !f.rent_amount ||
                !f.rental_period_start ||
                !f.rental_period_end
              ) {
                return toast.warn('Missing required fields');
              }
              onSave(f);
            }}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

