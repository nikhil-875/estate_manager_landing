import React, { useState, useRef, useEffect } from 'react';
import { toast } from 'react-toastify';
import { EditableField } from '../EditableField';
import { loadGoogleMapsApi, isGoogleMapsLoaded } from '../../utils/googleMapsLoader';
import { env } from '../../config/env';

const LABEL_COLOR = '#2C3E50';
const Maps_API_KEY = env.Maps_API_KEY;

// Helper hook for Google Places Autocomplete
const useAddressAutocomplete = (ref, enabled, cb) => {
  useEffect(() => {
    if (!enabled || !ref.current) return;
    const init = () => {
      const ac = new window.google.maps.places.Autocomplete(ref.current, {
        types: ['address'],
      });
      ac.addListener('place_changed', () => cb(ac.getPlace()));
    };
    isGoogleMapsLoaded()
      ? init()
      : loadGoogleMapsApi(Maps_API_KEY, ['places'], init);
  }, [enabled, cb, ref]);
};

// SaveRow Component
const SaveRow = ({ onSave, onCancel }) => (
  <div className="row mb-3">
    <div className="col-md-12 d-flex justify-content-end">
      <button className="btn btn-secondary me-2" onClick={onCancel}>
        Cancel
      </button>
      <button className="btn btn-primary" onClick={onSave}>
        Save
      </button>
    </div>
  </div>
);

// Section Component - Modified to handle exclusive opening
const Section = ({ id, title, icon = 'user', isOpen, onToggle, children }) => (
  <>
    <div
      className="d-flex justify-content-between align-items-center mb-3"
      style={{ cursor: 'pointer' }}
      onClick={() => onToggle(id)}
    >
      <h6 className="m-0" style={{ color: LABEL_COLOR }}>
        <i data-feather={icon} className="me-2" /> {title}
      </h6>
      <i data-feather={isOpen ? 'chevron-up' : 'chevron-down'} />
    </div>
    {isOpen && children}
  </>
);

export const TenantPersonalDetails = ({
  tenant,
  form,
  setForm,
  saveTenant,
  saveAddr,
  propertyId,
  unitId,
  uid
}) => {
  // Section visibility state with exclusive opening
  const [openSection, setOpenSection] = useState('personal');

  const altRef = useRef(null);
  const officeRef = useRef(null);

  // Handle section toggle with exclusive behavior
  const handleSectionToggle = (sectionId) => {
    setOpenSection(current => current === sectionId ? null : sectionId);
  };

  // Handle place selection from Google Places
  const handlePlace = (place, prefix) => {
    const get = (type) =>
      place.address_components?.find((c) => c.types[0] === type)?.long_name ||
      '';
    const street = `${get('street_number')} ${get('route')}`.trim();
    setForm((p) => ({
      ...p,
      [`${prefix}_address`]: street,
      [`${prefix}_city`]: get('locality'),
      [`${prefix}_state`]: get('administrative_area_level_1'),
      [`${prefix}_zip_code`]: get('postal_code'),
      [`${prefix}_country`]: get('country'),
    }));
  };

  // Setup autocomplete
  useAddressAutocomplete(altRef, openSection === 'alt', (pl) =>
    handlePlace(pl, 'alt')
  );
  
  useAddressAutocomplete(officeRef, openSection === 'office', (pl) =>
    handlePlace(pl, 'office')
  );

  // Field definitions
  const personalFields = [
    ['first_name', 'First Name', 'fa-user'],
    ['last_name', 'Last Name', 'fa-user'],
    ['email', 'Email', 'fa-envelope', 'email'],
    ['phone_number', 'Phone Number', 'fa-phone', 'tel'],
    ['total_family_members', 'Total Family Members', 'fa-users', 'number'],
  ];
  
  const altFields = [
    ['alt_name', 'Name', 'fa-user'],
    ['alt_phone', 'Phone', 'fa-phone', 'tel'],
  ];
  
  const officeFields = [
    ['office_name', 'Office Name', 'fa-briefcase'],
    ['office_phone', 'Office Phone', 'fa-phone', 'tel'],
  ];

  // Helper to render form fields
  const renderFields = (arr, col = 6) =>
    arr.map(([k, l, ic, type]) => (
      <div key={k} className={`col-md-${col}`}>
        <EditableField
          icon={ic}
          label={l}
          type={type}
          value={form[k] ?? ''}
          onChange={(v) => setForm((p) => ({ ...p, [k]: v }))}
        />
      </div>
    ));

  // Helper to save address data
  const upsertAddr = (kind) => {
    if (!tenant.id) return toast.error('Save personal details first');
    const existing = tenant.addresses?.find(
      (a) => a.address_type === kind,
    );
    saveAddr({
      action: existing ? 'update' : 'insert',
      ...(existing ? { id: existing.id } : { tenant_id: tenant.id }),
      address_type: kind,
      name: form[`${kind}_name`],
      phone_number: form[`${kind}_phone`],
      street: form[`${kind}_address`],
      city: form[`${kind}_city`],
      state: form[`${kind}_state`],
      zip_code: form[`${kind}_zip_code`],
      country: form[`${kind}_country`],
      uid,
    });
  };

  return (
    <>
      <Section
        id="personal"
        title="Personal Details"
        icon="user"
        isOpen={openSection === 'personal'}
        onToggle={handleSectionToggle}
      >
        <div className="row gx-3 gy-2">
          {renderFields(personalFields)}
        </div>
        <SaveRow
          onSave={() =>
            saveTenant({
              action: tenant.id ? 'update' : 'insert',
              id: tenant.id,
              property_id: propertyId,
              unit_id: unitId,
              uid,
              ...form,
            })
          }
          onCancel={() => setForm((p) => ({ ...p, ...tenant }))}
        />
      </Section>

      <Section
        id="alt"
        title="Alternative Contact"
        icon="user-plus"
        isOpen={openSection === 'alt'}
        onToggle={handleSectionToggle}
      >
        <div className="row gx-3 gy-2">
          {renderFields(altFields)}
          <div className="col-12">
            <EditableField
              icon="fa-map-marker"
              label="Address"
              value={form.alt_address || ''}
              onChange={(v) =>
                setForm((p) => ({ ...p, alt_address: v }))
              }
              externalRef={altRef}
            />
          </div>
        </div>
        <SaveRow
          onSave={() => upsertAddr('alt')}
          onCancel={() =>
            setForm((p) => ({ ...p, ...tenant }))
          }
        />
      </Section>

      <Section
        id="office"
        title="Office Details"
        icon="briefcase"
        isOpen={openSection === 'office'}
        onToggle={handleSectionToggle}
      >
        <div className="row gx-3 gy-2">
          {renderFields(officeFields)}
          <div className="col-12">
            <EditableField
              icon="fa-map"
              label="Office Address"
              value={form.office_address || ''}
              onChange={(v) =>
                setForm((p) => ({ ...p, office_address: v }))
              }
              externalRef={officeRef}
            />
          </div>
        </div>
        <SaveRow
          onSave={() => upsertAddr('office')}
          onCancel={() =>
            setForm((p) => ({ ...p, ...tenant }))
          }
        />
      </Section>
    </>
  );
};

