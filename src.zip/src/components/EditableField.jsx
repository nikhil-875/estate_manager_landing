import React, { useState, useEffect, useRef } from 'react';

export const LABEL_COLOR = '#2C3E50'; // Shared constant

export const EditableField = ({
  icon,
  label,
  placeholder,
  type = 'text',
  value,
  onChange,
  isSelect = false,
  options = [],
  inputClassName = 'form-control', // Added for flexibility
  containerClassName = 'd-flex align-items-start gap-2 mb-3',
  onSave, // Optional: if you want a specific save action beyond onChange on blur
  disabled = false,
  isEditing: externalIsEditing, // Control editing state externally
  setIsEditing: externalSetIsEditing, // Control editing state externally
  textareaRows = 2,
  externalRef, // New prop for external ref
  onRefAttached, // Callback for when the ref is attached
}) => {
  const [internalIsEditing, setInternalIsEditing] = useState(false);
  const [localValue, setLocalValue] = useState(value ?? '');
  const internalInputRef = useRef(null); // Renamed internal ref
  const [refAttached, setRefAttached] = useState(false);

  // Use externalRef if provided, otherwise use internalInputRef
  const inputRef = externalRef || internalInputRef;

  const isEditing = externalIsEditing !== undefined ? externalIsEditing : internalIsEditing;
  const setIsEditing = externalSetIsEditing !== undefined ? externalSetIsEditing : setInternalIsEditing;

  useEffect(() => {
    setLocalValue(value ?? '');
  }, [value]);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isEditing]);

  // Effect to notify when ref is attached
  useEffect(() => {
    if (inputRef.current && !refAttached) {
      setRefAttached(true);
      if (onRefAttached) {
        onRefAttached(inputRef.current);
      }
    }
  }, [inputRef.current, refAttached, onRefAttached]);

  const handleBlur = () => {
    if (externalIsEditing === undefined) { // Only manage internal state if not controlled externally
      setIsEditing(false);
    }
    if (onChange) {
      onChange(localValue);
    }
    if (onSave) {
      onSave(localValue);
    }
  };

  const handleChange = (e) => {
    setLocalValue(e.target.value);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && type !== 'textarea') {
      handleBlur();
    }
  };

  const handleDivClick = () => {
    if (!disabled && externalIsEditing === undefined) {
      setIsEditing(true);
    } else if (!disabled && externalSetIsEditing) {
      externalSetIsEditing(true);
    }
  };

  return (
    <div
      className={containerClassName}
      onClick={!isEditing ? handleDivClick : undefined} // Make div clickable to edit if not already editing
      style={!disabled && !isEditing ? { cursor: 'pointer' } : {}}
    >
      {icon && (
        <span className="pt-1 text-secondary">
          <i className={`fa ${icon}`} aria-hidden="true" />
        </span>
      )}
      <div style={{ flex: 1 }}>
        {label && (
          <small style={{ color: LABEL_COLOR }} className="fw-semibold">
            {label}
          </small>
        )}
        <br />
        {isEditing && !disabled ? (
          isSelect ? (
            <select
              ref={inputRef}
              className={inputClassName}
              value={localValue}
              onChange={handleChange}
              onBlur={handleBlur}
              disabled={disabled}
            >
              <option value="">{placeholder || 'Select...'}</option>
              {options.map(opt => (
                typeof opt === 'object' ? (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ) : (
                  <option key={opt} value={opt}>{opt}</option>
                )
              ))}
            </select>
          ) : type === 'textarea' ? (
            <textarea
              ref={inputRef}
              rows={textareaRows}
              className={inputClassName}
              placeholder={placeholder}
              value={localValue}
              onChange={handleChange}
              onBlur={handleBlur}
              disabled={disabled}
            />
          ) : (
            <input
              ref={inputRef}
              type={type}
              className={inputClassName}
              placeholder={placeholder}
              value={localValue}
              onChange={handleChange}
              onBlur={handleBlur}
              onKeyDown={handleKeyDown}
              disabled={disabled}
            />
          )
        ) : (
          <div className="form-text pt-1"> {/* Adjusted padding for better alignment */}
            {localValue || <em>{placeholder || label}</em>}
          </div>
        )}
      </div>
    </div>
  );
}

