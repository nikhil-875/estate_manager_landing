import React, { useState, useEffect } from "react";
import { Header } from "./Header";
import { Sidebar } from "./SideBar";
import { Footer } from "./Footer";
import { usePermissions } from "../hooks/usePermissions";
import { Loader } from "./Loader";

export const Layout = ({ children }) => {
  const { filteredMenuItems, loading } = usePermissions();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
    const savedState = localStorage.getItem("sidebarCollapsed");
    return savedState !== null ? JSON.parse(savedState) : false;
  });

  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);
  const [theme, setTheme] = useState(() => {
    const savedTheme = localStorage.getItem("appTheme");
    return savedTheme || "light";
  });

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
      // Close mobile sidebar when resizing to desktop
      if (window.innerWidth > 768) {
        setIsMobileSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    // Apply theme class to body
    document.body.className = theme === "dark" ? "dark-only" : "";
  }, [theme]);

  const toggleSidebar = () => {
    if (windowWidth <= 768) {
      setIsMobileSidebarOpen(!isMobileSidebarOpen);
    } else {
      setIsSidebarCollapsed((prevState) => {
        const newState = !prevState;
        localStorage.setItem("sidebarCollapsed", JSON.stringify(newState));
        return newState;
      });
    }
  };

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    localStorage.setItem("appTheme", newTheme);
  };

  const [pinnedMenus, setPinnedMenus] = useState(() => {
    const savedPins = localStorage.getItem("pinnedMenus");
    return savedPins ? JSON.parse(savedPins) : [];
  });

  const handleTogglePin = (menuId) => {
    setPinnedMenus((prev) => {
      const newPins = prev.includes(menuId)
        ? prev.filter((id) => id !== menuId)
        : [...prev, menuId];
      localStorage.setItem("pinnedMenus", JSON.stringify(newPins));
      return newPins;
    });
  };

  useEffect(() => {
    if (isSidebarCollapsed) {
      document.body.classList.add("sidebar-collapsed");
    } else {
      document.body.classList.remove("sidebar-collapsed");
    }
  }, [isSidebarCollapsed]);

  if (loading) return <Loader />;

  return (
    <div
      className={`page-wrapper compact-wrapper ${isSidebarCollapsed ? "sidebar-close" : ""} ${theme === "dark" ? "dark-theme" : ""}`}
      id="pageWrapper"
    >    
      {/* Pass the state to Header */}
      <Header 
        onToggleSidebar={toggleSidebar} 
        isSidebarCollapsed={isSidebarCollapsed} 
        onToggleTheme={toggleTheme}
        currentTheme={theme}
      />
      <div className="layout-container">
        <Sidebar
          isCollapsed={isSidebarCollapsed}
          isMobileOpen={isMobileSidebarOpen}
          onToggleSidebar={toggleSidebar}
          menuItems={filteredMenuItems}
          pinnedMenus={pinnedMenus}
          onTogglePin={handleTogglePin}
          theme={theme}
        />

        {/* Overlay for mobile */}
        {isMobileSidebarOpen && (
          <div
            className={`sidebar-overlay ${isMobileSidebarOpen ? 'active' : ''}`}
            onClick={() => setIsMobileSidebarOpen(false)}
          ></div>
        )}

        <main className={`main-content ${windowWidth <= 768 ? 'mobile-view' : ''} ${theme}`}>
          <div className="page-content-wrapper">
            {children}
          </div>
          <Footer />
        </main>
      </div>
    </div>
  );
}
