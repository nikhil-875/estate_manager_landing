export const env = {
    API_URL: import.meta.env.VITE_API_URL,
    LANDING_URL: import.meta.env.VITE_LANDING_URL,
    GOOGLE_CLIENT_ID: import.meta.env.VITE_GOOGLE_CLIENT_ID,
    GOOGLE_MAPS_API_KEY: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
    DEEPSEEK_API_KEY: import.meta.env.VITE_DEEPSEEK_API_KEY,
    OCR_ENDPOINT: import.meta.env.VITE_OCR_ENDPOINT,
    S3_BUCKET: import.meta.env.VITE_S3_BUCKET,
}