import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { Provider } from 'react-redux';
import { App } from './App.jsx';
import { store } from './store.js';
import { env } from './config/env.js';
import 'react-toastify/dist/ReactToastify.css';

const clientId = env.GOOGLE_CLIENT_ID;

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Provider store={store}>
      <GoogleOAuthProvider clientId={clientId}>
          <App />
      </GoogleOAuthProvider>
    </Provider>
  </StrictMode>
);
