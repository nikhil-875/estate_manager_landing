// src/pages/TenantMaintenance.jsx

import React, { useState, useMemo, useRef } from "react";
import {
  Card,
  Button,
  ListGroup,
  Badge,
  Modal,
  Form,
  InputGroup,
  Row,
  Col
} from "react-bootstrap";
import { FaSearch, FaPaperclip, FaStar, FaRegStar } from "react-icons/fa";

/* ---------- SAMPLE DATA ------------------------- */
const INITIAL_REQUESTS = [
  {
    id: 1,
    title: "Leaky Faucet",
    issueType: "Plumbing",
    status: "Pending",
    dateReported: "2024-08-01",
    description: "The faucet in the kitchen is leaking continuously.",
    comments: [
      {
        id: 1,
        author: "Maintenance Team",
        text: "We’ll send someone tomorrow.",
        date: "2024-08-02"
      }
    ],
    attachments: [{ id: 1, name: "faucet.jpg", url: "#" }],
    rating: 0
  },
  {
    id: 2,
    title: "Broken Window",
    issueType: "Carpentry",
    status: "In Progress",
    dateReported: "2024-08-03",
    description: "Window in the living room won’t close properly.",
    comments: [],
    attachments: [],
    rating: 0
  }
];
/* ------------------------------------------------ */

const STATUS_VARIANTS = {
  Pending: "warning",
  "In Progress": "primary",
  Completed: "success"
};

const ISSUE_TYPES = [
  "Electrical",
  "Plumbing",
  "HVAC",
  "Carpentry",
  "Other"
];

export default function TenantMaintenance() {
  const [requests, setRequests]         = useState(INITIAL_REQUESTS);
  const [searchTerm, setSearchTerm]     = useState("");
  const [filterStatus, setFilterStatus] = useState("All");

  const [showDetails, setShowDetails]   = useState(false);
  const [selected, setSelected]         = useState(null);

  const [newComment, setNewComment]     = useState("");
  const [newFile, setNewFile]           = useState(null);
  const fileInputRef                    = useRef(null);

  const [ratings, setRatings]           = useState({});

  const [showNew, setShowNew]           = useState(false);
  const [nrTitle, setNrTitle]           = useState("");
  const [nrType, setNrType]             = useState(ISSUE_TYPES[0]);
  const [nrDesc, setNrDesc]             = useState("");
  const [nrFile, setNrFile]             = useState(null);
  const nrFileRef                       = useRef(null);

  // filter & search
  const filtered = useMemo(() => {
    return requests.filter(r => {
      const matchesStatus =
        filterStatus === "All" || r.status === filterStatus;
      const matchesSearch =
        r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.issueType.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [requests, searchTerm, filterStatus]);

  const openDetails = req => {
    setSelected(req);
    setShowDetails(true);
  };
  const closeDetails = () => {
    setShowDetails(false);
    setSelected(null);
    setNewComment("");
    setNewFile(null);
  };

  const handleAddComment = () => {
    if (!newComment.trim() && !newFile) return;
    const comment = {
      id: Date.now(),
      author: "You",
      text: newComment.trim(),
      date: new Date().toISOString().split("T")[0],
      file: newFile && { id: Date.now(), name: newFile.name, url: URL.createObjectURL(newFile) }
    };
    setRequests(rs =>
      rs.map(r =>
        r.id === selected.id
          ? {
              ...r,
              comments: [...r.comments, comment],
              attachments: comment.file ? [...r.attachments, comment.file] : r.attachments
            }
          : r
      )
    );
    setNewComment("");
    setNewFile(null);
    fileInputRef.current.value = "";
  };

  const handleRate = star => {
    setRatings(r => ({ ...r, [selected.id]: star }));
    setRequests(rs =>
      rs.map(r =>
        r.id === selected.id
          ? { ...r, rating: star, status: "Completed" }
          : r
      )
    );
  };

  const openNew = () => setShowNew(true);
  const closeNew = () => {
    setShowNew(false);
    setNrTitle("");
    setNrType(ISSUE_TYPES[0]);
    setNrDesc("");
    setNrFile(null);
  };
  const handleCreate = () => {
    if (!nrTitle.trim() || !nrDesc.trim()) return;
    const req = {
      id: Date.now(),
      title: nrTitle.trim(),
      issueType: nrType,
      status: "Pending",
      dateReported: new Date().toISOString().split("T")[0],
      description: nrDesc.trim(),
      comments: [],
      attachments: nrFile
        ? [{ id: Date.now(), name: nrFile.name, url: URL.createObjectURL(nrFile) }]
        : [],
      rating: 0
    };
    setRequests([req, ...requests]);
    closeNew();
  };

  return (
    <div className="container mt-4 bg-white p-4">
      <h2 className="mb-4">My Maintenance Requests</h2>

      {/* Search / Filter / New */}
      <Row className="align-items-center mb-3">
        <Col md={5}>
          <InputGroup>
            <InputGroup.Text><FaSearch /></InputGroup.Text>
            <Form.Control
              placeholder="Search requests..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </InputGroup>
        </Col>
        <Col md={3}>
          <Form.Select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
          >
            <option>All</option>
            <option>Pending</option>
            <option>In Progress</option>
            <option>Completed</option>
          </Form.Select>
        </Col>
        <Col md={4} className="text-end">
          <Button variant="success" onClick={openNew}>
            New Request
          </Button>
        </Col>
      </Row>

      {/* Request Cards */}
      {filtered.map(req => {
        const starCount = ratings[req.id] ?? req.rating;
        return (
          <Card key={req.id} className="mb-3 bg-white">
            <Card.Header className="d-flex justify-content-between align-items-center">
              <div>
                <strong>{req.title}</strong>{" "}
                <Badge bg="info" className="text-white">{req.issueType}</Badge>
              </div>
              <div className="d-flex align-items-center">
                {[1,2,3,4,5].map(i =>
                  i <= starCount
                    ? <FaStar key={i} color="#FFC107" />
                    : <FaRegStar key={i} color="#CCC" />
                )}
                <Badge
                  bg={STATUS_VARIANTS[req.status] || "secondary"}
                  className="ms-3 text-white"
                >
                  {req.status}
                </Badge>
              </div>
            </Card.Header>
            <Card.Body>
              <Card.Text>{req.description}</Card.Text>
              <ListGroup variant="flush">
                <ListGroup.Item>
                  <strong>Date Reported:</strong> {req.dateReported}
                </ListGroup.Item>
                {req.attachments.length > 0 && (
                  <ListGroup.Item>
                    <strong>Attachments:</strong>{" "}
                    {req.attachments.map(a => (
                      <a href={a.url} key={a.id} className="me-2">
                        {a.name}
                      </a>
                    ))}
                  </ListGroup.Item>
                )}
              </ListGroup>
              <Button
                variant="primary"
                className="mt-3"
                onClick={() => openDetails(req)}
              >
                View Details
              </Button>
            </Card.Body>
          </Card>
        );
      })}

      {/* Details Modal */}
      {selected && (
        <Modal show={showDetails} onHide={closeDetails} size="lg" centered>
          <Modal.Header closeButton>
            <Modal.Title>{selected.title}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <p>
              <strong>Issue Type:</strong>{" "}
              <Badge bg="info" className="text-white">
                {selected.issueType}
              </Badge>
            </p>
            <p>
              <strong>Status:</strong>{" "}
              <Badge
                bg={STATUS_VARIANTS[selected.status] || "secondary"}
                className="text-white"
              >
                {selected.status}
              </Badge>
            </p>
            <p>
              <strong>Reported:</strong> {selected.dateReported}
            </p>
            <p>{selected.description}</p>

            {selected.status === "Completed" && (
              <div className="mb-4">
                <h5>Rate the Work</h5>
                {[1,2,3,4,5].map(i =>
                  i <= (ratings[selected.id] ?? selected.rating)
                    ? <FaStar
                        key={i}
                        size={24}
                        style={{ cursor: "pointer", color: "#FFC107" }}
                        onClick={() => handleRate(i)}
                      />
                    : <FaRegStar
                        key={i}
                        size={24}
                        style={{ cursor: "pointer" }}
                        onClick={() => handleRate(i)}
                      />
                )}
              </div>
            )}

            <h5 className="mt-4">Discussion</h5>
            <ListGroup className="mb-3">
              {selected.comments.map(c => (
                <ListGroup.Item key={c.id}>
                  <div className="d-flex justify-content-between">
                    <span>
                      <strong>{c.author}</strong> <small className="text-muted">{c.date}</small>
                    </span>
                    {c.file && (
                      <a href={c.file.url}>
                        <FaPaperclip /> {c.file.name}
                      </a>
                    )}
                  </div>
                  <div className="mt-1">{c.text}</div>
                </ListGroup.Item>
              ))}
              {selected.comments.length === 0 && (
                <ListGroup.Item className="text-muted">
                  No comments yet.
                </ListGroup.Item>
              )}
            </ListGroup>

            <Form>
              <InputGroup className="mb-2">
                <Button
                  variant="outline-secondary"
                  onClick={() => fileInputRef.current.click()}
                >
                  <FaPaperclip />
                </Button>
                <input
                  type="file"
                  ref={fileInputRef}
                  style={{ display: "none" }}
                  onChange={e => setNewFile(e.target.files[0])}
                />
                <Form.Control
                  placeholder="Add a comment…"
                  value={newComment}
                  onChange={e => setNewComment(e.target.value)}
                />
                <Button variant="primary" onClick={handleAddComment}>
                  Submit
                </Button>
              </InputGroup>
              {newFile && (
                <div className="mb-2 text-muted">
                  📎 {newFile.name}
                </div>
              )}
            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={closeDetails}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      )}

      {/* New Request Modal */}
      <Modal show={showNew} onHide={closeNew} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>New Maintenance Request</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Title</Form.Label>
              <Form.Control
                placeholder="Enter a short title"
                value={nrTitle}
                onChange={e => setNrTitle(e.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Issue Type</Form.Label>
              <Form.Select
                value={nrType}
                onChange={e => setNrType(e.target.value)}
              >
                {ISSUE_TYPES.map(type => (
                  <option key={type}>{type}</option>
                ))}
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Describe the issue"
                value={nrDesc}
                onChange={e => setNrDesc(e.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Attachment</Form.Label>
              <div className="d-flex">
                <Button
                  variant="outline-secondary"
                  onClick={() => nrFileRef.current.click()}
                >
                  <FaPaperclip />
                </Button>
                <input
                  type="file"
                  ref={nrFileRef}
                  style={{ display: "none" }}
                  onChange={e => setNrFile(e.target.files[0])}
                />
                <span className="ms-3">{nrFile?.name}</span>
              </div>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeNew}>
            Cancel
          </Button>
          <Button variant="success" onClick={handleCreate}>
            Create Request
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
