import React, { useEffect, useState } from 'react'
import { useGetSwitchableAccountsMutation, useManageUserProfileMutation } from '../api/authApi'

export function SwitchAccount() {
  const [accounts, setAccounts] = useState([])
  const [alert, setAlert] = useState({ show: false, message: '' })

  // RTKQ Hooks
  const [fetchAccounts, { isLoading: loadingAccounts }] = useGetSwitchableAccountsMutation()
  const [manageProfile, { isLoading: loadingAction }] = useManageUserProfileMutation()

  // Fetch on mount
  useEffect(() => {
    fetchAccounts({})
      .unwrap()
      .then(res => {
        if (res.status === 'success') {
          setAccounts(res.data)
        } else {
          setAlert({ show: true, message: res.message || 'Failed to load accounts.' })
        }
      })
      .catch(() => {
        setAlert({ show: true, message: 'Network error loading accounts.' })
      })
  }, [fetchAccounts])

  const hideAlert = () => setAlert({ show: false, message: '' })

  const handleAction = (type, action) => {
    manageProfile({ type, action })
      .unwrap()
      .then(res => {
        if (res.status_code !== 200) {
          return setAlert({ show: true, message: res.message })
        }
        if (action === 'switch') {
          if (res.token) {
            localStorage.setItem('token', res.token)
            window.location.reload()
          }
        }
        if (action === 'default') {
          setAccounts(prev =>
            prev.map(a => ({
              ...a,
              is_default:      a._type === type,
              can_set_default: a._type !== type,
              can_switch:      a._type !== type,
            }))
          )
        }
        if (action === 'request') {
          setAlert({ show: true, message: `Request submitted for ${type}` })
        }
      })
      .catch(() => setAlert({ show: true, message: `Could not ${action} account.` }))
  }

  return (
    <div className="p-4 bg-white min-vh-100">
      <div className="container col-md-8 mx-auto">
        {alert.show && (
          <div className="alert alert-danger alert-dismissible fade show">
            {alert.message}
            <button type="button" className="btn-close" onClick={hideAlert} />
          </div>
        )}

        <div className="card shadow-sm p-4">
          <h4 className="fw-bold mb-2">Switch Account</h4>
          <p className="text-muted mb-4">
            Choose an account to switch to, set as default, or request access
          </p>

          {loadingAccounts ? (
            <p>Loading accounts…</p>
          ) : (
            accounts.map(acct => (
              <div
                key={acct._type}
                className={`card mb-3 p-3 border ${
                  acct.is_default ? 'border-primary' : ''
                }`}
              >
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <h5 className="mb-1 text-capitalize">{acct._type.toLowerCase()}</h5>
                    {acct.request_access ? (
                      <small className="text-danger">Not Registered</small>
                    ) : (
                      <small className={acct.is_default ? 'text-success' : 'text-muted'}>
                        {acct.is_default ? 'Active' : acct.status}
                      </small>
                    )}
                  </div>

                  <div className="d-flex gap-2">
                    {acct.request_access ? (
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => handleAction(acct._type, 'request')}
                        disabled={loadingAction}
                      >
                        Request Access
                      </button>
                    ) : (
                      <>
                        {acct.is_default ? (
                          <span className="badge bg-primary">Default</span>
                        ) : (
                          <button
                            className="btn btn-outline-primary btn-sm"
                            onClick={() => handleAction(acct._type, 'default')}
                            disabled={loadingAction}
                          >
                            Set as Default
                          </button>
                        )}

                        {!acct.is_default && acct.can_switch && (
                          <button
                            className="btn btn-outline-success btn-sm"
                            onClick={() => handleAction(acct._type, 'switch')}
                            disabled={loadingAction}
                          >
                            Switch
                          </button>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
