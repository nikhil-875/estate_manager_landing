// ─────────────────────────────────────────────────────────────
// src/pages/Transaction.jsx
// FULL FILE – nothing omitted
// ─────────────────────────────────────────────────────────────
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { useSelector } from 'react-redux';
import {
  useGetTransactionsListMutation,
  useManageTransactionActionMutation,
  useGetOwnerCompaniesQuery,
} from '../api/company';
import UploadModal from '../components/Transaction/SuperAdminUploadModal';

/* -------------------------------------------------------------------------- */
/*                              CONSTANTS & HELPERS                           */
/* -------------------------------------------------------------------------- */
const PAGE_SIZES = [20, 30, 40, 50, 60, 70, 80, 90, 100];
const toDateObj = (d) => new Date(d);
const monthKey  = (ds) => ds.slice(0, 7);
const formatMonthYear = (ym) => {
  const [y, m] = ym.split('-');
  return new Date(`${y}-${m}-01`).toLocaleString('en-ZA', {
    month: 'short',
    year:  'numeric',
  });
};
const formatRange = (from, to) =>
  `${from.toLocaleDateString()} – ${to.toLocaleDateString()}`;
const Arrow = ({ dir }) =>
  dir === 'up'   ? <span className="text-success">▲</span> :
  dir === 'down' ? <span className="text-danger">▼</span> :
                   <span className="text-secondary">►</span>;

/* -------------------------------------------------------------------------- */
/*                             MAIN COMPONENT                                 */
/* -------------------------------------------------------------------------- */
function Transaction() {
  /* data hooks */
  const [fetchList,   { isLoading: loadingList  }] = useGetTransactionsListMutation();
  const [manageAct,   { isLoading: actionLoading }] = useManageTransactionActionMutation();
  const { data: ownerData = { members: [] }, isFetching: membersLoading } =useGetOwnerCompaniesQuery();

  const [transactions, setTransactions] = useState([]);

  /* UI state */
  const [searchTerm,  setSearchTerm]  = useState('');
  const [pageSize,    setPageSize]    = useState(PAGE_SIZES[0]);
  const [currentPage, setCurrentPage] = useState(1);

  const [categoryFilter, setCategoryFilter] = useState('');
  const [typeFilter,     setTypeFilter]     = useState('');
  const [headerCatOpen,  setHeaderCatOpen]  = useState(false);
  const [headerTypeOpen, setHeaderTypeOpen] = useState(false);

  const [editingCat,  setEditingCat]  = useState(null);
  const [editingType, setEditingType] = useState(null);
  const [editingAmt,  setEditingAmt]  = useState(null);
  const [amtDraft,    setAmtDraft]    = useState('');
  const [amtError,    setAmtError]    = useState('');

  const [showDelModal, setShowDelModal] = useState(false);
  const [toDeleteTx,   setToDeleteTx]   = useState(null);

  const [range,      setRange]      = useState([null, null]);
  const [fromDate,   toDate]        = range;
  const [pickerMode, setPickerMode] = useState('month');
  const datePickerRef = useRef(null);

  const [sortField, setSortField] = useState('date');
  const [sortDir,   setSortDir]   = useState('desc');

  /* transaction-details modal */
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedTx,      setSelectedTx]      = useState(null);
  const [detailCat,       setDetailCat]       = useState('');
  const [detailType,      setDetailType]      = useState('');
  const [assignTo,        setAssignTo]        = useState([]); // array
  const [allocInput,      setAllocInput]      = useState('');
  const [allocOptions,    setAllocOptions]    = useState([]);
  const [allocLoading,    setAllocLoading]    = useState(false);
  const [creatingCategory, setCreatingCategory] = useState(false);
  const [newCategoryName, setNewCategoryName]   = useState('');

  /* fetch on mount & refresh */
  const reload = useCallback(() => {
    fetchList()
      .unwrap()
      .then(r => setTransactions(r.transactions || []))
      .catch(() => setTransactions([]));
  }, [fetchList]);

  useEffect(reload, [reload]);
  useEffect(() => {
    window.addEventListener('transactions:refresh', reload);
    return () => window.removeEventListener('transactions:refresh', reload);
  }, [reload]);

  /* derived lists */
  const headerCatOptions = useMemo(
    () => Array.from(new Set(transactions.map(t => t.category_name))).sort(),
    [transactions]
  );
  const inlineCatOptions = useMemo(
    () => headerCatOptions.map(name => ({ name })),
    [headerCatOptions]
  );
  const memberToAlloc = (m) => ({
    id     : m.company_id,
    company: m.company,
    type   : m._type || 'Member',
  });

  /* filter / sort / paginate */
  const filteredTx = useMemo(() => {
    let tx = [...transactions];
    if (fromDate && toDate) {
      tx = tx.filter(t => {
        const d = toDateObj(t.txn_date);
        return d >= fromDate && d <= toDate;
      });
    }
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      tx = tx.filter(
        t =>
          t.description.toLowerCase().includes(term) ||
          t.category_name.toLowerCase().includes(term)
      );
    }
    if (categoryFilter) tx = tx.filter(t => t.category_name === categoryFilter);
    if (typeFilter)     tx = tx.filter(t => t.transaction_type === typeFilter);

    tx.sort((a, b) => {
      if (sortField === 'date') {
        const ymA = monthKey(a.txn_date), ymB = monthKey(b.txn_date);
        if (ymA !== ymB) {
          return sortDir === 'asc'
            ? ymA.localeCompare(ymB)
            : ymB.localeCompare(ymA);
        }
        return toDateObj(a.txn_date).getDate() - toDateObj(b.txn_date).getDate();
      }
      const signed = t => t.transaction_type === 'Debited' ? -t.amount : t.amount;
      return sortDir === 'asc'
        ? signed(a) - signed(b)
        : signed(b) - signed(a);
    });

    return tx;
  }, [
    transactions, searchTerm, fromDate, toDate,
    categoryFilter, typeFilter, sortField, sortDir
  ]);

  const firstIdx  = (currentPage - 1) * pageSize;
  const pageCount = Math.max(1, Math.ceil(filteredTx.length / pageSize));
  const pagedData = filteredTx.slice(firstIdx, firstIdx + pageSize);

  /* KPI metrics */
  const metrics = useMemo(() => {
    if (!transactions.length || !filteredTx.length) {
      return [
        { title:'Revenue',  value:0, count:0, change:{ pct:0, dir:'same' }, label:'' },
        { title:'Expense',  value:0, count:0, change:{ pct:0, dir:'same' }, label:'' },
        { title:'Net Profit', value:0, count:0, change:{ pct:0, dir:'same' }, label:'' },
      ];
    }
    let curTx = [], label = '';
    if (fromDate && toDate) {
      curTx = filteredTx;
      label = formatRange(fromDate, toDate);
    } else {
      const firstRec = filteredTx[firstIdx] || filteredTx[0];
      const curMonth = monthKey(firstRec.txn_date);
      curTx = transactions.filter(t => monthKey(t.txn_date) === curMonth);
      label = formatMonthYear(curMonth);
    }
    let prevTx = [];
    if (curTx.length) {
      const dates = curTx.map(t => toDateObj(t.txn_date)).sort((a,b)=>a-b);
      const start = dates[0], end = dates.at(-1);
      const span  = Math.round((end - start)/86400000) + 1;
      const prevEnd   = new Date(start); prevEnd.setDate(prevEnd.getDate() - 1);
      const prevStart = new Date(prevEnd); prevStart.setDate(prevStart.getDate() - span + 1);
      prevTx = transactions.filter(t => {
        const d = toDateObj(t.txn_date);
        return d >= prevStart && d <= prevEnd;
      });
    }
    const sumOf = (arr, type) =>
      arr.filter(t => t.transaction_type === type)
         .reduce((s,t)=>s+t.amount,0);
    const rC = sumOf(curTx,'Credited'), eC = sumOf(curTx,'Debited'), nC = rC - eC;
    const rP = sumOf(prevTx,'Credited'), eP = sumOf(prevTx,'Debited'), nP = rP - eP;
    const delta = (c,p)=> {
      if (c>p) return { pct:p?Math.round((c-p)/p*100):100, dir:'up' };
      if (c<p) return { pct:p?Math.round((p-c)/p*100):  0, dir:'down' };
      return { pct:0, dir:'same' };
    };
    return [
      { title:'Revenue',  value:rC, count:curTx.filter(t=>t.transaction_type==='Credited').length,
        change:delta(rC,rP), label, barClass:'bg-warning' },
      { title:'Expense',  value:eC, count:curTx.filter(t=>t.transaction_type==='Debited').length,
        change:delta(eC,eP), label, barClass:'bg-purple' },
      { title:'Net Profit', value:nC, count:curTx.length,
        change:delta(nC,nP), label, barClass:nC<0?'bg-danger':'bg-success' },
    ];
  }, [transactions, filteredTx, firstIdx, fromDate, toDate]);

  /* INLINE-EDIT & API HANDLERS */
  const apiUpdate = async (payload) => {
      await manageAct(payload).unwrap();
  };
  const baseOldNew = tx => ({
    description   : tx.description,
    reference_name: tx.reference_name,
    reference_id  : tx.reference_id,
  });

  const handleCategoryChange = async (id,newCat) => {
    const tx = transactions.find(t=>t.id===id);
    if (!tx) return;
    await apiUpdate({
      action:'update_category_type', id,
      changes:{
        old:{ ...baseOldNew(tx), category:tx.category_name, type:tx.transaction_type, amount:tx.amount },
        new:{ ...baseOldNew(tx), category:newCat,          type:tx.transaction_type, amount:tx.amount },
      },
    });
    setTransactions(ts=>ts.map(t=>t.id===id?{...t,category_name:newCat}:t));
    setEditingCat(null);
  };

  const handleTypeChange = async (id,newType) => {
    const tx = transactions.find(t=>t.id===id);
    if (!tx) return;
    await apiUpdate({
      action:'update_category_type', id,
      changes:{
        old:{ ...baseOldNew(tx), category:tx.category_name, type:tx.transaction_type, amount:tx.amount },
        new:{ ...baseOldNew(tx), category:tx.category_name, type:newType,            amount:tx.amount },
      },
    });
    setTransactions(ts=>ts.map(t=>t.id===id?{...t,transaction_type:newType}:t));
    setEditingType(null);
  };

  const handleAmtBlur = async (id) => {
    const tx = transactions.find(t=>t.id===id);
    if (!tx) { setEditingAmt(null); return; }
    const val = parseFloat(amtDraft);
    if (isNaN(val)||val<=0) {
      setAmtError('Enter a positive number'); return;
    }
    setAmtError('');
    await apiUpdate({
      action:'update_category_type', id,
      changes:{
        old:{ ...baseOldNew(tx), category:tx.category_name, type:tx.transaction_type, amount:tx.amount },
        new:{ ...baseOldNew(tx), category:tx.category_name, type:tx.transaction_type, amount:val },
      },
    });
    setTransactions(ts=>ts.map(t=>t.id===id?{...t,amount:val}:t));
    setEditingAmt(null);
  };

  /* DELETE HANDLER */
  const confirmDelete = async () => {
    if (!toDeleteTx) return;
    await manageAct({ action:'delete_transaction', ids:[toDeleteTx] }).unwrap();
    setTransactions(ts=>ts.filter(t=>t.id!==toDeleteTx));
    setShowDelModal(false);
  };

  /* DETAILS MODAL */
  const openDetail = (t) => {
    setSelectedTx(t);
    setDetailCat(t.category_name);
    setDetailType(t.transaction_type);
    // Normalize allocated array:
    let arr = [];
    if (Array.isArray(t.allocated)) {
      arr = t.allocated;
    } else if (Array.isArray(t.allocated?.allocated)) {
      arr = t.allocated.allocated;
    }
    setAssignTo(arr);
    setAllocInput('');
    setAllocOptions([]);
    setCreatingCategory(false);
    setNewCategoryName('');
    setShowDetailModal(true);
  };
  const closeDetail = () => setShowDetailModal(false);

  /* allocation autocomplete */
  const handleAllocSearch = (txt) => {
    setAllocInput(txt);
    if (txt.length<3 || membersLoading) {
      setAllocOptions([]); return;
    }
    setAllocLoading(true);
    const term = txt.toLowerCase();
    const matches = ownerData.members
      .filter(m =>
        (m.company   && m.company.toLowerCase().includes(term)) ||
        (m.contact   && m.contact.toLowerCase().includes(term)) ||
        (m.email     && m.email.toLowerCase().includes(term)) ||
        (m.package   && m.package.toLowerCase().includes(term))
      )
      .map(memberToAlloc);
    setTimeout(() => {
      setAllocOptions(matches);
      setAllocLoading(false);
    }, 150);
  };

  const chooseAlloc = (opt) => {
    if (!assignTo.some(a=>a.id===opt.id)) {
      setAssignTo(prev=>[...prev,opt]);
    }
    setAllocInput('');
    setAllocOptions([]);
  };

  const handleAllocKeyDown = (e) => {
    if (e.key===',') {
      e.preventDefault();
      if (allocOptions.length>0) chooseAlloc(allocOptions[0]);
    }
  };

  /* remove a tag */
  const handleRemoveAlloc = async (allocId) => {
    const newAssign = assignTo.filter(a => a.id!==allocId);
    await apiUpdate({
      action:'update_category_type',
      id:selectedTx.id,
      changes:{
        old:{ ...baseOldNew(selectedTx), category:selectedTx.category_name, type:selectedTx.transaction_type, amount:selectedTx.amount },
        new:{ ...baseOldNew(selectedTx), category:detailCat,                type:detailType,                amount:selectedTx.amount },
      },
      allocated: newAssign,
    });
    setAssignTo(newAssign);
  };

  /* save details */
  const saveDetail = async () => {
    const newCat = creatingCategory ? newCategoryName.trim() : detailCat;
    await apiUpdate({
      action:'update_category_type',
      id:selectedTx.id,
      changes:{
        old:{ ...baseOldNew(selectedTx), category:selectedTx.category_name, type:selectedTx.transaction_type, amount:selectedTx.amount },
        new:{ ...baseOldNew(selectedTx), category:newCat,                  type:detailType,                amount:selectedTx.amount },
      },
      allocated: assignTo,
    });
    setTransactions(ts =>
      ts.map(t =>
        t.id===selectedTx.id
          ? { ...t, category_name:newCat, transaction_type:detailType, allocated:assignTo }
          : t
      )
    );
    closeDetail();
  };

  /* RENDER */
  return (
    <div style={{ width:'100%' }}>
      {/* KPI CARDS */}
      <div className="row mb-4">
        {metrics.map((m,i)=>(
          <div key={i} className="col-xl-4 col-sm-6 mb-3">
            <div className="card ecommerce-widget">
              <div className="card-body support-ticket-font">
                <div className="d-flex justify-content-between">
                  <small className="text-secondary">{m.label}</small>
                  <div><Arrow dir={m.change.dir}/> {m.change.pct}%</div>
                </div>
                <h6 className="mt-2 mb-1 text-muted">{m.title}</h6>
                <h3 className="total-num counter">
                  R{m.value.toLocaleString(undefined,{minimumFractionDigits:2})}
                </h3>
                <small className="text-muted">{m.count} transactions</small>
                <div className="progress-showcase mt-2">
                  <div className="progress sm-progress-bar">
                    <div className={`progress-bar ${m.barClass}`} style={{width:'100%'}}/>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* TRANSACTIONS TABLE */}
      <div className="card mb-4">
        <div className="card-header d-flex justify-content-between align-items-center">
          <div>
            <h4>Transactions</h4>
            <small>Monthly revenue &amp; expenses</small>
          </div>
          <div className="d-flex align-items-center">
            <div className="position-relative me-3" style={{width:'260px'}}>
              <DatePicker
                ref={datePickerRef}
                selectsRange
                startDate={fromDate}
                endDate={toDate}
                onChange={upd=>{
                  setCurrentPage(1);
                  if (!upd) return setRange([null,null]);
                  const [s,e]=upd;
                  if (s&&e&&pickerMode==='month'&&s.getFullYear()===e.getFullYear()&&s.getMonth()===e.getMonth()) {
                    setRange([ new Date(s.getFullYear(),s.getMonth(),1),
                               new Date(s.getFullYear(),s.getMonth()+1,0) ]);
                  } else setRange([s,e]);
                }}
                isClearable
                placeholderText={pickerMode==='month'?'Select months':'Select dates'}
                showMonthYearPicker={pickerMode==='month'}
                className="form-control form-control-sm w-100 pe-5"
              />
              <i className="fa fa-calendar position-absolute calendar-icon"
                 style={{top:'50%',right:'12px',transform:'translateY(-50%)'}}
                 onClick={()=>{
                   setPickerMode(p=>p==='month'?'day':'month');
                   setTimeout(()=>datePickerRef.current?.setOpen(true),0);
                 }}/>
            </div>
            <div className="position-relative me-3" style={{width:'200px'}}>
              <input type="search" placeholder="Search..."
                     className="form-control form-control-sm w-100 pe-5"
                     value={searchTerm}
                     onChange={e=>{setSearchTerm(e.target.value);setCurrentPage(1);}}/>
              <i className="fa fa-search position-absolute"
                 style={{top:'50%',right:'12px',transform:'translateY(-50%)'}}/>
            </div>
            <button className="btn button-light-secondary btn-sm"
                    onClick={()=>window.$('#uploadModal').modal('show')}>
              Add
            </button>
            <button className="btn button-light-secondary btn-sm"
                    style={{marginLeft:'8px', display:'None'}}
                    onClick={()=>window.$('#uploadModal').modal('show')}>
              Reports
            </button>
          </div>
        </div>

        <div className="card-body px-0 py-0">
          <div className="table-responsive theme-scrollbar">
            <table className="display nowrap w-100">
              <thead>
                <tr>
                  <th className="sortable"
                      onClick={()=>{
                        sortField==='date'
                          ? setSortDir(d=>d==='asc'?'desc':'asc')
                          : (setSortField('date'),setSortDir('desc'));
                      }}>
                    Date {sortField==='date'? (sortDir==='asc'?'▲':'▼'):''}
                  </th>
                  <th>Description</th>
                  <th style={{display:'none'}}>Ref Name</th>
                  <th style={{display:'none'}}>Ref ID</th>
                  <th style={{minWidth:200,position:'relative'}}>
                    <span className={`badge ${!categoryFilter?'bg-primary':'bg-secondary'}`}
                          style={{cursor:'pointer',marginRight:8}}
                          onClick={()=>setHeaderCatOpen(o=>!o)}>
                      {categoryFilter||'Category'}
                    </span>
                    {headerCatOpen&&(
                      <ul className="dropdown-menu show"
                          style={{position:'absolute',top:'1.5rem',left:0}}>
                        <li><button className="dropdown-item"
                                    onClick={()=>{setCategoryFilter('');setCurrentPage(1);setHeaderCatOpen(false);}}>
                          All Categories</button></li>
                        {headerCatOptions.map(cat=>(
                          <li key={cat}><button className="dropdown-item"
                                  onClick={()=>{setCategoryFilter(cat);setCurrentPage(1);setHeaderCatOpen(false);}}>
                            {cat}</button></li>
                        ))}
                      </ul>
                    )}
                    <span className={`badge ${!typeFilter?'bg-primary':'bg-secondary'}`}
                          style={{cursor:'pointer'}}
                          onClick={()=>setHeaderTypeOpen(o=>!o)}>
                      {typeFilter||'Type'}
                    </span>
                    {headerTypeOpen&&(
                      <ul className="dropdown-menu show"
                          style={{position:'absolute',top:'1.5rem',left:120}}>
                        <li><button className="dropdown-item"
                                    onClick={()=>{setTypeFilter('');setCurrentPage(1);setHeaderTypeOpen(false);}}>
                          All Types</button></li>
                        <li><button className="dropdown-item"
                                    onClick={()=>{setTypeFilter('Credited');setCurrentPage(1);setHeaderTypeOpen(false);}}>
                          Credited</button></li>
                        <li><button className="dropdown-item"
                                    onClick={()=>{setTypeFilter('Debited');setCurrentPage(1);setHeaderTypeOpen(false);}}>
                          Debited</button></li>
                      </ul>
                    )}
                  </th>
                  <th className="text-end sortable"
                      onClick={()=>{
                        sortField==='amount'
                          ? setSortDir(d=>d==='asc'?'desc':'asc')
                          : (setSortField('amount'),setSortDir('desc'));
                      }}>
                    Amount {sortField==='amount'? (sortDir==='asc'?'▲':'▼'):''}
                  </th>
                  <th/>
                </tr>
              </thead>
              <tbody>
                {loadingList && (
                  <tr><td colSpan={6} className="text-center py-4">Loading…</td></tr>
                )}
                {!loadingList && pagedData.length===0 && (
                  <tr><td colSpan={6} className="text-center py-4">No transactions.</td></tr>
                )}
                {pagedData.map(t=>{
                  const isDebit = t.transaction_type==='Debited';
                  const day = toDateObj(t.txn_date).toLocaleDateString('en-ZA',{
                    weekday:'short',day:'numeric',month:'short'});
                  const desc = t.description.length>75
                                 ? `${t.description.slice(-70)}…`
                                 : t.description;
                  const fmtAmt = t.amount.toLocaleString(undefined,{
                                    minimumFractionDigits:2});
                  return (
                    <tr key={t.id} className="table-row">
                      <td>{day}</td>
                      <td style={{cursor:'pointer'}} onClick={()=>openDetail(t)}>{desc}</td>
                      <td style={{display:'none'}}>{t.reference_name}</td>
                      <td style={{display:'none'}}>{t.reference_id}</td>
                      <td>
                        {editingCat===t.id ? (
                          <select className="form-select form-select-sm me-2"
                                  value={t.category_name}
                                  onChange={e=>handleCategoryChange(t.id,e.target.value)}
                                  onBlur={()=>setEditingCat(null)} autoFocus>
                            {inlineCatOptions.map(o=>(
                              <option key={o.name} value={o.name}>{o.name}</option>
                            ))}
                          </select>
                        ) : (
                          <span className="badge bg-secondary me-2">
                            {t.category_name}
                            <i className="fa fa-edit ms-1" onClick={()=>setEditingCat(t.id)}/>
                          </span>
                        )}
                        {editingType===t.id ? (
                          <select className="form-select form-select-sm"
                                  value={t.transaction_type}
                                  onChange={e=>handleTypeChange(t.id,e.target.value)}
                                  onBlur={()=>setEditingType(null)} autoFocus>
                            <option value="Credited">Credited</option>
                            <option value="Debited">Debited</option>
                          </select>
                        ) : (
                          <span className={`badge ${isDebit?'bg-danger':'bg-success'}`}>
                            {t.transaction_type}
                            <i className="fa fa-edit ms-1" onClick={()=>setEditingType(t.id)}/>
                          </span>
                        )}
                      </td>
                      <td className={`text-end ${isDebit?'text-danger':'text-success'}`}
                          onClick={()=>{setEditingAmt(t.id);setAmtDraft(t.amount);setAmtError('');}}>
                        {editingAmt===t.id ? (
                          <>
                            <input type="number" step="0.01"
                                   className="form-control form-control-sm text-end"
                                   value={amtDraft}
                                   onChange={e=>{setAmtDraft(e.target.value);setAmtError('');}}
                                   onBlur={()=>handleAmtBlur(t.id)}
                                   onKeyDown={e=>e.key==='Enter'&&handleAmtBlur(t.id)}
                                   autoFocus/>
                            {amtError && <small className="text-danger">{amtError}</small>}
                          </>
                        ) : `R${fmtAmt}`}
                      </td>
                      <td className="text-center">
                        <i className="fa fa-trash delete-icon"
                           onClick={()=>{ setToDeleteTx(t.id); setShowDelModal(true); }}/>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* PAGINATION */}
        <div className="d-flex justify-content-end align-items-center p-3">
          <div className="me-3">
            Show&nbsp;
            <select className="form-select form-select-sm d-inline-block w-auto"
                    value={pageSize}
                    onChange={e=>{ setPageSize(+e.target.value); setCurrentPage(1); }}>
              {PAGE_SIZES.map(sz=><option key={sz} value={sz}>{sz}</option>)}
            </select>
          </div>
          <nav>
            <ul className="pagination pagination-sm mb-0">
              <li className={`page-item ${currentPage===1?'disabled':''}`}>
                <button className="page-link" onClick={()=>setCurrentPage(p=>p-1)}>Prev</button>
              </li>
              {Array.from({length:pageCount},(_,i)=>(
                <li key={i} className={`page-item ${currentPage===i+1?'active':''}`}>
                  <button className="page-link" onClick={()=>setCurrentPage(i+1)}>{i+1}</button>
                </li>
              ))}
              <li className={`page-item ${currentPage===pageCount?'disabled':''}`}>
                <button className="page-link" onClick={()=>setCurrentPage(p=>p+1)}>Next</button>
              </li>
            </ul>
          </nav>
        </div>
      </div>

      {/* DETAILS MODAL */}
      {showDetailModal && (
        <div className="modal fade show" style={{display:'block',background:'rgba(0,0,0,0.5)'}} tabIndex={-1}>
          <div className="modal-dialog modal-lg" style={{maxWidth:'800px'}}>
            <div className="modal-content" style={{maxHeight:'800px',overflowY:'auto'}}>
              <div className="modal-header">
                <h5 className="modal-title">Transaction Details</h5>
                <button type="button" className="btn-close" onClick={closeDetail}/>
              </div>
              <div className="modal-body">
                <p><strong>Date:</strong> {toDateObj(selectedTx.txn_date).toLocaleDateString('en-ZA')}</p>
                <p><strong>Description:</strong> {selectedTx.description}</p>

                {/* CATEGORY */}
                <div className="mb-3">
                  <label className="form-label">Category</label>
                  <select className="form-select"
                          value={creatingCategory?'__create__':detailCat}
                          onChange={e=>{
                            if(e.target.value==='__create__'){
                              setCreatingCategory(true); setDetailCat('');
                            } else {
                              setCreatingCategory(false); setDetailCat(e.target.value);
                            }
                          }}>
                    <option value="">Select category…</option>
                    <option value="__create__">+ Create Category</option>
                    {headerCatOptions.map(c=>(
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                  {creatingCategory && (
                    <input type="text" className="form-control mt-2"
                           placeholder="New category name"
                           value={newCategoryName}
                           onChange={e=>setNewCategoryName(e.target.value)}
                           autoFocus/>
                  )}
                </div>

                {/* TYPE */}
                <div className="mb-3">
                  <label className="form-label d-block">Type</label>
                  {['Credited','Debited'].map(t=>(
                    <div key={t} className="form-check form-check-inline">
                      <input className="form-check-input" type="radio"
                             name="detailType" id={`detailType${t}`} value={t}
                             checked={detailType===t}
                             onChange={e=>setDetailType(e.target.value)}/>
                      <label className="form-check-label" htmlFor={`detailType${t}`}>
                        {t==='Credited'?'Credit':'Debit'}
                      </label>
                    </div>
                  ))}
                </div>

                {/* ALLOCATION */}
                <div className="mb-3 position-relative">
                  <label className="form-label">Allocate</label>
                  <div className="mb-2">
                    {assignTo.length > 0 && assignTo.map(a=>(
                      <span key={a.id} className="badge bg-secondary me-1">
                        {a.company} <small>({a.type})</small>
                        <i className="fa fa-times ms-1" style={{cursor:'pointer'}}
                           onClick={()=>handleRemoveAlloc(a.id)}/>
                      </span>
                    ))}
                  </div>
                  <input type="text" className="form-control" placeholder="Type and select…"
                         value={allocInput}
                         onChange={e=>handleAllocSearch(e.target.value)}
                         onKeyDown={handleAllocKeyDown}/>
                  {allocOptions.length>0 && (
                    <ul className="list-group position-absolute w-100 shadow"
                        style={{zIndex:10,maxHeight:180,overflowY:'auto'}}>
                      {allocOptions.map(opt=>(
                        <li key={opt.id} className="list-group-item list-group-item-action"
                            style={{cursor:'pointer'}} onClick={()=>chooseAlloc(opt)}>
                          <strong>{opt.company}</strong>&nbsp;
                          <small className="text-muted">({opt.type})</small>
                        </li>
                      ))}
                      {allocLoading && <li className="list-group-item text-center">Loading…</li>}
                      {!allocLoading && allocOptions.length===0 && (
                        <li className="list-group-item text-center">No results</li>
                      )}
                    </ul>
                  )}
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary btn-sm" onClick={closeDetail}>Cancel</button>
                <button className="btn btn-primary btn-sm" onClick={saveDetail}>Save</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DELETE MODAL */}
      <div className={`modal fade ${showDelModal?'show':''}`}
           style={{display:showDelModal?'block':'none'}} tabIndex={-1}>
        <div className="modal-dialog modal-sm modal-dialog-centered">
          <div className="modal-content" style={{maxHeight:'200px'}}>
            <div className="modal-header">
              <h5 className="modal-title">Confirm Delete</h5>
              <button type="button" className="btn-close" onClick={()=>setShowDelModal(false)}/>
            </div>
            <div className="modal-body"><p>Do you want to delete?</p></div>
            <div className="modal-footer">
              <button className="btn btn-secondary btn-sm"
                      onClick={()=>setShowDelModal(false)}>Cancel</button>
              <button className="btn btn-danger btn-sm" onClick={confirmDelete}
                      disabled={actionLoading}>
                {actionLoading?'Deleting…':'Delete'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* UPLOAD MODAL */}
      <UploadModal/>

      {/* INLINE STYLES */}
      <style>{`
        .sortable { cursor:pointer; user-select:none; }
        .card.ecommerce-widget { min-height:140px; padding:.75rem; }
        .support-ticket-font small { font-size:.85rem; color:#6c757d; }
        .total-num { font-size:2rem; margin:0; }
        .progress.sm-progress-bar { height:6px; }
        .table-responsive { padding:1rem; }
        table th, table td { padding:14px 18px; border:none!important; white-space:nowrap; }
        table tbody tr { background:#fff; box-shadow:0 0 0 1px rgba(0,0,0,.05); transition:box-shadow .2s; }
        table tbody tr:hover { box-shadow:0 4px 12px rgba(0,0,0,.08); }
        .delete-icon { visibility:hidden; color:lightgrey; cursor:pointer; }
        .table-row:hover .delete-icon { visibility:visible; }
        .calendar-icon:hover { cursor:pointer; }
        .bg-purple { background-color:#6f42c1!important; }
        .modal-dialog.modal-lg { max-width:800px; }
        .modal-content { height:600px; overflow-y:auto; }
      `}</style>
    </div>
  );
}

export default Transaction;
