import React from 'react';

// Mock Data (to be replaced with real API data later)
const mockAuthUser = {
    name: 'John Doe',
    profile: 'profile.png', // Replace with actual profile image name if available
};

const mockTotalHistories = 5;

const mockHistories = [
    {
        id: 1,
        user: { name: 'Alice', email: 'alice@example.com' },
        date: '2025-04-23T08:00:00Z',
        ip: '192.168.1.1',
        details: JSON.stringify({
            city: 'New York',
            regionName: 'New York',
            country: 'USA',
            os: 'Windows 10',
        }),
    },
    {
        id: 2,
        user: { name: 'Bob', email: 'bob@example.com' },
        date: '2025-04-22T08:30:00Z',
        ip: '192.168.1.2',
        details: JSON.stringify({
            city: 'Los Angeles',
            regionName: 'California',
            country: 'USA',
            os: 'MacOS',
        }),
    },
    // Add more mock data entries as needed
];

export const LoggedHistory = () => {
    return (
        <div className="row">
            <div className="col-sm-12">
                <div className="card alert alert-primary p-1">
                    <div className="card-body pb-0 total-sells">
                        <div className="d-flex align-items-center gap-3">
                            <div className="social-img-wrap">
                                <div className="social-img cust-profile">
                                    <img
                                        // 
                                        src=''
                                        alt="profile"
                                    />
                                </div>
                            </div>
                            <div className="flex-grow-1">
                                <div className="d-flex align-items-center gap-2">
                                    <h2 className="text-white">Welcome back</h2>
                                </div>
                                <p className="text-white">{mockAuthUser.name}</p>
                            </div>
                        </div>
                        <hr />
                        <div className="d-flex align-items-center gap-3">
                            <p className="btn button-light bg-light p-2 text-primary">
                                <i data-feather="users"></i>
                            </p>
                            <div className="flex-grow-1">
                                <div className="d-flex align-items-center gap-2">
                                    <h2 className="text-white">{mockTotalHistories}</h2>
                                </div>
                                <p className="text-white">Total Logged History</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="col-sm-12">
                <div className="card table-card">
                    <div className="card-header">
                        <div className="row align-items-center g-2">
                            <div className="col">
                                <h5>Logged History List</h5>
                            </div>
                        </div>
                    </div>

                    <div className="card-body">
                        <div className="table-responsive theme-scrollbar">
                            <table className="table light-card advance-datatable">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Email</th>
                                        <th>Login Date</th>
                                        <th>System IP</th>
                                        <th>City</th>
                                        <th>State</th>
                                        <th>Country</th>
                                        <th>System</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {mockHistories.map((history) => {
                                        const historyDetail = JSON.parse(history.details);
                                        return (
                                            <tr key={history.id}>
                                                <td>{history.user ? history.user.name : '-'}</td>
                                                <td>{history.user ? history.user.email : '-'}</td>
                                                <td>{history.date ? new Date(history.date).toLocaleDateString() : '-'}</td>
                                                <td>{history.ip}</td>
                                                <td>{historyDetail ? historyDetail.city : '-'}</td>
                                                <td>{historyDetail ? historyDetail.regionName : '-'}</td>
                                                <td>{historyDetail ? historyDetail.country : '-'}</td>
                                                <td>{historyDetail ? historyDetail.os : '-'}</td>
                                                <td className="text-right">
                                                    <ul className="action">
                                                        <form
                                                            method="POST"
                                                            action={`/logged/history/destroy/${history.id}`}
                                                            onSubmit={(e) => {
                                                                e.preventDefault();
                                                                if (window.confirm('Are you sure you want to delete this?')) {
                                                                    e.target.submit();
                                                                }
                                                            }}
                                                        >
                                                            <button type="submit" className="text-danger confirm_dialog">
                                                                <i className="icon-trash"></i>
                                                            </button>
                                                        </form>
                                                    </ul>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

