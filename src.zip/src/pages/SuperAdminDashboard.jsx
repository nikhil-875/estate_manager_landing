import React from 'react';
import { FaBoxOpen, FaDollarSign } from 'react-icons/fa';
import { DataCard, UsersCard } from '../components/DashboardCard';
import { RecentOrders } from '../components/TransactionsTable';
import { SalesOverview } from '../components/SalesCharts';
import { useGetDashboardStatsQuery } from '../api/company';
import { Loader } from '../components/Loader';
import emptyCartSvg from '../assets/svg/no_sales.svg';

/* ───────────────────────── helpers ───────────────────────── */
const getLatest = (arr = []) => (arr.length ? arr[arr.length - 1] : {});

const formatStat = (data, defaultValue = 0) => {
  return data ?? defaultValue;
};

/* ───────────────────────── component ───────────────────────── */
export const SuperAdminDashboard = () => {
  const { data: stats, isLoading, isError } = useGetDashboardStatsQuery();

  if (isLoading) return <Loader />;
  if (isError || !stats)
    return <div className="text-danger p-3">Error loading dashboard data.</div>;

  console.log(stats);

  const {
    registration_stats = {},
    subscriber_stats = {},
    expense_stats = [],
    revenue_stats = [],
    sales_overview = [],
    currency = 'R',
  } = stats.payload;

  console.log({
    registration_stats,
    subscriber_stats,
    expense_stats,
    revenue_stats,
    sales_overview,
  });

  /* ─── Packages (subscribers) ─────────────────────────────── */
  const latestSubYear = getLatest(subscriber_stats.yearly_data);
  const latestSubMonth = getLatest(subscriber_stats.monthly_data);
  const packagesPayload = {
    year: latestSubYear.year,
    month: latestSubMonth.month,
    total_subscribers: formatStat(latestSubYear.total_subscribers),
    subscriber_growth_rate: formatStat(latestSubYear.subscriber_growth_rate),
    month_total_subs: formatStat(latestSubMonth.total_subscribers),
    monthly_growth_rate: formatStat(latestSubMonth.monthly_growth_rate),
  };

  /* ─── Expenses ───────────────────────────────────────────── */
  const latestExpense = getLatest(expense_stats);
  const expensesPayload = {
    year: latestExpense.year,
    month: latestSubMonth.month,
    total_expense: formatStat(latestExpense.total_expense),
    expense_growth_rate: formatStat(latestExpense.expense_growth_rate),
    monthly_growth_rate: 0, // no monthly breakdown yet
  };

  /* ─── Revenue ────────────────────────────────────────────── */
  const latestRevenue = getLatest(revenue_stats);
  const revenuePayload = {
    year: latestRevenue.year,
    month: latestSubMonth.month,
    total_sells: formatStat(latestRevenue.total_sells),
    sells_growth_rate: formatStat(latestRevenue.sells_growth_rate),
    monthly_growth_rate: 0, // no monthly breakdown yet
  };

  /* ─── Recent orders placeholder ──────────────────────────── */
  const transactions = [];

  return (
    <div className="container-fluid">
      {/* Top summary cards */}
      <div className="row g-4 mb-4">
        {/* Total Users */}
        <div className="col-xl-3 col-md-6 col-sm-12">
          <UsersCard payload={registration_stats} />
        </div>

        {/* Total Packages */}
        <div className="col-xl-3 col-md-6 col-sm-12">
          <DataCard
            title="Subscribers"
            icon={<FaBoxOpen className="text-white" />}
            bgColor="#1cc88a"
            payload={packagesPayload}
            yearlyKey="year"
            monthlyKey="month"
            yearlyValueKey="total_subscribers"
            yearlyPctKey="subscriber_growth_rate"
            monthlyValueKey="month_total_subs"
            monthlyPctKey="monthly_growth_rate"
            currency={currency}
          />
        </div>

        {/* Expenses */}
        <div className="col-xl-3 col-md-6 col-sm-12">
          <DataCard
            title="Transactions"
            icon={<FaDollarSign className="text-white" />}
            bgColor="#ff7043"
            payload={expensesPayload}
            yearlyKey="year"
            monthlyKey="month"
            yearlyValueKey="total_expense"
            yearlyPctKey="expense_growth_rate"
            monthlyValueKey="total_expense"
            monthlyPctKey="monthly_growth_rate"
            currency={currency}
          />
        </div>

        {/* Revenue */}
        <div className="col-xl-3 col-md-6 col-sm-12">
          <DataCard
            title="Growth"
            icon={<FaDollarSign className="text-white" />}
            bgColor="#ec407a"
            payload={revenuePayload}
            yearlyKey="year"
            monthlyKey="month"
            yearlyValueKey="total_sells"
            yearlyPctKey="sells_growth_rate"
            monthlyValueKey="total_sells"
            monthlyPctKey="monthly_growth_rate"
            currency={currency}
          />
        </div>
      </div>

      {/* Recent Orders & Sales Overview */}
      <div className="row g-4">
        {/* Recent Orders */}
        <div className="col-xxl-7 col-xl-8 col-sm-12">
          <div className="card border-0">
            <div className="card-header">Recent Orders</div>
            <div
              className="card-body d-flex flex-column align-items-center"
              style={{ minHeight: '420px' }}
            >
              {transactions.length > 0 ? (
                <RecentOrders payload={transactions} />
              ) : (
                <>
                  <img
                    src={emptyCartSvg}
                    alt="No recent orders"
                    className="img-fluid mb-3"
                    style={{ maxWidth: '200px' }}
                  />
                  <p className="text-muted">No recent orders</p>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Sales Overview */}
        <div className="col-xxl-5 col-xl-4 col-lg-5 col-sm-12">
          <div className="card border-0">
            <div className="card-header">Sales Overview</div>
            <div className="card-body" style={{ minHeight: '360px' }}>
              <SalesOverview payload={sales_overview} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
