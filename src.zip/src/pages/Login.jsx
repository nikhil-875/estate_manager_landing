import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { FaGoogle, FaEye, FaEyeSlash } from "react-icons/fa";
import { Card, Button, Form, Alert, Container, InputGroup } from "react-bootstrap";
import { motion } from "framer-motion";
import { useLoginMutation, useGoogleAuthMutation, useGetMeQuery, authApi } from "../api/authApi";
import { useDispatch } from "react-redux";
import { GoogleLogin } from '@react-oauth/google';
import { handlePostAuth } from "../utils/authUtils";

export const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();

  const [login, { isLoading }] = useLoginMutation();
  const [googleAuth] = useGoogleAuthMutation();
  const { refetch: refetchMe } = useGetMeQuery(undefined, { skip: true });

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    remember: false,
  });

  const [alerts, setAlerts] = useState({
    error: "",
    success: location.state?.message || ""
  });

  const [showPassword, setShowPassword] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  useEffect(() => {
    if (alerts.success) {
      const timer = setTimeout(() => {
        setAlerts(prev => ({ ...prev, success: "" }));
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [alerts.success]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setAlerts({ error: "", success: "" });

    try {
      const res = await login({
        method: "password",
        email: formData.email,
        password: formData.password,
      }).unwrap();

      if (res?.success && res.data?.token) {
        const token = res.data.token;
        localStorage.setItem("token", token);

        const meRes = await dispatch(authApi.endpoints.getMe.initiate());
        const user = meRes?.data?.data;

        if (user) {
          await handlePostAuth({
            userData: user,
            token,
            dispatch,
          });

          // If phone is not verified
          if (!user?.is_active) {
            navigate("/verify-phone", {
              state: {
                userId: user.id,
                type: 'login',
                message: "One more step to complete your registration"
              }
            });
          } else {
            navigate("/dashboard");
          }
        } else {
          throw new Error("Failed to load user profile.");
        }
      } else {
        throw new Error(res?.message || "Login failed.");
      }
    } catch (err) {
      console.error("Login error:", err);
      setAlerts({
        error: err?.data?.message || err?.message || "Login failed"
      });
    }
  };

  const handleGoogleSuccess = async (credentialResponse) => {
    setGoogleLoading(true);
    try {
      const response = await googleAuth({
        token: credentialResponse.credential
      }).unwrap();

      if (response.success) {
        const token = response.data.token;
        localStorage.setItem("token", token);

        const meRes = await dispatch(authApi.endpoints.getMe.initiate());
        const user = meRes?.data?.data;

        if (user) {
          await handlePostAuth({
            userData: user,
            token,
            dispatch,
          });

          // If phone is not verified
          if (!user?.is_active) {
            navigate("/verify-phone", {
              state: {
                userId: user.id,
                type: 'login',
                message: "One more step to complete your registration"
              }
            });
          } else {
            navigate("/dashboard");
          }
        } else {
          setAlerts({ error: response.message || "Google authentication failed" });
        }
      }
    } catch (error) {
      console.error("Google auth error:", error);
      setAlerts({
        error: error?.data?.message || error.message || "Google sign-in failed."
      });
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleGoogleError = () => {
    setAlerts({ error: "Google sign-in failed. Please try again." });
    setGoogleLoading(false);
  };

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: "100vh" }}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={{ width: "100%", maxWidth: "450px" }}
      >
        <Card className="shadow-lg border-0 rounded-4 overflow-hidden">
          <Card.Body className="p-5">
            <div className="text-center mb-4">
              <h2 className="fw-bold mb-2">Welcome Back</h2>
              <p className="text-muted">Sign in to your account</p>
            </div>

            {alerts.error && (
              <Alert variant="danger" className="mb-4">{alerts.error}</Alert>
            )}

            {alerts.success && (
              <Alert variant="success" className="mb-4">{alerts.success}</Alert>
            )}

            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3">
                <Form.Label>Email Address</Form.Label>
                <Form.Control
                  type="email"
                  name="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  disabled={isLoading}
                />
              </Form.Group>

              <Form.Group className="mb-4">
                <div className="d-flex justify-content-between align-items-center mb-1">
                  <Form.Label>Password</Form.Label>
                  <Link to="/forgot-password" className="small">Forgot Password?</Link>
                </div>
                <InputGroup>
                  <Form.Control
                    type={showPassword ? "text" : "password"}
                    name="password"
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                  />
                  <InputGroup.Text onClick={() => setShowPassword(!showPassword)} style={{ cursor: 'pointer' }}>
                    {showPassword ? <FaEyeSlash /> : <FaEye />}
                  </InputGroup.Text>
                </InputGroup>
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Check
                  type="checkbox"
                  name="remember"
                  label="Remember me"
                  checked={formData.remember}
                  onChange={handleChange}
                  disabled={isLoading}
                />
              </Form.Group>

              <Button
                variant="primary"
                type="submit"
                className="w-100 py-2 mb-4"
                disabled={isLoading}
              >
                {isLoading ? "Signing In..." : "Sign In"}
              </Button>
            </Form>

            <div className="d-flex align-items-center mb-4">
              <div className="flex-grow-1 border-bottom"></div>
              <span className="mx-3 text-muted">or</span>
              <div className="flex-grow-1 border-bottom"></div>
            </div>

            <div className="w-100 mb-4 d-flex justify-content-center">
              {googleLoading ? (
                <Button variant="outline-danger" className="w-100 py-2" disabled>
                  Connecting...
                </Button>
              ) : (
                <div className="w-100">
                  <GoogleLogin
                    onSuccess={handleGoogleSuccess}
                    onError={handleGoogleError}
                    useOneTap
                    theme="outline"
                    size="large"
                    text="signin_with"
                    shape="rectangular"
                    logo_alignment="center"
                    width="100%"
                  />
                </div>
              )}
            </div>

            <div className="text-center">
              <p>
                Don't have an account?{" "}
                <Link to="/register" className="fw-medium">
                  Sign up
                </Link>
              </p>
            </div>
          </Card.Body>
        </Card>
      </motion.div>
    </Container>
  );
};
