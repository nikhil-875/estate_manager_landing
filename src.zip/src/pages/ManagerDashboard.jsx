// src/pages/ManagerDashboard.jsx
import React, { useEffect, useState } from "react";
import ApexCharts from "apexcharts";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import { List as ListIcon, Calendar as CalendarIcon } from "lucide-react";

// — dummy data —
const upcomingLeases = [
  { tenant: "Michael Brown", date: "2024-08-14" },
  { tenant: "Emily Clark",   date: "2024-08-20" },
  { tenant: "Daniel Martinez", date: "2024-08-05" },
];
const tenantScreening = [
  { name: "Junsung Park", id: "32449", status: "Paid"    },
  { name: "Yongjae Choi", id: "95460", status: "Pending" },
  { name: "Seonil Jang",  id: "95468", status: "Paid"    },
  { name: "Joohee Min",   id: "95462", status: "Pending" },
  { name: "Soojung Kin",  id: "34586", status: "Paid"    },
];
const quickStats = [
  {
    title: "Total Properties",
    value: 145,
    color: "#7366FF",
    icon: "icofont-building-alt",
  },
  {
    title: "Occupancy Rate",
    value: "92%",
    color: "#28C76F",
    icon: "icofont-home",
  },
    {
    title: "Listed Properties",
    value: 7,
    color: "#00CFE8",
    icon: "icofont-users",
  },
  {
    title: "Outstanding Maintenance",
    value: 5,
    color: "#FF9F43",
    icon: "icofont-wrench",
  },

];

const ManagerDashboard = () => {
  const [leaseView, setLeaseView] = useState("list"); // toggle list/calendar

  useEffect(() => {
    // Rent Collection chart
    const rentOptions = {
      series: [{ name: "Rent", data: [45, 52, 68, 75, 90] }],
      chart: { type: "bar", height: 250, toolbar: { show: false } },
      plotOptions: { bar: { borderRadius: 4, columnWidth: "50%" } },
      dataLabels: { enabled: true, style: { colors: ["#fff"] } },
      colors: ["#7366FF"],
      xaxis: { categories: ["Feb", "Mar", "Apr", "May", "Jun"] },
      grid: { borderColor: "#eee" },
    };
    const rentChart = new ApexCharts(
      document.querySelector("#rent-collection-chart"),
      rentOptions
    );
    rentChart.render();
    return () => rentChart.destroy();
  }, []);

  return (
    <div className="container my-4">
      <h2 className="mb-4">Manager Dashboard</h2>

      {/* Top stats (short cards) */}
      <div className="row g-4 mb-5">
        {quickStats.map((stat, i) => (
          <div key={i} className="col-md-3">
            <div className="card basic-card mb-0" style={{ minHeight: 140 }}>
              <div className="card-header d-flex justify-content-between align-items-center pb-0">
                <h6 className="mb-0">{stat.title}</h6>
                <i className="icofont-ui-more" />
              </div>
              <div className="card-body d-flex align-items-center pt-2">
                <div
                  style={{
                    backgroundColor: stat.color + "20",
                    color: stat.color,
                    borderRadius: "50%",
                    padding: "10px",
                    fontSize: "1.25rem",
                  }}
                >
                  <i className={stat.icon} />
                </div>
                <div className="ms-3">
                  <h3 className="mb-1">{stat.value}</h3>
                  <small className="text-muted">Year 2025</small>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main row: rent (4 cols), screening (4), leases (4) */}
      <div className="row g-4">
        {/* Rent Collection */}
        <div className="col-lg-4">
          <div className="card basic-card mb-0">
            <div className="card-header card-no-border pb-0">
              <h6 className="mb-0">Rent Collection</h6>
            </div>
            <div className="card-body p-4">
              <div id="rent-collection-chart"></div>
            </div>
          </div>
        </div>

        {/* Tenant Screening */}
        <div className="col-lg-4">
          <div className="card basic-card mb-0">
            <div className="card-header d-flex justify-content-between align-items-center pb-0">
              <h6 className="mb-0">Tenant Screening</h6>
              <i className="icofont-ui-more" />
            </div>
            <ul className="list-group list-group-flush">
              {tenantScreening.map((t, idx) => (
                <li
                  key={idx}
                  className="list-group-item d-flex justify-content-between align-items-center"
                  style={{
                    borderBottom:
                      idx < tenantScreening.length - 1
                        ? "1px dashed #dee2e6"
                        : "none",
                  }}
                >
                  <div className="d-flex align-items-center">
                    <div
                      className="bg-light rounded-circle me-3"
                      style={{ width: 40, height: 40 }}
                    />
                    <div>
                      <div className="fw-semibold">{t.name}</div>
                      <small className="text-muted">ID #{t.id}</small>
                    </div>
                  </div>
                  <span
                    className={`text-${
                      t.status === "Paid" ? "success" : "danger"
                    }`}
                  >
                    {t.status}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Upcoming Leases (toggle) */}
        <div className="col-lg-4">
          <div className="card basic-card mb-0">
            <div className="card-header d-flex justify-content-between align-items-center pb-0">
              <h6 className="mb-0">Upcoming Lease Expirations</h6>
              <div>
                <ListIcon
                  size={18}
                  className={`me-2 cursor-pointer ${
                    leaseView === "list" ? "text-primary" : "text-muted"
                  }`}
                  onClick={() => setLeaseView("list")}
                />
                <CalendarIcon
                  size={18}
                  className={`cursor-pointer ${
                    leaseView === "calendar" ? "text-primary" : "text-muted"
                  }`}
                  onClick={() => setLeaseView("calendar")}
                />
              </div>
            </div>
            <div className="card-body p-0">
              {leaseView === "calendar" ? (
                <FullCalendar
                  plugins={[dayGridPlugin]}
                  initialView="dayGridMonth"
                  events={upcomingLeases.map((e) => ({
                    title: e.tenant,
                    start: e.date,
                  }))}
                  height={500}
                  headerToolbar={{
                    left: "",
                    center: "title",
                    right: "prev,next",
                  }}
                />
              ) : (
                <div style={{ minHeight: 500, overflowY: "auto" }}>
                  <ul className="list-group list-group-flush">
                    {upcomingLeases.map((e, idx) => (
                      <li
                        key={idx}
                        className="list-group-item d-flex justify-content-between"
                        style={{
                          borderBottom:
                            idx < upcomingLeases.length - 1
                              ? "1px dashed #dee2e6"
                              : "none",
                        }}
                      >
                        {e.tenant}
                        <small className="text-muted">
                          {new Date(e.date).toLocaleDateString()}
                        </small>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export { ManagerDashboard };
export default ManagerDashboard;
