import React, { useState, useEffect } from 'react';

export const TenantList = ({ contacts = [], canCreate = false }) => {
  const [selectedContactId, setSelectedContactId] = useState(contacts.length > 0 ? contacts[0].id : null);
  const [selectedContact, setSelectedContact] = useState(null);

  useEffect(() => {
    if (selectedContactId) {
      const contact = contacts.find(c => c.id === selectedContactId);
      setSelectedContact(contact);
    }
  }, [selectedContactId, contacts]);

  const getProfileImage = (user) => {
    return user?.profile
      ? `/storage/upload/profile/${user.profile}`
      : `/storage/upload/profile/avatar.png`;
  };

  return (
    <div className="row">
      <div className="email-wrap">
        <div className="col-sm-12">
          <div className="email-right-aside contacts-tabs">
            <div className="email-body radius-left dark-contact">
              <div className="card">
                <div className="card-header">
                  <div className="row">
                    <div className="col-6 text-start">
                      <h4>Tenant List</h4>
                    </div>
                    <div className="col-6 text-end">
                      {canCreate && (
                        <a className="btn btn-primary contactCreate" href="#">
                          Create
                        </a>
                      )}
                    </div>
                  </div>
                </div>

                <div className="card-body p-0">
                  <div className="row list-persons">
                    <div className="col-xl-4 xl-50 col-md-5">
                      <div className="nav flex-column nav-pills">
                        {contacts.length > 0 ? (
                          contacts.map((contact, idx) => (
                            <a
                              key={contact.id}
                              className={`nav-link contactView ${selectedContactId === contact.id ? 'active' : ''}`}
                              onClick={() => setSelectedContactId(contact.id)}
                              href="#"
                            >
                              <div className="d-flex">
                                <img
                                  className="img-50 img-fluid me-3 rounded-circle"
                                  src={getProfileImage(contact.user)}
                                  alt="Profile"
                                />
                                <div className="flex-grow-1">
                                  <h6>{contact.name}</h6>
                                  <p>{contact.email}</p>
                                </div>
                              </div>
                            </a>
                          ))
                        ) : (
                          <a className="nav-link contactView" data-id="0">
                            <div className="d-flex">
                              <div className="flex-grow-1">
                                <div className="card-body reset-rating-wrapper">
                                  <div className="ratingCard">
                                    <p>No Contact Data</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </a>
                        )}
                      </div>
                    </div>

                    <div className="col-xl-8 xl-50 col-md-7">
                      <div id="contact-view">
                        {selectedContact ? (
                          <div className="p-3">
                            <h5>{selectedContact.name}</h5>
                            <p><strong>Email:</strong> {selectedContact.email}</p>
                            {/* Add more fields as needed */}
                          </div>
                        ) : (
                          <div className="p-3 text-muted">Select a contact to view details.</div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

