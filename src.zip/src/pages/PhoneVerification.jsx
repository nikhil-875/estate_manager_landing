import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, Button, Form, Alert, Container, InputGroup } from "react-bootstrap";
import { FaArrowLeft } from "react-icons/fa";
import { useResendActivationTokenMutation } from "../api/authApi";

export const PhoneVerification = () => {
    const navigate = useNavigate();
    const [resendActivationToken, { isLoading }] = useResendActivationTokenMutation();
    
    const [phoneNumber, setPhoneNumber] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState("");


    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");

        if (!phoneNumber.trim()) {
            setError("Please enter your phone number");
            return;
        }

        console.log("Submitting phone number:", phoneNumber);
        setIsSubmitting(true);

        try {
            // Call resendActivationToken with userId and phoneNumber
            const response = await resendActivationToken({
                phoneNumber: phoneNumber,
            }).unwrap();

            if (!response.success) {
                throw new Error(response.message || "Failed to get activation code");
            }

            // Navigate to verification code page
            navigate("/verify-code", {
                state: {
                    phoneNumber: phoneNumber,
                }
            });
        } catch (err) {
            console.error("Error:", err);

            if (err.data?.message) {
                setError(err.data.message);
            } else if (err.message) {
                setError(err.message);
            } else {
                setError("An unexpected error occurred. Please try again.");
            }
        } finally {
            setIsSubmitting(false);
        }
    };

    const goBack = () => {
        navigate(-1);
    };

    return (
        <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: "100vh" }}>
            <div
                style={{ width: "100%", maxWidth: "450px" }}
            >
                <Card className="shadow-lg border-0 rounded-4 overflow-hidden">
                    <Card.Body className="p-5">
                        <Button
                            variant="link"
                            className="p-0 mb-4 text-decoration-none"
                            onClick={goBack}
                        >
                            <FaArrowLeft className="me-2" /> Back
                        </Button>

                        {error && (
                            <Alert variant="danger" className="mb-4">
                                {error}
                            </Alert>
                        )}

                        <Form onSubmit={handleSubmit}>
                            <Form.Group className="mb-4">
                                <Form.Label>Phone Number</Form.Label>
                                <InputGroup>
                                    <Form.Control
                                        type="tel"
                                        placeholder="Enter your phone number"
                                        value={phoneNumber}
                                        onChange={(e) => setPhoneNumber(e.target.value)}
                                        className="py-2"
                                        disabled={isSubmitting || isLoading}
                                    />
                                </InputGroup>
                                <Form.Text className="text-muted">
                                    A verification code will be sent to your WhatsApp
                                </Form.Text>
                            </Form.Group>

                            <Button
                                variant="primary"
                                type="submit"
                                className="w-100 py-2 mb-3"
                                disabled={isSubmitting || isLoading}
                            >
                                {(isSubmitting || isLoading) ? (
                                    <>
                                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                        Sending Code...
                                    </>
                                ) : (
                                    "Send Verification Code"
                                )}
                            </Button>
                        </Form>
                    </Card.Body>
                </Card>
            </div>
        </Container>
    );
};
