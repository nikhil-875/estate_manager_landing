import React from 'react';

export const CouponList = ({
  coupons = [],
  canCreate = false,
  canEdit = false,
  canDelete = false,
  onCreate,
  onEdit,
  onDelete
}) => {
  const formatDate = (dateStr) => new Date(dateStr).toLocaleDateString();

  return (
    <div className="row">
      <div className="col-sm-12">
        <div className="card table-card">
          <div className="card-header">
            <div className="row align-items-center g-2">
              <div className="col">
                <h5>Coupon List</h5>
              </div>
              {canCreate && (
                <div className="col-auto">
                  <button className="btn btn-secondary" onClick={onCreate}>
                    <i className="ti ti-circle-plus align-text-bottom"></i> Create Coupon
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="card-body pt-0">
            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>Coupon Name</th>
                    <th>Type</th>
                    <th>Rate</th>
                    <th>Code</th>
                    <th>Valid For</th>
                    <th>Use Limit</th>
                    <th>Applicable Packages</th>
                    <th>Total Used</th>
                    <th>Status</th>
                    {(canEdit || canDelete) && <th className="text-right">Action</th>}
                  </tr>
                </thead>
                <tbody>
                  {coupons.length > 0 ? coupons.map((coupon) => (
                    <tr key={coupon.id}>
                      <td>{coupon.name}</td>
                      <td>{coupon.typeText}</td>
                      <td>{coupon.rate}</td>
                      <td>{coupon.code}</td>
                      <td>{formatDate(coupon.valid_for)}</td>
                      <td>{coupon.use_limit}</td>
                      <td>
                        {coupon.packages.map(pkg => (
                          <span key={pkg.id} className="badge bg-light-secondary ms-2 f-12">{pkg.title}</span>
                        ))}
                      </td>
                      <td>{coupon.total_used}</td>
                      <td>
                        <span className={`badge ms-2 f-12 ${coupon.status === 1 ? 'bg-success' : 'bg-danger'}`}>
                          {coupon.statusText}
                        </span>
                      </td>
                      {(canEdit || canDelete) && (
                        <td className="text-right">
                          <div className="cart-action d-flex gap-2 justify-content-end">
                            {canEdit && (
                              <button
                                className="btn btn-sm btn-link text-secondary"
                                onClick={() => onEdit(coupon.id)}
                                title="Edit"
                              >
                                <i className="ti ti-edit"></i>
                              </button>
                            )}
                            {canDelete && (
                              <button
                                className="btn btn-sm btn-link text-danger"
                                onClick={() => onDelete(coupon.id)}
                                title="Delete"
                              >
                                <i className="ti ti-trash-2"></i>
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  )) : (
                    <tr>
                      <td colSpan="10" className="text-center text-muted">No coupons available</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

