// src/components/SupportTickets.jsx
import React, { useState, useRef } from 'react';
import { FaPaperclip } from 'react-icons/fa';
import { useSelector } from 'react-redux';
import {
  useGetUserTicketsQuery,
  useCreateTicketMutation,
  useCreateTicketMessageMutation,
  useManageTicketDocumentMutation,
  useUpdateTicketStatusMutation,
} from '../api/supportApi';

const statusOptions = [
  { code: 'open',         label: 'Open'         },
  { code: 'in_progress',  label: 'In Progress'  },
  { code: 'waiting_user', label: 'Waiting User' },
  { code: 'resolved',     label: 'Resolved'     },
  { code: 'closed',       label: 'Closed'       },
];
const priorityOptions = [
  { code: 'low',    label: 'Low'    },
  { code: 'normal', label: 'Normal' },
  { code: 'high',   label: 'High'   },
  { code: 'urgent', label: 'Urgent' },
];
const statusBadge = {
  open:         'badge bg-primary',
  in_progress:  'badge bg-warning text-white',
  waiting_user: 'badge bg-info text-white',
  resolved:     'badge bg-success',
  closed:       'badge bg-secondary',
};

export const SupportTickets = () => {
  const user = useSelector(s => s.auth.user);

  // ─── Load existing tickets ──────────────────────────
  const { data, error, isLoading, refetch } = useGetUserTicketsQuery(
    { user_id: user?.id },
    { skip: !user?.id }
  );
  const tickets = data?.tickets ?? [];

  // ─── Mutations ──────────────────────────────────────
  const [createTicket]    = useCreateTicketMutation();
  const [createMsg]       = useCreateTicketMessageMutation();
  const [manageDoc]       = useManageTicketDocumentMutation();
  const [updateStatus]    = useUpdateTicketStatusMutation();
  const [updatePriority]  = useUpdateTicketStatusMutation();

  // ─── New-ticket form ────────────────────────────────
  const [form, setForm]   = useState({
    category:'', priority:'normal', subject:'', description:'', file:null
  });
  const fileRef           = useRef(null);
  const pill              = (base,code)=>`${base} rounded-pill me-2${form.priority===code?' shadow-sm':''}`;
  const [alert, setAlert] = useState(null);

  // ─── Modal + comment state ─────────────────────────
  const [modal, setModal]         = useState(null);
  const [newComment, setComment]  = useState('');
  const [isInternal, setInternal] = useState(false);
  const [attachFile, setAttach]   = useState(null);
  const attachRef                 = useRef(null);

  // ─── Handlers ──────────────────────────────────────
  const handleSubmit = async e => {
    e.preventDefault();
    const r = await createTicket({
      raised_by:   user.id,
      title:       form.subject,
      description: form.description,
      priority:    form.priority,
    }).unwrap();
    if (r.status==='success') {
      setAlert({ type:'success', message:`Ticket #${r.ticket_id} created!` });
      setForm({ category:'', priority:'normal', subject:'', description:'', file:null });
      fileRef.current && (fileRef.current.value='');
      refetch();
    } else {
      setAlert({ type:'danger', message:r.message });
    }
  };

  const openModal  = t => {
    setModal({ ...t, messages: t.messages||[] });
    setComment(''); setInternal(false); setAttach(null);
  };
  const closeModal = () => setModal(null);

  const saveStatus = async code => {
    await updateStatus({ ticket_id:modal.ticket_id, status:code }).unwrap();
    setModal(m=>({...m,status:code}));
    refetch();
  };
  const savePriority = async code => {
    await updatePriority({ ticket_id:modal.ticket_id, priority:code }).unwrap();
    setModal(m=>({...m,priority:code}));
    refetch();
  };

  // ─── THE FIXED ADD COMMENT ─────────────────────────
  const addComment = async () => {
    if (!newComment.trim()) return;

    // 1) create the message record
    const res = await createMsg({
      ticket_id: modal.ticket_id,
      sender_id: user.id,
      message:   newComment,
      is_internal: isInternal,
    }).unwrap();

    // 2) prepare our newMsg object
    const newMsg = {
      message_id:  res.message_id,
      sender_id:   user.id,
      message:     newComment,
      is_internal: isInternal,
      created_at:  new Date().toISOString(),  // <— now it shows a valid date
      attachments: [],
    };

    // 3) if there's a file, upload it
    if (attachFile) {
      const docRes = await manageDoc({
        action:     'insert',
        ticket_id:  modal.ticket_id,
        message_id: res.message_id,
        file_name:  attachFile.name,
        file_url:   attachFile.name,
        file_size:  `${(attachFile.size/1024).toFixed(0)}KB`,
        mime_type:  attachFile.type,
      }).unwrap();

      if (docRes.status === 'success') {
        newMsg.attachments.push(docRes);
      }
    }

    // 4) append it to our modal state
    setModal(m=>({
      ...m,
      messages: [...m.messages, newMsg]
    }));

    // 5) reset the inputs
    setComment(''); setInternal(false); setAttach(null);
    attachRef.current && (attachRef.current.value='');
  };

  // ─── Render ─────────────────────────────────────────
  return (
    <div style={{ background:'#fff', padding:'2rem', minHeight:'100vh' }}>
      <div className="row g-4">

        {/* Submit Ticket */}
        <div className="col-md-6">
          <div className="card p-4 shadow-sm rounded">
            <h4 className="mb-4">Submit Ticket</h4>
            {alert && (
              <div className={`alert alert-${alert.type} alert-dismissible`} role="alert">
                {alert.message}
                <button className="btn-close" onClick={()=>setAlert(null)}/>
              </div>
            )}
            <form onSubmit={handleSubmit}>
              <div className="mb-4 d-flex">
                {priorityOptions.map(p=>(
                  <React.Fragment key={p.code}>
                    <input
                      id={p.code}
                      type="radio"
                      name="priority"
                      className="btn-check"
                      value={p.code}
                      checked={form.priority===p.code}
                      onChange={e=>setForm({...form,priority:e.target.value})}
                    />
                    <label
                      htmlFor={p.code}
                      className={pill(
                      `btn btn-sm px-2 py-1 ${{
                        low: 'btn-secondary',
                        normal: 'btn-info text-white',
                        high: 'btn-warning text-white',
                        urgent: 'btn-danger'
                      }[p.code]}`,
                      p.code
                    )}
                    >
                      {p.label}
                    </label>
                  </React.Fragment>
                ))}
              </div>
               <div className="mb-4">
                <label className="form-label">Category</label>
                <select className="form-select" required
                  value={form.category}
                  onChange={e=>setForm({...form,category:e.target.value})}>
                  <option value="">Select category</option>
                  <option>Technical</option>
                  <option>Billing</option>
                  <option>Feature</option>
                  <option>Account</option>
                </select>
              </div>
             
              <div className="mb-4">
                <label className="form-label">Subject – {form.priority}</label>
                <input
                  className="form-control"
                  required
                  value={form.subject}
                  onChange={e=>setForm({...form,subject:e.target.value})}
                />
              </div>
              <div className="mb-4">
                <label className="form-label">Description</label>
                <textarea
                  rows="3"
                  className="form-control"
                  required
                  value={form.description}
                  onChange={e=>setForm({...form,description:e.target.value})}
                />
              </div>
              <div className="mb-4 d-flex align-items-center gap-2">
                <input
                  type="file"
                  ref={fileRef}
                  className="d-none"
                  onChange={e=>setForm({...form,file:e.target.files[0]})}
                />
                <button
                  type="button"
                  className="btn btn-outline-secondary p-2"
                  onClick={()=>fileRef.current.click()}
                >
                  <FaPaperclip size={18}/>
                </button>
                <span className="text-muted">
                  {form.file?.name || 'No file chosen'}
                </span>
              </div>
              <button className="btn btn-primary w-100">Submit</button>
            </form>
          </div>
        </div>

        {/* Previous Tickets */}
        <div className="col-md-6">
          <div className="card p-4 shadow-sm rounded">
            <h4 className="mb-4">Previous Tickets</h4>
            {isLoading ? (
              <p>Loading…</p>
            ) : error ? (
              <p className="text-danger">Failed to load tickets.</p>
            ) : (
              <table className="table">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Priority</th>
                    <th>Created</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {tickets.map(t=>{
                    const badge = statusBadge[t.status]||'badge bg-secondary';
                    return (
                      <tr key={t.ticket_id}>
                        <td>
                          <span
                            style={{ cursor:'pointer', color: modal?.ticket_id===t.ticket_id ? 'darkblue':'inherit' }}
                            onClick={()=>openModal(t)}
                          >
                            {t.title}
                          </span>
                        </td>
                        <td>{t.priority.charAt(0).toUpperCase()+t.priority.slice(1)}</td>
                        <td>{new Date(t.created_at).toLocaleDateString()}</td>
                        <td><span className={badge}>
                          {statusOptions.find(s=>s.code===t.status)?.label}
                        </span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

      </div>

      {/* Modal */}
      {modal && (
        <>
          <div className="modal-backdrop show" onClick={closeModal}/>
          <div className="modal show d-block" tabIndex={-1}>
            <div className="modal-dialog modal-lg modal-dialog-centered">
              <div className="modal-content">

                <div className="modal-header">
                  <h5 className="modal-title fw-bold">
                    Ticket #{modal.ticket_id}: {modal.title}
                  </h5>
                  <button className="btn-close" onClick={closeModal}/>
                </div>

                <div className="modal-body">

                  <div className="d-flex flex-wrap mb-3" style={{ borderTop:'1px dashed #dee2e6', paddingTop:'1rem' }}>
                    <div className="me-4 mb-2">
                      <strong className="me-2">Status:</strong>
                      <select
                        className="form-select form-select-sm"
                        value={modal.status}
                        onChange={e=>saveStatus(e.target.value)}
                      >
                        {statusOptions.map(o=>(
                          <option key={o.code} value={o.code}>{o.label}</option>
                        ))}
                      </select>
                    </div>
                    <div className="mb-2">
                      <strong className="me-2">Priority:</strong>
                      <select
                        className="form-select form-select-sm"
                        value={modal.priority}
                        onChange={e=>savePriority(e.target.value)}
                      >
                        {priorityOptions.map(o=>(
                          <option key={o.code} value={o.code}>{o.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <h6 className="fw-bold mb-2" style={{ borderTop:'1px dashed #dee2e6', paddingTop:'1rem' }}>
                    Comments
                  </h6>
                  {modal.messages.length ? (
                    <div
                      className="mb-4"
                      style={{
                        maxHeight:250,
                        overflowY:'auto',
                        padding:'1rem',
                        background:'#f8f9fa',
                        borderRadius:'.5rem'
                      }}
                    >
                      {modal.messages.map(m=>(
                        <div key={m.message_id} className="mb-3">
                          <div className="small text-muted mb-1">
                            <strong>User {m.sender_id}</strong> – {new Date(m.created_at).toLocaleString()}
                            {m.is_internal && <span className="badge bg-info ms-2">Internal</span>}
                          </div>
                          <div style={{
                            background:'#fff',
                            padding:'.75rem',
                            borderRadius:'.5rem',
                            border:'1px solid #dee2e6'
                          }}>
                            {m.message}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted mb-4">No comments yet.</p>
                  )}

                  <h6 className="fw-bold mb-2">Add Comment</h6>
                  <textarea
                    className="form-control mb-3"
                    rows="3"
                    placeholder="Type your comment here…"
                    value={newComment}
                    onChange={e=>setComment(e.target.value)}
                  />

                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <div>
                      <input type="file" ref={attachRef} className="d-none"
                             onChange={e=>setAttach(e.target.files[0])}/>
                      <button className="btn btn-outline-primary" onClick={()=>attachRef.current.click()}>
                        Attach file
                      </button>
                      {attachFile && <span className="ms-2 small">{attachFile.name}</span>}
                    </div>
                    <div className="form-check">
                      <input
                        type="checkbox"
                        id="internal"
                        className="form-check-input"
                        checked={isInternal}
                        onChange={()=>setInternal(v=>!v)}
                      />
                      <label htmlFor="internal" className="form-check-label">Internal</label>
                    </div>
                  </div>

                  <button
                    className="btn btn-primary"
                    disabled={!newComment.trim()}
                    onClick={addComment}
                  >
                    Add Comment
                  </button>
                </div>

                <div className="modal-footer" style={{ borderTop:'1px dashed #dee2e6' }}>
                  <button className="btn btn-primary px-4" onClick={closeModal}>Done</button>
                </div>

              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
