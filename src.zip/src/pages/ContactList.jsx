import React, { useState, useMemo, useRef, useEffect, memo, useCallback } from 'react';
import { FaInfoCircle } from 'react-icons/fa';
import { useDispatch, useSelector } from 'react-redux';
import {
  chatApi,
  useGetConversationsQuery,
  useGetMessagesQuery,
  useMarkConversationAsReadMutation,
  useManageContactsMutation,
  useUpdateConversationContactDetailsMutation,
  useGetContactsQuery
} from '../api/chatApi';
import { io } from 'socket.io-client';
import { setOnlineUsers, setUserPresence } from '../redux/chatSlice';
import { env } from '../config/env';
import {
  uploadApi,
  useGetS3UploadUrlMutation,
  useUploadFileToS3Mutation,
} from '../api/uploadApi';
import { setUser } from '../redux/authSlice';
import { getFallbackImage, handleImageError } from '../utils/fallbackImage';

// Import Chat Components
import { ChatSidebar } from '../components/Chat/ChatSidebar';
import { ChatHeader } from '../components/Chat/ChatHeader';
import { ChatMessages } from '../components/Chat/ChatMessages';
import { ChatInput } from '../components/Chat/ChatInput';
import { AttachmentModal } from '../components/Chat/AttachmentModal';
import { ContextMenu } from '../components/Chat/ContextMenu';
import { DeleteConfirmModal } from '../components/Chat/DeleteConfirmModal';
import { NewChatModal } from '../components/Chat/NewChatModal';


const getDisplayName = (contact) => {
  if (!contact) return 'Unknown User';
  if (contact.firstName && contact.lastName) return `${contact.firstName} ${contact.lastName}`;
  if (contact.firstName) return contact.firstName;
  if (contact.email) return contact.email.split('@')[0];
  return `User ${contact.contactId || contact.id || ''}`.trim();
};

const ContactListComponent = () => {
  const dispatch = useDispatch();
  const [tab, setTab] = useState('chats'); // Used by ChatSidebar
  const [selectedConversationId, setSelectedConversationId] = useState(null); // Used by multiple components
  const [messageInput, setMessageInput] = useState(''); // Used by ChatInput
  const listRef = useRef(null); // For ChatSidebar scrolling, can be managed internally by ChatSidebar or passed
  const messagesEndRef = useRef(null); // For ChatMessages auto-scroll
  const currentQuerySubscriptions = useRef({});

  const [showContextMenu, setShowContextMenu] = useState(false); // For ContextMenu
  const [contextMenuPosition, setContextMenuPosition] = useState({ x: 0, y: 0 }); // For ContextMenu
  const [selectedMessageForAction, setSelectedMessageForAction] = useState(null); // For ContextMenu & DeleteConfirmModal
  const [selectedMessageForReply, setSelectedMessageForReply] = useState(null); // For ChatInput

  const [fileToUpload, setFileToUpload] = useState(null); // Used by ChatInput
  const [filePreviewUrl, setFilePreviewUrl] = useState(null); // Used by ChatInput
  const [downloadedAttachmentUrls, setDownloadedAttachmentUrls] = useState({}); // Used by ChatMessages
  const [attachmentLoadingStatus, setAttachmentLoadingStatus] = useState({}); // Used by ChatMessages

  const [fullScreenAttachment, setFullScreenAttachment] = useState(null); // For AttachmentModal
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false); // For DeleteConfirmModal

  const [showNewChatModal, setShowNewChatModal] = useState(false); // For NewChatModal

  const [showEditContactModal, setShowEditContactModal] = useState(false); // Stays in ContactList
  const [editingContactDetails, setEditingContactDetails] = useState({ contactId: null, firstName: '', lastName: '' }); // Stays in ContactList

  const [errorMessage, setErrorMessage] = useState('');
  const [infoMessage, setInfoMessage] = useState('Initializing...');

  const [getS3UploadUrl] = useGetS3UploadUrlMutation();
  const [uploadFileToS3] = useUploadFileToS3Mutation();
  const [manageContacts] = useManageContactsMutation();
  const [markConversationAsRead] = useMarkConversationAsReadMutation();
  const [updateConversationContactDetails, { isLoading: isUpdatingContactDetails }] = useUpdateConversationContactDetailsMutation();

  const primary = '#7B5FFF';
  const bg = '#F6F7FB';

  const authUser = useSelector(state => state.auth.user);

  const currentUserPublicId = authUser?.id;
  const currentUserContactId = authUser?.contactId;
  const currentUserType = authUser?.type;
  const currentUserEmail = authUser?.email;
  const currentUserFirstName = authUser?.first_name;
  const currentUserLastName = authUser?.last_name;
  const currentUserPhoneNumber = authUser?.phone_number;


  const userPresence = useSelector(state => state.chat?.userPresence || {});

  const selectedConversationIdRef = useRef(selectedConversationId);
  useEffect(() => {
    selectedConversationIdRef.current = selectedConversationId;
  }, [selectedConversationId]);

  const {
    data: rawConversationsData,
    refetch: refetchConversations
  } = useGetConversationsQuery(
    { userContactId: currentUserContactId },
    { skip: !currentUserContactId || isNaN(currentUserContactId) }
  );

  const {
    data: rawMessagesDataFromAPI,
    isLoading: isLoadingMessages,
  } = useGetMessagesQuery(
    { conversationId: selectedConversationId },
    { skip: !selectedConversationId || !currentUserContactId || isNaN(selectedConversationId) }
  );

  const { data: contactsData, isLoading: isLoadingContacts } = useGetContactsQuery({
    userContactId: currentUserContactId,
  },
    { skip: tab !== 'contacts' || !currentUserContactId || isNaN(currentUserContactId) }
  );

  const conversations = useMemo(() => {
    if (!Array.isArray(rawConversationsData) || rawConversationsData.length === 0 || !currentUserContactId) {
      return [];
    }
    return rawConversationsData.map(item => {
      if (!item || item.status_code !== 200 || !item.conversation) {
        console.warn("Skipping invalid item in rawConversationsData:", item);
        return null;
      }
      const convo = item.conversation;
      if (!convo.otherUser) {
        console.warn("Conversation item missing otherUser details:", convo);
        return null;
      }
      const name = getDisplayName(convo.otherUser);

      return {
        // Shape expected by ChatSidebar (or adapt ChatSidebar)
        id: convo.conversationId, // ChatSidebar might expect 'id'
        conversationId: convo.conversationId,
        name: name,
        avatarUrl: convo.otherUser.profile || getFallbackImage(name),
        lastMessage: convo.lastMessage || 'No messages yet',
        time: convo.lastMessageAt
          ? new Date(convo.lastMessageAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          : '',
        unread: convo.unreadCount || 0,
        // Additional data needed by ContactList
        lastMessageId: convo.lastMessageId,
        currentUserContactId: convo.currentUserContactId,
        otherUserContactId: convo.otherUserContactId,
        otherUser: convo.otherUser,
        otherUserStatus: userPresence[convo.otherUserContactId]?.status || 'offline',
        otherUserLastSeenAt: userPresence[convo.otherUserContactId]?.lastSeenAt,
      };
    }).filter(Boolean);
  }, [rawConversationsData, currentUserContactId, userPresence, primary]);


  const selectedConversation = useMemo(() => {
    return conversations.find(c => String(c.conversationId) === String(selectedConversationId));
  }, [conversations, selectedConversationId]);

  const messages = useMemo(() => {
    let itemsToProcess = [];
    if (!rawMessagesDataFromAPI) {
      itemsToProcess = [];
    } else if (Array.isArray(rawMessagesDataFromAPI)) {
      itemsToProcess = rawMessagesDataFromAPI;
    } else if (typeof rawMessagesDataFromAPI === 'object' && rawMessagesDataFromAPI !== null) {
      if (rawMessagesDataFromAPI.status_code === 404 || rawMessagesDataFromAPI.status_code === 500) {
        itemsToProcess = [];
      } else if (rawMessagesDataFromAPI.status_code === 200 && Array.isArray(rawMessagesDataFromAPI.message_data)) {
        itemsToProcess = rawMessagesDataFromAPI.message_data;
      } else {
        itemsToProcess = [];
      }
    } else {
      itemsToProcess = [];
    }

    const validMessages = itemsToProcess.filter(item => item && item.message_data);

    if (validMessages.length === 0) {
      return [];
    }
    // Map to shape expected by ChatMessages component
    // ChatMessages expects: { id, senderId, message, createdAt, attachmentUrl, attachmentType, isDeleted, status, replyToMessageId (optional) }
    return [...validMessages].map(item => ({
      ...item.message_data, // Spread the core message data
      senderId: item.message_data.senderContactId, // Map senderContactId to senderId
      // Ensure all fields ChatMessages might need are present, e.g. status
    })).sort((a, b) => {
      const dateA = new Date(a?.createdAt || 0);
      const dateB = new Date(b?.createdAt || 0);
      return dateA.getTime() - dateB.getTime();
    });
  }, [rawMessagesDataFromAPI]);


  const socketRef = useRef(null);

  useEffect(() => {
    if (!currentUserPublicId || !currentUserType || !currentUserEmail) {
      setInfoMessage("User details missing. Cannot initialize chat.");
      if (socketRef.current && socketRef.current.connected) {
        socketRef.current.disconnect();
      }
      socketRef.current = null;
      return;
    }

    if (!socketRef.current) {
      socketRef.current = io(env.API_URL, { withCredentials: true });
      setInfoMessage("Connecting to chat service...");
    }
    const socket = socketRef.current;
    const handleConnect = () => {
      setInfoMessage("Chat service connected. Joining session...");
      const payload = {
        publicUserId: currentUserPublicId, userType: currentUserType, contactId: currentUserContactId,
        email: currentUserEmail, firstName: currentUserFirstName, lastName: currentUserLastName, phoneNumber: currentUserPhoneNumber
      };
      socket.emit('join', payload);
    };
    const handleJoinSuccess = (data) => {
      if (data.contactId && data.userType) {
        const updatedUser = { ...authUser, contactId: data.contactId };
        dispatch(setUser({ user: updatedUser, permissions: authUser?.permissions || [] }));
        setInfoMessage("Chat session active."); setErrorMessage("");
      } else {
        setErrorMessage("Failed to initialize chat: Critical IDs missing from server."); setInfoMessage("");
      }
    };
    const handleJoinError = (error) => { setErrorMessage(`Socket join failed: ${error.message}`); setInfoMessage("Chat initialization failed."); };
    const handleDisconnect = (reason) => { setInfoMessage(`Chat service disconnected. Reason: ${reason}`); };

    if (socket.connected && authUser.contactId) { setInfoMessage("Chat session active."); }
    else if (socket.connected && !authUser.contactId) { handleConnect(); }
    else if (!socket.connected) { socket.once('connect', handleConnect); socket.connect(); }

    socket.on('join_success', handleJoinSuccess);
    socket.on('join_error', handleJoinError);
    socket.on('disconnect', handleDisconnect);
    return () => {
      if (socketRef.current) {
        socketRef.current.off('connect', handleConnect);
        socketRef.current.off('join_success', handleJoinSuccess);
        socketRef.current.off('join_error', handleJoinError);
        socketRef.current.off('disconnect', handleDisconnect);
        // Consider disconnecting socket if component unmounts fully
        // socketRef.current.disconnect();
        // socketRef.current = null;
      }
    };
  }, [currentUserPublicId, currentUserType, currentUserEmail, currentUserContactId, currentUserFirstName, currentUserLastName, currentUserPhoneNumber, dispatch, authUser]);

  useEffect(() => {
    if (!socketRef.current || !socketRef.current.connected || !currentUserContactId) {
      return;
    }
    const socket = socketRef.current;

    const handleRealtimeMessage = (socketReceivedMessageContent) => {
      if (!socketReceivedMessageContent || !socketReceivedMessageContent.conversationId || !currentUserContactId || !currentUserType) return;
      const wrappedMessageForCache = {
        user_type: socketReceivedMessageContent.userType || currentUserType || "guest",
        status_code: 200,
        message_data: socketReceivedMessageContent
      };
      const currentSelectedConvoId = selectedConversationIdRef.current;
      const isSender = String(wrappedMessageForCache.message_data.senderContactId) === String(currentUserContactId);

      dispatch(chatApi.util.updateQueryData('getConversations', { userContactId: currentUserContactId }, (draft) => {
        const draftConversations = draft || [];
        const convoIndex = draftConversations.findIndex(
          cData => String(cData.conversation?.conversationId) === String(wrappedMessageForCache.message_data.conversationId)
        );
        if (convoIndex > -1) {
          const convoToUpdate = draftConversations[convoIndex].conversation;
          if (convoToUpdate) {
            convoToUpdate.lastMessage = wrappedMessageForCache.message_data.message || (wrappedMessageForCache.message_data.attachmentType ? `[${wrappedMessageForCache.message_data.attachmentType.split('/')[0].toUpperCase()} File]` : 'Attachment');
            convoToUpdate.lastMessageAt = wrappedMessageForCache.message_data.createdAt;
            convoToUpdate.lastMessageId = wrappedMessageForCache.message_data.id;
            if (!isSender && String(wrappedMessageForCache.message_data.conversationId) !== String(currentSelectedConvoId)) {
              convoToUpdate.unreadCount = (convoToUpdate.unreadCount || 0) + 1;
            } else if (!isSender && String(wrappedMessageForCache.message_data.conversationId) === String(currentSelectedConvoId)) {
              convoToUpdate.unreadCount = 0;
              socketRef.current?.emit('messages_seen_in_conversation', {
                conversationId: wrappedMessageForCache.message_data.conversationId,
                contactId: currentUserContactId,
                userType: currentUserType
              });
            }
          }
        } else { refetchConversations(); }
      }));

      dispatch(chatApi.util.updateQueryData('getMessages', { conversationId: wrappedMessageForCache.message_data.conversationId }, (draft) => {
        const draftMessages = draft || [];
        let existingMsgIndex = -1;
        if (wrappedMessageForCache.message_data.tempId) {
          existingMsgIndex = draftMessages.findIndex(m => String(m.message_data?.tempId) === String(wrappedMessageForCache.message_data.tempId));
        }

        if (existingMsgIndex > -1) {
          draftMessages[existingMsgIndex].message_data = wrappedMessageForCache.message_data;
          draftMessages[existingMsgIndex].user_type = wrappedMessageForCache.user_type;
          draftMessages[existingMsgIndex].status_code = wrappedMessageForCache.status_code;
        } else if (!draftMessages.some(m => String(m.message_data?.id) === String(wrappedMessageForCache.message_data.id))) {
          draftMessages.push(wrappedMessageForCache);
        }
        draftMessages.sort((a, b) => new Date(a.message_data?.createdAt || 0).getTime() - new Date(b.message_data?.createdAt || 0).getTime());
      }));
    };

    const handleMessageStatusUpdate = (updatedMessageContentOrArray) => {
      const messagesToProcess = Array.isArray(updatedMessageContentOrArray) ? updatedMessageContentOrArray : [updatedMessageContentOrArray];
      if (messagesToProcess.length === 0 || !messagesToProcess[0]?.conversationId || !currentUserContactId || !currentUserType) return;
      const conversationId = messagesToProcess[0].conversationId;

      dispatch(chatApi.util.updateQueryData('getMessages', { conversationId }, (draft) => {
        const draftMessages = draft || [];
        messagesToProcess.forEach(updatedMsgContent => {
          const index = draftMessages.findIndex(m => String(m.message_data?.id) === String(updatedMsgContent.id));
          if (index > -1) {
            Object.assign(draftMessages[index].message_data, updatedMsgContent);
          }
        });
      }));
    };

    const handleMessageDeleted = (deletedMessageInfo) => {
      if (!currentUserContactId || !currentUserType || !deletedMessageInfo?.conversationId || !deletedMessageInfo?.messageId) return;
      dispatch(chatApi.util.updateQueryData('getMessages', { conversationId: deletedMessageInfo.conversationId }, (draft) => {
        const draftMessages = draft || [];
        const index = draftMessages.findIndex(m => String(m.message_data?.id) === String(deletedMessageInfo.messageId));
        if (index > -1) {
          draftMessages[index].message_data.isDeleted = true;
          draftMessages[index].message_data.message = deletedMessageInfo.message || 'This message was deleted.';
        }
      }));
    };

    const handleUserPresenceUpdate = (p) => dispatch(setUserPresence(p));
    const handleCurrentOnlineUsers = (ul) => { dispatch(setOnlineUsers(ul.map(u => u.contactId))); ul.forEach(p => dispatch(setUserPresence(p))); };

    socket.on('receive_message', handleRealtimeMessage);
    socket.on('message_sent', handleRealtimeMessage);
    socket.on('message_status_update', handleMessageStatusUpdate);
    socket.on('message_updated', handleMessageStatusUpdate);
    socket.on('message_deleted', handleMessageDeleted);
    socket.on('user_presence_update', handleUserPresenceUpdate);
    socket.on('current_online_users', handleCurrentOnlineUsers);
    socket.on('error_sending_message', (e) => { console.error('ContactList.jsx: Socket error_sending_message:', e); setErrorMessage(`Socket error: ${e.message || 'Unknown error'}`); });

    return () => {
      if (socketRef.current) {
        socketRef.current.off('receive_message', handleRealtimeMessage);
        socketRef.current.off('message_sent', handleRealtimeMessage);
        socketRef.current.off('message_status_update', handleMessageStatusUpdate);
        socketRef.current.off('message_updated', handleMessageStatusUpdate);
        socketRef.current.off('message_deleted', handleMessageDeleted);
        socketRef.current.off('user_presence_update', handleUserPresenceUpdate);
        socketRef.current.off('current_online_users', handleCurrentOnlineUsers);
        socketRef.current.off('error_sending_message');
      }
    };
  }, [currentUserContactId, currentUserType, dispatch, refetchConversations, selectedConversationIdRef]);

  useEffect(() => {
    // This effect is for downloading S3 attachments
    // It iterates over the 'messages' array, which contains items like { message_data: { attachmentUrl: ... } }
    // The 'messages' variable here is the one mapped for ChatMessages component
    if (messages && messages.length > 0) {
      messages.forEach(messageContent => { // messageContent is the flat message object for ChatMessages
        if (messageContent && messageContent.attachmentUrl && !downloadedAttachmentUrls[messageContent.attachmentUrl] && !currentQuerySubscriptions.current[messageContent.attachmentUrl] && attachmentLoadingStatus[messageContent.attachmentUrl] !== 'error') {
          setAttachmentLoadingStatus(prev => ({ ...prev, [messageContent.attachmentUrl]: 'loading' }));
          const queryThunk = uploadApi.endpoints.getS3DownloadUrl.initiate(messageContent.attachmentUrl);
          const queryPromise = dispatch(queryThunk);
          currentQuerySubscriptions.current[messageContent.attachmentUrl] = queryPromise.unsubscribe;
          queryPromise.then((result) => {
            let fetchedUrl = null;
            if (result.data) { if (result.data.data?.url) fetchedUrl = result.data.data.url; else if (typeof result.data === 'string') fetchedUrl = result.data; }
            if (fetchedUrl) {
              setDownloadedAttachmentUrls(prev => ({ ...prev, [messageContent.attachmentUrl]: fetchedUrl })); setAttachmentLoadingStatus(prev => ({ ...prev, [messageContent.attachmentUrl]: 'success' }));
            } else { setAttachmentLoadingStatus(prev => ({ ...prev, [messageContent.attachmentUrl]: 'error' })); }
          }).catch(() => setAttachmentLoadingStatus(prev => ({ ...prev, [messageContent.attachmentUrl]: 'error' })));
        }
      });
    }
    return () => { Object.values(currentQuerySubscriptions.current).forEach(unsub => unsub()); currentQuerySubscriptions.current = {}; };
  }, [messages, downloadedAttachmentUrls, dispatch, attachmentLoadingStatus]);


  const handleSelectConversation = useCallback((conversation) => { // conversation here is the one from `conversations` array (UI shape)
    if (conversation?.conversationId && currentUserContactId && currentUserType) {
      setSelectedConversationId(conversation.conversationId); setTab('chats'); setSelectedMessageForReply(null); setShowContextMenu(false);
      if (conversation.unread > 0) {
        markConversationAsRead({ contactId: currentUserContactId, conversationId: conversation.conversationId, lastReadMessageId: conversation.lastMessageId || null });
      }
      if (socketRef.current?.connected) {
        socketRef.current.emit('messages_seen_in_conversation', { conversationId: conversation.conversationId, contactId: currentUserContactId, userType: currentUserType });
      }
    } else { setSelectedConversationId(null); }
  }, [currentUserContactId, currentUserType, markConversationAsRead]);

  const [isSendingSocketMessage, setIsSendingSocketMessage] = useState(false);

  const handleSendMessage = useCallback(async (e) => {
    if (e) e.preventDefault(); // ChatInput might not pass 'e' if called directly
    if (!selectedConversation || !currentUserContactId || !currentUserType || !socketRef.current?.connected) {
      setErrorMessage('Cannot send: User/Convo not ready or not connected.'); return;
    }
    if (isSendingSocketMessage || (!messageInput.trim() && !fileToUpload)) {
      if (!messageInput.trim() && !fileToUpload) setErrorMessage('Type a message or select a file.'); return;
    }
    setIsSendingSocketMessage(true); setErrorMessage('');
    const receiverContactId = selectedConversation.otherUserContactId;
    let attachmentUrl = null, attachmentType = null;
    if (fileToUpload) {
      try {
        const uploadKey = `chat_attachments/convo_${selectedConversation.conversationId}/user_${currentUserContactId}/${Date.now()}_${fileToUpload.name}`;
        const s3Response = await getS3UploadUrl({ key: uploadKey, fileType: fileToUpload.type, fileName: fileToUpload.name }).unwrap();
        await uploadFileToS3({ url: s3Response.data.url, file: fileToUpload }).unwrap();
        attachmentUrl = s3Response.data.key; attachmentType = fileToUpload.type;
      } catch (err) { setErrorMessage(`Upload error: ${err.data?.error || err.message}`); setIsSendingSocketMessage(false); return; }
    }

    const tempId = `temp-${Date.now()}`;
    const optimisticMessageContent = {
      id: tempId,
      conversationId: selectedConversation.conversationId,
      senderContactId: currentUserContactId,
      message: messageInput,
      createdAt: new Date().toISOString(),
      status: 'sending',
      isEdited: false,
      isDeleted: false,
      attachmentUrl,
      attachmentType,
      replyToMessageId: selectedMessageForReply?.id || null,
      tempId: tempId
    };
    const optimisticMessageForCache = { user_type: currentUserType || "guest", status_code: 200, message_data: optimisticMessageContent };

    dispatch(chatApi.util.updateQueryData('getMessages', { conversationId: selectedConversation.conversationId }, (d) => {
      const draftMessages = d || []; draftMessages.push(optimisticMessageForCache);
      draftMessages.sort((a, b) => new Date(a.message_data?.createdAt || 0).getTime() - new Date(b.message_data?.createdAt || 0).getTime());
    }));
    dispatch(chatApi.util.updateQueryData('getConversations', { userContactId: currentUserContactId }, (d) => {
      const draftConversations = d || [];
      const i = draftConversations.findIndex(cData => String(cData.conversation?.conversationId) === String(selectedConversation.conversationId));
      if (i > -1 && draftConversations[i].conversation) {
        draftConversations[i].conversation.lastMessage = messageInput || (attachmentType ? `[${attachmentType.split('/')[0].toUpperCase()} File]` : 'Attachment');
        draftConversations[i].conversation.lastMessageAt = optimisticMessageContent.createdAt;
      }
    }));

    setMessageInput(''); setFileToUpload(null); setFilePreviewUrl(null); setSelectedMessageForReply(null);

    const messagePayloadForSocket = { ...optimisticMessageContent, receiverContactId: receiverContactId, userType: currentUserType, };
    delete messagePayloadForSocket.id;

    socketRef.current.emit('send_message', messagePayloadForSocket, (ack) => {
      setIsSendingSocketMessage(false);
      if (ack?.error) {
        setErrorMessage(`Send fail: ${ack.error}`);
        dispatch(chatApi.util.updateQueryData('getMessages', { conversationId: selectedConversation.conversationId }, (d) => {
          const draft = d || []; const idx = draft.findIndex(m => m.message_data?.tempId === tempId);
          if (idx > -1) draft[idx].message_data.status = 'failed';
        }));
      }
    });
  }, [messageInput, fileToUpload, selectedConversation, currentUserContactId, currentUserType, selectedMessageForReply, dispatch, getS3UploadUrl, uploadFileToS3, isSendingSocketMessage]);


  const confirmDeleteMessage = useCallback(() => {
    if (!selectedMessageForAction || !socketRef.current || !currentUserContactId || !currentUserType) return;
    socketRef.current.emit('delete_message', { messageId: selectedMessageForAction.id, conversationId: selectedMessageForAction.conversationId, senderContactId: currentUserContactId, userType: currentUserType }, (ack) => {
      if (ack?.success) {
        setSelectedMessageForAction(null); setShowContextMenu(false);
      } else { setErrorMessage(`Delete fail: ${ack?.error}`); }
      setShowDeleteConfirm(false);
    });
  }, [selectedMessageForAction, currentUserContactId, currentUserType]);

  // messageContent is the flat message_data from the `messages` array (already mapped for ChatMessages)
  const handleMessageClickForContextMenu = useCallback((e, messageContent) => {
    e.preventDefault(); e.stopPropagation();
    let senderName = 'User';
    if (selectedConversation && currentUserContactId) {
      if (String(messageContent.senderId) === String(currentUserContactId)) senderName = "You"; // Use senderId
      else if (selectedConversation.otherUser && String(messageContent.senderId) === String(selectedConversation.otherUser.contactId)) senderName = getDisplayName(selectedConversation.otherUser);
    }
    setContextMenuPosition({ x: e.clientX, y: e.clientY });
    setSelectedMessageForAction({ ...messageContent, senderName });
    setShowContextMenu(true);
  }, [selectedConversation, currentUserContactId]);

  const handleDeleteMessageFromContextMenu = useCallback(() => { if (!selectedMessageForAction) return; setShowDeleteConfirm(true); setShowContextMenu(false); }, [selectedMessageForAction]);
  const handleReplyToMessageFromContextMenu = useCallback(() => { if (!selectedMessageForAction) return; setSelectedMessageForReply(selectedMessageForAction); setMessageInput(`Replying to ${selectedMessageForAction.senderName || 'User'}... `); setShowContextMenu(false); }, [selectedMessageForAction]);
  const handleClearReply = useCallback(() => { setSelectedMessageForReply(null); setMessageInput(''); }, []);
  const handleFileChangeForInput = useCallback((e) => { const f = e.target.files?.[0]; if (f) { setFileToUpload(f); setFilePreviewUrl(URL.createObjectURL(f)); e.target.value = null; } }, []);
  const handleRemoveFileForInput = useCallback(() => { setFileToUpload(null); setFilePreviewUrl(null); }, []);
  const scrollToMessage = useCallback((id) => { const el = document.getElementById(`message-${id}`); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, []);
  useEffect(() => { if (messagesEndRef.current) messagesEndRef.current.scrollIntoView({ behavior: 'auto' }); }, [messages]); // messages is the mapped array
  const formatDateSeparator = (dStr) => { const d = new Date(dStr); const t = new Date(); const y = new Date(t); y.setDate(t.getDate() - 1); if (d.toDateString() === t.toDateString()) return 'Today'; if (d.toDateString() === y.toDateString()) return 'Yesterday'; return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }); };
  const formatLastSeen = useCallback((ts) => {
    if (!ts) return ''; const d = new Date(ts); const n = new Date(); const s = Math.floor((n.getTime() - d.getTime()) / 1000); if (s < 60) return 'just now'; if (s < 3600) return `${Math.floor(s / 60)} min ago`; if (s < 86400) return `${Math.floor(s / 3600)} hr ago`; const td = new Date(n.getFullYear(), n.getMonth(), n.getDate()); const yd = new Date(td); yd.setDate(td.getDate() - 1); if (d.toDateString() === td.toDateString()) return `today at ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`; if (d.toDateString() === yd.toDateString()) return `yesterday at ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`; return `${d.toLocaleDateString()} at ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  }, []);

  const handleNewChatCreated = () => {
    refetchConversations(); // Refetch conversations to include the new one
    setShowNewChatModal(false);
    setTab('chats'); // Switch to chats tab
  };


  const handleOpenEditContactModal = () => { if (selectedConversation?.otherUser) { setEditingContactDetails({ contactId: selectedConversation.otherUser.contactId, firstName: selectedConversation.otherUser.firstName || '', lastName: selectedConversation.otherUser.lastName || '' }); setShowEditContactModal(true); } };
  const handleSaveContactDetails = async () => {
    if (!selectedConversationId || !editingContactDetails.contactId || !currentUserType || !currentUserContactId) return;
    try {
      await updateConversationContactDetails({
        conversationId: selectedConversationId, firstName: editingContactDetails.firstName, lastName: editingContactDetails.lastName, updatedByContactId: currentUserContactId, updatingForContactId: editingContactDetails.contactId,
      }).unwrap();
      setShowEditContactModal(false); refetchConversations();
    } catch (err) { console.error("Err updating contact:", err); setErrorMessage(err.data?.error || err.message || "Update failed."); }
  };

  // Mapped contacts for ChatSidebar
  const mappedContactsForSidebar = useMemo(() => {
    // 1. initial check:
    if (isLoadingContacts || !contactsData || contactsData.length === 0) {
      return [];
    }

    // 2. Iterate over the contactsData array
    const mappedData = contactsData.map(conversation => {
      let otherUserDetails;

      // Ensure conversation and its nested details exist before accessing them
      if (conversation && conversation.user1Details && conversation.user1Details.contactId === currentUserContactId) {
        otherUserDetails = conversation.user2Details;
      } else if (conversation && conversation.user2Details && conversation.user2Details.contactId === currentUserContactId) {
        otherUserDetails = conversation.user1Details;
      } else {
        console.warn("Logged in user (" + currentUserContactId + ") not found in this conversation, or conversation structure is unexpected:", conversation);
        return null; // Skip this conversation if the other user can't be determined
      }

      if (!otherUserDetails) {
        console.warn("Could not determine other user details for conversation:", conversation);
        return null; // Skip if otherUserDetails ended up null/undefined
      }

      const displayName = getDisplayName(otherUserDetails);
      // Ensure conversation object exists before accessing relationship
      const relationship = conversation ? (conversation.relationship || 'N/A') : 'N/A';

      return {
        id: otherUserDetails.contactId,
        name: displayName,
        avatarUrl: otherUserDetails.profile || getFallbackImage(displayName),
        description: relationship,
        originalConversationData: conversation,
        otherUser: otherUserDetails
      };
    }).filter(Boolean); // Filter out any null entries from the map (e.g., if a user couldn't be determined)
    return mappedData;

    // 3. Updated dependency array:
    //    Include all external variables that the memoized function depends on.
  }, [contactsData, isLoadingContacts, currentUserContactId]);

  //  handle select contact from sidebar
  const handleSelectContactFromSidebar = useCallback(async (selectedContact) => {
    // selectedContact is an item from mappedContactsForSidebar
    // Ensure all required current user details and selected contact details are present
    if (!currentUserType || !currentUserPublicId || !currentUserContactId || !selectedContact || !selectedContact.otherUser) {
      setErrorMessage("Your session details are incomplete or contact data is missing.");
      return;
    }

    const otherUserInfo = selectedContact.otherUser; // Details of the other user in the conversation

    try {
      // Call manageContacts with the details of the OTHER user from the selected sidebar item
      // create a new conversation with the OTHER user's details
      const result = await manageContacts({
        email: otherUserInfo.email,
        firstName: otherUserInfo.firstName,
        lastName: otherUserInfo.lastName,
        // phone_number: otherUserInfo.phoneNumber ? ((typeof otherUserInfo.phoneNumber === 'string' || otherUserInfo.phoneNumber === null) ? otherUserInfo.phoneNumber : JSON.stringify(otherUserInfo.phoneNumber)) : null,
      }).unwrap();

      if (result.data?.conversationId) {
        const conversationFromResult = result.data;

        // Determine participant details from the manageContacts response
        const isUser1Current = String(conversationFromResult.user1ContactId) === String(currentUserContactId);
        const finalOtherUserDetails = isUser1Current ? conversationFromResult.user2Details : conversationFromResult.user1Details;
        const finalOtherUserContactId = isUser1Current ? conversationFromResult.user2ContactId : conversationFromResult.user1ContactId;

        if (!finalOtherUserDetails || !finalOtherUserContactId) {
          setErrorMessage('Chat interaction initiated, but participant details are missing from the server response.');
          return;
        }

        const displayNameFromResult = getDisplayName(finalOtherUserDetails);
        const convoToSelect = {
          conversationId: conversationFromResult.conversationId,
          name: displayNameFromResult,
          avatarUrl: finalOtherUserDetails.profile || getFallbackImage(displayNameFromResult),
          lastMessage: conversationFromResult.lastMessage,
          lastMessageAt: conversationFromResult.lastMessageAt,
          unread: conversationFromResult.unreadCount !== undefined ? conversationFromResult.unreadCount : 0,
          lastMessageId: conversationFromResult.lastMessageId,
          currentUserContactId: currentUserContactId,
          otherUserContactId: finalOtherUserContactId,
          otherUser: finalOtherUserDetails,
          id: conversationFromResult.conversationId
        };

        handleSelectConversation(convoToSelect);
        setTab('chats');
      } else {
        setErrorMessage(result.message || result.error || 'Could not start or find chat via manageContacts.');
      }
    } catch (err) {
      const errorData = err.data || err; // Handle RTK Query error structure or standard error
      setErrorMessage(errorData?.error || errorData?.message || err.message || 'Failed to initiate chat.');
    }
  }, [currentUserType, currentUserPublicId, currentUserContactId, manageContacts, handleSelectConversation, setTab, setErrorMessage]);

  if (!currentUserPublicId || !currentUserType || !currentUserEmail) {
    return <div style={{ padding: 20, textAlign: 'center', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}><p>{infoMessage || "Authenticating user..."}</p><small>Please ensure you are logged in and user details (ID, Type, Email) are available.</small></div>;
  }
  if (!currentUserContactId) {
    return <div style={{ padding: 20, textAlign: 'center', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}><p>{infoMessage || "Initializing chat session..."}</p><small>(Waiting for Contact ID from server after join)</small>{errorMessage && <p style={{ color: 'black', marginTop: '10px' }}>{errorMessage}</p>}</div>;
  }

  return (
    <div style={{ 
      fontFamily: 'Outfit, sans-serif', 
      display: 'flex', 
      height: 'calc(100vh - 110px)', 
      background: bg, 
      overflow: 'hidden',
      position: 'relative',
      // maxHeight: 'calc(100vh - 100px)',
      margin: '0 auto',
      padding: '0 auto',
      width: '100%',
      backgroundColor: 'white',
    }}>
      <br></br>
      <ChatSidebar
        tab={tab}
        setTab={setTab}
        conversations={conversations}
        contacts={mappedContactsForSidebar}
        selectedId={selectedConversationId}
        onSelectConversation={handleSelectConversation}
        onSelectContact={handleSelectContactFromSidebar}
        onNewChat={() => { setErrorMessage(''); setShowNewChatModal(true); }}
        userContactId={currentUserContactId}
        listRef={listRef}
        primaryColor={primary}
        handleImageError={handleImageError}
      />

      <section style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        background: bg,
        height: '100%',
        overflow: 'hidden'
      }} onClick={() => setShowContextMenu(false)}>
        {selectedConversation && currentUserContactId ? (
          <>
            <ChatHeader
              user={{ name: selectedConversation.name, avatarUrl: selectedConversation.avatarUrl }}
              statusText={selectedConversation.otherUserStatus === 'online' ? 'Online' : formatLastSeen(selectedConversation.otherUserLastSeenAt)}
              statusColor={selectedConversation.otherUserStatus === 'online' ? '#28a745' : '#9E9E9E'}
              onInfoClick={() => { setErrorMessage(''); handleOpenEditContactModal(); }}
              handleImageError={handleImageError}
            />
            <div style={{
              flex: 1,
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column'
            }}>
              <ChatMessages
                messages={messages}
                currentUserId={currentUserContactId}
                downloadedUrls={downloadedAttachmentUrls}
                attachmentStatus={attachmentLoadingStatus}
                onContextMenu={handleMessageClickForContextMenu}
                onImageClick={(url, type) => setFullScreenAttachment({ url, type: type || 'image/' })}
                formatDateSeparator={formatDateSeparator}
                scrollToMessage={scrollToMessage}
                messagesEndRef={messagesEndRef}
                selectedConversationName={selectedConversation.name}
                primaryColor={primary}
                isLoading={isLoadingMessages && messages.length === 0}
                handleImageError={handleImageError}
              />
            </div>
            <ChatInput
              message={messageInput}
              setMessage={setMessageInput}
              file={fileToUpload}
              previewUrl={filePreviewUrl}
              onFileChange={handleFileChangeForInput}
              onRemoveFile={handleRemoveFileForInput}
              onSend={handleSendMessage}
              disabled={isSendingSocketMessage || !selectedConversation}
              replyingTo={selectedMessageForReply}
              onClearReply={handleClearReply}
              primaryColor={primary}
            />
          </>
        ) : (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', color: '#7f7f7f', textAlign: 'center', padding: 20 }}>
            <FaInfoCircle size={48} style={{ marginBottom: 16 }} />
            <div style={{ fontWeight: 500, fontSize: '1.2em' }}> Select a chat to start messaging. </div>
            <p>Or, click the "+" icon to start a new chat, or go to the 'Contacts' tab.</p>
          </div>
        )}
      </section>

      {showContextMenu && selectedMessageForAction && (
        <ContextMenu
          x={contextMenuPosition.x}
          y={contextMenuPosition.y}
          visible={showContextMenu}
          onReply={handleReplyToMessageFromContextMenu}
          // Conditionally show delete if it's the current user's message
          onDelete={String(selectedMessageForAction.senderId) === String(currentUserContactId) && !selectedMessageForAction.isDeleted ? handleDeleteMessageFromContextMenu : null}
          onClose={() => setShowContextMenu(false)} // Added for completeness
        />
      )}

      {fullScreenAttachment && (
        <AttachmentModal
          file={{ type: fullScreenAttachment.type, name: "Attachment" }} // AttachmentModal might expect a 'file' object
          url={fullScreenAttachment.url}
          onClose={() => setFullScreenAttachment(null)}
        />
      )}

      {showDeleteConfirm && (
        <DeleteConfirmModal
          show={showDeleteConfirm}
          onConfirm={confirmDeleteMessage}
          onCancel={() => setShowDeleteConfirm(false)}
        />
      )}

      {showNewChatModal && (
        <NewChatModal
          show={showNewChatModal}
          onClose={() => { setShowNewChatModal(false); setErrorMessage(''); }}
          // NewChatModal uses its own manageContactMutation hook.
          // If it needs to signal success to parent to select chat:
          onSuccess={handleNewChatCreated} // You'd need NewChatModal to call this
          currentUserId={currentUserContactId} // Pass if NewChatModal needs it for its logic
          primaryColor={primary} // Pass for styling if needed
        />
      )}

      {/* Edit Contact Modal remains directly in ContactList.jsx as no separate component was provided for it */}
      {showEditContactModal && selectedConversation && editingContactDetails && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.6)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 10000 }} onClick={() => setShowEditContactModal(false)}>
          <div style={{ background: 'white', padding: 30, borderRadius: 12, boxShadow: '0 5px 15px rgba(0,0,0,0.3)', textAlign: 'left', maxWidth: 400, width: '90%' }} onClick={(e) => e.stopPropagation()}>
            <h2 style={{ marginBottom: 20, color: primary, textAlign: 'center' }}>Edit Contact Info for {getDisplayName(selectedConversation.otherUser)}</h2>
            <p style={{ fontSize: '0.9em', color: '#666', marginBottom: 15, textAlign: 'center' }}>This name is how they appear to you in this conversation.</p>
            <label htmlFor="editFirstName" style={{ display: 'block', marginBottom: 5, fontWeight: 500 }}>First Name</label>
            <input id="editFirstName" type="text" value={editingContactDetails.firstName} onChange={(e) => setEditingContactDetails(prev => ({ ...prev, firstName: e.target.value }))} style={{ width: '100%', padding: '10px 15px', marginBottom: 15, borderRadius: 8, border: '1px solid #E0E0E0', outline: 'none', boxSizing: 'border-box' }} />
            <label htmlFor="editLastName" style={{ display: 'block', marginBottom: 5, fontWeight: 500 }}>Last Name</label>
            <input id="editLastName" type="text" value={editingContactDetails.lastName} onChange={(e) => setEditingContactDetails(prev => ({ ...prev, lastName: e.target.value }))} style={{ width: '100%', padding: '10px 15px', marginBottom: 20, borderRadius: 8, border: '1px solid #E0E0E0', outline: 'none', boxSizing: 'border-box' }} />
            {errorMessage && <p style={{ color: 'red', textAlign: 'center', marginBottom: 10 }}>{errorMessage}</p>}
            <div style={{ display: 'flex', justifyContent: 'space-around', gap: 15 }}>
              <button onClick={handleSaveContactDetails} disabled={isUpdatingContactDetails} style={{ padding: '10px 20px', borderRadius: 8, border: 'none', background: primary, color: 'white', cursor: 'pointer', fontSize: '1em', flex: 1 }}>{isUpdatingContactDetails ? "Saving..." : "Save Changes"}</button>
              <button onClick={() => setShowEditContactModal(false)} style={{ padding: '10px 20px', borderRadius: 8, border: '1px solid #ccc', background: 'white', color: '#303030', cursor: 'pointer', fontSize: '1em', flex: 1 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {errorMessage && !showNewChatModal && !showEditContactModal && !showDeleteConfirm && (
        <div style={{ position: 'fixed', bottom: 20, left: '50%', transform: 'translateX(-50%)', background: 'rgba(255,0,0,0.8)', color: 'white', padding: '10px 20px', borderRadius: 8, zIndex: 10001, boxShadow: '0 2px 5px rgba(0,0,0,0.3)' }}>
          {errorMessage}
          <button onClick={() => setErrorMessage('')} style={{ background: 'none', border: 'none', color: 'white', marginLeft: 15, fontWeight: 'bold', cursor: 'pointer' }}>X</button>
        </div>
      )}
    </div>
  );
};

export const ContactList = memo(ContactListComponent);
