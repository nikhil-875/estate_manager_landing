import React from 'react';

export const Units = () => {
  return (
    <div className="row">


      {/* User Table */}
      <div className="col-sm-12">
        <div className="card">
          <div className="card-header">
            <h5>Unit List</h5>
          </div>
          <div className="card-body">
            <div className="table-responsive theme-scrollbar">
              <table className="table light-card">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Rent Type</th>
                    <th>Rent</th>
                    <th>Rent Duration</th>
                    <th>Property</th>
                    <th>Action</th>

                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="table-user">
                      Unit
                    </td>
                    <td>monthly</td>
                    <td>$890</td>
                    <td>12</td>
                    <td>Arlogenix Properties</td>
                    <td>
                      <ul className="action d-flex gap-2">
                        <a href="#" className="text-warning">
                          <i className="icon-eye"></i>
                        </a>
                        <a href="#" className="text-success">
                          <i className="icon-pencil-alt"></i>
                        </a>
                        <a href="#" className="text-danger">
                          <i className="icon-trash"></i>
                        </a>
                        <a href="#" className="text-info">
                          <i className="icon-shift-right"></i>
                        </a>
                      </ul>
                    </td>
                  </tr>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

