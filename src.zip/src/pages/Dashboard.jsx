import { useSelector } from "react-redux";
import { SuperAdminDashboard } from "./SuperAdminDashboard";
import { OwnerDashboard } from "./OwnerDashboard";
import { ManagerDashboard } from "./ManagerDashboard";
import { MaintainerDashboard } from "./MaintainerDashboard";
import { TenantDashboard } from "./TenantDashboard";
import { GuestDashboard } from "./GuestDashboard";

export const Dashboard = () => {
  const role = useSelector((state) => state.auth.user?.type);

  switch (role) {
    case "super admin":
      return <SuperAdminDashboard />;
    case "owner":
      return <OwnerDashboard />;
    case "manager":
      return <ManagerDashboard />;
    case "maintainer":
      return <MaintainerDashboard />;
    case "tenant":
      return <TenantDashboard />;
    default:
      return <GuestDashboard />;
  }
};

