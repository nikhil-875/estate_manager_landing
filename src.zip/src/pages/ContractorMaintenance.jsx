// src/components/maintenance/ContractorMaintenance.jsx

import React, {
  useState,
  useMemo,
  useRef,
  useEffect,
  useCallback,
} from 'react';
import {
  Tab,
  Nav,
  Row,
  Col,
  Badge,
  Card,
  Spinner,
  Alert,
} from 'react-bootstrap';
import { FaStar, FaStarHalfAlt, FaRegStar } from 'react-icons/fa';

import ContractorJobList from '../components/maintenance/ContractorJobList';
import ContractorJobDetails from '../components/maintenance/ContractorJobDetails';
import ContractorQuotation from '../components/maintenance/ContractorQuotation';
import ContractorComment from '../components/maintenance/ContractorComment';

import { useFetchNearbyRequestsQuery } from '../api/maintenance';

/* ----------------------------------------------------------------------------
   Fallback data (used when the server returns no rows)
---------------------------------------------------------------------------- */
const FALLBACK_JOBS = [
  {
    id: 1,
    title: 'Demo Job Title',
    property: '456 Cedar St, Unit A-101',
    description: 'Just a demo job description...',
    applied: false,
    address: 'Demo Address',
    serviceOffer: 'Demo Service',
    reportedAt: '2024-01-01T00:00:00Z',
    amount: 0,
    quotesaved: false,
    quotationId: null,
    service: [],
  },
];

const FALLBACK_MY_JOBS = [
  {
    id: 101,
    title: 'Demo My Job',
    property: '456 Cedar St, Unit 2A',
    status: 'Assigned',
    dueDate: '2024-08-15',
    priority: 'High',
    rating: 4.5,
    description: 'Just a demo job description...',
  },
];

const FALLBACK_INVITES = [
  {
    id: 301,
    title: 'Demo Job Invitation',
    property: '222 Elm St',
    description: 'Just a demo job description.',
  },
];

export default function ContractorMaintenance() {
  const {
    data: rawAllRows,
    isLoading: allLoading,
    error: allError,
    refetch: refetchAllJobs,
  } = useFetchNearbyRequestsQuery({
    action: 'all_job',
  });

  const {
    data: rawMyRows,
    isLoading: myLoading,
    error: myError,
    refetch: refetchMyJobs,
  } = useFetchNearbyRequestsQuery({
    action: 'my_jobs',
  });

  const {
    data: rawInviteRows,
    isLoading: invLoading,
    error: invError,
    refetch: refetchInvites,
  } = useFetchNearbyRequestsQuery({
    action: 'invite',
  });

  // Make sure we're properly handling when the API returns an error object
  const allRows = Array.isArray(rawAllRows) ? rawAllRows : [];
  const myRows = Array.isArray(rawMyRows) ? rawMyRows : [];
  const inviteRows = Array.isArray(rawInviteRows) ? rawInviteRows : [];

  // ─────────────────────────────────────────────────────────────────────────
  // NORMALIZED LISTS
  // ─────────────────────────────────────────────────────────────────────────
  const ALL_JOBS = useMemo(() => {
    if (allRows.length === 0) {
      return FALLBACK_JOBS;
    }

    const seen = new Set();
    return allRows.reduce((acc, r) => {
      if (seen.has(r.request_id)) return acc;
      seen.add(r.request_id);

      const distanceKm = Math.round(r.distance_meters / 1000);
      acc.push({
        id: r.request_id,
        title: r.title,
        property: `${r.city} ~${distanceKm} km nearby`,
        description: r.description ?? 'No description',
        propertyName: r.property_name,
        reportedAt: r.reported_at,
        applied: Boolean(r.applied),
        quotesaved: Boolean(r.quotesaved),
        address: r.address,
        amount: r.amount ?? 0,
        quotationId: r.quotation_id ?? null,
        service: Array.isArray(r.service) ? r.service : [],
      });
      return acc;
    }, []);
  }, [allRows]);

  const MY_JOBS = useMemo(() => {
    if (myRows.length === 0) {
      return FALLBACK_MY_JOBS;
    }
    return myRows.map((r) => ({
      id: r.job_id,
      title: r.title,
      property: r.property_name,
      status: r.job_status_name,
      dueDate: r.due_date,
      priority: r.priority_id,
      rating: r.rating,
      description: r.description,
    }));
  }, [myRows]);

  const INVITES = useMemo(() => {
    if (inviteRows.length === 0) {
      return FALLBACK_INVITES;
    }
    return inviteRows.map((r) => ({
      id: r.request_id,
      title: r.title,
      property: r.property_name,
      description: `Invited on ${new Date(
        r.invitation_details.invited_at
      ).toLocaleDateString()}`,
    }));
  }, [inviteRows]);

  // ─────────────────────────────────────────────────────────────────────────
  // UI STATE
  // ─────────────────────────────────────────────────────────────────────────
  const [activeTab, setActiveTab] = useState('allJobs');
  const [selectedJob, setSelectedJob] = useState(null);

  const [allSearch, setAllSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all'); // 'all' | 'apply' | 'applied'
  const [mySearch, setMySearch] = useState('');
  const [invSearch, setInvSearch] = useState('');

  const [quotations, setQuotations] = useState({});
  const [comments, setComments] = useState({});

  const [newComment, setNewComment] = useState('');
  const [fileAttachment, setFileAttachment] = useState(null);
  const fileInputRef = useRef(null);

  const [amounts, setAmounts] = useState({});
  const [showModal, setShowModal] = useState(false);

  // ─────────────────────────────────────────────────────────────────────────
  // HANDLERS
  // ─────────────────────────────────────────────────────────────────────────
  const handleSelectJob = useCallback((job) => {
    setSelectedJob(job);
  }, []);

  const handleAmountChange = useCallback((amt, jobId) => {
    setAmounts((prev) => ({ ...prev, [jobId]: amt }));
  }, []);

  const handleSaveQuotation = useCallback(
    (quotationPayload, jobId) => {
      setQuotations((prev) => ({ ...prev, [jobId]: quotationPayload }));
      refetchAllJobs();
      refetchMyJobs();
      refetchInvites();
    },
    [refetchAllJobs, refetchMyJobs, refetchInvites]
  );

  const handleAttachClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFileAttachment(e.target.files[0]);
    }
  };

  const handleAddComment = (e) => {
    e.preventDefault();
    if (!newComment.trim() && !fileAttachment) return;

    setComments((prev) => ({
      ...prev,
      [selectedJob.id]: [
        ...(prev[selectedJob.id] || []),
        { text: newComment.trim(), file: fileAttachment },
      ],
    }));
    setNewComment('');
    setFileAttachment(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // ─────────────────────────────────────────────────────────────────────────
  // KEEP selectedJob IN SYNC WITH CURRENT TAB'S LIST
  // ─────────────────────────────────────────────────────────────────────────
  useEffect(() => {
    let currentList = [];
    if (activeTab === 'allJobs') {
      currentList = ALL_JOBS;
    } else if (activeTab === 'myJobs') {
      currentList = MY_JOBS;
    } else {
      currentList = INVITES;
    }

    if (
      currentList.length > 0 &&
      (!selectedJob || !currentList.some((j) => j.id === selectedJob.id))
    ) {
      setSelectedJob(currentList[0]);
    }
  }, [activeTab, ALL_JOBS, MY_JOBS, INVITES, selectedJob]);

  // ─────────────────────────────────────────────────────────────────────────
  // FILTERED LISTS FOR LEFT PANE
  // ─────────────────────────────────────────────────────────────────────────
  const filteredAll = useMemo(() => {
    return ALL_JOBS.filter((j) => {
      const s = allSearch.toLowerCase();
      const matchesSearch =
        j.title.toLowerCase().includes(s) ||
        j.property.toLowerCase().includes(s);
      if (!matchesSearch) return false;

      // Now filter by "applied" status using j.applied instead of local state
      if (statusFilter === 'apply') {
        return !j.applied;
      }
      if (statusFilter === 'applied') {
        return j.applied;
      }
      return true; // statusFilter === 'all'
    });
  }, [ALL_JOBS, allSearch, statusFilter]);

  const filteredMy = useMemo(() => {
    const s = mySearch.toLowerCase();
    return MY_JOBS.filter(
      (j) =>
        j.title.toLowerCase().includes(s) ||
        j.property.toLowerCase().includes(s)
    );
  }, [MY_JOBS, mySearch]);

  const filteredInv = useMemo(() => {
    const s = invSearch.toLowerCase();
    return INVITES.filter(
      (j) =>
        j.title.toLowerCase().includes(s) ||
        j.property.toLowerCase().includes(s)
    );
  }, [INVITES, invSearch]);

  // ─────────────────────────────────────────────────────────────────────────
  // DETAIL OBJECT FOR "All Jobs" TAB
  // ─────────────────────────────────────────────────────────────────────────
  const detailJob = useMemo(() => {
    if (activeTab !== 'allJobs' || !selectedJob) {
      return null;
    }
    const propertyText = selectedJob.propertyName
      ? `${selectedJob.propertyName} | ${new Date(
          selectedJob.reportedAt
        ).toLocaleDateString()}`
      : selectedJob.property;

    const servicesArray = Array.isArray(selectedJob.service)
      ? selectedJob.service
      : [];
    const serviceOffer =
      servicesArray.length > 1
        ? `${servicesArray[0].name} & Others`
        : servicesArray[0]?.name ?? '';

    return {
      ...selectedJob,
      property: propertyText,
      serviceOffer,
    };
  }, [activeTab, selectedJob]);

  // ─────────────────────────────────────────────────────────────────────────
  // HELPER: Render star icons
  // ─────────────────────────────────────────────────────────────────────────
  const renderStars = (rating) =>
    [...Array(5)].map((_, i) =>
      rating >= i + 1 ? (
        <FaStar key={i} />
      ) : rating + 0.5 >= i + 1 ? (
        <FaStarHalfAlt key={i} />
      ) : (
        <FaRegStar key={i} />
      )
    );

  // ─────────────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div
      className="container mt-4"
      style={{ background: '#fff', padding: '1rem' }}
    >
      <h2 className="mb-4">Contractor Dashboard</h2>

      {allLoading && (
        <div className="d-flex align-items-center mb-3">
          <Spinner animation="border" size="sm" className="me-2" />
          Loading nearby requests…
        </div>
      )}
      {allError && (
        <Alert variant="danger" className="mb-3">
          Unable to fetch All Jobs.
        </Alert>
      )}

      <Tab.Container
        activeKey={activeTab}
        onSelect={(k) => setActiveTab(k)}
      >
        <Row>
          {/* ─────────────────── LEFT PANE: LISTS ─────────────────── */}
          <Col md={4}>
            <Nav variant="pills" className="mb-3">
              <Nav.Item>
                <Nav.Link eventKey="allJobs" className="rounded-pill">
                  <Badge bg="secondary" pill className="me-1">
                    {filteredAll.length}
                  </Badge>
                  All Jobs
                </Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="myJobs" className="rounded-pill">
                  <Badge bg="secondary" pill className="me-1">
                    {filteredMy.length}
                  </Badge>
                  My Jobs
                </Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="invites" className="rounded-pill">
                  <Badge bg="secondary" pill className="me-1">
                    {filteredInv.length}
                  </Badge>
                  Invites
                </Nav.Link>
              </Nav.Item>
            </Nav>

            <Tab.Content>
              <Tab.Pane eventKey="allJobs">
                <ContractorJobList
                  placeholder="Search all jobs…"
                  searchValue={allSearch}
                  onSearch={setAllSearch}
                  showStatus
                  statusValue={statusFilter}
                  onStatus={setStatusFilter}
                  items={filteredAll}
                  selectedId={selectedJob?.id}
                  onSelect={handleSelectJob}
                  highlightBg="#E6E6FA"
                  getBadge={(job) => ({
                    text: job.applied ? 'Applied' : 'Apply',
                    variant: job.applied ? 'success' : 'primary',
                  })}
                />
              </Tab.Pane>

              <Tab.Pane eventKey="myJobs">
                {myLoading && (
                  <Spinner animation="border" size="sm" className="mb-2" />
                )}
                {myError && (
                  <Alert variant="danger">Unable to fetch My Jobs.</Alert>
                )}
                <ContractorJobList
                  placeholder="Search my jobs…"
                  searchValue={mySearch}
                  onSearch={setMySearch}
                  items={filteredMy}
                  selectedId={selectedJob?.id}
                  onSelect={handleSelectJob}
                  highlightBg="#E6E6FA"
                  getBadge={(job) => ({
                    text: job.priority,
                    variant:
                      job.priority === 'High' ? 'danger' : 'warning',
                  })}
                />
              </Tab.Pane>

              <Tab.Pane eventKey="invites">
                {invLoading && (
                  <Spinner animation="border" size="sm" className="mb-2" />
                )}
                {invError && (
                  <Alert variant="danger">Unable to fetch Invites.</Alert>
                )}
                <ContractorJobList
                  placeholder="Search invites…"
                  searchValue={invSearch}
                  onSearch={setInvSearch}
                  items={filteredInv}
                  selectedId={selectedJob?.id}
                  onSelect={handleSelectJob}
                  highlightBg="#E6E6FA"
                  getBadge={() => null}
                />
              </Tab.Pane>
            </Tab.Content>
          </Col>

          {/* ─────────────────── RIGHT PANE: DETAILS ─────────────────── */}
          <Col md={8}>
            <Tab.Content>
              {/* ─────── All Jobs: ContractorJobDetails + ContractorQuotation ─────── */}
              <Tab.Pane eventKey="allJobs">
                {detailJob && (
                  <React.Fragment key={detailJob.id}>
                    <ContractorJobDetails
                      job={detailJob}
                      showModal={showModal}
                      onHide={() => setShowModal(false)}
                      comments={comments[detailJob.id]}
                      requestId={detailJob.id}
                      quoteAmount={detailJob.amount}
                      quotationId={quotations[detailJob.id]?.quotationId}
                      requestStatus={detailJob.applied ? 'Applied' : 'New'}
                      newComment={newComment}
                      setNewComment={setNewComment}
                      fileAttachment={fileAttachment}
                      fileInputRef={fileInputRef}
                      onAttachClick={handleAttachClick}
                      onFileChange={handleFileChange}
                      onAddComment={handleAddComment}
                      onCreateInvoice={(data) =>
                        console.log('Creating invoice', data)
                      }
                      invoiceAmount={amounts[detailJob.id] ?? 0}
                    />

                    <ContractorQuotation
                      requestId={detailJob.id}
                      propertyId={detailJob.id}
                      propertyName={detailJob.propertyName}
                      address={detailJob.address}
                      requestStatus={
                        detailJob.applied ? 'Applied' : 'New'
                      }
                      quotesaved={
                        detailJob.quotesaved ? 'Saved' : 'New'
                      }
                      quotationId={
                        quotations[detailJob.id]?.quotationId ?? null
                      }
                      requestTitle={detailJob.title}
                      requestDescription={detailJob.description}
                      requestDate={detailJob.reportedAt}
                      serviceOffer={detailJob.serviceOffer}
                      tasks={[
                        {
                          id: detailJob.id,
                          description: detailJob.title,
                          qty: 1,
                        },
                      ]}
                      onSave={(tpl) =>
                        handleSaveQuotation(tpl, detailJob.id)
                      }
                      onEmail={() =>
                        alert(
                          `Sending quotation for "${detailJob.title}"`
                        )
                      }
                      onAmountChange={(amt) =>
                        handleAmountChange(amt, detailJob.id)
                      }
                    />
                  </React.Fragment>
                )}
              </Tab.Pane>

              {/* ─────── My Jobs: summary card + ContractorComment ─────── */}
              <Tab.Pane eventKey="myJobs">
                {selectedJob && (
                  <React.Fragment key={selectedJob.id}>
                    <Card className="mb-3">
                      <Card.Header className="d-flex justify-content-between">
                        <strong>{selectedJob.title}</strong>
                        <div>{renderStars(selectedJob.rating)}</div>
                      </Card.Header>
                      <Card.Body>
                        <p>
                          <strong>Property:</strong>{' '}
                          {selectedJob.property}
                        </p>
                        <p>
                          <strong>Status:</strong>{' '}
                          {selectedJob.status}
                        </p>
                        <p>
                          <strong>Due Date:</strong>{' '}
                          {selectedJob.dueDate}
                        </p>
                        <p>{selectedJob.description}</p>
                      </Card.Body>
                    </Card>

                    <ContractorComment
                      comments={comments[selectedJob.id]}
                      newComment={newComment}
                      setNewComment={setNewComment}
                      fileAttachment={fileAttachment}
                      onAttachClick={handleAttachClick}
                      onFileChange={handleFileChange}
                      onAddComment={handleAddComment}
                      fileInputRef={fileInputRef}
                    />
                  </React.Fragment>
                )}
              </Tab.Pane>

              {/* ─────── Invites: only ContractorJobDetails ─────── */}
              <Tab.Pane eventKey="invites">
                {selectedJob && (
                  <ContractorJobDetails
                    key={`invite-${selectedJob.id}`}
                    job={selectedJob}
                    showModal={showModal}
                    onHide={() => setShowModal(false)}
                    comments={comments[selectedJob.id]}
                    requestId={selectedJob.id}
                    quoteAmount={selectedJob.amount}
                    quotationId={
                      quotations[selectedJob.id]?.quotationId
                    }
                    newComment={newComment}
                    setNewComment={setNewComment}
                    fileAttachment={fileAttachment}
                    fileInputRef={fileInputRef}
                    onAttachClick={handleAttachClick}
                    onFileChange={handleFileChange}
                    onAddComment={handleAddComment}
                    onCreateInvoice={(data) =>
                      console.log('Creating invoice', data)
                    }
                    invoiceAmount={amounts[selectedJob.id] ?? 0}
                  />
                )}
              </Tab.Pane>
            </Tab.Content>
          </Col>
        </Row>
      </Tab.Container>
    </div>
  );
}
