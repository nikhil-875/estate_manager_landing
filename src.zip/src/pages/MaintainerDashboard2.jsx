import React from 'react';
import { Link } from 'react-router-dom';

export const MaintainerDashboard2 = ({ result, maintainer }) => {
  const cards = [
    { title: 'Total Property', count: maintainer.properties.length },
    { title: 'Total Request', count: result.totalRequest },
    { title: 'Today Request', count: result.todayRequest },
    { title: 'Total Contact', count: result.totalContact },
    { title: 'Total Notes', count: result.totalNote }
  ];

  return (
    <div className="row">
      <div className="col-md-12 project-list">
        <div className="card">
          <div className="row">
            <div className="col-md-6" />
            <div className="col-md-6 text-end">
              <div className="form-group mb-0 me-0" />
              <Link to="/maintainer/advance-dashboard" className="btn btn-primary">
                Advanced Dashboard
              </Link>
            </div>
          </div>
        </div>
      </div>

      {cards.map((card, index) => (
        <div className="col-xxl-3 col-sm-6 cdx-xxl-50" key={index}>
          <div className="card sale-revenue">
            <div className="card-header">
              <h4>{card.title}</h4>
            </div>
            <div className="card-body progressCounter">
              <h2><span className="count">{card.count}</span></h2>
            </div>
          </div>
        </div>
      ))}

      <div className="col-xxl-3 col-sm-6 cdx-xxl-50">
        <div className="card sale-revenue">
          <div className="card-header">
            <h4>Property</h4>
          </div>
          <div className="card-body progressCounter">
            <h5>
              {maintainer.properties.length > 0 ? (
                maintainer.properties.map((property, index) => (
                  <div key={index}>{property.name}<br /></div>
                ))
              ) : (
                <span>No Properties Found</span>
              )}
            </h5>
          </div>
        </div>
      </div>
    </div>
  );
};

