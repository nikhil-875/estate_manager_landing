// src/pages/CompanyDetails.jsx
import React, { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';

import { TransactionTable } from '../components/CompanyDetails/TransactionTabModal';
import { SupportTab } from '../components/CompanyDetails/SupportTabModal';
import { DocumentTab } from '../components/CompanyDetails/DocumentTabModal';

import {
  useGetSubscriptionQuery,
  useGetTransactionHistoryMutation,
  useQueryDocumentsMutation,
  useGetSupportTicketsMutation,
} from '../api/company';

import {
  useGetSubscriptionsQuery,
  useManageSubscriptionContractMutation,
} from '../api/subscription';

export const CompanyDetails = () => {
  const { companyId, userId } = useLocation().state || {};

  // ─── Auth & contract mutation ───────────────────────
  const loginUser = useSelector(state => state.auth.user);
  const subscribeBy = loginUser?.id;
  const [manageSubscriptionContract, { isLoading: isContracting }] =
    useManageSubscriptionContractMutation();

  // ─── Owner’s current subscription ────────────────────
  const { data: ownerSub } = useGetSubscriptionQuery(userId);
  const rawContracts = ownerSub?.results?.data?.results?.data ?? [];
  const currentPlan =
    rawContracts.find(p => p.is_active) ||
    rawContracts[0] || {
      title: 'Loading…',
      interval: 'monthly',
      contract_amount: 0,
      benefits: [],
    };

  // ─── Transactions (POST `/transactions/history`) ─────
  const [fetchHistory, { data: txResp = { data: [] }, isLoading: txLoading }] =
    useGetTransactionHistoryMutation();

  // fetch history once on mount, including user_id
  useEffect(() => {
    if (userId) {
      console.log({
        userId,
      });
      fetchHistory({ status: 'paid', company_user_id: userId });
    }
  }, [fetchHistory, userId]);

  const transactions = txResp.data || [];


  // ─── Documents & support (lazy fetch) ──────────────
  const [fetchDocuments] = useQueryDocumentsMutation();
  const [fetchTickets] = useGetSupportTicketsMutation();
  const [documentsData, setDocumentsData] = useState([]);
  const [supportData, setSupportData] = useState([]);
  const [activeTab, setActiveTab] = useState('transactions');

  const handleTab = async (tab) => {
    setActiveTab(tab);
    if (tab === 'documents' && !documentsData.length) {
      const res = await fetchDocuments({ company_user_id: userId, company_id: companyId });
      setDocumentsData(res?.data.documents || []);
    }
    if (tab === 'support' && !supportData.length) {
      const res = await fetchTickets({ company_user_id: userId });
      setSupportData(res?.data.tickets || []);
    }
  };

  // ─── All available plans ────────────────────────────
  const { data: allPlans = [] } = useGetSubscriptionsQuery();
  const plans = useMemo(() => {
    const seen = new Set();
    return allPlans.filter(p => {
      if (seen.has(p.title)) return false;
      seen.add(p.title);
      return true;
    });
  }, [allPlans]);

  // ─── Modal state ───────────────────────────────────
  const [showModal, setShowModal] = useState(false);
  const [selectedTitle, setSelectedTitle] = useState(currentPlan.title);

  useEffect(() => {
    setSelectedTitle(currentPlan.title);
  }, [currentPlan.title]);

  const selectedPlan = plans.find(p => p.title === selectedTitle) || {};

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Company Details</h2>

      <div className="row gx-4">
        {/* Profile Card */}
        <div className="col-md-4">
          <div className="card mb-4">
            <div className="card-header">Company Profile</div>
            <div className="card-body py-4 px-4" style={{ minHeight: 420 }}>
              <div className="d-flex align-items-center mb-4">
                <img
                  src={`https://i.pravatar.cc/100?img=${userId || 7}`}
                  className="rounded-circle me-4"
                  width="70"
                  height="70"
                  alt="Avatar"
                />
                <div>
                  <h5 className="mb-1">Owner</h5>
                  <span
                    role="button"
                    className="d-inline-block border rounded px-2 py-1 text-primary mb-2"
                    onClick={() => setShowModal(true)}
                  >
                    {currentPlan.title}
                  </span>
                  <p className="mb-0">
                    <strong>
                      ${(currentPlan.contract_amount ?? currentPlan.package_amount ?? 0).toFixed(2)}
                    </strong> / {currentPlan.interval}
                  </p>
                </div>
              </div>
              <p className="mb-2"><strong>Email:</strong> owner@gmail.com</p>
              <ul className="list-unstyled mb-4">
                {(
                  Array.isArray(currentPlan.benefits)
                    ? currentPlan.benefits
                    : Object.entries(currentPlan.benefits || {}).map(([k, v]) => ({
                        benefit_id: k,
                        benefit_label: k,
                        link_label: v,
                      }))
                ).map(b => (
                  <li key={b.benefit_id} className="mb-1">
                    • {b.benefit_label}: {b.link_label}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="col-md-8">
          <div className="card mb-4">
            <div className="card-header p-0">
              <ul className="nav nav-tabs px-3">
                {['transactions', 'support', 'documents'].map(t => (
                  <li className="nav-item" key={t}>
                    <button
                      className={`nav-link ${activeTab === t ? 'active' : ''}`}
                      onClick={() => handleTab(t)}
                    >
                      {t.charAt(0).toUpperCase() + t.slice(1)}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div className="card-body py-4 px-4" style={{ minHeight: 420 }}>
              {activeTab === 'transactions' && (
                <TransactionTable data={transactions} loading={txLoading} />
              )}
              {activeTab === 'support' && <SupportTab data={supportData} />}
              {activeTab === 'documents' && (
                <DocumentTab
                  data={documentsData}
                  companyUserId={userId}
                  companyId={companyId}
                  fetchDocuments={fetchDocuments}
                  setDocumentsData={setDocumentsData}
                />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Subscription Modal */}
      {showModal && (
        <>
          <div className="modal-backdrop fade show" />
          <div className="modal fade show d-block" tabIndex={-1}>
            <div className="modal-dialog modal-lg modal-dialog-centered">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Choose Subscription</h5>
                  <button className="btn-close" onClick={() => setShowModal(false)} />
                </div>
                <div className="modal-body" style={{ minHeight: 400 }}>
                  <div className="mb-3">
                    <select
                      className="form-select"
                      value={selectedTitle}
                      onChange={e => setSelectedTitle(e.target.value)}
                    >
                      {plans.map(p => (
                        <option key={p.subscription_id} value={p.title}>
                          {p.title}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="card">
                    <div className="card-body">
                      <h5 className="card-title">{selectedPlan.title}</h5>
                      <p className="mb-3">
                        <strong>${(selectedPlan.package_amount || 0).toFixed(2)}</strong> / {selectedPlan.interval}
                      </p>
                      <ul className="list-unstyled mb-0">
                        {(selectedPlan.benefits || []).map(b => (
                          <li key={b.benefit_id} className="mb-1">
                            ✔ {b.benefit_label}: {b.link_label}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button
                    className="btn btn-primary"
                    disabled={isContracting || !selectedPlan.subscription_id}
                    onClick={async () => {
                      try {
                        await manageSubscriptionContract({
                          action: 'insert',
                          user_id: userId,
                          subscription_id: selectedPlan.subscription_id,
                          subscribe_by: subscribeBy,
                        }).unwrap();
                        setShowModal(false);
                      } catch (err) {
                        console.error('Failed to change subscription:', err);
                      }
                    }}
                  >
                    {isContracting ? 'Updating…' : 'Change Subscription'}
                  </button>
                  <button className="btn btn-secondary" onClick={() => setShowModal(false)}>
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
