// src/pages/InvoicePage.jsx

import React from 'react';

/* --------------------------- SAMPLE DATA --------------------------- */
const invoices = [
  { number: 'INV-001', property: 'Sunset Gardens / A-101', period: 'Mar 2025', amount: '$1,200', status: 'paid' },
  { number: 'INV-002', property: 'Greenwood Apartments / B-204', period: 'Apr 2025', amount: '$950', status: 'pending' },
  { number: 'INV-003', property: 'Maple Residences / C-302', period: 'Apr 2025', amount: '$1,050', status: 'overdue' },
];

/* ----------------------------- HELPERS ----------------------------- */
const badgeClass = s =>
  `badge rounded-pill ${s === 'paid' ? 'badge-success' : s === 'pending' ? 'badge-warning' : 'badge-danger'}`;

/* --------------------------- COMPONENT ----------------------------- */
export const InvoicePage = () => {
  return (
    <div className="card shadow-sm border-0 mt-4">
      <div className="card-body">
        
        {/* ── TITLE & SEARCH BAR ─────────────────────────────────────── */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h4 className="mb-0">Invoices</h4>
          <div className="input-group input-group-sm" style={{ maxWidth: '250px' }}>
            <span className="input-group-text bg-white border-end-0">
              <i className="icofont icofont-search text-secondary" />
            </span>
            <input
              type="search"
              className="form-control border-start-0"
              placeholder="Search invoices..."
            />
          </div>
        </div>

        {/* ── INVOICE TABLE ─────────────────────────────────────────── */}
        <div className="table-responsive theme-scrollbar">
          <table className="display dataTable table table-striped align-middle mb-0">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Property</th>
                <th>Period</th>
                <th className="text-end">Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv, i) => (
                <tr key={i}>
                  <td>{inv.number}</td>
                  <td>{inv.property}</td>
                  <td>{inv.period}</td>
                  <td className="text-end">{inv.amount}</td>
                  <td>
                    <span className={badgeClass(inv.status)}>{inv.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* ── PAGINATION (placeholder) ──────────────────────────────── */}
        <div className="d-flex justify-content-between align-items-center mt-3">
          <small className="text-muted">
            Showing 1 to {invoices.length} of {invoices.length} entries
          </small>
          <div>
            <button className="btn btn-sm btn-outline-secondary me-2" disabled>
              Previous
            </button>
            <button className="btn btn-sm btn-primary">1</button>
            <button className="btn btn-sm btn-outline-secondary ms-2">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};
