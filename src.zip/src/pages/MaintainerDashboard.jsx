import React from 'react';

export const MaintainerDashboard = ({ result={totalProperty:10,totalRequest:12,totalContact:14,totalNote:34} }) => {
  const assignments = [
    {
      id: '0542',
      teacher: 'Gary Payi',
      img: '../assets/images/dashboard-4/user/1.png',
      subject: 'Accounts',
      startDate: '12 May 2024',
      endDate: '20 May 2024',
      progress: 80,
      progressColor: 'primary',
    },
    {
      id: '9548',
      teacher: 'Ralph Waters',
      img: '../assets/images/dashboard-4/user/2.png',
      subject: 'UI/UX Design',
      startDate: '06 May 2024',
      endDate: '16 May 2024',
      progress: 60,
      progressColor: 'secondary',
    },
    {
      id: '2950',
      teacher: 'Edwin Day',
      img: '../assets/images/dashboard-4/user/3.png',
      subject: 'Mathematics',
      startDate: '25 Sep 2024',
      endDate: '30 May 2024',
      progress: 50,
      progressColor: 'warning',
    },
  ];

  return (
    <div className="row">
      {/* Stats Cards */}
      <div className="col-xl-6 col-md-12 proorder-md-1">
        <div className="row">
          {[
            {
              label: 'Total Property',
              value: result.totalProperty,
              img: 'assets/images/dashboard-4/icon/student.png',
              className: 'student',
            },
            {
              label: 'Total Request',
              value: result.totalRequest,
              img: 'assets/images/dashboard-4/icon/teacher.png',
              className: 'student-2',
            },
            {
              label: 'Total Contact',
              value: result.totalContact,
              img: 'assets/images/dashboard-4/icon/invoice.png',
              className: 'student-4',
            },
            {
              label: 'Total Note',
              value: result.totalNote,
              img: 'assets/images/dashboard-4/icon/calendar.png',
              className: 'student-3',
            },
          ].map((item, i) => (
            <div className="col-xl-6 col-sm-6" key={i}>
              <div className="card">
                <div className={`card-body ${item.className}`}>
                  <div className="d-flex gap-2 align-items-end">
                    <div className="flex-grow-1">
                      <h2>{item.value}</h2>
                      <p className="mb-0 text-truncate">{item.label}</p>
                    </div>
                    <div className="flex-shrink-0">
                      <img src={item.img} alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Schedule Section */}
      <div className="col-xxl-6 col-xl-6 box-col-6 proorder-md-9" >
        <div className="card" style={{minHeight:"280px"}}>
          <div className="card-header card-no-border pb-0">
            <div className="header-top d-flex justify-content-between">
              <h4>Schedule</h4>
              <div className="dropdown icon-dropdown">
                <button className="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
                  <i className="icon-more-alt"></i>
                </button>
                <div className="dropdown-menu dropdown-menu-end">
                  <a className="dropdown-item" href="#">Weekly</a>
                  <a className="dropdown-item" href="#">Monthly</a>
                  <a className="dropdown-item" href="#">Yearly</a>
                </div>
              </div>
            </div>
          </div>
          <div className="card-body schedult-calendar pt-0">
            <div className="schedule-container">
              <div id="schedulechart">{/* Integrate chart here */}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Assignments Table */}
      <div className="col-xl-12 col-md-12 proorder-md-4">
        <div className="card">
          <div className="card-header card-no-border pb-0">
            <div className="header-top d-flex justify-content-between">
              <h4>Assignments</h4>
              <div className="dropdown icon-dropdown">
                <button className="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
                  <i className="icon-more-alt"></i>
                </button>
                <div className="dropdown-menu dropdown-menu-end">
                  <a className="dropdown-item" href="#">Weekly</a>
                  <a className="dropdown-item" href="#">Monthly</a>
                  <a className="dropdown-item" href="#">Yearly</a>
                </div>
              </div>
            </div>
          </div>
          <div className="card-body pt-0 assignments-table px-0">
            <div className="table-responsive theme-scrollbar">
              <table className="table display" id="assignments-table" style={{ width: '100%' }}>
                <thead>
                  <tr>
                    <th><input type="checkbox" className="form-check-input" /></th>
                    <th>Id no</th>
                    <th>Teacher</th>
                    <th>Subject</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Progress</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {assignments.map((item, i) => (
                    <tr key={i}>
                      <td><input type="checkbox" className="form-check-input" /></td>
                      <td><span>{item.id}</span></td>
                      <td>
                        <div className="d-flex align-items-center">
                          <div className="flex-shrink-0">
                            <img src={item.img} alt="" />
                          </div>
                          <div className="flex-grow-1 ms-2">
                            <h6>{item.teacher}</h6>
                          </div>
                          <div className="active-status active-online"></div>
                        </div>
                      </td>
                      <td>{item.subject}</td>
                      <td>{item.startDate}</td>
                      <td>{item.endDate}</td>
                      <td>
                        <div className="progress-showcase">
                          <div className={`progress sm-progress-bar progress-border-${item.progressColor}`}>
                            <div className="progress-bar" role="progressbar" style={{ width: `${item.progress}%` }}></div>
                          </div>
                        </div>
                      </td>
                      <td className="text-center">
                        <div className="dropdown icon-dropdown">
                          <button className="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i className="icon-more-alt"></i>
                          </button>
                          <div className="dropdown-menu dropdown-menu-end">
                            <a className="dropdown-item" href="#">Weekly</a>
                            <a className="dropdown-item" href="#">Monthly</a>
                            <a className="dropdown-item" href="#">Yearly</a>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

