// src/pages/Transaction.jsx
import React from "react";
import { useSelector } from "react-redux";
import SuperAdminTransaction from "./SuperAdminTransaction";
import OwnerTransaction from "./OwnerTransaction";

export const Transaction = () => {
  const role = useSelector((state) => state.auth.user?.type);

  switch (role) {
    case "super admin":
      return <SuperAdminTransaction />;
    case "owner":
      return <OwnerTransaction />;
    default:
      return null; // or show a "Not authorized" message here
  }
};

export default Transaction;
