import React from 'react';

export const CouponHistoryList = ({ historyData = [], canDelete = false, onDelete }) => {
  const formatDate = (dateStr) => new Date(dateStr).toLocaleDateString();

  return (
    <div className="row">
      <div className="col-sm-12">
        <div className="card table-card">
          <div className="card-header">
            <div className="row align-items-center g-2">
              <div className="col">
                <h5>Coupon History List</h5>
              </div>
            </div>
          </div>

          <div className="card-body pt-0">
            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>Coupon</th>
                    <th>Package</th>
                    <th>User</th>
                    <th>Date</th>
                    {canDelete && <th className="text-right">Action</th>}
                  </tr>
                </thead>
                <tbody>
                  {historyData.length > 0 ? (
                    historyData.map((entry) => (
                      <tr key={entry.id}>
                        <td>{entry.coupon?.name || '-'}</td>
                        <td>{entry.package?.name || '-'}</td>
                        <td>{entry.user?.name || '-'}</td>
                        <td>{formatDate(entry.date)}</td>
                        {canDelete && (
                          <td className="text-right">
                            <button
                              className="btn btn-sm btn-link text-danger"
                              onClick={() => onDelete(entry.id)}
                              title="Delete"
                            >
                              <i className="ti ti-trash-2"></i>
                            </button>
                          </td>
                        )}
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={canDelete ? 5 : 4} className="text-center text-muted">
                        No coupon history available.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

