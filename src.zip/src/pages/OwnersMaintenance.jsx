// src/pages/OwnersMaintenance.jsx

import React, { useState, useMemo, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Modal, Button, Form, Alert } from 'react-bootstrap';
import {
  FaCommentDots, FaPaperclip, FaEye,
  FaRegUserCircle, FaTrashAlt
} from 'react-icons/fa';

import OwnerRequests     from '../components/maintenance/OwnerRequests';
import OwnerQuotations   from '../components/maintenance/OwnerQuotations';
import OwnerContractors  from '../components/maintenance/OwnerContractors';
import OwnerTask         from '../components/maintenance/OwnerTask';

import {
  useFetchRequestQuery,
  useManageRequestCommentMutation,
} from '../api/maintenance';
import { useGetOwnerDetailsQuery } from '../api/owner';

const STATUS_FILTERS = [
  { key: 'all',         label: 'All',         color: 'primary' },
  { key: 'open',        label: 'Open',        color: 'success' },
  { key: 'in progress', label: 'In Progress', color: 'warning text-white' },
  { key: 'closed',      label: 'Closed',      color: 'secondary' },
];

const DEMO_REQUEST = {
  request_id: 1,
  request_title: 'Demo: Leaking Sink',
  property_name: '456 Cedar St',
  unit_name: 'Unit A-101',
  tenant_name: 'John Doe',
  reported_at: '2024-04-13T10:00:00Z',
  request_status: 'Open',
  request_description: 'Demo row so list is never empty.',
  owner_id: 0,
  owner_first_name: 'Demo',
  owner_last_name: 'Owner',
  quotations: [],
  comments: [],
  attachments: [],
};

const timeAgo = dateStr => {
  const ms = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(ms / 60000);
  const hrs = Math.floor(mins / 60);
  const days = Math.floor(hrs / 24);
  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hrs % 24) parts.push(`${hrs % 24}h`);
  parts.push(`${mins % 60}m`);
  return parts.join(' ') + ' ago';
};

const fmtDate = d => {
  const dt = new Date(d);
  const mm = String(dt.getMonth() + 1).padStart(2, '0');
  const dd = String(dt.getDate()).padStart(2, '0');
  const yy = String(dt.getFullYear()).slice(-2);
  return `${mm}/${dd}/${yy}`;
};

export default function OwnersMaintenance() {
  // Redux user
  const user = useSelector(s => s.auth.user);
  const LOGGED_IN_USER_ID    = user?.id;
  const LOGGED_IN_USER_EMAIL = user?.email;

  // Owner dropdown state
  const { data: ownersList = [] } = useGetOwnerDetailsQuery();
  const [currentOwnerId, setCurrentOwnerId] = useState(LOGGED_IN_USER_ID);
  const [ownerOptions,   setOwnerOptions]   = useState([]);

  // Fetch maintenance requests, passing ownerId as param
  const {
    data: rawData = [],
    isLoading,
    isError,
    refetch
  } = useFetchRequestQuery(
    { ownerId: currentOwnerId },
    { skip: !currentOwnerId }
  );

  const [requests,       setRequests]      = useState([]);
  const [selectedId,     setSelectedId]    = useState(null);
  const [search,         setSearch]        = useState('');
  const [activeTab,      setActiveTab]     = useState('quotations');
  const [selectedStatus, setSelectedStatus] = useState('all');

  // Comment modal state
  const [showModal,  setShowModal]  = useState(false);
  const [commentTxt, setCommentTxt] = useState('');
  const [errorMsg,   setErrorMsg]   = useState('');
  const [saveComment, { isLoading: isSaving }] = useManageRequestCommentMutation();

  // Initialize owner dropdown
  useEffect(() => {
    if (LOGGED_IN_USER_ID && !currentOwnerId) {
      setCurrentOwnerId(LOGGED_IN_USER_ID);
    }
  }, [LOGGED_IN_USER_ID]);

  // Build ownerOptions list
  useEffect(() => {
    const opts = ownersList?.owners?.map(o => ({
      id:   o.id,
      name: o.company
    })) || [];

    if (!opts.some(o => o.id === LOGGED_IN_USER_ID) && LOGGED_IN_USER_ID) {
      opts.unshift({
        id:   LOGGED_IN_USER_ID,
        name: LOGGED_IN_USER_EMAIL || 'Current User'
      });
    }
    setOwnerOptions(opts);
  }, [ownersList, LOGGED_IN_USER_ID, LOGGED_IN_USER_EMAIL]);

  // Refetch when owner changes
  useEffect(() => {
    if (currentOwnerId) {
      refetch();
    }
  }, [currentOwnerId, refetch]);

  // Map API data to UI model
  useEffect(() => {
    if (isLoading) return;
    const rows = rawData.length
      ? rawData
      : [{ results: DEMO_REQUEST }];

    const mapped = rows.map(({ results }) => ({
      id:                results.request_id,
      title:             results.request_title,
      property:          results.property_name,
      unitName:          results.unit_name,
      date_reported:     results.reported_at,
      status:            (results.request_status || 'open').toLowerCase(),
      description:       results.request_description,
      quotations:        Array.isArray(results.quotations) ? results.quotations : [],
      comments:          (results.comments || []).map(c => ({
                           id: c.comment_id,
                           text: c.body,
                           created_at: c.created_at,
                           user: `${results.owner_first_name} ${results.owner_last_name}`
                         })),
      attachments:       Array.isArray(results.attachments) ? results.attachments : [],
      owner_id:          results.owner_id,
      owner_first_name:  results.owner_first_name,
      owner_last_name:   results.owner_last_name,
    }));

    setRequests(mapped);
    if (selectedId === null) {
      setSelectedId(mapped[0]?.id ?? null);
    }
  }, [rawData, isLoading, selectedId]);

  // Filter and search
  const statusOptions = useMemo(() => {
    const present = new Set(requests.map(r => r.status));
    return [
      STATUS_FILTERS.find(f => f.key === 'all'),
      ...STATUS_FILTERS.filter(f => f.key !== 'all' && present.has(f.key))
    ];
  }, [requests]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return requests
      .filter(r => selectedStatus === 'all' || r.status === selectedStatus)
      .filter(r =>
        !q ||
        [r.title, r.property, r.unitName, r.status]
          .some(f => (f ?? '').toLowerCase().includes(q))
      );
  }, [requests, search, selectedStatus]);

  // Keep selection valid
  useEffect(() => {
    if (!filtered.length) return;
    if (!filtered.some(r => r.id === selectedId)) {
      setSelectedId(filtered[0].id);
    }
  }, [filtered, selectedId]);

  const selected = useMemo(
    () => filtered.find(r => r.id === selectedId),
    [filtered, selectedId]
  );

  // Add comment locally (optimistic)
  const addCommentLocally = txt => {
    setRequests(rs =>
      rs.map(r =>
        r.id === selected.id
          ? {
              ...r,
              comments: [
                ...r.comments,
                { id: Date.now(), text: txt, created_at: new Date().toISOString(), user: 'Me' }
              ]
            }
          : r
      )
    );
  };

  // Save comment to server
  const handleSaveComment = async () => {
    if (!commentTxt.trim()) return;
    setErrorMsg('');
    try {
      await saveComment({
        action: 'add',
        request_id: selected.id,
        author_id: currentOwnerId,
        body: commentTxt.trim(),
        parent_comment_id: null,
      }).unwrap();
      addCommentLocally(commentTxt.trim());
      setCommentTxt('');
      setShowModal(false);
    } catch {
      setErrorMsg('Failed to save comment. Please try again.');
    }
  };

  if (isLoading) return <div>Loading requests…</div>;
  if (isError)   return <div className="text-danger">Error loading requests.</div>;

  const getBadgeColor = status =>
    STATUS_FILTERS.find(f => f.key === status)?.color ?? 'primary';

  // Helper for comment avatar
  function getUserColor(name) {
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return `hsl(${Math.abs(hash) % 360}, 70%, 80%)`;
  }

  return (
    <div className="container pb-5">
      {/* Header */}
      <div className="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <h2 className="mb-2 mb-md-0">Maintenance Requests</h2>
        <div className="d-flex align-items-center gap-3">
          <label className="small fw-semibold mb-0">Owner</label>
          <select
            className="form-select form-select-sm bg-white"
            style={{
              width: '250px',
              maxWidth: '100%',
              borderColor: '#ced4da',
              boxShadow: 'none'
            }}
            value={currentOwnerId}
            onChange={e => setCurrentOwnerId(e.target.value)}
            disabled={isLoading}
          >
            {ownerOptions.map(o => (
              <option key={o.id} value={o.id}>{o.name}</option>
            ))}
          </select>
          <button
            className="btn btn-sm"
            onClick={() => console.log('Delete owner', currentOwnerId)}
            title="Delete Owner"
            style={{ color: 'red', border: 'none', background: 'transparent' }}
          >
            <FaTrashAlt />
          </button>
        </div>
      </div>

      <div className="row gx-4">
        {/* Request list */}
        <div className="col-md-4 mb-4">
          <div className="d-flex mb-2" style={{ overflowX: 'auto' }}>
            {statusOptions.map(f => (
              <span
                key={f.key}
                className={`badge rounded-pill bg-${f.color} me-2 ${
                  selectedStatus === f.key ? '' : 'opacity-50'
                }`}
                style={{ cursor: 'pointer', fontSize: '0.7rem' }}
                onClick={() => setSelectedStatus(f.key)}
              >
                {f.label.toUpperCase()}
              </span>
            ))}
          </div>
          <OwnerRequests
            requests={filtered.map(r => ({ ...r, timeAgo: timeAgo(r.date_reported) }))}
            selectedId={selected?.id}
            onSelect={id => {
              setSelectedId(id);
              setActiveTab('quotations');
            }}
            search={search}
            onSearch={setSearch}
            onNewRequest={() => {}}
          />
        </div>

        {/* Details pane */}
        <div className="col-md-8">
          {!selected ? (
            <div className="text-muted">Select a request to view details.</div>
          ) : (
            <div className="card h-100 shadow-sm rounded border-0">
              <div className="card-header bg-white border-0 d-flex justify-content-between align-items-start">
                <div>
                  <h4 className="mb-1">{selected.title}</h4>
                  <small className="text-muted d-block mb-1">
                    {selected.property} • {selected.unitName}
                  </small>
                  <div className="d-flex align-items-center mb-2">
                    <span className={`badge bg-${getBadgeColor(selected.status)} text-uppercase me-2`}>
                      {selected.status}
                    </span>
                    <small className="text-muted me-4">{fmtDate(selected.date_reported)}</small>
                    <small className="text-muted d-flex align-items-center me-3">
                      <FaCommentDots className="me-1" /> {selected.comments.length}
                    </small>
                    <small className="text-muted d-flex align-items-center me-3">
                      <FaPaperclip className="me-1" /> {selected.attachments.length}
                    </small>
                    <small className="text-muted d-flex align-items-center me-3">
                      <FaEye className="me-1" /> 0
                    </small>
                  </div>
                </div>
                <button className="btn p-1 text-dark" onClick={() => setShowModal(true)} title="Add comment">
                  <FaCommentDots size={20} />
                </button>
              </div>

              <div className="card-body overflow-auto px-4 py-3" style={{ maxHeight: '75vh' }}>
                <p className="mb-4">{selected.description}</p>

                {selected.attachments.length > 0 && (
                  <div className="mb-3">
                    {selected.attachments.map(att => (
                      <div key={att.attachment_id} className="d-flex align-items-center small mb-1">
                        <FaPaperclip className="me-1" />
                        <a href={att.file_path} download className="text-decoration-none">
                          {att.file_path.split('/').pop()}
                        </a>
                      </div>
                    ))}
                  </div>
                )}

                <h6 className="mb-3">Comments</h6>
                {selected.comments.length > 0 ? (
                  selected.comments.map(c => (
                    <div key={c.id} className="d-flex align-items-start mb-3">
                      <div
                        className="rounded-circle flex-shrink-0 d-flex align-items-center justify-content-center me-2"
                        style={{
                          width: 32,
                          height: 32,
                          fontSize: 12,
                          backgroundColor: getUserColor(c.user)
                        }}
                        title={c.user}
                      >
                        {c.user.split(' ').map(w => w[0]).join('').toUpperCase() || <FaRegUserCircle />}
                      </div>
                      <div>
                        <div className="small text-muted">
                          {c.user} • {timeAgo(c.created_at)}
                        </div>
                        <div>{c.text}</div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-muted mb-3">No comments.</div>
                )}

                <ul className="nav nav-tabs mb-3">
                  {selected.status === 'open' ? (
                    <>
                      <li className="nav-item">
                        <button
                          className={`nav-link${activeTab === 'quotations' ? ' active' : ''}`}
                          onClick={() => setActiveTab('quotations')}
                        >
                          Quotations
                        </button>
                      </li>
                      <li className="nav-item">
                        <button
                          className={`nav-link${activeTab === 'contractors' ? ' active' : ''}`}
                          onClick={() => setActiveTab('contractors')}
                        >
                          My Contractors
                        </button>
                      </li>
                    </>
                  ) : (
                    <li className="nav-item">
                      <button className="nav-link active">Job Task</button>
                    </li>
                  )}
                </ul>

                {selected.status === 'open' && activeTab === 'quotations' && (
                  <OwnerQuotations request={selected} />
                )}
                {selected.status === 'open' && activeTab === 'contractors' && (
                  <OwnerContractors requestId={selected.id} />
                )}
                {selected.status !== 'open' && (
                  <OwnerTask
                    request={selected}
                    owner={`${selected.owner_first_name} ${selected.owner_last_name}`}
                  />
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add Comment</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {errorMsg && <Alert variant="danger">{errorMsg}</Alert>}
          <Form.Control
            as="textarea"
            rows={4}
            className="mb-4"
            value={commentTxt}
            onChange={e => setCommentTxt(e.target.value)}
            placeholder="Type your comment…"
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>Cancel</Button>
          <Button variant="primary" onClick={handleSaveComment} disabled={isSaving}>
            {isSaving ? 'Saving…' : 'Save'}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
