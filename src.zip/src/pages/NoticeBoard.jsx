import React from "react";

export const NoticeBoard = () => {
  return (
    <div className="row">
      {/* Welcome Card */}
      <div className="col-sm-8">
        <div className="card alert alert-primary p-1">
          <div className="card-body pb-0 total-sells">
            <div className="d-flex align-items-center gap-3">
              <div className="social-img-wrap">
                <div className="social-img cust-profile">
                  <img src="" alt="profile" />
                </div>
              </div>
              <div className="flex-grow-1">
                <h2 className="text-white">Welcome back</h2>
                <p className="text-white">John Doe</p>
              </div>
            </div>
            <hr />
            <div className="d-flex align-items-center gap-3">
              <p className="btn button-light bg-light p-2 text-primary">
                <i data-feather="users"></i>
              </p>
              <div className="flex-grow-1">
                <h2 className="text-white">3</h2>
                <p className="text-white">Total Note</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Create User Card */}
      <div className="col-sm-4">
        <div className="card social-profile">
          <div className="card-body">
            <div className="social-img-wrap">
              <div className="social-img cust-profile">
                <img src="" alt="profile" />
              </div>
            </div>
            <div className="social-details">
              <h5 className="mb-1">Notes</h5>
              <div className="col-auto">
                <a href="#" className="btn btn-primary">
                  Create Note
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* User Table */}
      <div className="col-sm-12">
        <div className="card">
          <div className="card-header">
            <h5>Note List</h5>
          </div>
          <div className="card-body">
            <div className="card border" style={{ width: "28rem" }}>
              <div className="card-body">
                <h5 className="card-title">Apr 8, 2025</h5>
                <div className="mb-2">
                  <p className="card-text m-0 p-0 text-muted">Title</p>
                  <p className="fw-bold card-text">New Release</p>
                </div>
                <div>
                  <p className="card-text text-muted m-0 p-0">Description</p>
                  <p className="fw-bold card-text">What is new</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

