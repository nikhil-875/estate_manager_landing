import React, { useState } from "react";

export const MaintainerList = ({
  maintainers = [],
  canCreate = false,
  onCreateClick,
  onMaintainerClick,
}) => {
  const [activeId, setActiveId] = useState(maintainers[0]?.id || null);

  const handleMaintainerClick = (id) => {
    setActiveId(id);
    if (onMaintainerClick) onMaintainerClick(id);
  };

  return (
    <div className="row">
      <div className="email-wrap">
        <div className="col-sm-12">
          <div className="email-right-aside contacts-tabs">
            <div className="email-body radius-left dark-contact">
              <div className="card">
                <div className="card-header">
                  <div className="row">
                    <div className="col-6 text-start">
                      <h4>Maintainer List</h4>
                    </div>
                    <div className="col-6 text-end">
                      {canCreate && (
                        <button
                          className="btn btn-primary maintainerCreate"
                          onClick={onCreateClick}
                        >
                          Create
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="card-body p-0">
                  <div className="row list-persons">
                    <div className="col-xl-4 xl-50 col-md-5">
                      <div className="nav flex-column nav-pills">
                        {maintainers.length > 0 ? (
                          maintainers.map((maintainer, key) => {
                            const user = maintainer.user || {};
                            const profile = user.profile
                              ? `/storage/upload/profile/${user.profile}`
                              : `/storage/upload/profile/avatar.png`;

                            return (
                              <a
                                key={maintainer.id}
                                className={`nav-link maintainerView ${
                                  maintainer.id === activeId ? "active" : ""
                                }`}
                                onClick={() =>
                                  handleMaintainerClick(maintainer.id)
                                }
                                style={{ cursor: "pointer" }}
                              >
                                <div className="d-flex">
                                  <img
                                    className="img-50 img-fluid m-r-20 rounded-circle"
                                    src={profile}
                                    alt="Profile"
                                  />
                                  <div className="flex-grow-1">
                                    <h6>
                                      {`${user.first_name || ""} ${
                                        user.last_name || ""
                                      }`}
                                    </h6>
                                    <p>{user.email || "-"}</p>
                                  </div>
                                </div>
                              </a>
                            );
                          })
                        ) : (
                          <a className="nav-link maintainerView" data-id="0">
                            <div className="d-flex">
                              <div className="flex-grow-1">
                                <div className="card-body reset-rating-wrapper">
                                  <div className="ratingCard">
                                    <p>No Maintainer Data</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </a>
                        )}
                      </div>
                    </div>

                    <div className="col-xl-8 xl-50 col-md-7">
                      <div id="maintainer-view">
                        <div className="ratingCard">
                          <p>No Maintainer Data</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
