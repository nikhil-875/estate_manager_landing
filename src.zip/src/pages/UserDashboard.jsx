// src/components/UserDashboard.jsx
import React, { useEffect, useState, useMemo } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, Link } from 'react-router-dom';
import { Modal, Button, Form, Tabs, Tab } from 'react-bootstrap';
import CRC32 from 'crc-32';
import {
  useGetOwnerCompaniesQuery,
  useRemoveCompanyMutation,
  useGetInviteUserListQuery,
  useGetTransactionHistoryMutation,
  useInviteUserMutation,
} from '../api/company';
import { useImpersonateUserMutation } from '../api/authApi';
import {
  FaUserShield, FaUserTie, FaUserCog,
  FaHome, FaTools, FaBuilding,
  FaEnvelope, FaRegClock,
} from 'react-icons/fa';
import { IoMdEye } from 'react-icons/io';
import { MdDeleteOutline } from 'react-icons/md';
import { CgLogIn } from 'react-icons/cg';
import { toast } from 'react-toastify';

// Helper: map a UUID string to a number between 1 and 70 via CRC32
function shortUuidCrc(uuid) {
  const crc = CRC32.str(uuid);
  return (Math.abs(crc) % 70) + 1;
}

export const UserDashboard = () => {
  const [activeTab, setActiveTab] = useState('companies');
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteForm, setInviteForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    role: 2,
  });
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [companyToDelete, setCompanyToDelete] = useState(null);

  const loginUser = useSelector(s => s.auth.user);
  const isSuper = loginUser?.type === 'super admin';

  const {
    data: usersData = { members: [] },
    isLoading,
    refetch: refetchCompanies,
  } = useGetOwnerCompaniesQuery(loginUser?.id, { skip: !loginUser?.id });
  const users = usersData.members;

  const [removeCompany, { isLoading: isRemoving }] = useRemoveCompanyMutation();
  const [inviteUser, { isSuccess: inviteSuccess, isLoading: inviteLoading }] =
    useInviteUserMutation();
  const { data: invitedUsers = [] } =
    useGetInviteUserListQuery(loginUser?.id, { skip: !loginUser?.id });

  const [impersonateUser] = useImpersonateUserMutation();

  const navigate = useNavigate();

  useEffect(() => {
    if (inviteSuccess) {
      setShowInviteModal(false);
      setInviteForm({ firstName: '', lastName: '', email: '', role: 2 });
    }
  }, [inviteSuccess]);

  const tableAvatarStyle = {
    width: 40,
    height: 40,
    borderRadius: '50%',
    objectFit: 'cover',
    marginRight: 10,
  };

  const packageColors = useMemo(() => {
    const distinct = Array.from(new Set(users.map(u => u.package)));
    const palette = ['#e67e22', '#8e44ad', '#3498db', '#2ecc71', '#f1c40f', '#e74c3c'];
    return distinct.reduce((acc, pkg, i) => {
      acc[pkg] = palette[i % palette.length];
      return acc;
    }, {});
  }, [users]);

  const getUserTypeBadge = type => {
    const map = {
      admin:      { icon: <FaUserShield />, label: 'Admin',      color: '#e74c3c' },
      manager:    { icon: <FaUserTie />,    label: 'Manager',    color: '#2980b9' },
      owner:      { icon: <FaUserCog />,    label: 'Owner',      color: '#27ae60' },
      tenant:     { icon: <FaHome />,       label: 'Tenant',     color: '#8e44ad' },
      contractor: { icon: <FaTools />,      label: 'Contractor', color: '#f39c12' },
    };
    const b = map[type?.toLowerCase()];
    if (!b) return <span className="badge bg-secondary">Unknown</span>;
    return (
      <span style={{
        backgroundColor: b.color,
        color: 'white',
        padding: '4px 8px',
        borderRadius: 12,
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        fontSize: '0.85rem',
      }}>
        {b.icon}{b.label}
      </span>
    );
  };

  const getPackageBadge = pkg => (
    <span style={{
      backgroundColor: packageColors[pkg] || '#6c757d',
      color: 'white',
      padding: '4px 8px',
      borderRadius: 12,
      fontSize: '0.85rem',
    }}>
      {pkg}
    </span>
  );

  const handleInviteChange = ({ target }) =>
    setInviteForm(f => ({ ...f, [target.name]: target.value }));

  const handleInviteSubmit = e => {
    e.preventDefault();
    inviteUser({
      action: 'send',
      receiver_email: inviteForm.email,
      first_name: inviteForm.firstName,
      last_name: inviteForm.lastName,
      role_offered: inviteForm.role,
      status_id: 2,
      company: loginUser.first_name,
    });
  };

  const openDeleteModal = company => {
    setCompanyToDelete(company);
    setShowDeleteModal(true);
  };
  const confirmDelete = async () => {
    try {
      await removeCompany({ companyId: companyToDelete.company_id }).unwrap();
      toast.success(`Removed ${companyToDelete.company} successfully`);
      setShowDeleteModal(false);
      setCompanyToDelete(null);
      refetchCompanies();
    } catch (err) {
      toast.error(err?.data?.message || 'Failed to remove company');
    }
  };

  const openCompany = (companyId, userId) =>
    navigate('/company', { state: { companyId, userId } });

  const handleImpersonation = async userId => {
    try {
      const { data } = await impersonateUser(userId);
      if (data.status === 'success' && data.token) {
        localStorage.setItem('token', data.token);
        toast.success('User impersonation successful');
        navigate('/');
        window.location.reload();
      }
    } catch (err) {
      toast.error(err.data?.message || 'Failed to impersonate user');
    }
  };

  const visitors = [];
  const totalCompanies = users.length;
  const pendingInvites = invitedUsers.length;

  return (
    <div className="bg-white p-0">
      <style jsx>{`
        .clickable { cursor: pointer; }
        .stat-card { min-height: 160px; }
      `}</style>

      {/* Stat cards */}
      <div className="row g-3">
        <div className="col-sm-3">
          <div
            className="card stat-card clickable"
            onClick={() => setActiveTab('companies')}
          >
            <div className="card-body text-center">
              <FaBuilding className="fs-1 text-primary mb-2" />
              <h6>Total Companies</h6>
              <p className="fs-4 mb-0">{totalCompanies}</p>
            </div>
          </div>
        </div>
        <div className="col-sm-3">
          <div
            className="card stat-card clickable"
            onClick={() => setActiveTab('invites')}
          >
            <div className="card-body text-center">
              <FaEnvelope className="fs-1 text-warning mb-2" />
              <h6>Pending Invites</h6>
              <p className="fs-4 mb-0">{pendingInvites}</p>
            </div>
          </div>
        </div>
        <div className="col-sm-3">
          <div
            className="card stat-card clickable"
            onClick={() => setActiveTab('visitors')}
          >
            <div className="card-body text-center">
              <FaRegClock className="fs-1 text-info mb-2" />
              <h6>Visitors Waiting</h6>
              <p className="fs-4 mb-0">{visitors.length}</p>
            </div>
          </div>
        </div>
        <div className="col-sm-3">
          <div
            className="card stat-card text-center clickable"
            style={{ backgroundColor: '#E5E4FB', color: '#3A3A3C' }}
            onClick={() => setShowInviteModal(true)}
          >
            <div className="card-body d-flex flex-column align-items-center justify-content-center">
              <i className="fa fa-user fs-1 text-primary mb-2" />
              <h6 className="fw-semibold mb-2">Invite Users</h6>
              <small className="text-primary">Click to invite</small>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs activeKey={activeTab} onSelect={k => setActiveTab(k)} className="mt-4">
        <Tab eventKey="companies" title="Companies">
          <div className="card">
            <div className="card-header"><h5>Companies</h5></div>
            <div className="card-body">
              <div className="table-responsive theme-scrollbar">
                <table className="table light-card">
                  <thead>
                    <tr>
                      <th>Joined</th>
                      <th>Company Name</th>
                      <th>Role</th>
                      <th>Package</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {isLoading ? (
                      <tr>
                        <td colSpan="5" className="text-center">Loading…</td>
                      </tr>
                    ) : users.length ? (
                      users.map(u => {
                        const avatarNum = shortUuidCrc(u.id);
                        return (
                          <tr key={u.id}>
                            <td>
                              {u.user_created_at
                                ? new Date(
                                    `${new Date().toISOString().split('T')[0]}T${u.user_created_at.split('+')[0]}`
                                  ).toLocaleDateString('en-ZA', {
                                    year: 'numeric',
                                    month: 'short',
                                    day: 'numeric',
                                  })
                                : '—'}
                            </td>
                            <td className="d-flex align-items-center">
                              <img
                                src={`https://i.pravatar.cc/100?img=${avatarNum}`}
                                alt=""
                                style={tableAvatarStyle}
                              />
                              <span
                                className="clickable text-decoration-none"
                                // onClick={() => openCompany(u.company_id, u.id)}
                              >
                                {u.company || u.contact}
                              </span>
                            </td>
                            <td>{getUserTypeBadge(u._type)}</td>
                            <td>{getPackageBadge(u.package)}</td>
                            <td>
                              {u.can_view && (
                                <IoMdEye
                                  size="1rem"
                                  className={`mx-2 clickable`}
                                  onClick={() => openCompany(u.company_id, u.id)}
                                  title="View company details"
                                />
                              )}
                              {u.can_delete && (
                                <MdDeleteOutline
                                  size="1rem"
                                  className="mx-2 clickable text-danger"
                                  onClick={() => openDeleteModal(u)}
                                  title="Remove company"
                                />
                              )}
                              {u.log_as && (
                                <CgLogIn
                                  size="1rem"
                                  className="mx-2 clickable"
                                  onClick={() => handleImpersonation(u.id)}
                                  title="Login as this user"
                                />
                              )}
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan="5" className="text-center">No companies found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </Tab>

        {/* Invites Tab */}
        <Tab eventKey="invites" title="Invites">
          <div className="card">
            <div className="card-header"><h5>Pending Invites</h5></div>
            <div className="card-body">
              <div className="table-responsive theme-scrollbar">
                <table className="table light-card">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invitedUsers.length ? (
                      invitedUsers.map((inv) => (
                        <tr key={inv.id}>
                          <td>{inv.first_name} {inv.last_name}</td>
                          <td>{inv.receiver_email}</td>
                          <td><span className="badge bg-info">{inv.status_description}</span></td>
                          <td>
                            {inv.can_revoke && (
                              <Button size="sm" variant="outline-danger" onClick={() => inviteUser({ action: 'revoke', token: inv.token })}>
                                Revoke
                              </Button>
                            )}{' '}
                            {inv.can_resend && (
                              <Button size="sm" variant="outline-primary" onClick={() => inviteUser({
                                action: 'send',
                                receiver_email: inv.receiver_email,
                                first_name: inv.first_name,
                                last_name: inv.last_name,
                                role_offered: inv.role_offered,
                                status_id: 2,
                                company: loginUser.first_name,
                              })}>
                                Resend
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="4" className="text-center">No invites.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </Tab>

        {/* Visitors Tab */}
        <Tab eventKey="visitors" title="Visitors">
          <div className="card">
            <div className="card-header"><h5>Visitors</h5></div>
            <div className="card-body">
              <div className="table-responsive theme-scrollbar">
                <table className="table light-card">
                  <thead>
                    <tr>
                      <th>Requested Date</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visitors.length ? (
                      visitors.map((v) => (
                        <tr key={v.id}>
                          <td>{v.requestedAt}</td>
                          <td>{v.name}</td>
                          <td>{v.email}</td>
                          <td>
                            <Button
                              size="sm"
                              variant="outline-primary"
                              onClick={() => {
                                setInviteForm({
                                  firstName: v.name.split(' ')[0],
                                  lastName: v.name.split(' ').slice(1).join(' '),
                                  email: v.email,
                                  role: 2,
                                });
                                setShowInviteModal(true);
                              }}
                            >
                              Invite
                            </Button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="4" className="text-center">No visitors.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </Tab>

      </Tabs>

      {/* Delete Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Removal</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to remove <strong>{companyToDelete?.company}</strong>?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)} disabled={isRemoving}>
            Cancel
          </Button>
          <Button variant="danger" onClick={confirmDelete} disabled={isRemoving}>
            {isRemoving ? 'Removing…' : 'Yes, Remove'}
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Invite Modal */}
      <Modal show={showInviteModal} onHide={() => setShowInviteModal(false)} size="lg" centered>
        <Form onSubmit={handleInviteSubmit}>
          <Modal.Header closeButton>
            <Modal.Title>Invite a New User</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>First Name</Form.Label>
              <Form.Control
                name="firstName"
                value={inviteForm.firstName}
                onChange={handleInviteChange}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Last Name</Form.Label>
              <Form.Control
                name="lastName"
                value={inviteForm.lastName}
                onChange={handleInviteChange}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Email Address</Form.Label>
              <Form.Control
                type="email"
                name="email"
                value={inviteForm.email}
                onChange={handleInviteChange}
                required
              />
            </Form.Group>
            <Form.Label>Role</Form.Label>
            <div className="mb-3">
              {isSuper && (
                <Form.Check
                  inline
                  type="radio"
                  label="Estate Agent"
                  name="role"
                  value={2}
                  checked={inviteForm.role === 2}
                  onChange={handleInviteChange}
                />
              )}
              <Form.Check
                inline
                type="radio"
                label="Landlord"
                name="role"
                value={3}
                checked={inviteForm.role === 3}
                onChange={handleInviteChange}
              />
              <Form.Check
                inline
                type="radio"
                label="Contractor"
                name="role"
                value={5}
                checked={inviteForm.role === 5}
                onChange={handleInviteChange}
              />
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowInviteModal(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={inviteLoading}>
              {inviteLoading ? 'Sending…' : 'Send Invite'}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </div>
  );
};
