import React, { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button, Modal, Spinner, Alert } from "react-bootstrap";
import { useAcceptInvitationMutation } from "../api/company";
import { useManageTenantInvitationMutation } from "../api/propertyApi";

export const InvitationAccept = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  const email = searchParams.get("email");
  const type = searchParams.get("type");

  // State for validation and modals
  const [validParams, setValidParams] = useState(true);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showDeclineModal, setShowDeclineModal] = useState(false);

  // API hooks
  const [acceptInvitation, { isSuccess: isUserSuccess, isLoading: isUserLoading, error: userError }] = useAcceptInvitationMutation();
  const [manageTenantInvitation, { isSuccess: isTenantSuccess, isLoading: isTenantLoading, error: tenantError }] = useManageTenantInvitationMutation();

  // Combined states for UI
  const isSuccess = isUserSuccess || isTenantSuccess;
  const isLoading = isUserLoading || isTenantLoading;
  const error = userError || tenantError;

  // Validate query parameters
  useEffect(() => {
    if (!token || !email) {
      setValidParams(false);
      console.log("Invalid parameters:", { token, email });  // Log invalid parameters
    }
  }, [token, email, type]);

  // Handle success redirect
  useEffect(() => {
    if (isSuccess) {
      const timer = setTimeout(() => {
        navigate("/login");
      }, 3000);

      console.log("Invitation accepted successfully.");  // Log success

      return () => clearTimeout(timer);
    }
  }, [isSuccess, navigate]);

  const handleAcceptInvitation = () => {
    setShowConfirmModal(false);

    const invitationData = {
      action: "accept",
      token,
      email
    };

    if (type === "tenant") {
      console.log("Accepting tenant invitation:", invitationData);  // Log the invitation acceptance
      manageTenantInvitation(invitationData);
    } else {
      console.log("Accepting user invitation:", invitationData);  // Log the invitation acceptance
      acceptInvitation(invitationData);
    }
  };

  const handleDeclineInvitation = () => {
    setShowDeclineModal(false);
    navigate("/login");
    console.log("Invitation declined.");  // Log decline action
  };

  // If invalid parameters, show error
  if (!validParams) {
    return (
      <div className="container text-center mt-5">
        <Alert variant="danger">
          Invalid invitation link. Please check your email for the correct link.
        </Alert>
        <Button variant="secondary" onClick={() => navigate("/login")}>
          Return to Login
        </Button>
      </div>
    );
  }

  return (
    <div className="container text-center mt-5">
      <div className="card shadow p-4 mx-auto" style={{ maxWidth: "600px" }}>
        <h2 className="mb-4">Invitation to Estate Manager</h2>

        <div className="mb-4">
          <div className="d-flex justify-content-center mb-3">
            <div className="rounded-circle bg-light p-3">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="currentColor" className="bi bi-envelope-open text-primary" viewBox="0 0 16 16">
                <path d="M8.47 1.318a1 1 0 0 0-.94 0l-6 3.2A1 1 0 0 0 1 5.4v.817l5.75 3.45L8 8.917l1.25.75L15 6.217V5.4a1 1 0 0 0-.53-.882l-6-3.2ZM15 7.383l-4.778 2.867L15 13.117V7.383Zm-.035 6.88L8 10.082l-6.965 4.18A1 1 0 0 0 2 15h12a1 1 0 0 0 .965-.738ZM1 13.116l4.778-2.867L1 7.383v5.734ZM7.059.435a2 2 0 0 1 1.882 0l6 3.2A2 2 0 0 1 16 5.4V14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V5.4a2 2 0 0 1 1.059-1.765l6-3.2Z"/>
              </svg>
            </div>
          </div>
          <p className="lead">You've been invited to join Estate Manager {type === "tenant" ? "as a tenant" : "as a team member"}.</p>
          <p className="text-muted">Email: {email}</p>
        </div>

        <div className="d-grid gap-2 d-md-flex justify-content-md-center">
          <Button
            variant="primary"
            onClick={() => setShowConfirmModal(true)}
            disabled={isLoading}
            aria-label="Accept invitation"
            className="px-4 py-2"
            size="lg"
          >
            {isLoading ? <Spinner animation="border" size="sm" /> : "Accept Invitation"}
          </Button>

          <Button
            variant="outline-secondary"
            onClick={() => setShowDeclineModal(true)}
            disabled={isLoading}
            aria-label="Decline invitation"
            className="px-4 py-2"
            size="lg"
          >
            Decline
          </Button>
        </div>

        {error && (
          <Alert variant="danger" className="mt-4">
            {error.status === 404
              ? "This invitation has expired or is invalid."
              : "Error accepting invitation. Please try again later."}
          </Alert>
        )}
      </div>

      {/* Confirmation Modal */}
      <Modal show={showConfirmModal} onHide={() => setShowConfirmModal(false)} centered backdrop="static" aria-labelledby="confirm-modal">
        <Modal.Header closeButton>
          <Modal.Title id="confirm-modal">Confirm Acceptance</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to accept this invitation to join Estate Manager {type === "tenant" ? "as a tenant" : "as a team member"}?</p>
          <p className="text-muted">Email: {email}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowConfirmModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleAcceptInvitation}>
            Yes, Accept Invitation
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Decline Modal */}
      <Modal show={showDeclineModal} onHide={() => setShowDeclineModal(false)} centered aria-labelledby="decline-modal">
        <Modal.Header closeButton>
          <Modal.Title id="decline-modal">Decline Invitation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to decline this invitation?</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeclineModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeclineInvitation}>
            Yes, Decline Invitation
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Success Modal */}
      <Modal show={isSuccess} backdrop="static" keyboard={false} centered aria-labelledby="success-modal">
        <Modal.Body className="text-center p-5">
          <div className="mb-4">
            <div className="rounded-circle bg-success text-white d-inline-flex p-3 mb-3">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="currentColor" className="bi bi-check-lg" viewBox="0 0 16 16">
                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
              </svg>
            </div>
            <h4 className="text-success" id="success-modal">Success!</h4>
            <p className="lead">Your invitation has been accepted.</p>
            <p>You will be redirected to the login page in a moment...</p>
            <div className="mt-4">
              <Spinner animation="border" variant="primary" />
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
};
