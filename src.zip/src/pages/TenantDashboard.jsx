// src/pages/TenantDashboard.jsx
import React, { useState } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import {
  Calendar as CalIcon,
  List as ListIcon,
  Wrench,
  FileText,
  MessageCircle,
  Bell,
  Camera as CameraIcon,
} from 'lucide-react';

// dummy schedule entries
const scheduleEvents = [
  { title: 'Branding',      start: '2024-01-10', end: '2024-01-12', color: '#A78BFA' },
  { title: 'Web Design',    start: '2024-02-05', end: '2024-02-07', color: '#60A5FA' },
  { title: 'UX Research',   start: '2024-03-01', end: '2024-03-03', color: '#F472B6' },
  { title: 'Mobile Design', start: '2024-01-20', end: '2024-01-22', color: '#EC4899' },
  { title: 'NFT Website',   start: '2024-02-15', end: '2024-02-18', color: '#22C55E' },
  { title: 'Logo Design',   start: '2024-03-10', end: '2024-03-11', color: '#A78BFA' }
];

export const TenantDashboard = () => {
  const [viewMode, setViewMode] = useState('list');      // 'list' or 'calendar'
  const [showRequestModal, setShowRequestModal] = useState(false);

  return (
    <>
      <style>{`
        /* FullCalendar tweaks */
        .fc .fc-toolbar { padding: 1rem !important; }
        .fc .fc-toolbar-chunk:first-child { flex: 0 1 auto !important; }
        .fc .fc-toolbar-title { margin-left: 0 !important; }
        .fc .fc-scroller, .fc .fc-scrollgrid-sync-table { overflow: hidden !important; }
        .fc .fc-daygrid { padding: 1rem; }
        .pending-view { margin-top: -0.4rem; display: inline-block; }
      `}</style>

      <div className="container-fluid py-4">
        {/* Top Cards */}
        <div className="row g-3">
          {/* Rent Due */}
          <div className="col-md-4">
            <div className="card shadow-sm">
              <div className="card-body d-flex justify-content-between align-items-center">
                <div>
                  <h6 className="text-muted mb-1">Rent Due</h6>
                  <h2 className="mb-1">$1,200.00</h2>
                  <small className="text-muted">Due on May 1, 2024</small>
                </div>
                <CalIcon size={36} className="text-primary" />
              </div>
            </div>
          </div>

          {/* Maintenance Requests */}
          <div className="col-md-4">
            <div className="card shadow-sm">
              <div className="card-body d-flex justify-content-between align-items-center">
                <div>
                  <h6 className="text-muted mb-1">Maintenance Requests</h6>
                  <h2 className="mb-1">2 Requests</h2>
                  <small className="text-muted pending-view">
                    Log a{' '}
                    <button
                      type="button"
                      className="btn btn-link p-0 align-baseline"
                      onClick={() => setShowRequestModal(true)}
                    >
                      Request
                    </button>
                  </small>
                </div>
                <Wrench size={36} className="text-warning" />
              </div>
            </div>
          </div>

          {/* Lease Status */}
          <div className="col-md-4">
            <div className="card shadow-sm">
              <div className="card-body d-flex justify-content-between align-items-center">
                <div>
                  <h6 className="text-muted mb-1">Lease Status</h6>
                  <h2 className="text-success mb-1">Active</h2>
                  <small className="text-muted">Ends on Dec 31, 2024</small>
                </div>
                <FileText size={36} className="text-success" />
              </div>
            </div>
          </div>
        </div>

        {/* Schedule + Side Panels */}
        <div className="row g-3 mt-3">
          {/* Schedule */}
          <div className="col-xxl-5 col-xl-6">
            <div className="card shadow-sm">
              <div className="card-header d-flex justify-content-between align-items-center pb-0">
                <h4 className="mb-0">Schedule</h4>
                <div>
                  <ListIcon
                    size={20}
                    className={`me-2 cursor-pointer ${viewMode === 'list' ? 'text-primary' : 'text-muted'}`}
                    onClick={() => setViewMode('list')}
                  />
                  <CalIcon
                    size={20}
                    className={`cursor-pointer ${viewMode === 'calendar' ? 'text-primary' : 'text-muted'}`}
                    onClick={() => setViewMode('calendar')}
                  />
                </div>
              </div>
              <div className="card-body p-0">
                {viewMode === 'calendar' ? (
                  <FullCalendar
                    plugins={[dayGridPlugin]}
                    initialView="dayGridMonth"
                    events={scheduleEvents}
                    height={550}
                    headerToolbar={{ left: 'title', center: '', right: 'today prev,next' }}
                  />
                ) : (
                  <ul className="list-group list-group-flush">
                    {scheduleEvents.map((e, i) => (
                      <li className="list-group-item" key={i}>
                        <strong>{e.title}</strong><br/>
                        <small>
                          {new Date(e.start).toLocaleDateString()} &ndash;{' '}
                          {new Date(e.end).toLocaleDateString()}
                        </small>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="col-lg-3">
            <div className="card shadow-sm h-100">
              <div className="card-header d-flex align-items-center">
                <MessageCircle className="me-2" /><h6 className="mb-0">Messages</h6>
              </div>
              <div className="card-body d-flex flex-column">
                <p className="flex-grow-1">
                  <strong>Landlord</strong> Please remember to take out the trash bins tomorrow…
                </p>
                <input className="form-control" placeholder="Type a message…" />
              </div>
            </div>
          </div>

          {/* Notifications */}
          <div className="col-lg-3">
            <div className="card shadow-sm h-100">
              <div className="card-header d-flex align-items-center">
                <Bell className="me-2" /><h6 className="mb-0">Notifications</h6>
              </div>
              <div className="card-body">
                <ul className="list-unstyled mb-0">
                  <li className="mb-2">
                    <small className="text-muted">New message from landlord</small><br/>
                    <strong>2 hours ago</strong>
                  </li>
                  <li>
                    <small className="text-muted">Maintenance request updated</small><br/>
                    <strong>1 day ago</strong>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* —— Log a Request Modal —— */}
      {showRequestModal && (
        <>
          {/* Backdrop */}
          <div className="modal-backdrop fade show" />

          {/* Modal */}
          <div className="modal fade show d-block" tabIndex="-1" role="dialog" aria-modal="true">
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Log a Request</h5>
                  <button
                    type="button"
                    className="btn-close"
                    aria-label="Close"
                    onClick={() => setShowRequestModal(false)}
                  />
                </div>
                <div className="modal-body">
                  <form>
                    <div className="mb-3">
                      <label className="form-label">Issue Type</label>
                      <select className="form-select">
                        <option>Select</option>
                        <option>Plumbing</option>
                        <option>Electrical</option>
                        <option>Other</option>
                      </select>
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Title</label>
                      <input type="text" className="form-control" />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Description</label>
                      <textarea className="form-control" rows="3" />
                    </div>
                    <div className="mb-3">
                      <button type="button" className="btn btn-outline-secondary">
                        <CameraIcon className="me-1" size={16} />
                        Attach Photo
                      </button>
                    </div>
                  </form>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => setShowRequestModal(false)}
                  >
                    Close
                  </button>
                  <button type="button" className="btn btn-primary">
                    Submit
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};

