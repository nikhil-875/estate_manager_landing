import React, { useState } from "react";
import { Container, Row, Col, Navbar, Nav, Dropdown, Image, Card, Button, Badge } from "react-bootstrap";
import { Link } from "react-router-dom";
import { Menu, X, Check, Smile } from "lucide-react";
import { FaBed, FaBath, FaRulerCombined, FaSearchLocation, FaComments } from "react-icons/fa";

export const GuestDashboard = () => {
    const [expanded, setExpanded] = useState(false);

    const testimonials = [
        { name: "Jane Smith", role: "Tenant, Sunrise Apartments", text: "Paying rent and maintenance requests have never been easier!" },
        { name: "Mr. Gupta", role: "Owner, Palm Residency", text: "Managing multiple tenants and reminders is now effortless." },
        { name: "Sneha Reddy", role: "Property Manager, Sky Heights", text: "We manage 50+ tenants smoothly with this system!" },
    ];

    // Dummy property data
    const featuredProperties = [
        {
            id: 1,
            name: "Skyline Apartments",
            address: "123 Downtown Ave, City Center",
            image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1073&q=80",
            rent: 2200,
            bedrooms: 2,
            bathrooms: 2,
            area: "1,200 sq ft",
            status: "Available",
            description: "Luxury apartment with stunning city views and modern amenities"
        },
        {
            id: 2,
            name: "Garden Villas",
            address: "456 Park Lane, Green Hills",
            image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
            rent: 3500,
            bedrooms: 3,
            bathrooms: 2.5,
            area: "2,100 sq ft",
            status: "Available",
            description: "Spacious villa with private garden, perfect for families"
        },
        {
            id: 3,
            name: "Riverside Lofts",
            address: "789 Water St, Riverside",
            image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
            rent: 1800,
            bedrooms: 1,
            bathrooms: 1,
            area: "850 sq ft",
            status: "Available",
            description: "Modern loft with river views and industrial-chic design"
        }
    ];

    return (
        <>
            {/* ANIMATION STYLES */}
            <style>
                {`
                @keyframes float {
                    0%, 100% { transform: translateY(0); }
                    50% { transform: translateY(-10px); }
                }
                .float {
                    animation: float 6s ease-in-out infinite;
                }
                .hover-lift:hover {
                    transform: translateY(-5px);
                    transition: transform 0.3s ease;
                }
                .custom-btn {
                    position: relative;
                    overflow: hidden;
                    transition: all 0.3s ease-in-out;
                    padding: 12px 24px;
                    font-weight: bold;
                    letter-spacing: 1px;
                }
                .custom-btn::before {
                    content: '';
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    width: 200%;
                    height: 200%;
                    background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0) 100%);
                    transition: transform 0.5s ease;
                    transform: translate(-50%, -50%) scale(0);
                }
                .custom-btn:hover::before {
                    transform: translate(-50%, -50%) scale(1);
                }
                .custom-btn:hover {
                    transform: translateY(-3px);
                    box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.1);
                }
                `}
            </style>

            {/* NAVBAR */}
            <Navbar expand="lg" expanded={expanded} className="bg-light shadow-sm px-3">
                <Navbar.Brand as={Link} to="/" className="fw-bold">
                    Estate<span className="text-primary">Manager</span>
                </Navbar.Brand>
                <Navbar.Toggle onClick={() => setExpanded(!expanded)} aria-label="Toggle menu">
                    {expanded ? <X size={24} /> : <Menu size={24} />}
                </Navbar.Toggle>
                <Navbar.Collapse className="justify-content-end">
                    <Nav>
                        {/* <Nav.Link as={Link} to="/features">Features</Nav.Link> */}
                        <Nav.Link as={Link} to="/property-listing">Find Property</Nav.Link>
                    </Nav>
                    <Dropdown align="end" className="ms-3">
                        <Image src="https://i.pravatar.cc/40?img=12" alt="User" roundedCircle width={40} height={40} className="me-2" />
                        <span className="fw-semibold text-primary bg-transparent">Guest User</span>
                    </Dropdown>
                </Navbar.Collapse>
            </Navbar>

            {/* HERO SECTION */}
            <section className="py-5 bg-white">
                <Container>
                    <Row className="align-items-center">
                        <Col lg={6}>
                            <h1 className="display-5 fw-bold">Welcome, <span className="text-primary">Guest</span> 👋</h1>
                            <p className="lead text-muted">Manage services, access requests, and stay informed easily.</p>
                            <div className="d-flex gap-3 mt-4">
                                <Link to="/login" className="btn btn-primary btn-lg rounded-pill custom-btn">Login</Link>
                                <Link to="/register" className="btn btn-outline-secondary btn-lg rounded-pill custom-btn">Register</Link>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>

            {/* FEATURED PROPERTIES SECTION */}
            <section className="py-5 bg-light">
                <Container>
                    <div className="d-flex justify-content-between align-items-center mb-4">
                        <h2 className="fw-bold">Featured Properties</h2>
                        <Link to="/property-listing" className="btn btn-primary rounded-pill">
                            View All Properties
                        </Link>
                    </div>

                    <Row className="g-4">
                        {featuredProperties.map((property) => (
                            <Col key={property.id} lg={4} md={6} sm={12}>
                                <Card className="h-100 shadow-sm hover-lift" style={{ borderRadius: '12px', overflow: 'hidden' }}>
                                    <div style={{ height: '220px', overflow: 'hidden', position: 'relative' }}>
                                        <img
                                            src={property.image}
                                            className="card-img-top"
                                            alt={property.name}
                                            style={{ objectFit: 'cover', height: '100%', width: '100%' }}
                                        />
                                        <Badge
                                            bg={property.status === 'Available' ? 'success' : 'warning'}
                                            style={{ position: 'absolute', top: '15px', right: '15px', fontSize: '0.9rem', padding: '0.5em 1em' }}
                                        >
                                            {property.status}
                                        </Badge>
                                    </div>
                                    <Card.Body>
                                        <h5 className="card-title fw-bold mb-1" style={{ color: '#2c3e50' }}>{property.name}</h5>
                                        <p className="text-muted small mb-3">
                                            <FaSearchLocation className="me-1" />
                                            {property.address}
                                        </p>

                                        <div className="d-flex justify-content-between mb-3">
                                            <div className="d-flex align-items-center">
                                                <FaBed className="text-primary me-1" />
                                                <span className="fw-semibold">{property.bedrooms} beds</span>
                                            </div>
                                            <div className="d-flex align-items-center">
                                                <FaBath className="text-primary me-1" />
                                                <span className="fw-semibold">{property.bathrooms} baths</span>
                                            </div>
                                            <div className="d-flex align-items-center">
                                                <FaRulerCombined className="text-primary me-1" />
                                                <span className="fw-semibold">{property.area}</span>
                                            </div>
                                        </div>

                                        <p className="card-text" style={{ minHeight: '48px' }}>
                                            {property.description}
                                        </p>

                                        <div className="d-flex justify-content-between align-items-center mt-3">
                                            <h4 className="fw-bold text-primary mb-0">
                                                ${property.rent}/mo
                                            </h4>
                                            <Link
                                                to={`/property-listing?id=${property.id}`}
                                                className="btn btn-outline-primary d-flex align-items-center gap-2 rounded-pill px-3"
                                            >
                                                <FaComments /> Inquire Now
                                            </Link>
                                        </div>
                                    </Card.Body>
                                </Card>
                            </Col>
                        ))}
                    </Row>
                </Container>
            </section>

            {/* FEATURES */}
            <section className="py-5 bg-light">
                <Container>
                    <h2 className="text-center fw-bold mb-5">Your Available Features</h2>
                    <Row className="g-4">
                        {[
                            { icon: Check, title: "Raise Maintenance Request", desc: "Log issues and track resolution." },
                            { icon: Smile, title: "View Rent Status", desc: "Check dues and payment history." },
                            { icon: Check, title: "Announcements", desc: "Stay updated with property admin notices." },
                            { icon: Smile, title: "Support Chat", desc: "Reach out to help easily." },
                        ].map(({ icon: Icon, title, desc }, i) => (
                            <Col key={i} md={6} lg={3}>
                                <div className="p-4 bg-white shadow-sm rounded text-center hover-lift">
                                    <Icon className="text-primary mb-3" size={32} />
                                    <h5 className="fw-semibold">{title}</h5>
                                    <p className="text-muted small">{desc}</p>
                                </div>
                            </Col>
                        ))}
                    </Row>
                </Container>
            </section>

            {/* TESTIMONIALS */}
            <section className="py-5 bg-white">
                <Container>
                    <h2 className="text-center fw-bold mb-5">What Others Say</h2>
                    <Row className="g-4 justify-content-center">
                        {testimonials.map(({ name, role, text }, i) => (
                            <Col key={i} md={6} lg={4}>
                                <blockquote className="p-4 border rounded bg-light shadow-sm h-100">
                                    <p className="text-muted">"{text}"</p>
                                    <footer className="blockquote-footer mt-3">
                                        <strong>{name}</strong>, <cite>{role}</cite>
                                    </footer>
                                </blockquote>
                            </Col>
                        ))}
                    </Row>
                </Container>
            </section>

        </>
    );
};
