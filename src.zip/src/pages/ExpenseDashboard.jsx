import React, { useState, useEffect } from 'react';
import { FaEye, FaEdit, FaTrashAlt, FaDownload } from 'react-icons/fa';

export const ExpenseDashboard = () => {
  // Mocked state
  const [loginUser, setLoginUser] = useState(null);
  const [totalExpense, setTotalExpense] = useState('₹12,340.50');
  const [expenses, setExpenses] = useState([]);
  const [permissions, setPermissions] = useState({
    canCreateExpense: true,
    canEditExpense: true,
    canDeleteExpense: true,
    canShowExpense: true,
  });

  // Simulate fetching data
  useEffect(() => {
    setLoginUser({
      name: 'John Doe',
      profile: null, // simulate no profile image
    });

    setExpenses([
      {
        id: 1,
        expense_id: 101,
        title: 'Office Rent',
        properties: { name: 'HQ Building' },
        units: { name: 'Unit A' },
        types: { title: 'Rent' },
        date: '2025-04-20',
        amount: 5000,
        receipt: 'receipt1.jpg',
      },
      {
        id: 2,
        expense_id: 102,
        title: 'Electricity Bill',
        properties: null,
        units: null,
        types: { title: 'Utility' },
        date: '2025-04-15',
        amount: 1200.75,
        receipt: null,
      },
    ]);
  }, []);

  const assetUrl = (path) => `/storage/${path}`;
  const dateFormat = (date) => new Date(date).toLocaleDateString();
  const priceFormat = (amount) => `₹${parseFloat(amount).toFixed(2)}`;
  const expensePrefix = () => 'EXP-';

  return (
    <div className="row">
      {/* Welcome & Total Expense Card */}
      <div className="col-sm-8">
        <div className="card alert alert-primary p-1">
          <div className="card-body pb-0 total-sells">
            <div className="d-flex align-items-center gap-3">
              <div className="social-img-wrap">
                <div className="social-img cust-profile">
                  <img
                    src={
                      loginUser?.profile
                        ? assetUrl(`upload/profile/${loginUser.profile}`)
                        : assetUrl('upload/profile/avatar.png')
                    }
                    alt="profile"
                  />
                </div>
              </div>
              <div className="flex-grow-1">
                <h2 className="text-white">Welcome back</h2>
                <p className="text-white">{loginUser?.name}</p>
              </div>
            </div>
            <hr />
            <div className="d-flex align-items-center gap-3">
              <p className="btn button-light bg-light p-2 text-primary">
                💸
              </p>
              <div className="flex-grow-1">
                <h2 className="text-white">{totalExpense}</h2>
                <p className="text-white">Total Expense</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Create Expense Card */}
      <div className="col-sm-4">
        <div className="card social-profile">
          <div className="card-body">
            <div className="social-img-wrap">
              <div className="social-img cust-profile">
                <img
                  src={
                    loginUser?.profile
                      ? assetUrl(`upload/profile/${loginUser.profile}`)
                      : assetUrl('upload/profile/avatar.png')
                  }
                  alt="profile"
                />
              </div>
            </div>
            <div className="social-details">
              <h5 className="mb-1">Expense</h5>
              {permissions.canCreateExpense && (
                <button className="btn btn-primary mt-2">
                  Create Expense
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Expense Table */}
      <div className="col-sm-12">
        <div className="card table-card mt-4">
          <div className="card-header">
            <h5>Expense List</h5>
          </div>
          <div className="card-body">
            <div className="table-responsive theme-scrollbar">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Expense</th>
                    <th>Title</th>
                    <th>Property</th>
                    <th>Unit</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Receipt</th>
                    {(permissions.canEditExpense || permissions.canDeleteExpense || permissions.canShowExpense) && (
                      <th className="text-end">Actions</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {expenses.map((expense) => (
                    <tr key={expense.id}>
                      <td>{expensePrefix() + expense.expense_id}</td>
                      <td>{expense.title}</td>
                      <td>{expense.properties?.name || '-'}</td>
                      <td>{expense.units?.name || '-'}</td>
                      <td>{expense.types?.title || '-'}</td>
                      <td>{dateFormat(expense.date)}</td>
                      <td>{priceFormat(expense.amount)}</td>
                      <td>
                        {expense.receipt ? (
                          <a href={assetUrl(`upload/receipt/${expense.receipt}`)} download>
                            <FaDownload />
                          </a>
                        ) : (
                          '-'
                        )}
                      </td>
                      {(permissions.canEditExpense || permissions.canDeleteExpense || permissions.canShowExpense) && (
                        <td className="text-end">
                          <div className="d-flex justify-content-end gap-2">
                            {permissions.canShowExpense && (
                              <button className="btn btn-sm btn-warning">
                                <FaEye />
                              </button>
                            )}
                            {permissions.canEditExpense && (
                              <button className="btn btn-sm btn-success">
                                <FaEdit />
                              </button>
                            )}
                            {permissions.canDeleteExpense && (
                              <button className="btn btn-sm btn-danger">
                                <FaTrashAlt />
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                  {expenses.length === 0 && (
                    <tr>
                      <td colSpan="9" className="text-center text-muted">No expenses found</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

