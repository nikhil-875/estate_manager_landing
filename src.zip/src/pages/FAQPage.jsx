import React from 'react';

const mockUser = {
  name: 'John Doe',
  profile: '', // Leave empty for fallback avatar
};

const mockTotalFAQ = 10;

const mockFAQs = [
  { id: 1, question: 'What is React?', enabled: 1 },
  { id: 2, question: 'How to use useState?', enabled: 0 },
];

const mockPermissions = {
  canCreateFAQ: true,
  canEditFAQ: true,
  canDeleteFAQ: true,
};

export const FAQPage = () => {
  const profileImage = mockUser.profile
    ? `/storage/upload/profile/${mockUser.profile}`
    : `/storage/upload/profile/avatar.png`;

  return (
    <div className="row">
      <div className="col-sm-8">
        <div className="card alert alert-primary p-1">
          <div className="card-body pb-0 total-sells">
            <div className="d-flex align-items-center gap-3">
              <div className="social-img-wrap">
                <div className="social-img cust-profile">
                  <img src={profileImage} alt="profile" />
                </div>
              </div>
              <div className="flex-grow-1">
                <div className="d-flex align-items-center gap-2">
                  <h2 className="text-white">Welcome back</h2>
                </div>
                <p className="text-white">{mockUser.name}</p>
              </div>
            </div>
            <hr />
            <div className="d-flex align-items-center gap-3">
              <p className="btn button-light bg-light p-2 text-primary">
                <i data-feather="book"></i>
              </p>
              <div className="flex-grow-1">
                <div className="d-flex align-items-center gap-2">
                  <h2 className="text-white">{mockTotalFAQ}</h2>
                </div>
                <p className="text-white">Total FAQ</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="col-sm-4">
        <div className="card social-profile">
          <div className="card-body">
            <div className="social-img-wrap">
              <div className="social-img cust-profile">
                <img src={profileImage} alt="profile" />
              </div>
            </div>
            <div className="social-details">
              <h5 className="mb-1">FAQ</h5>
              {mockPermissions.canCreateFAQ && (
                <div className="col-auto">
                  <a
                    href="#"
                    className="btn btn-primary customModal"
                    data-size="md"
                    data-url="/FAQ/create"
                    data-title="Create FAQ"
                  >
                    Create FAQ
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="col-sm-12">
        <div className="card table-card">
          <div className="card-header">
            <div className="row align-items-center g-2">
              <div className="col">
                <h5>FAQ List</h5>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="table-responsive theme-scrollbar">
              <table className="table light-card advance-datatable">
                <thead>
                  <tr>
                    <th>Question</th>
                    <th>Enable</th>
                    {(mockPermissions.canEditFAQ || mockPermissions.canDeleteFAQ) && (
                      <th>Action</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {mockFAQs.map((faq) => (
                    <tr key={faq.id}>
                      <td>{faq.question}</td>
                      <td>
                        {faq.enabled === 1 ? (
                          <span className="d-inline badge text-bg-success">Enable</span>
                        ) : (
                          <span className="d-inline badge text-bg-danger">Disable</span>
                        )}
                      </td>
                      {(mockPermissions.canEditFAQ || mockPermissions.canDeleteFAQ) && (
                        <td>
                          <ul className="action">
                            {mockPermissions.canEditFAQ && (
                              <a
                                href="#"
                                className="text-success customModal"
                                data-bs-toggle="tooltip"
                                data-size="lg"
                                data-bs-original-title="Edit"
                                data-url={`/FAQ/edit/${faq.id}`}
                                data-title="Edit FAQ"
                              >
                                <i className="icon-pencil-alt"></i>
                              </a>
                            )}
                            {mockPermissions.canDeleteFAQ && (
                              <a
                                href="#"
                                className="text-danger confirm_dialog"
                                data-bs-toggle="tooltip"
                                data-bs-original-title="Delete"
                              >
                                <i className="icon-trash"></i>
                              </a>
                            )}
                          </ul>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

