import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Card, Button, Form, Alert, Container } from "react-bootstrap";
import { motion } from "framer-motion";
import { useRequestPasswordResetMutation } from "../api/authApi";

export const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [alerts, setAlerts] = useState({ error: "", success: "" });
  const navigate = useNavigate();

  const [forgotPassword, { isLoading }] = useRequestPasswordResetMutation();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setAlerts({ error: "", success: "" });

    if (!email.trim()) {
      setAlerts({ error: "Please enter your email address" });
      return;
    }

    try {
      const response = await forgotPassword({ email }).unwrap();

      if (response.status === 'ok') {
        setAlerts({
          success: "Password reset instructions have been sent to your email address."
        });
        setEmail("");
        navigate('/login')
      } else {
        throw new Error(response.message || "Failed to process your request");
      }
    } catch (err) {
      console.error("Error:", err);

      if (err.data?.message) {
        setAlerts({ error: err.data.message });
      } else if (err.message) {
        setAlerts({ error: err.message });
      } else {
        setAlerts({ error: "An unexpected error occurred. Please try again." });
      }
    }
  };

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: "100vh" }}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={{ width: "100%", maxWidth: "450px" }}
      >
        <Card className="shadow-lg border-0 rounded-4 overflow-hidden">
          <Card.Body className="p-5">
            <div className="text-center mb-4">
              <h2 className="fw-bold mb-2">Forgot Password</h2>
              <p className="text-muted">Enter your email to reset your password</p>
            </div>

            {alerts.error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
              >
                <Alert variant="danger" className="mb-4">
                  {alerts.error}
                </Alert>
              </motion.div>
            )}

            {alerts.success && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
              >
                <Alert variant="success" className="mb-4">
                  {alerts.success}
                </Alert>
              </motion.div>
            )}

            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-4">
                <Form.Label>Email Address</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="py-2"
                  disabled={isLoading}
                  required
                />
              </Form.Group>

              <Button
                variant="primary"
                type="submit"
                className="w-100 py-2 mb-4"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    Sending...
                  </>
                ) : (
                  "Send Reset Link"
                )}
              </Button>
            </Form>

            <div className="text-center">
              <p className="mb-0">
                Remember your password?{" "}
                <Link to="/login" className="text-decoration-none fw-medium">
                  Back to Login
                </Link>
              </p>
            </div>
          </Card.Body>
        </Card>
      </motion.div>
    </Container>
  );
};

