import React, { useState } from "react";
import { useGetSubscriptionsQuery, useManageSubscriptionMutation } from "../api/subscription";
import { useSelector } from "react-redux";
import { toast } from 'react-toastify';

export const Subscriptions = () => {
    const user = useSelector(state => state.auth.user);
    const userId = user?.id
    const activeSubscription = user?.activeSubscriptionId;
    // RTK Query hooks for fetching plans and managing a subscription
    const { data, isLoading, isError } = useGetSubscriptionsQuery();
    const [manageSubscription, { isLoading: isManaging }] = useManageSubscriptionMutation();

    const [dollars, setDollars] = useState(100);
    const credits = dollars * 100; // Based on your component's logic
    const [loadingPlans, setLoadingPlans] = useState({}); // Track loading state per plan

    // --- RENDER LOGIC ---

    if (isLoading) {
        return <div>Loading Plans...</div>;
    }

    if (isError || !data) {
        return <div>Error: Could not fetch subscription plans.</div>;
    }

    // --- DATA PREPARATION ---

    // Extract all benefits from the first plan to display in the feature lists
    const FEATURES = data.length > 0 ? data[0].benefits.map(benefit => benefit.label) : [];

    // Find the 'Pay as you go' plan from the API data
    const payGoPlanFromAPI = data.find(plan => plan.interval === null);

    // Filter for only the recurring subscription plans
    const subscriptionPlansFromAPI = data.filter(plan => plan.interval !== null);

    // Map the API data for recurring plans into a format for the UI, ensuring the ID is preserved
    const PLANS = subscriptionPlansFromAPI.map(plan => ({
        id: plan.id, // **Crucial: Keep the original ID for API calls**
        title: plan.title,
        label: `R${plan.package_amount.toFixed(2)}`,
        interval: `${plan.currency}/${plan.interval}`,
        credit: plan.credit_amount, // Use the value from API
        cta: "Choose plan"
    }));

    // --- HANDLER FUNCTION ---

    /**
     * Handles the purchase of both top-ups and subscription plans.
     * @param {object} plan - The plan object, which must include an `id`.
     */
    const handlePurchase = async (plan) => {
        // A real user ID would come from your authentication context/state management

        // Set loading state for this specific plan
        setLoadingPlans(prev => ({ ...prev, [plan.id]: true }));

        // Construct the JSON payload for the `manage_subscription_credits` function
        const payload = {
            id: user?.id,
            subscription_id: plan.id,
            // Include top_up_amount only if it's the Pay as you go plan
            top_up_amount: plan.interval === null ? credits : 0,
        };

        try {
            console.log("Calling manageSubscription with payload:", payload);
            // Call the mutation from RTK Query
            const result = await manageSubscription(payload).unwrap();
            console.log("Purchase successful:", result);
            // Replace alert with a more user-friendly notification in a real app
            toast.success(`Successfully purchased ${plan.title}!`);
        } catch (err) {
            console.error("Failed to complete purchase:", err);
            toast.error(`Error: Could not complete the purchase. ${err.data?.error || ''}`);
        } finally {
            // Clear loading state for this plan
            setLoadingPlans(prev => ({ ...prev, [plan.id]: false }));
        }
    };

    return (
        <>
            <style>{`
                /* Styles from your component are included here */
                .pricing-page { max-width: 1200px; margin: 0 auto; padding: 2rem; font-family: sans-serif; color: #333; }
                .section-title { font-size: 1.75rem; margin-bottom: 0.5rem; text-align: left; }
                .registration-bonus { display: block; font-size: 0.875rem; color: #555; margin-bottom: 1.5rem; text-align: left; }
                .cards-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px,1fr)); gap: 1.5rem; }
                @media (max-width: 600px) {
                  .cards-grid { grid-template-columns: 1fr; }
                  .pricing-page { padding: 0.5rem; }
                }
                .card { background: #fff; border: 1px solid #e2e8f0; border-radius: 0.75rem; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); text-align: center; position: relative; display: flex; flex-direction: column; transition: border 0.2s, box-shadow 0.2s; }
                .card.current-plan { border: 2px solid #2563eb; box-shadow: 0 2px 8px rgba(37,99,235,0.08); }
                .badge { position: absolute; top: -0.75rem; left: 50%; transform: translateX(-50%); background: #2563eb; color: #fff; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.625rem; font-weight: 600; }
                .badge.current { background: #10b981; }
                .plan-title { font-size: 1.25rem; font-weight: 600; margin-bottom: 0.5rem; }
                .plan-header { font-size: 1.75rem; font-weight: 600; margin-bottom: 0.5rem; }
                .plan-interval { font-size: 1rem; font-weight: 400; margin-bottom: 1rem; display: block; }
                .plan-credit { color: #555; margin-bottom: 1rem; }
                .slider { width: 100%; accent-color: #2563eb; margin: 1rem 0; }
                .slider-labels { display: flex; justify-content: space-between; font-size: 0.75rem; color: #777; }
                .btn-primary { background: #2563eb; color: #fff; border: none; padding: 0.75rem 1.5rem; border-radius: 0.5rem; cursor: pointer; font-size: 1rem; transition: background 0.2s; }
                .btn-primary:hover { background: #1e40af; }
                .btn-primary:disabled { background: #9ca3af; cursor: not-allowed; }
                .feature-list { list-style: none; margin: 2rem 0 0; padding: 0; text-align: left; margin-top: auto; }
                .feature-list li { display: flex; align-items: center; margin-bottom: 0.5rem; font-size: 0.875rem; }
                .feature-list .check { color: #2563eb; margin-right: 0.5rem; }
                .plan-card .btn-primary { margin-top: 1rem; }
            `}</style>

            <div className="pricing-page">
                {/* Header */}
                <h2 className="section-title">Purchase Credit</h2>
                <span className="registration-bonus">
                    Plus, enjoy <strong>10,000 free credits</strong> when you register!
                </span>

                <div className="cards-grid">
                    {/* PayGO card styled as most popular */}
                    {payGoPlanFromAPI && (
                        <div className="card plan-card popular">
                            <div className="badge">MOST POPULAR</div>
                            <div className="plan-title">{payGoPlanFromAPI.title}</div>
                            <div className="plan-header">R{dollars.toFixed(2)}</div>
                            <div className="plan-interval">{credits.toLocaleString()} Credit</div>
                            <input
                                type="range"
                                min="100" max="1000" step="5"
                                value={dollars}
                                onChange={(e) => setDollars(Number(e.target.value))}
                                className="slider"
                                disabled={loadingPlans[payGoPlanFromAPI.id]} // Disable slider during purchase for this plan
                            />
                            <div className="slider-labels">
                                <span>100</span><span>500</span><span>1000</span>
                            </div>
                            <button
                                className="btn-primary"
                                onClick={() => handlePurchase(payGoPlanFromAPI)}
                                disabled={loadingPlans[payGoPlanFromAPI.id]} // Disable button during purchase for this plan
                            >
                                {loadingPlans[payGoPlanFromAPI.id] ? 'Processing...' : 'Buy now'}
                            </button>
                            <ul className="feature-list">
                                {FEATURES.map((feat) => (<li key={feat}><span className="check">✔</span>{feat}</li>))}
                            </ul>
                        </div>
                    )}

                    {/* Subscription plans */}
                    {PLANS.map((plan) => {
                        const isCurrent = plan.id === activeSubscription;
                        const isPlanLoading = loadingPlans[plan.id];
                        return (
                            <div key={plan.id} className={`card plan-card${isCurrent ? ' current-plan' : ''}`}>
                                {isCurrent && <div className="badge current">Current Plan</div>}
                                <div className="plan-title">{plan.title}</div>
                                <div className="plan-header">{plan.label}</div>
                                <span className="plan-interval">{plan.interval}</span>
                                <div className="plan-credit">{plan.credit.toLocaleString()} Credit</div>
                                <button
                                    className="btn-primary"
                                    onClick={() => handlePurchase(plan)}
                                    disabled={isPlanLoading || isCurrent} // Disable button if current plan or this plan is loading
                                >
                                    {isCurrent ? 'Current Plan' : (isPlanLoading ? 'Processing...' : plan.cta)}
                                </button>
                                <ul className="feature-list">
                                    {FEATURES.map((feat) => (<li key={feat}><span className="check">✔</span>{feat}</li>))}
                                </ul>
                            </div>
                        );
                    })}
                </div>
            </div>
        </>
    );
};