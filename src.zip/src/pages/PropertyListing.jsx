import React, { useState, useEffect } from 'react';
import { Container, Row, Col, InputGroup, Form, Button, Spinner } from 'react-bootstrap';
import { FaHome, FaMapMarkerAlt, FaSearchLocation, FaTimesCircle } from 'react-icons/fa';
import { useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';

// Import API hooks
import {
  useSearchListingsMutation,
  useManageRentalApplicationMutation,
  useManageViewingBookingMutation,
  useSendMessageMutation,
  useEnsureContactMutation,
  useLazyGetMessagesQuery
} from '../api/listingApi';
import { useSearchListingFaqsMutation } from '../api/aiApi';

// Import components
import PropertyListingCard from '../components/Listing/PropertyListingCard';
import PropertyChat from '../components/Listing/PropertyChat';
import PropertyContactForm from '../components/Listing/PropertyContactForm';

// Import styles
import { pageStyles } from '../components/Listing/ListingStyles';

// Helper function to get user info from localStorage
const getUserInfoFromStorage = () => {
  try {
    const storedUserInfo = localStorage.getItem('propertyUserInfo');
    return storedUserInfo ? JSON.parse(storedUserInfo) : null;
  } catch (error) {
    console.error("Error reading user info from localStorage:", error);
    return null;
  }
};

// Helper function to save user info to localStorage
const saveUserInfoToStorage = (userInfo) => {
  try {
    localStorage.setItem('propertyUserInfo', JSON.stringify(userInfo));
  } catch (error) {
    console.error("Error saving user info to localStorage:", error);
  }
};

export const PropertyListing = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const propertyIdFromUrl = searchParams.get('id');

  // --- Redux & RTK Query Hooks ---
  const { user, isAuthenticated } = useSelector((state) => state.auth);
  const [searchListings, { data: apiProperties, isLoading: isApiLoading, error: apiError }] = useSearchListingsMutation();
  const [manageRentalApplication, { isLoading: isManagingApp }] = useManageRentalApplicationMutation();
  const [manageViewingBooking, { isLoading: isBooking }] = useManageViewingBookingMutation();
  const [sendMessage, { isLoading: isSendingMessage }] = useSendMessageMutation();
  const [searchListingFaqs, { isLoading: isSearchingFaqs }] = useSearchListingFaqsMutation();
  const [ensureContact, { isLoading: isEnsuringContact }] = useEnsureContactMutation();
  const [getMessages, { data: messagesData, isLoading: isLoadingMessages }] = useLazyGetMessagesQuery();

  // --- Component State ---
  const [searchTerm, setSearchTerm] = useState('');
  const [properties, setProperties] = useState([]);
  const [filteredProperties, setFilteredProperties] = useState([]);
  const [selectedProperty, setSelectedProperty] = useState(null);

  // Get stored user info from localStorage first, then fallback to auth state
  const storedUserInfo = getUserInfoFromStorage();
  
  // Chat & Modal State
  const [isChatModalOpen, setChatModalOpen] = useState(false);
  const [isUserInfoModalOpen, setUserInfoModalOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatStep, setChatStep] = useState('initial');
  const [messageInput, setMessageInput] = useState('');
  const [userInfo, setUserInfo] = useState({ 
    firstName: storedUserInfo?.firstName || (isAuthenticated ? user?.first_name || '' : ''), 
    lastName: storedUserInfo?.lastName || (isAuthenticated ? user?.last_name || '' : ''), 
    email: storedUserInfo?.email || (isAuthenticated ? user?.email || '' : '') 
  });
  
  const [isLoadingChatHistory, setIsLoadingChatHistory] = useState(false);
  const [hasExistingChat, setHasExistingChat] = useState(false);
  const [hasFilledUserInfo, setHasFilledUserInfo] = useState(!!storedUserInfo || (isAuthenticated && !!user?.email));
  const [shouldStoreSystemMessages, setShouldStoreSystemMessages] = useState(true);
  const [ownerContactId, setOwnerContactId] = useState(null);
  const [userContactId, setUserContactId] = useState(null);
  const [currentConversationId, setCurrentConversationId] = useState(null);

  // --- Effects ---

  // Initial data load
  useEffect(() => {
    const loadListings = async () => {
      try {
        // If we have a property ID in the URL, search for that specific property
        if (propertyIdFromUrl) {
          await searchListings({ listing_id: propertyIdFromUrl }).unwrap();
        } else {
          // Otherwise load all properties
          await searchListings({ address: 'a' }).unwrap();
        }
      } catch (error) {
        console.error("Failed to fetch initial listings:", error);
      }
    };
    loadListings();

    // First try to get user info from localStorage
    const storedInfo = getUserInfoFromStorage();
    
    if (storedInfo) {
      setUserInfo({
        firstName: storedInfo.firstName || '',
        lastName: storedInfo.lastName || '',
        email: storedInfo.email || ''
      });
      setHasFilledUserInfo(!!storedInfo.email);
    } 
    // Fallback to auth state if no localStorage data but user is authenticated
    else if (isAuthenticated && user) {
      setUserInfo({
        firstName: user.first_name || '',
        lastName: user.last_name || '',
        email: user.email || ''
      });
      setHasFilledUserInfo(!!user.email);
      
      // Also save authenticated user info to localStorage for future visits
      if (user.email) {
        saveUserInfoToStorage({
          firstName: user.first_name || '',
          lastName: user.last_name || '',
          email: user.email || ''
        });
      }
    }
  }, [searchListings, isAuthenticated, user, propertyIdFromUrl]);

  // Process API data once it arrives
  useEffect(() => {
    if (apiProperties) {
      const mapped = apiProperties?.listing?.map(p => ({
        id: p.listing_id,
        propertyId: p.property_id,
        unitId: p.unit_id,
        name: p.name || 'Unnamed Property',
        address: p.address || 'No address provided',
        image: (p.property_images?.[0]?.image || p.unit_images?.[0]?.image || `https://placehold.co/600x400/E2E8F0/4A5568?text=${encodeURIComponent(p.name)}`),
        rent: p.price_per_month || 0,
        description: p.description || 'No description available.',
        details: {
          bedrooms: p.bedrooms || 2,
          bathrooms: p.bathrooms || 1,
          area: p.area ? `${p.area} sq ft` : 'N/A',
          status: p.is_available ? 'Available' : 'Not Available',
        },
        viewings: p.viewing || [],
        requirements: p.property_requirements || []
      }));
      setProperties(mapped);
      setFilteredProperties(mapped);
    }
  }, [apiProperties]);

  // --- Handlers ---

  const handleSearch = async () => {
    try {
      await searchListings({ address: searchTerm || 'a' }).unwrap();
    } catch (error) {
      console.error("Failed to execute search:", error);
    }
  };

  // Reset chat state function
  const resetChatState = () => {
    setChatMessages([]);
    setChatStep('initial');
    setMessageInput('');
    setCurrentConversationId(null);
    setUserContactId(null);
    setOwnerContactId(null);
    setIsLoadingChatHistory(false);
    setHasExistingChat(false);
    setSelectedProperty(null);
  };

  const addMessage = async (sender, text, buttons = null, directIds = null) => {
    // First add the message to UI
    const newMessage = { id: Date.now() + Math.random(), sender, text, buttons };
    setChatMessages(prev => [...prev, newMessage]);

    // Only proceed with API call if we have all required IDs
    if (!selectedProperty) return;

    // Get IDs from directIds if provided, otherwise from state
    // Use optional chaining to avoid reference errors
    const conversationId = directIds?.conversationId || currentConversationId;
    const senderOwnerContactId = directIds?.ownerContactId || ownerContactId;
    const senderUserContactId = directIds?.userContactId || userContactId;

    // Only proceed if we have all required IDs
    if (!conversationId || !senderOwnerContactId || !senderUserContactId) return;

    // For system messages
    if (sender === 'system' && shouldStoreSystemMessages) {
      try {
        // If there are buttons, encode them in the message with a special prefix
        let messageToStore = text;
        if (buttons && buttons.length > 0) {
          const buttonsJson = JSON.stringify(buttons);
          messageToStore = `${text}\n\n__BUTTONS__${buttonsJson}`;
        }

        const result = await sendMessage({
          listing_id: selectedProperty.id,
          sender_id: senderOwnerContactId,
          recipient_contact_id: senderUserContactId,
          message: messageToStore,
          conversation_id: conversationId,
          user_type: 'system'
        }).unwrap();
      } catch (error) {
        console.error("Failed to store system message:", error);
      }
    }
    // For user messages
    else if (sender === 'user') {
      try {
        const result = await sendMessage({
          listing_id: selectedProperty.id,
          sender_id: senderUserContactId,
          recipient_contact_id: senderOwnerContactId,
          message: text,
          conversation_id: conversationId,
          user_type: 'guest'
        }).unwrap();
      } catch (error) {
        console.error("Failed to store user message:", error);
      }
    }
  };

  // Step 1: User clicks "Inquire Now"
  const handleInquiryStart = async (property) => {
    setSelectedProperty(property);
    setChatMessages([]);
    setChatModalOpen(true);

    // Create welcome message with buttons
    const welcomeText = `Welcome! You are inquiring about "${property.name}".\n\nClick the button below to start.`;
    const buttons = [{ text: 'Inquire About Availability', action: 'start' }];

    const newMessage = {
      id: Date.now() + Math.random(),
      sender: 'system',
      text: welcomeText,
      buttons: buttons
    };
    setChatMessages([newMessage]);

    // If we already have conversation details, store this message
    if (currentConversationId && ownerContactId && userContactId) {
      try {
        const buttonsJson = JSON.stringify(buttons);
        const messageToStore = `${welcomeText}\n\n__BUTTONS__${buttonsJson}`;

        await sendMessage({
          listing_id: property.id,
          sender_id: ownerContactId,
          recipient_contact_id: userContactId,
          message: messageToStore,
          conversation_id: currentConversationId,
          user_type: 'system'
        }).unwrap();
      } catch (error) {
        console.error("Failed to store welcome message:", error);
      }
    }

    setChatStep('initial');
  };

  // Step 2: User clicks "Inquire About Availability"
  const handleInitialInquiry = async () => {
    // First check if we already have user info in localStorage
    const storedInfo = getUserInfoFromStorage();
    
    if (storedInfo && storedInfo.email) {
      // Use stored info and proceed without showing the form
      setUserInfo({
        firstName: storedInfo.firstName || '',
        lastName: storedInfo.lastName || '',
        email: storedInfo.email || '',
      });
      setHasFilledUserInfo(true);
      
      // Skip the form and process the user info directly
      processUserInfo();
    }
    // Fallback to authenticated user if available
    else if (isAuthenticated && user && user.email) {
      setUserInfo({
        firstName: user.first_name || '',
        lastName: user.last_name || '',
        email: user.email || '',
      });
      setHasFilledUserInfo(true);
      
      // Skip the form and process the user info directly
      processUserInfo();
    }
    // No user info available, show the form
    else {
      setChatStep('collectingUserInfo');
      setUserInfoModalOpen(true);
    }
  };

  // Step 3: User submits their details
  const handleUserInfoSubmit = async (e) => {
    e.preventDefault();
    if (isSendingMessage) return;

    processUserInfo();
  };

  // Separate the logic to process user info into its own function
  const processUserInfo = async () => {
    try {
      setUserInfoModalOpen(false);
      setHasFilledUserInfo(true);
      
      // Save user info to localStorage for future use
      saveUserInfoToStorage(userInfo);

      // First ensure contact exists and get IDs
      const contactResult = await ensureContact({
        listing_id: selectedProperty.id,
        email: userInfo.email,
        first_name: userInfo.firstName,
        last_name: userInfo.lastName
      }).unwrap();

      // Extract contact data
      const contactData = contactResult?.data || {};
      const exists = contactData.exists || false;
      const user_contact_id = contactData.user_contact_id;
      const owner_contact_id = contactData.owner_contact_id;
      const conversation_id = contactData.conversation_id;
      const has_conversation = contactData.has_conversation || false;

      // Store these IDs in state for future use
      if (user_contact_id) setUserContactId(user_contact_id);
      if (owner_contact_id) setOwnerContactId(owner_contact_id);
      if (conversation_id) setCurrentConversationId(conversation_id);
      setHasExistingChat(has_conversation);

      // If contact exists, handle accordingly
      if (exists) {
        try {
          setIsLoadingChatHistory(true);

          // If there's a conversation ID, fetch messages
          if (conversation_id) {
            // Fetch messages for this conversation
            const messagesResult = await getMessages({
              conversationId: conversation_id,
              user_type: user?.type || 'guest',
              limit: 50
            }).unwrap();

            // Handle both array and object with results property
            const messageArray = Array.isArray(messagesResult) ? messagesResult :
              (messagesResult && messagesResult.results ? messagesResult.results : []);

            if (messageArray && messageArray.length > 0) {
              // Format messages
              const formattedMessages = messageArray.map(item => {
                const messageData = item.message_data || item;
                const isUser = messageData.senderContactId === user_contact_id || messageData.sender_id === user_contact_id;

                // Extract message text and buttons if they exist
                let messageText = messageData.message || messageData.content;
                let buttons = null;

                // Check if message contains encoded buttons
                if (messageText && messageText.includes('__BUTTONS__')) {
                  const parts = messageText.split('__BUTTONS__');
                  messageText = parts[0].trim(); // The actual message text
                  try {
                    // Parse the JSON buttons
                    buttons = JSON.parse(parts[1]);
                  } catch (error) {
                    console.error('Failed to parse buttons from message:', error);
                  }
                }

                return {
                  id: messageData.id || messageData.messageId,
                  sender: isUser ? 'user' : 'system',
                  text: messageText,
                  buttons: buttons,
                  timestamp: new Date(messageData.createdAt || messageData.created_at).getTime()
                };
              });

              // Sort by date (oldest first)
              const sortedMessages = formattedMessages.sort((a, b) => a.timestamp - b.timestamp);

              // Add historical messages to chat (with buttons if they exist)
              setChatMessages(prev => [
                ...prev,
                ...sortedMessages
              ]);
            }

            // Set chat step to open chat since we have a conversation
            setChatStep('openChat');
          } else {
            // If no conversation exists, create one by sending initial message
            const initialMessage = `Inquiry for listing #${selectedProperty.id}: ${selectedProperty.name}`;

            // First add the user message to UI only
            const userMsg = {
              id: Date.now() + Math.random(),
              sender: 'user',
              text: initialMessage,
              buttons: null
            };
            setChatMessages(prev => [...prev, userMsg]);

            try {
              // Then send to API with direct IDs
              const result = await sendMessage({
                listing_id: selectedProperty.id,
                email: userInfo.email,
                first_name: userInfo.firstName,
                last_name: userInfo.lastName,
                user_type: isAuthenticated ? user?.type : 'guest',
                message: initialMessage,
                sender_id: user_contact_id,
                recipient_contact_id: owner_contact_id
              }).unwrap();

              // Extract IDs directly from response
              const newConversationId = result.data?.conversationId || result.conversation_id;
              const newUserContactId = result.data?.user_contact_id || result.user_contact_id;
              const newOwnerContactId = result.data?.owner_contact_id || result.owner_contact_id;

              // Update state for future use
              if (newConversationId) setCurrentConversationId(newConversationId);
              if (newUserContactId) setUserContactId(newUserContactId);
              if (newOwnerContactId) setOwnerContactId(newOwnerContactId);

              // Now check if the property has requirements and show them
              if (selectedProperty.requirements && selectedProperty.requirements.length > 0) {
                let reqMessage = "This property has the following requirements:\n\n";
                selectedProperty.requirements.forEach(req => {
                  reqMessage += `• ${req.label}: ${req.description}\n`;
                });
                reqMessage += "\nAre you interested in this property?";

                const buttons = [
                  { text: "Yes, I'm Interested", action: 'interest_yes' },
                  { text: "No, Just Inquiring", action: 'interest_no' }
                ];

                const reqMsg = {
                  id: Date.now() + Math.random(),
                  sender: 'system',
                  text: reqMessage,
                  buttons: buttons
                };
                setChatMessages(prev => [...prev, reqMsg]);

                // Also send to backend (with encoded buttons)
                const buttonsJson = JSON.stringify(buttons);
                const messageToStore = `${reqMessage}\n\n__BUTTONS__${buttonsJson}`;

                await sendMessage({
                  listing_id: selectedProperty.id,
                  sender_id: newOwnerContactId,
                  recipient_contact_id: newUserContactId,
                  message: messageToStore,
                  conversation_id: newConversationId,
                  user_type: 'system'
                }).unwrap();
              } else {
                const buttons = [
                  { text: "Yes, I'm Interested", action: 'interest_yes' },
                  { text: "No, Just Inquiring", action: 'interest_no' }
                ];

                const viewingMsg = {
                  id: Date.now() + Math.random(),
                  sender: 'system',
                  text: `Thanks, ${userInfo.firstName}! Are you interested in scheduling a viewing?`,
                  buttons: buttons
                };
                setChatMessages(prev => [...prev, viewingMsg]);

                // Also send to backend (with encoded buttons)
                const buttonsJson = JSON.stringify(buttons);
                const messageToStore = `${viewingMsg.text}\n\n__BUTTONS__${buttonsJson}`;

                await sendMessage({
                  listing_id: selectedProperty.id,
                  sender_id: newOwnerContactId,
                  recipient_contact_id: newUserContactId,
                  message: messageToStore,
                  conversation_id: newConversationId,
                  user_type: 'system'
                }).unwrap();
              }

              setChatStep('interestCheck');
            } catch (error) {
              console.error("Failed to send initial inquiry message:", error);
              toast.error("Could not send your inquiry. Please try again.");
              setChatStep('openChat');
            }
          }

          setIsLoadingChatHistory(false);

        } catch (error) {
          console.error("Failed to handle existing contact:", error);
          setIsLoadingChatHistory(false);
          // Still go to open chat for existing contacts even if there's an error
          setChatStep('openChat');
        }
      } else {
        // No contact found, create one by sending first message
        try {
          // Send the initial inquiry message
          const initialMessage = `Inquiry for listing #${selectedProperty.id}: ${selectedProperty.name}`;

          // First add the user message to UI only
          const userMsg = {
            id: Date.now() + Math.random(),
            sender: 'user',
            text: initialMessage,
            buttons: null
          };
          setChatMessages(prev => [...prev, userMsg]);

          // Then send to API
          try {
            const result = await sendMessage({
              listing_id: selectedProperty.id,
              email: userInfo.email,
              first_name: userInfo.firstName,
              last_name: userInfo.lastName,
              user_type: isAuthenticated ? user?.type : 'guest',
              message: initialMessage
            }).unwrap();

            // Extract IDs directly from response
            const newConversationId = result.data?.conversationId || result.conversation_id;
            const newUserContactId = result.data?.user_contact_id || result.user_contact_id;
            const newOwnerContactId = result.data?.owner_contact_id || result.owner_contact_id;

            // Update state for future use
            if (newConversationId) setCurrentConversationId(newConversationId);
            if (newUserContactId) setUserContactId(newUserContactId);
            if (newOwnerContactId) setOwnerContactId(newOwnerContactId);

            // Now check if the property has requirements and show them
            if (selectedProperty.requirements && selectedProperty.requirements.length > 0) {
              let reqMessage = "This property has the following requirements:\n\n";
              selectedProperty.requirements.forEach(req => {
                reqMessage += `• ${req.label}: ${req.description}\n`;
              });
              reqMessage += "\nAre you interested in this property?";

              const buttons = [
                { text: "Yes, I'm Interested", action: 'interest_yes' },
                { text: "No, Just Inquiring", action: 'interest_no' }
              ];

              const reqMsg = {
                id: Date.now() + Math.random(),
                sender: 'system',
                text: reqMessage,
                buttons: buttons
              };
              setChatMessages(prev => [...prev, reqMsg]);

              // Also send to backend (with encoded buttons)
              const buttonsJson = JSON.stringify(buttons);
              const messageToStore = `${reqMessage}\n\n__BUTTONS__${buttonsJson}`;

              await sendMessage({
                listing_id: selectedProperty.id,
                sender_id: newOwnerContactId,
                recipient_contact_id: newUserContactId,
                message: messageToStore,
                conversation_id: newConversationId,
                user_type: 'system'
              }).unwrap();
            } else {
              const buttons = [
                { text: "Yes, I'm Interested", action: 'interest_yes' },
                { text: "No, Just Inquiring", action: 'interest_no' }
              ];

              const viewingMsg = {
                id: Date.now() + Math.random(),
                sender: 'system',
                text: `Thanks, ${userInfo.firstName}! Are you interested in scheduling a viewing?`,
                buttons: buttons
              };
              setChatMessages(prev => [...prev, viewingMsg]);

              // Also send to backend (with encoded buttons)
              const buttonsJson = JSON.stringify(buttons);
              const messageToStore = `${viewingMsg.text}\n\n__BUTTONS__${buttonsJson}`;

              await sendMessage({
                listing_id: selectedProperty.id,
                sender_id: newOwnerContactId,
                recipient_contact_id: newUserContactId,
                message: messageToStore,
                conversation_id: newConversationId,
                user_type: 'system'
              }).unwrap();
            }

            setChatStep('interestCheck');
          } catch (error) {
            console.error("Failed to send initial inquiry message:", error);
            toast.error("Could not send your inquiry. Please try again.");
            setChatStep('openChat');
          }
        } catch (error) {
          console.error("Failed to send initial inquiry message:", error);
          toast.error("Could not send your inquiry. Please try again.");
          setChatStep('openChat');
        }
      }
    } catch (error) {
      console.error('Failed to manage contact:', error);
      toast.error('Could not process your contact information. Please try again later.');

      // Add error message to chat
      const errorMsg = {
        id: Date.now() + Math.random(),
        sender: 'system',
        text: 'Sorry, there was an error processing your request. Please try again later.',
        buttons: null
      };
      setChatMessages(prev => [...prev, errorMsg]);

      setChatStep('openChat');
    }
  };

  // Step 4: User expresses interest
  const handleInterestCheck = async (interested) => {
    if (interested) {
      await addMessage('user', "Yes, I'm Interested");
      try {
        await manageRentalApplication({
          action: 'insert',
          listing_id: selectedProperty.id,
          property_id: selectedProperty.propertyId,
          unit_id: selectedProperty.unitId,
          status: 1,
          applicant: {
            full_name: `${userInfo.firstName} ${userInfo.lastName}`,
            email: userInfo.email
          },
          message: 'User expressed interest via chat.'
        }).unwrap();

        // Check if property has viewing slots
        if (selectedProperty.viewings && selectedProperty.viewings.length > 0) {
          const formattedViewings = selectedProperty.viewings.map(v => ({
            text: `${v.scheduled_date} at ${v.start_time} - ${v.end_time}`,
            action: 'book_viewing',
            payload: {
              id: v.id,
              scheduled_date: v.scheduled_date,
              start_time: v.start_time,
              end_time: v.end_time,
              location: v.location
            }
          }));

          await addMessage('system', 'Excellent! Please select an available viewing time:',
            formattedViewings
          );
          setChatStep('booking');
        } else {
          await addMessage('system', "Thank you for your interest!\nOur agent will contact you soon to arrange a viewing time that works for you.\n\nIn the meantime, feel free to ask any questions you might have about the property.");
          setChatStep('openChat');
        }

      } catch (error) {
        console.error("Failed to manage rental application:", error);
        toast.error("Could not register your interest. Please try again later.");
        await addMessage('system', 'Sorry, an error occurred. Feel free to ask any other questions you may have.');
        setChatStep('openChat');
      }
    } else {
      await addMessage('user', "No, Just Enquiring");
      await addMessage('system', 'Thank you for your inquiry. Feel free to ask any questions you have about this property.');
      setChatStep('openChat');
    }
  };

  // Step 5: User books a viewing
  const handleBooking = async (viewingData) => {
    const viewingSlot = `${viewingData.scheduled_date} at ${viewingData.start_time} - ${viewingData.end_time}`;
    await addMessage('user', `I'd like to book: ${viewingSlot}`);
    try {
      await manageViewingBooking({
        action: 'insert',
        viewing_id: viewingData.id,
        applicant: {
          full_name: `${userInfo.firstName} ${userInfo.lastName}`,
          email: userInfo.email
        },
        status: 'confirmed',
        message: 'Booking confirmed via chat.'
      }).unwrap();

      await addMessage('system', `Excellent! Your viewing is confirmed for ${viewingSlot} at ${viewingData.location}${viewingData.notes ? '. ' + viewingData.notes : ''}.\n\nWe look forward to seeing you! Feel free to ask any other questions about the property.`);
      toast.success(`Viewing booked successfully for ${viewingSlot}`);
      setChatStep('openChat');
    } catch (error) {
      console.error("Failed to book viewing:", error);
      toast.error("Could not book viewing. Please try another time or contact the agent directly.");
      await addMessage('system', 'Sorry, we couldn\'t confirm that booking. Please try another time or contact the agent directly.');
      setChatStep('openChat');
    }
  };

  // Handle sending messages in the chat
  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!messageInput.trim() || isSendingMessage) return;

    const messageText = messageInput;
    setMessageInput('');

    try {
      // First add the user message to UI only
      const userMsg = {
        id: Date.now() + Math.random(),
        sender: 'user',
        text: messageText,
        buttons: null
      };
      setChatMessages(prev => [...prev, userMsg]);

      // Create message payload
      const messagePayload = {
        listing_id: selectedProperty.id,
        message: messageText,
        user_type: isAuthenticated ? user?.type : 'guest',
      };

      // If we have user info, include it
      if (userInfo.email) {
        messagePayload.email = userInfo.email;
        messagePayload.first_name = userInfo.firstName;
        messagePayload.last_name = userInfo.lastName;
      }

      // If we have contact IDs, include them
      if (userContactId) {
        messagePayload.sender_id = userContactId;
      }

      if (ownerContactId) {
        messagePayload.recipient_contact_id = ownerContactId;
      }

      // If we have a conversation ID, include it
      if (currentConversationId) {
        messagePayload.conversation_id = currentConversationId;
      }

      // Send to API
      const result = await sendMessage(messagePayload).unwrap();

      // Extract IDs directly from the response
      const newConversationId = result.data?.conversationId || result.conversation_id;
      const newUserContactId = result.data?.user_contact_id || result.user_contact_id;
      const newOwnerContactId = result.data?.owner_contact_id || result.owner_contact_id;

      // Update state for future use
      if (newConversationId) setCurrentConversationId(newConversationId);
      if (newUserContactId) setUserContactId(newUserContactId);
      if (newOwnerContactId) setOwnerContactId(newOwnerContactId);
      
      // Now search for relevant FAQs using our AI endpoint
      try {
        // Set a temporary "typing" message
        const typingMsgId = Date.now() + Math.random();
        setChatMessages(prev => [
          ...prev, 
          { 
            id: typingMsgId, 
            sender: 'system', 
            text: "Searching for relevant information...", 
            isTyping: true 
          }
        ]);
        
        // Call the FAQ search API
        const faqResponse = await searchListingFaqs({
          listingId: selectedProperty.id,
          query: messageText
        }).unwrap();
        
        // Remove the typing indicator
        setChatMessages(prev => prev.filter(msg => msg.id !== typingMsgId));
        
        // Add a system message with the response
        const faqMsg = {
          id: Date.now() + Math.random(),
          sender: 'system',
          text: faqResponse?.message,
        };
        setChatMessages(prev => [...prev, faqMsg]);
        
        // Also store this message if we have the required IDs
        if (newConversationId && newOwnerContactId && newUserContactId) {
          await sendMessage({
            listing_id: selectedProperty.id,
            sender_id: newOwnerContactId,
            recipient_contact_id: newUserContactId,
            message: faqResponse?.message,
            conversation_id: newConversationId,
            user_type: 'system'
          }).unwrap();
        }
      } catch (faqError) {
        console.error("Failed to search FAQs:", faqError);
        // We don't need to show an error to the user since this is a supplementary feature
      }

    } catch (error) {
      console.error("Failed to send message:", error);
      toast.error("Could not send message. Please try again.");

      // Add error message to chat
      const errorMsg = {
        id: Date.now() + Math.random(),
        sender: 'system',
        text: 'Error: Could not send message. Please try again.',
        buttons: null
      };
      setChatMessages(prev => [...prev, errorMsg]);

      setMessageInput(messageText);
    }
  };

  const handleChatButtonClick = async (button) => {
    setChatMessages(prev => prev.map(msg => ({ ...msg, buttons: null })));

    switch (button.action) {
      case 'start':
        await handleInitialInquiry();
        break;
      case 'interest_yes':
        await handleInterestCheck(true);
        break;
      case 'interest_no':
        await handleInterestCheck(false);
        break;
      case 'book_viewing':
        await handleBooking(button.payload);
        break;
      default:
        break;
    }
  };

  // --- Render ---
  return (
    <>
      <style>{pageStyles}</style>
      <Container fluid className="py-5 bg-light">
        {/* Hero Search Section */}
        <Row className="mb-5 justify-content-center">
          <Col lg={10} md={11}>
            <div className="search-container p-4 p-md-5 bg-white">
              <h2 className="mb-3 fw-bold text-center"><FaHome className="me-2 text-primary" /> Find Your Dream Property</h2>
              <p className="text-muted mb-4 text-center">Browse our selection of premium properties available for rent.</p>
              <InputGroup className="mb-3 search-bar">
                <InputGroup.Text className="bg-transparent border-0 ps-4">
                  <FaMapMarkerAlt className="text-muted" />
                </InputGroup.Text>
                <Form.Control
                  placeholder="Search by location or property name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  className="border-0 shadow-none py-3"
                />
                <Button
                  variant="primary"
                  className="search-btn fw-semibold"
                  onClick={handleSearch}
                  disabled={isApiLoading}
                >
                  {isApiLoading ? <Spinner as="span" animation="border" size="sm" /> : 'Search'}
                </Button>
              </InputGroup>
            </div>
          </Col>
        </Row>

        {/* Properties Grid */}
        <Row className="justify-content-center">
          <Col lg={11}>
            {isApiLoading && properties?.length === 0 ? (
              <div className="loading-state">
                <Spinner animation="border" variant="primary" style={{ width: '3rem', height: '3rem' }} />
                <p className="mt-4 text-muted">Discovering available properties...</p>
              </div>
            ) : apiError ? (
              <div className="error-state">
                <FaTimesCircle className="error-state-icon text-danger" />
                <h4 className="mt-2 fw-bold">Error loading properties</h4>
                <p className="text-muted">{apiError.data?.error || 'Please try again later.'}</p>
              </div>
            ) : filteredProperties?.length === 0 ? (
              <div className="empty-state">
                <FaSearchLocation className="empty-state-icon text-muted" />
                <h4 className="mt-2 fw-bold">No properties found</h4>
                <p className="text-muted">Try adjusting your search criteria or try a different location.</p>
              </div>
            ) : (
              <Row className="g-4">
                {filteredProperties?.map((property) => (
                  <Col key={property.id} lg={4} md={6} sm={12}>
                    <PropertyListingCard 
                      property={property} 
                      onInquireClick={handleInquiryStart} 
                    />
                  </Col>
                ))}
              </Row>
            )}
          </Col>
        </Row>
      </Container>

      {/* Chat Modal - Using our component */}
      <PropertyChat
        show={isChatModalOpen}
        onHide={() => setChatModalOpen(false)}
        propertyName={selectedProperty?.name}
        chatMessages={chatMessages}
        chatStep={chatStep}
        messageInput={messageInput}
        onMessageInputChange={setMessageInput}
        onSendMessage={handleSendMessage}
        isLoadingChatHistory={isLoadingChatHistory}
        isSendingMessage={isSendingMessage}
        onButtonClick={handleChatButtonClick}
        resetChat={resetChatState}
      />

      {/* User Info Modal - Using our component */}
      <PropertyContactForm
        show={isUserInfoModalOpen}
        onHide={() => {
          setUserInfoModalOpen(false);
          if (!hasFilledUserInfo) {
            setChatStep('initial');
          }
        }}
        userInfo={userInfo}
        onUserInfoChange={setUserInfo}
        onSubmit={handleUserInfoSubmit}
        isSubmitting={isSendingMessage}
        hasFilledUserInfo={hasFilledUserInfo}
      />
    </>
  );
};


