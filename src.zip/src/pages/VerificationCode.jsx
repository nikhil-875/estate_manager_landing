import React, { useState, useRef, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Card, Button, Form, Alert, Container, Row, Col } from "react-bootstrap";
import { motion } from "framer-motion";
import { FaArrowLeft, FaCheckCircle } from "react-icons/fa";
import { useVerifyAccountMutation, useResendActivationTokenMutation } from "../api/authApi";
import { useSelector } from "react-redux";

export const VerificationCode = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const user = useSelector(state => state.auth.user);
    const email = user?.email;
    const { phoneNumber, verificationMethod = "whatsapp" } = location.state || {};
    const [verifyUser, { isLoading: isVerifying }] = useVerifyAccountMutation();
    const [resendActivationToken, { isLoading: isResending }] = useResendActivationTokenMutation();

    const [verificationCode, setVerificationCode] = useState(["", "", "", "", "", ""]);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState(false);
    const [resendDisabled, setResendDisabled] = useState(false);
    const [countdown, setCountdown] = useState(0);

    const inputRefs = useRef([]);

    // Use useEffect to handle navigation
    useEffect(() => {
        if (!phoneNumber) {
            navigate("/register");
        }
    }, [phoneNumber, navigate]);

    useEffect(() => {
        // Focus on first input when component mounts
        if (inputRefs.current[0]) {
            inputRefs.current[0].focus();
        }

        // Handle countdown for resend button
        let timer;
        if (countdown > 0) {
            timer = setTimeout(() => setCountdown(countdown - 1), 1000);
        } else {
            setResendDisabled(false);
        }

        return () => {
            if (timer) clearTimeout(timer);
        };
    }, [countdown]);

    // If no phoneNumber is provided, render nothing until the useEffect redirects
    if (!phoneNumber) {
        return null;
    }

    const handleInputChange = (index, value) => {
        // Only allow digits
        if (!/^\d*$/.test(value)) return;

        // Update the verification code array
        const newCode = [...verificationCode];
        newCode[index] = value;
        setVerificationCode(newCode);

        // Auto-focus to next input if value is entered
        if (value && index < 5 && inputRefs.current[index + 1]) {
            inputRefs.current[index + 1].focus();
        }
    };

    const handleKeyDown = (index, e) => {
        // Move to previous input on backspace if current input is empty
        if (e.key === "Backspace" && !verificationCode[index] && index > 0) {
            inputRefs.current[index - 1].focus();
        }
    };

    const handlePaste = (e) => {
        e.preventDefault();
        const pastedData = e.clipboardData.getData("text/plain").trim();

        // Check if pasted content is a 6-digit number
        if (/^\d{6}$/.test(pastedData)) {
            const digits = pastedData.split("");
            setVerificationCode(digits);

            // Focus on the last input
            if (inputRefs.current[5]) {
                inputRefs.current[5].focus();
            }
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");

        const code = verificationCode.join("");

        if (code.length !== 6) {
            setError("Please enter the complete 6-digit verification code");
            return;
        }

        setIsSubmitting(true);

        try {
            // Call API to verify the code using RTK Query
            const response = await verifyUser({
                phoneNumber: phoneNumber,
                verification_code: code
            }).unwrap();

            console.log(response);
            if (response.status_code === 200) {
                setSuccess(true);

                // Redirect to login page after 2 seconds
                setTimeout(() => {
                    navigate("/dashboard", {
                        state: { message: "Account verified successfully! You can now log in." }
                    });
                }, 2000);
            } else {
                throw new Error(response.message || "Invalid verification code. Please try again.");
            }
        } catch (err) {
            console.error("Error:", err);

            if (err.data?.message) {
                setError(err.data.message);
            } else if (err.message) {
                setError(err.message);
            } else {
                setError("An unexpected error occurred. Please try again.");
            }
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleResendCode = async () => {
        setError("");
        setResendDisabled(true);
        setCountdown(60); // 60 seconds cooldown

        try {
            // Call API to resend verification code using RTK Query
            const response = await resendActivationToken({
                phoneNumber: phoneNumber,
            }).unwrap();

            if (!response.success) {
                throw new Error(response.message || "Failed to resend verification code. Please try again.");
            }
        } catch (err) {
            console.error("Error:", err);

            if (err.data?.message) {
                setError(err.data.message);
            } else if (err.message) {
                setError(err.message);
            } else {
                setError("An unexpected error occurred. Please try again.");
            }

            // Reset countdown if there was an error
            setCountdown(0);
            setResendDisabled(false);
        }
    };

    const goBack = () => {
        navigate(-1);
    };

    return (
        <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: "100vh" }}>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                style={{ width: "100%", maxWidth: "450px" }}
            >
                <Card className="shadow-lg border-0 rounded-4 overflow-hidden">
                    <Card.Body className="p-5">
                        {!success && (
                            <Button
                                variant="link"
                                className="p-0 mb-4 text-decoration-none"
                                onClick={goBack}
                            >
                                <FaArrowLeft className="me-2" /> Back
                            </Button>
                        )}

                        <div className="text-center mb-4">
                            <h2 className="fw-bold mb-2">
                                {success ? "Verification Successful" : "Verification Code"}
                            </h2>
                            <p className="text-muted">
                                {success
                                    ? "Your account has been verified successfully!"
                                    : `Enter the 6-digit code sent to your ${verificationMethod === "whatsapp" ? "WhatsApp" : "email"}`}
                            </p>
                        </div>

                        {error && (
                            <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                transition={{ duration: 0.3 }}
                            >
                                <Alert variant="danger" className="mb-4">
                                    {error}
                                </Alert>
                            </motion.div>
                        )}

                        {success ? (
                            <div className="text-center py-4">
                                <FaCheckCircle className="text-success mb-3" size={60} />
                                <p>Redirecting to login page...</p>
                            </div>
                        ) : (
                            <Form onSubmit={handleSubmit}>
                                <Form.Group className="mb-4">
                                    <Row className="g-2 justify-content-center">
                                        {verificationCode.map((digit, index) => (
                                            <Col key={index} xs={2}>
                                                <Form.Control
                                                    ref={el => inputRefs.current[index] = el}
                                                    type="text"
                                                    maxLength={1}
                                                    value={digit}
                                                    onChange={(e) => handleInputChange(index, e.target.value)}
                                                    onKeyDown={(e) => handleKeyDown(index, e)}
                                                    onPaste={index === 0 ? handlePaste : undefined}
                                                    className="form-control-lg text-center"
                                                    style={{
                                                        width: '100%',
                                                        height: '60px',
                                                        fontSize: '1.5rem'
                                                    }}
                                                    disabled={isSubmitting || isVerifying}
                                                />
                                            </Col>
                                        ))}
                                    </Row>
                                </Form.Group>

                                <Button
                                    variant="primary"
                                    type="submit"
                                    className="w-100 py-2 mb-3"
                                    disabled={isSubmitting || isVerifying}
                                >
                                    {(isSubmitting || isVerifying) ? (
                                        <>
                                            <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                            Verifying...
                                        </>
                                    ) : (
                                        "Verify Code"
                                    )}
                                </Button>

                                <div className="d-flex justify-content-center flex-column align-items-center">
                                    <div className="mb-2">
                                        <Button
                                            variant="link"
                                            className="text-decoration-none p-0"
                                            onClick={handleResendCode}
                                            disabled={resendDisabled || isResending}
                                        >
                                            {isResending ? (
                                                <>
                                                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                                    Sending...
                                                </>
                                            ) : resendDisabled ? (
                                                `Resend code in ${countdown}s`
                                            ) : (
                                                "Didn't receive a code? Resend"
                                            )}
                                        </Button>
                                    </div>
                                </div>
                            </Form>
                        )}
                    </Card.Body>
                </Card>
            </motion.div>
        </Container>
    );
};
