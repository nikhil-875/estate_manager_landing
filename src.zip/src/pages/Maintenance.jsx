// src/pages/Maintenance.jsx

import { useSelector } from "react-redux";
import OwnersMaintenance from "./OwnersMaintenance";
import ContractorMaintenance from "./ContractorMaintenance";
import TenantMaintenance from "./TenantMaintenance";

export const Maintenance = () => {
  const role = useSelector((state) => state.auth.user?.type);

  switch (role) {
    case "owner":
      return <OwnersMaintenance />;
    case "manager":
      return <OwnersMaintenance />;
    case "maintainer":
      return <ContractorMaintenance />;
    case "tenant":
      return <TenantMaintenance />;
    default:
      return <div>Access denied or role not recognized.</div>;
  }
};
