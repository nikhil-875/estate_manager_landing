import React from 'react';

export const Customers = () => {
  return (
    <div className="row">
      {/* Welcome Card */}
      <div className="col-sm-8">
        <div className="card alert alert-primary p-1">
          <div className="card-body pb-0 total-sells">
            <div className="d-flex align-items-center gap-3">
              <div className="social-img-wrap">
                <div className="social-img cust-profile">
                  <img src="" alt="profile" />
                </div>
              </div>
              <div className="flex-grow-1">
                <h2 className="text-white">Welcome back</h2>
                <p className="text-white">John Doe</p>
              </div>
            </div>
            <hr />
            <div className="d-flex align-items-center gap-3">
              <p className="btn button-light bg-light p-2 text-primary">
                <i data-feather="users"></i>
              </p>
              <div className="flex-grow-1">
                <h2 className="text-white">10</h2>
                <p className="text-white">Total Customers</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Create User Card */}
      <div className="col-sm-4">
        <div className="card social-profile">
          <div className="card-body">
            <div className="social-img-wrap">
              <div className="social-img cust-profile">
                <img src="" alt="profile" />
              </div>
            </div>
            <div className="social-details">
              <h5 className="mb-1">Customers</h5>
              <div className="col-auto">
                <a href="#" className="btn btn-primary">
                  Create Customers
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* User Table */}
      <div className="col-sm-12">
        <div className="card">
          <div className="card-header">
            <h5>User List</h5>
          </div>
          <div className="card-body">
            <div className="table-responsive theme-scrollbar">
              <table className="table light-card">
                <thead>
                  <tr>
                    <th>User</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Assign Role</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="table-user">
                      <img
                        src=""
                        alt=""
                        className="mr-2 avatar-sm rounded-circle user-avatar"
                      />
                      <a href="#" className="text-body font-weight-semibold">
                        Jane Smith
                      </a>
                    </td>
                    <td>jane@example.com</td>
                    <td>+1234567890</td>
                    <td>Admin</td>
                    <td>
                      <ul className="action d-flex gap-2">
                        <a href="#" className="text-warning">
                          <i className="icon-eye"></i>
                        </a>
                        <a href="#" className="text-success">
                          <i className="icon-pencil-alt"></i>
                        </a>
                        <a href="#" className="text-danger">
                          <i className="icon-trash"></i>
                        </a>
                        <a href="#" className="text-info">
                          <i className="icon-shift-right"></i>
                        </a>
                      </ul>
                    </td>
                  </tr>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

