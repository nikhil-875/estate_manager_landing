// src/pages/Listing.jsx

import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import {
  Row, Col, Card, ListGroup, Badge, Modal,
  Button, Spinner,
} from 'react-bootstrap';
import {
  FaFileAlt, FaMoneyBillWave, FaEdit,
  FaUserCircle, FaTrashAlt
} from 'react-icons/fa';

import ListingWizard   from '../components/Listing/listingWizard';
import ChatWindow      from '../components/Listing/ChatWindow';
import {
  useGetListingsMutation,
  useInitiateListingMutation,
  useSendMessageMutation,
  useLazyGetMessagesQuery
} from '../api/listingApi';
import { useGetOwnerDetailsQuery } from '../api/owner';
import { toast } from 'react-toastify';

export function Listing() {
  // Redux user
  const user = useSelector(s => s.auth.user);
  const LOGGED_IN_USER_ID    = user?.id;
  const LOGGED_IN_USER_EMAIL = user?.email;

  // Owner state
  const { data: ownersList = [] } = useGetOwnerDetailsQuery();
  const [currentOwnerId, setCurrentOwnerId] = useState(LOGGED_IN_USER_ID);
  const [ownerOptions,   setOwnerOptions]   = useState([]);

  // Fetch properties
  const [getListings,
        { data: listings = [], isLoading, error }] = useGetListingsMutation();

  const listed    = listings.filter(p => p.listing_id !== null);
  const available = listings.filter(p => p.listing_id === null);

  // Initiate for edit
  const [initiateListing,
        { data: initData, isLoading: isInitiating }] = useInitiateListingMutation();

  // Chat API hooks
  const [sendMessage,
        { isLoading: isSendingMessage }] = useSendMessageMutation();
  const [getMessages,
        { isLoading: isLoadingMessages }] = useLazyGetMessagesQuery();

  // UI state
  const [filter,         setFilter]         = useState('listed');
  const [selectedRow,    setSelectedRow]    = useState(null);
  const [selectedKey,    setSelectedKey]    = useState(null);
  const [selectedTenant, setSelectedTenant] = useState(null);

  const [showInline,    setShowInline]    = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetails,   setShowDetails]   = useState(false);

  // Chat state
  const [chatMsgs,              setChatMsgs]            = useState([]);
  const [isChatLoading,         setIsChatLoading]       = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState(null);
  const [recipientContactId,    setRecipientContactId]    = useState(null);

  // Default tab
  useEffect(() => {
    if (!isLoading) {
      setFilter(listed.length > 0 ? 'listed' : 'available');
    }
  }, [isLoading, listed.length]);

  // Initialize currentOwnerId
  useEffect(() => {
    if (LOGGED_IN_USER_ID && !currentOwnerId) {
      setCurrentOwnerId(LOGGED_IN_USER_ID);
    }
  }, [LOGGED_IN_USER_ID]);

  // Generate owner options
  useEffect(() => {
    const opts = ownersList?.owners?.map(o => ({
      id:   o.id,
      name: o.company
    })) || [];

    if (!opts.some(o => o.id === LOGGED_IN_USER_ID) && LOGGED_IN_USER_ID) {
      opts.unshift({
        id:   LOGGED_IN_USER_ID,
        name: LOGGED_IN_USER_EMAIL || 'Current User'
      });
    }
    setOwnerOptions(opts);
  }, [ownersList, LOGGED_IN_USER_ID, LOGGED_IN_USER_EMAIL]);

  // Fetch listings when owner changes
  useEffect(() => {
    if (currentOwnerId) {
      getListings({ uid: currentOwnerId });
    }
  }, [currentOwnerId]);

  // Fetch conversation on tenant select
  useEffect(() => {
    if (selectedRow?.listing_id && selectedTenant) {
      fetchConversation();
    } else {
      setChatMsgs([]);
      setCurrentConversationId(null);
    }
  }, [selectedRow?.listing_id, selectedTenant]);

  // Helpers
  const truncate = (s, m = 30) =>
    !s ? '' : s.length > m ? `${s.slice(0, m)}…` : s;
  const rowKey = r =>
    r.listing_id != null
      ? `L-${r.listing_id}`
      : `A-${r.property.id}-${r.unit.id}`;

  const findConversationForListing = (convs, listingId) => {
    if (!convs?.length) return null;
    return convs.find(c => c.listing_id === listingId) || convs[0];
  };

  // Fetch conversation
  const fetchConversation = async () => {
    if (!selectedRow?.listing_id || !selectedTenant) return;

    try {
      setIsChatLoading(true);

      const conv = findConversationForListing(
        selectedTenant.conversations,
        selectedRow.listing_id
      );
      if (!conv) {
        setChatMsgs([]);
        setCurrentConversationId(null);
        return;
      }

      setCurrentConversationId(conv.conversation_id);
      setRecipientContactId(conv.recipient_contact_id);

      const res = await getMessages({
        conversationId: conv.conversation_id,
        uid:            currentOwnerId,
      }).unwrap();

      const arr = Array.isArray(res) ? res : (res.results || []);
      const msgs = arr.map(item => ({
        id:        item.message_data.id,
        sender:    item.message_data.senderContactId === conv.recipient_contact_id
                    ? selectedTenant.full_name
                    : 'You',
        msg:       item.message_data.message,
        date:      new Date(item.message_data.createdAt).toISOString().slice(0, 10),
        time:      new Date(item.message_data.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        timestamp: new Date(item.message_data.createdAt).getTime(),
        status:    item.message_data.status
      })).sort((a, b) => a.timestamp - b.timestamp);

      setChatMsgs(msgs);
    } catch (err) {
      console.error("Failed to fetch conversation:", err);
      toast.error("Could not load conversation history");
      setChatMsgs([]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Send message
  const sendMsg = async text => {
    if (!text.trim() || !selectedRow?.listing_id || !selectedTenant) return;

    const now   = new Date();
    const tempId = now.getTime();
    const tempMsg = {
      id:        tempId,
      sender:    'You',
      msg:       text,
      date:      now.toISOString().slice(0, 10),
      time:      now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timestamp: tempId,
      pending:   true
    };
    setChatMsgs(prev => [...prev, tempMsg]);

    try {
      await sendMessage({
        listing_id:         selectedRow.listing_id,
        uid:                currentOwnerId,
        email:              user?.email,
        message:            text,
        conversation_id:    currentConversationId,
        recipient_contact_id: recipientContactId,
      }).unwrap();

      // remove temp and refresh
      setChatMsgs(prev => prev.filter(m => m.id !== tempId));
      fetchConversation();
    } catch (err) {
      console.error("Failed to send message:", err);
      toast.error("Could not send message. Please try again.");
      setChatMsgs(prev =>
        prev.map(m =>
          m.id === tempId ? { ...m, pending: false, failed: true } : m
        )
      );
    }
  };

  // Owner dropdown + delete button
  const OwnerControl = () => (
    <div className="d-flex align-items-center gap-3">
      <label className="small fw-semibold mb-0">Owner</label>
      <select
        className="form-select form-select-sm bg-white"
        style={{
          width: '250px',      // increased width
          maxWidth: '100%',
          borderColor: '#ced4da',
          boxShadow: 'none'
        }}
        value={currentOwnerId}
        onChange={e => setCurrentOwnerId(e.target.value)}
        disabled={isLoading}
      >
        {ownerOptions.map(o => (
          <option key={o.id} value={o.id}>{o.name}</option>
        ))}
      </select>
      <button
        className="btn btn-sm"
        onClick={() => {
          // placeholder delete action
          console.log('Delete owner', currentOwnerId);
        }}
        title="Delete Owner"
        style={{
          color: 'red',
          border: 'none',
          background: 'transparent'
        }}
      >
        <FaTrashAlt />
      </button>
    </div>
  );

  // Row item
  function RowItem({ row }) {
    const key   = rowKey(row);
    const isSel = key === selectedKey;

    const onSelect = () => {
      let upd = { ...row };
      if (upd.applicants?.applicants?.length) {
        const sorted = [...upd.applicants.applicants].sort((a, b) => {
          const at = a.conversations?.[0]?.last_message_at;
          const bt = b.conversations?.[0]?.last_message_at;
          if (!at && !bt) return 0;
          if (!at) return 1;
          if (!bt) return -1;
          return new Date(bt) - new Date(at);
        });
        upd = {
          ...upd,
          applicants: { ...upd.applicants, applicants: sorted }
        };
      }

      setSelectedKey(key);
      setSelectedRow(upd);
      setSelectedTenant(null);
      setShowDetails(false);
      setCurrentConversationId(null);
      setChatMsgs([]);

      const inline = row.listing_id == null;
      setShowInline(inline);
      if (!inline) setShowEditModal(false);
    };

    const onEdit = e => {
      e.stopPropagation();
      initiateListing({ listing_id: row.listing_id, uid: currentOwnerId });
      setSelectedKey(key);
      setSelectedRow(row);
      setShowEditModal(true);
    };

    return (
      <ListGroup.Item
        action
        key={key}
        className="d-flex align-items-center justify-content-between"
        style={{ background: isSel ? '#E6E6FA' : undefined }}
        onClick={onSelect}
      >
        <div>
          <div>{truncate(row.property.name)}</div>
          <small className="text-muted">
            {truncate(`${row.unit.name} (R${row.unit.rent.toLocaleString()}/m)`)}
          </small>
        </div>
        {row.listing_id != null && (
          <FaEdit
            className="text-secondary"
            style={{ cursor: 'pointer' }}
            onClick={onEdit}
          />
        )}
      </ListGroup.Item>
    );
  }

  const listToRender = filter === 'listed' && listed.length > 0 ? listed : available;

  return (
    <div className="container py-4 bg-white">
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 style={{ fontFamily: 'Outfit, sans-serif' }}>Listing & Screening</h2>
        <OwnerControl />
      </div>

      <Row className="g-4">
        {/* Left pane */}
        <Col md={3}>
          <Card className="min-vh-100">
            <Card.Body>
              <div className="d-flex gap-2 mb-3">
                <Badge
                  pill
                  bg={filter === 'listed' ? 'primary' : 'secondary'}
                  style={{ cursor: 'pointer', fontSize: '0.8rem', padding: '0.5em 0.8em' }}
                  onClick={() => setFilter('listed')}
                >
                  Listed <Badge bg="light" text="dark" pill>{listed.length}</Badge>
                </Badge>
                <Badge
                  pill
                  bg={filter === 'available' ? 'primary' : 'secondary'}
                  style={{ cursor: 'pointer', fontSize: '0.8rem', padding: '0.5em 0.8em' }}
                  onClick={() => setFilter('available')}
                >
                  Available <Badge bg="light" text="dark" pill>{available.length}</Badge>
                </Badge>
              </div>
              <ListGroup variant="flush">
                {isLoading && (
                  <div className="text-center py-4"><Spinner animation="border" /></div>
                )}
                {error && (
                  <div className="text-danger text-center py-4">Error loading</div>
                )}
                {!isLoading && !error && listToRender.map(r => (
                  <RowItem key={rowKey(r)} row={r} />
                ))}
                {!isLoading && !error && listToRender.length === 0 && (
                  <div className="text-muted text-center py-4">No {filter}</div>
                )}
              </ListGroup>
            </Card.Body>
          </Card>
        </Col>

        {/* Inline wizard */}
        {showInline && selectedRow?.listing_id == null ? (
          <Col md={9}>
            <ListingWizard
              key={selectedKey}
              onClose={() => {
                setShowInline(false);
                setSelectedKey(null);
                setSelectedRow(null);
              }}
              userId={currentOwnerId}
              initialData={{
                basic: {
                  id:             null,
                  title:          selectedRow.unit.name,
                  description:    selectedRow.property.description,
                  property_id:    selectedRow.property.id,
                  unit_id:        selectedRow.unit.id,
                  is_available:   true,
                  is_furnished:   false,
                  available_from: '',
                  deposit_amount: selectedRow.unit.deposit_amount,
                  price_per_month: selectedRow.unit.rent,
                },
                faqs:         [],
                viewings:     [],
                requirements: [],

                isEditing:    false,
              }}
            />
          </Col>
        ) : (
          <>
            {/* Applicants */}
            <Col md={3}>
              <Card className="min-vh-100">
                <Card.Header>
                  <FaFileAlt className="me-2 text-warning" />
                  Tenant Screening
                </Card.Header>
                {!selectedRow && (
                  <div className="p-4 text-muted">Select a listing</div>
                )}
                <ListGroup variant="flush">
                  {selectedRow?.listing_id && (
                    (selectedRow.applicants?.applicants?.length > 0
                      ? selectedRow.applicants.applicants
                      : [{ applicant_id: 0, full_name: 'Demo Applicant' }]
                    ).map(a => (
                      <ListGroup.Item
                        key={a.applicant_id}
                        action
                        onClick={() => setSelectedTenant(a)}
                        style={{
                          background:
                            a.applicant_id === selectedTenant?.applicant_id
                              ? '#E6E6FA'
                              : undefined,
                        }}
                        className="d-flex align-items-center justify-content-between"
                      >
                        <div className="d-flex align-items-center w-100">
                          <FaUserCircle size={32} className="me-2 text-secondary" />
                          <div className="w-100 overflow-hidden">
                            <div className="fw-semibold d-flex justify-content-between">
                              <span>{a.full_name}</span>
                              {a.conversations?.length > 0 && (() => {
                                const conv = findConversationForListing(
                                  a.conversations,
                                  selectedRow.listing_id
                                );
                                return conv?.sent_message_count > 0 && (
                                  <Badge bg="primary" pill className="ms-2">
                                    {conv.sent_message_count}
                                  </Badge>
                                );
                              })()}
                            </div>
                            <div className="d-flex justify-content-between align-items-center">
                              <small className="text-muted text-truncate">
                                {a.conversations?.length > 0 && (() => {
                                  const conv = findConversationForListing(
                                    a.conversations,
                                    selectedRow.listing_id
                                  );
                                  return conv?.last_message
                                    ? truncate(conv.last_message, 20)
                                    : `ID #${a.applicant_id}`;
                                })() || `ID #${a.applicant_id}`}
                              </small>
                              {a.conversations?.length > 0 && (() => {
                                const conv = findConversationForListing(
                                  a.conversations,
                                  selectedRow.listing_id
                                );
                                return conv?.last_message_at && (
                                  <small
                                    className="text-muted ms-2"
                                    style={{ fontSize: '0.7rem', whiteSpace: 'nowrap' }}
                                  >
                                    {new Date(conv.last_message_at).toLocaleDateString()}
                                  </small>
                                );
                              })()}
                            </div>
                          </div>
                        </div>
                      </ListGroup.Item>
                    ))
                  )}
                </ListGroup>
              </Card>
            </Col>

            {/* Chat */}
            <Col md={6}>
              <Card className="min-vh-100 d-flex flex-column">
                <Card.Header className="d-flex align-items-center" style={{ width: '100%' }}>
                  <FaMoneyBillWave className="me-2 text-success" />Chat
                  <Button
                    size="sm"
                    className="ms-auto"
                    variant="outline-primary"
                    disabled={!(selectedRow && selectedTenant)}
                    onClick={() => setShowDetails(true)}
                  >
                    Details
                  </Button>
                  <Button
                    size="sm"
                    className="ms-2"
                    variant="outline-secondary"
                    disabled={!(selectedRow && selectedTenant)}
                    onClick={fetchConversation}
                  >
                    Refresh
                  </Button>
                </Card.Header>
                <Card.Body className="flex-grow-1 d-flex flex-column">
                  {!(selectedRow && selectedTenant) ? (
                    <p className="text-muted m-0">
                      Select a listing <strong>and</strong> tenant
                    </p>
                  ) : isChatLoading ? (
                    <div className="d-flex justify-content-center align-items-center flex-grow-1">
                      <Spinner animation="border" variant="primary" />
                      <span className="ms-2">Loading conversation...</span>
                    </div>
                  ) : (
                    <ChatWindow newMessages={chatMsgs} onSend={sendMsg} />
                  )}
                </Card.Body>
              </Card>
            </Col>
          </>
        )}
      </Row>

      {/* Edit Listing Modal */}
      <Modal
        show={showEditModal}
        onHide={() => setShowEditModal(false)}
        size="lg"
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>Edit Listing</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ minHeight: '50vh' }}>
          {(isInitiating || !initData) ? (
            <div
              className="d-flex justify-content-center align-items-center"
              style={{ minHeight: '50vh' }}
            >
              <Spinner animation="border" />
            </div>
          ) : (
            <ListingWizard
              key={selectedKey}
              onClose={() => setShowEditModal(false)}
              userId={currentOwnerId}
              initialData={{ ...initData, isEditing: true }}
            />
          )}
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default Listing;
