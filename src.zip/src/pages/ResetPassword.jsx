import React, { useState, useEffect } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { FaEye, FaEyeSlash, FaCheckCircle, FaTimesCircle } from "react-icons/fa";
import { Card, Button, Form, Alert, Container, ProgressBar, InputGroup } from "react-bootstrap";
import { motion } from "framer-motion";
import { useResetPasswordMutation } from "../api/authApi";

export const ResetPassword = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token')
  const email = searchParams.get('email')
  const [formData, setFormData] = useState({
    password: "",
    password_confirmation: "",
  });

  const [alerts, setAlerts] = useState({ error: "", success: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [passwordFeedback, setPasswordFeedback] = useState("");
  const [tokenValidated, setTokenValidated] = useState(true);


  // RTK Query hook for reset password
  const [resetPassword, { isLoading: isResetting }] = useResetPasswordMutation();


  // Password strength checker
  useEffect(() => {
    if (!formData.password) {
      setPasswordStrength(0);
      setPasswordFeedback("");
      return;
    }

    let strength = 0;
    let feedback = [];

    // Length check
    if (formData.password.length >= 8) {
      strength += 25;
    } else {
      feedback.push("Password should be at least 8 characters");
    }

    // Uppercase check
    if (/[A-Z]/.test(formData.password)) {
      strength += 25;
    } else {
      feedback.push("Include at least one uppercase letter");
    }

    // Number check
    if (/\d/.test(formData.password)) {
      strength += 25;
    } else {
      feedback.push("Include at least one number");
    }

    // Special character check
    if (/[^A-Za-z0-9]/.test(formData.password)) {
      strength += 25;
    } else {
      feedback.push("Include at least one special character");
    }

    setPasswordStrength(strength);
    setPasswordFeedback(feedback.join(", "));
  }, [formData.password]);

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 50) return "danger";
    if (passwordStrength < 75) return "warning";
    return "success";
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setAlerts({ error: "", success: "" });

    // Client-side validation
    if (formData.password.length < 8) {
      setAlerts({ error: "Password must be at least 8 characters" });
      return;
    }

    if (formData.password !== formData.password_confirmation) {
      setAlerts({ error: "Passwords do not match" });
      return;
    }

    try {
      const result = await resetPassword({
        token,
        email,
        newPassword: formData.password,
      }).unwrap();

      if (result.status === "success") {
        setAlerts({ success: "Password has been reset successfully!" });
        // Clear form
        setFormData({
          password: "",
          password_confirmation: "",
        });

        // Redirect to login after a delay
        setTimeout(() => {
          navigate("/login", {
            state: { message: "Your password has been reset. Please log in with your new password." }
          });
        }, 2000);
      } else {
        setTokenValidated(false);
        throw new Error(result.message || "Failed to reset password");
      }
    } catch (err) {
      console.error("Error:", err);

      if (err.data?.message) {
        setAlerts({ error: err.data.message });
      } else if (err.message) {
        setAlerts({ error: err.message });
      } else {
        setAlerts({ error: "An unexpected error occurred. Please try again." });
      }
    }
  };

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: "100vh" }}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={{ width: "100%", maxWidth: "450px" }}
      >
        <Card className="shadow-lg border-0 rounded-4 overflow-hidden">
          <Card.Body className="p-5">
            <div className="text-center mb-4">
              <h2 className="fw-bold mb-2">Reset Password</h2>
              <p className="text-muted">Create a new password for your account</p>
            </div>

            {alerts.error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
              >
                <Alert variant="danger" className="mb-4">
                  {alerts.error}
                </Alert>
              </motion.div>
            )}

            {alerts.success && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
              >
                <Alert variant="success" className="mb-4">
                  {alerts.success}
                </Alert>
              </motion.div>
            )}

            {tokenValidated ? (
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>New Password</Form.Label>
                  <InputGroup>
                    <Form.Control
                      type={showPassword ? "text" : "password"}
                      name="password"
                      placeholder="Enter new password"
                      value={formData.password}
                      onChange={handleChange}
                      className="py-2"
                      disabled={isResetting}
                      required
                    />
                    <Button
                      variant="outline-secondary"
                      onClick={() => setShowPassword(!showPassword)}
                      disabled={isResetting}
                    >
                      {showPassword ? <FaEyeSlash /> : <FaEye />}
                    </Button>
                  </InputGroup>
                  {formData.password && (
                    <div className="mt-2">
                      <ProgressBar
                        now={passwordStrength}
                        variant={getPasswordStrengthColor()}
                        className="mb-2"
                        style={{ height: "8px" }}
                      />
                      <small className={`text-${getPasswordStrengthColor()}`}>
                        {passwordStrength < 50 && "Weak password"}
                        {passwordStrength >= 50 && passwordStrength < 75 && "Moderate password"}
                        {passwordStrength >= 75 && "Strong password"}
                      </small>
                      {passwordFeedback && (
                        <small className="d-block text-muted mt-1">{passwordFeedback}</small>
                      )}
                    </div>
                  )}
                </Form.Group>

                <Form.Group className="mb-4">
                  <Form.Label>Confirm New Password</Form.Label>
                  <InputGroup>
                    <Form.Control
                      type={showConfirmPassword ? "text" : "password"}
                      name="password_confirmation"
                      placeholder="Confirm new password"
                      value={formData.password_confirmation}
                      onChange={handleChange}
                      className="py-2"
                      disabled={isResetting}
                      required
                    />
                    <Button
                      variant="outline-secondary"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      disabled={isResetting}
                    >
                      {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
                    </Button>
                  </InputGroup>
                  {formData.password && formData.password_confirmation && (
                    <div className="mt-2">
                      {formData.password === formData.password_confirmation ? (
                        <small className="text-success d-flex align-items-center">
                          <FaCheckCircle className="me-1" /> Passwords match
                        </small>
                      ) : (
                        <small className="text-danger d-flex align-items-center">
                          <FaTimesCircle className="me-1" /> Passwords do not match
                        </small>
                      )}
                    </div>
                  )}
                </Form.Group>

                <Button
                  variant="primary"
                  type="submit"
                  className="w-100 py-2 mb-4"
                  disabled={isResetting}
                >
                  {isResetting ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Resetting Password...
                    </>
                  ) : (
                    "Reset Password"
                  )}
                </Button>
              </Form>
            ) : (
              <div className="text-center py-4">
                <p className="mb-4">This password reset link is invalid or has expired.</p>
                <Button
                  variant="primary"
                  onClick={() => navigate("/forgot-password")}
                  className="mb-3"
                >
                  Request New Reset Link
                </Button>
              </div>
            )}

            <div className="text-center">
              <p className="mb-0">
                <Link to="/login" className="text-decoration-none fw-medium">
                  Back to Login
                </Link>
              </p>
            </div>
          </Card.Body>
        </Card>
      </motion.div>
    </Container>
  );
};
