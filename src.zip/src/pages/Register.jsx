import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaGoogle, FaEye, FaEyeSlash, FaCheckCircle, FaTimesCircle } from "react-icons/fa";
import { Card, Button, Form, Alert, Container, ProgressBar, InputGroup } from "react-bootstrap";
import { motion } from "framer-motion";
import { useGoogleAuthMutation, authApi, useCreateUserMutation } from "../api/authApi";
import { useDispatch } from "react-redux";
import { GoogleLogin } from '@react-oauth/google';
import { handlePostAuth } from "../utils/authUtils";

export const Register = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [googleAuth] = useGoogleAuthMutation();
  const [createUser, { isLoading: isCreatingUser }] = useCreateUserMutation();
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    password_confirmation: "",
  });

  const [alerts, setAlerts] = useState({ error: "", success: "" });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [passwordFeedback, setPasswordFeedback] = useState("");
  const [googleLoading, setGoogleLoading] = useState(false);

  // Password strength checker
  useEffect(() => {
    if (!formData.password) {
      setPasswordStrength(0);
      setPasswordFeedback("");
      return;
    }

    let strength = 0;
    let feedback = [];

    // Length check
    if (formData.password.length >= 8) {
      strength += 25;
    } else {
      feedback.push("Password should be at least 8 characters");
    }

    // Uppercase check
    if (/[A-Z]/.test(formData.password)) {
      strength += 25;
    } else {
      feedback.push("Include at least one uppercase letter");
    }

    // Number check
    if (/\d/.test(formData.password)) {
      strength += 25;
    } else {
      feedback.push("Include at least one number");
    }

    // Special character check
    if (/[^A-Za-z0-9]/.test(formData.password)) {
      strength += 25;
    } else {
      feedback.push("Include at least one special character");
    }

    setPasswordStrength(strength);
    setPasswordFeedback(feedback.join(", "));
  }, [formData.password]);

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 50) return "danger";
    if (passwordStrength < 75) return "warning";
    return "success";
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setAlerts({ error: "", success: "" });
    setErrors({});
    setSubmitting(true);

    // Client-side validation
    const validationErrors = {};
    if (!formData.name.trim()) validationErrors.name = ["Name is required"];
    if (!formData.email.trim()) validationErrors.email = ["Email is required"];
    if (!/\S+@\S+\.\S+/.test(formData.email)) validationErrors.email = ["Please enter a valid email address"];
    if (formData.password.length < 8) validationErrors.password = ["Password must be at least 8 characters"];
    if (formData.password !== formData.password_confirmation) {
      validationErrors.password_confirmation = ["Passwords do not match"];
    }

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmitting(false);
      return;
    }

    try {
      // Split the name into first_name and last_name
      const nameParts = formData.name.trim().split(' ');
      const firstName = nameParts[0];
      const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : '';

      // Prepare data for API
      const apiData = {
        first_name: firstName,
        last_name: lastName,
        email: formData.email,
        password: formData.password,
        register_by: 0,
        type: "guest",
        extra: "{}"
      };

      // Call createUser API directly
      const response = await createUser(apiData).unwrap();
      
      if (response.status_code === 200 || response.success) {
        // Store token in localStorage if available
        if (response.token) {
          localStorage.setItem("token", response.token);
          
          // Fetch user data
          const meRes = await dispatch(authApi.endpoints.getMe.initiate());
          const user = meRes?.data?.data;
          
          if (user) {
            // Set up auth state
            await handlePostAuth({
              userData: user,
              token: response.token,
              dispatch,
            });
            
            // Check if phone verification is needed
            if (!user.is_active) {
              // Navigate to phone verification
              navigate("/verify-phone", {
                state: {
                  userId: user.id,
                  type: 'register',
                  message: "One more step to complete your registration"
                }
              });
            } else {
              // User is already active, go to dashboard
              navigate("/dashboard");
            }
          } else {
            // No user data, navigate to phone verification with user ID from response
            navigate("/verify-phone", {
              state: {
                userId: response.user_id,
                type: 'register',
                message: "One more step to complete your registration"
              }
            });
          }
        } else {
          // No token in response, navigate to phone verification with user ID
          navigate("/verify-phone", {
            state: {
              userId: response.user_id,
              type: 'register',
              message: "One more step to complete your registration"
            }
          });
        }
      } else {
        throw new Error(response.message || "Registration failed");
      }
    } catch (err) {
      console.error("Error:", err);
      if (err.data?.errors) {
        setErrors(err.data.errors);
      } else if (err.data?.message) {
        setAlerts({ error: err.data.message });
      } else {
        setAlerts({ error: err.message || "An unexpected error occurred." });
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleGoogleSuccess = async (credentialResponse) => {
    setGoogleLoading(true);
    try {
      const response = await googleAuth({
        token: credentialResponse.credential
      }).unwrap();

      if (response.success) {
        const token = response.data.token;
        localStorage.setItem("token", token);

        const meRes = await dispatch(authApi.endpoints.getMe.initiate());
        const user = meRes?.data?.data;

        if (user) {
          await handlePostAuth({
            userData: user,
            token,
            dispatch,
          });

          // If phone is not verified
          if (!user?.is_active) {
            navigate("/verify-phone", {
              state: {
                userId: user.id,
                type: 'register',
                message: "One more step to complete your registration"
              }
            });
          } else {
            navigate("/dashboard");
          }
        } else {
          setAlerts({ error: response.message || "Google authentication failed" });
        }
      }
    } catch (error) {
      console.error("Google auth error:", error);
      setAlerts({
        error: error?.data?.message || error.message || "Google sign-in failed."
      });
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleGoogleError = () => {
    setAlerts({ error: "Google sign-in failed. Please try again." });
    setGoogleLoading(false);
  };

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: "100vh" }}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={{ width: "100%", maxWidth: "450px" }}
      >
        <Card className="shadow-lg border-0 rounded-4 overflow-hidden">
          <Card.Body className="p-5">
            <div className="text-center mb-4">
              <h2 className="fw-bold mb-2">Create Account</h2>
              <p className="text-muted">Join our community of property managers</p>
            </div>

            {alerts.error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
              >
                <Alert variant="danger" className="mb-4">
                  {alerts.error}
                </Alert>
              </motion.div>
            )}

            {alerts.success && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
              >
                <Alert variant="success" className="mb-4">
                  {alerts.success}
                </Alert>
              </motion.div>
            )}

            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3">
                <Form.Label>Full Name</Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  placeholder="Enter your name"
                  value={formData.name}
                  onChange={handleChange}
                  isInvalid={!!errors.name}
                  className="py-2"
                />
                <Form.Control.Feedback type="invalid">
                  {errors.name && errors.name[0]}
                </Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Email Address</Form.Label>
                <Form.Control
                  type="email"
                  name="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={handleChange}
                  isInvalid={!!errors.email}
                  className="py-2"
                />
                <Form.Control.Feedback type="invalid">
                  {errors.email && errors.email[0]}
                </Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Password</Form.Label>
                <InputGroup>
                  <Form.Control
                    type={showPassword ? "text" : "password"}
                    name="password"
                    placeholder="Create a password"
                    value={formData.password}
                    onChange={handleChange}
                    isInvalid={!!errors.password}
                    className="py-2 border-end-0"
                  />
                  <InputGroup.Text
                    className={`bg-transparent cursor-pointer ${errors.password ? 'border-danger' : 'border-start-0'}`}
                    onClick={() => setShowPassword(!showPassword)}
                    style={{ cursor: 'pointer' }}
                  >
                    {showPassword ? <FaEyeSlash className="text-muted" /> : <FaEye className="text-muted" />}
                  </InputGroup.Text>
                  <Form.Control.Feedback type="invalid">
                    {errors.password && errors.password[0]}
                  </Form.Control.Feedback>
                </InputGroup>
                {formData.password && (
                  <div className="mt-2">
                    <ProgressBar
                      now={passwordStrength}
                      variant={getPasswordStrengthColor()}
                      className="mb-2"
                      style={{ height: "8px" }}
                    />
                    <small className={`text-${getPasswordStrengthColor()}`}>
                      {passwordStrength < 50 && "Weak password"}
                      {passwordStrength >= 50 && passwordStrength < 75 && "Moderate password"}
                      {passwordStrength >= 75 && "Strong password"}
                    </small>
                    {passwordFeedback && (
                      <small className="d-block text-muted mt-1">{passwordFeedback}</small>
                    )}
                  </div>
                )}
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label>Confirm Password</Form.Label>
                <InputGroup>
                  <Form.Control
                    type={showConfirmPassword ? "text" : "password"}
                    name="password_confirmation"
                    placeholder="Confirm your password"
                    value={formData.password_confirmation}
                    onChange={handleChange}
                    isInvalid={!!errors.password_confirmation}
                    className="py-2 border-end-0"
                  />
                  <InputGroup.Text
                    className={`bg-transparent cursor-pointer ${errors.password_confirmation ? 'border-danger' : 'border-start-0'}`}
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    style={{ cursor: 'pointer' }}
                  >
                    {showConfirmPassword ? <FaEyeSlash className="text-muted" /> : <FaEye className="text-muted" />}
                  </InputGroup.Text>
                  <Form.Control.Feedback type="invalid">
                    {errors.password_confirmation && errors.password_confirmation[0]}
                  </Form.Control.Feedback>
                </InputGroup>
                {formData.password && formData.password_confirmation && (
                  <div className="mt-2">
                    {formData.password === formData.password_confirmation ? (
                      <small className="text-success d-flex align-items-center">
                        <FaCheckCircle className="me-1" /> Passwords match
                      </small>
                    ) : (
                      <small className="text-danger d-flex align-items-center">
                        <FaTimesCircle className="me-1" /> Passwords do not match
                      </small>
                    )}
                  </div>
                )}
              </Form.Group>
              <Button
                variant="primary"
                type="submit"
                className="w-100 py-2 mb-4"
                disabled={submitting || isCreatingUser}
              >
                {(submitting || isCreatingUser) ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    Creating Account...
                  </>
                ) : (
                  "Create Account"
                )}
              </Button>
            </Form>

            <div className="d-flex align-items-center mb-4">
              <div className="flex-grow-1 border-bottom"></div>
              <span className="mx-3 text-muted">or</span>
              <div className="flex-grow-1 border-bottom"></div>
            </div>

            <div className="w-100 mb-4 d-flex justify-content-center">
              {googleLoading ? (
                <Button variant="outline-danger" className="w-100 py-2" disabled>
                  Connecting...
                </Button>
              ) : (
                <div className="w-100">
                  <GoogleLogin
                    onSuccess={handleGoogleSuccess}
                    onError={handleGoogleError}
                    useOneTap
                    theme="outline"
                    size="large"
                    text="signup_with"
                    shape="rectangular"
                    logo_alignment="center"
                    width="100%"
                  />
                </div>
              )}
            </div>

            <div className="text-center">
              <p className="mb-0">
                Already have an account?{" "}
                <Link to="/login" className="text-decoration-none fw-medium">
                  Sign in
                </Link>
              </p>
            </div>
          </Card.Body>
        </Card>
      </motion.div>
    </Container>
  );
};
