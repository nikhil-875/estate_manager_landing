/******************************************************************************
 *  src/pages/OwnerDashboard.jsx
 *  • Dashboard for property owners
 *  • Summary cards · rent-collection chart · tenant­screening · upcoming leases
 *  • Extra UX:
 *      – If no calendar data → still show empty calendar
 *      – If no tenant-screening data → show placeholder SVG
 *      – Tenant list now shows “property (unit)” under the name - truncated
 ******************************************************************************/

import React, { useEffect, useState, useMemo } from 'react';
import ApexCharts from 'apexcharts';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import { List as ListIcon, Calendar as CalendarIcon } from 'lucide-react';
import {
  FaBuilding,
  FaPercent,
  FaListAlt,
  FaTools,
} from 'react-icons/fa';

import { useGetDashboardStatsMutation } from '../api/owner';
import emptyCartSvg from '../assets/svg/no_sales.svg';

/* ─────── helpers ─────── */
const truncate = (str = '', len = 30) =>
  str.length > len ? `${str.slice(0, len)}…` : str;

/* ─────── component ─────── */
export const OwnerDashboard = () => {
  /* API fetch */
  const [getDashboardStats, { data, isLoading, isError }] =
    useGetDashboardStatsMutation();

  useEffect(() => {
    getDashboardStats();
  }, [getDashboardStats]);

  /* local UI state */
  const [leaseView, setLeaseView] = useState('list'); // list | calendar

  /* payload shortcut */
  const stats = data?.results ?? {};

  /* ── Summary cards (4) ── */
  const quickStats = useMemo(() => {
    if (isLoading || isError || !Object.keys(stats).length) {
      return [
        {
          title: 'Total Properties',
          value: '—',
          subtitle: '— Properties',
          bg: '#7366FF',
          icon: <FaBuilding color="white" />,
        },
        {
          title: 'Occupancy Rate',
          value: '—',
          subtitle: '— Occupied',
          bg: '#1cc88a',
          icon: <FaPercent color="white" />,
        },
        {
          title: 'Listed Properties',
          value: '—',
          subtitle: '— Listings',
          bg: '#ff7043',
          icon: <FaListAlt color="white" />,
        },
        {
          title: 'Outstanding Maintenance',
          value: '—',
          subtitle: '— Units',
          bg: '#ec407a',
          icon: <FaTools color="white" />,
        },
      ];
    }
    return [
      {
        title: 'Total Properties',
        value: stats.property_count ?? 0,
        subtitle: `${stats.property_count ?? 0} Properties`,
        bg: '#7366FF',
        icon: <FaBuilding color="white" size={20} />,
      },
      {
        title: 'Occupancy Rate',
        value: `${stats.occupancy_rate ?? 0}%`,
        subtitle: `${stats.occupied_units ?? 0}/${stats.total_units ?? 0} Occupied`,
        bg: '#1cc88a',
        icon: <FaPercent color="white" size={20} />,
      },
      {
        title: 'Listed Properties',
        value: stats.listed_properties ?? 0,
        subtitle: `${stats.listed_properties ?? 0} Listings`,
        bg: '#ff7043',
        icon: <FaListAlt color="white" size={20} />,
      },
      {
        title: 'Outstanding Maintenance',
        value: stats.units_in_maintenance ?? 0,
        subtitle: `${stats.units_in_maintenance ?? 0} Units`,
        bg: '#ec407a',
        icon: <FaTools color="white" size={20} />,
      },
    ];
  }, [stats, isLoading, isError]);

  /* ── Tenant screening list ── */
  const tenantScreening = useMemo(() => {
    if (isLoading || isError || !Array.isArray(stats.tenant_payments)) return [];
    return stats.tenant_payments.map(t => ({
      name: t.tenant_name,
      id: t.tenant_id,
      status: (t.final_status ?? '').toLowerCase() === 'paid' ? 'Paid' : 'Pending',
      property: t.property_name ?? '—',
      unit: t.unit_name ?? '',
    }));
  }, [stats, isLoading, isError]);

  /* ── Upcoming leases ── */
  const upcomingLeases = useMemo(() => {
    if (isLoading || isError || !Array.isArray(stats.calendar_events)) return [];
    return stats.calendar_events
      .filter(ev => ev.event_type === 'lease_expiry' || ev.event_type === 'lease_expiration')
      .map(ev => ({ tenant: ev.title, date: ev.event_date }))
      .sort((a, b) => new Date(a.date) - new Date(b.date));
  }, [stats, isLoading, isError]);

  /* ── Rent-collection chart ── */
  useEffect(() => {
    if (isLoading || isError || !Array.isArray(stats.rent_collection)) return;
    const old = ApexCharts.getChartByID('rentChart');
    if (old) old.destroy();
    const lastSix = stats.rent_collection.slice(-6);
    const months = lastSix.map(r => r.month);
    const values = lastSix.map(r => Number(r.rent_collected));
    const chart = new ApexCharts(document.querySelector('#rent-collection-chart'), {
      chart: { id: 'rentChart', type: 'bar', height: 250, toolbar: { show: false } },
      series: [{ name: 'Rent', data: values }],
      plotOptions: { bar: { borderRadius: 4, columnWidth: '50%' } },
      dataLabels: { enabled: true, style: { colors: ['#fff'] } },
      colors: ['#7366FF'],
      xaxis: { categories: months },
      grid: { borderColor: '#eee' },
    });
    chart.render();
    return () => chart.destroy();
  }, [stats, isLoading, isError]);

  if (isError) {
    return (
      <div className="container my-4">
        <h2 className="text-danger">Error loading dashboard.</h2>
      </div>
    );
  }

  const noLeases = !isLoading && upcomingLeases.length === 0;
  const noTenants = !isLoading && tenantScreening.length === 0;

  return (
    <div className="container my-4">
      <h2 className="mb-4">Owner Dashboard</h2>

      {/* ───── summary cards ───── */}
      <div className="row g-4 mb-5">
        {quickStats.map(({ title, value, subtitle, bg, icon }, i) => (
          <div key={i} className="col-xl-3 col-md-6 col-sm-12">
            <div className="card border-0 shadow-sm rounded-4 p-3 h-100">
              <div className="d-flex justify-content-between align-items-start">
                <h6 className="text-muted">{title}</h6>
                <i className="fas fa-ellipsis-v text-muted" />
              </div>
              <div className="d-flex align-items-center mt-3">
                <div
                  className="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                  style={{ backgroundColor: bg, width: 44, height: 44 }}
                >
                  {icon}
                </div>
                <div className="ms-3">
                  <h3 className="fw-bold mb-0">{value}</h3>
                  <small className="text-muted">{subtitle}</small>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ───── main panels ───── */}
      <div className="row g-4">
        {/* Rent Collection */}
        <div className="col-lg-4">
          <div className="card border-0 shadow-sm rounded-4 h-100">
            <div className="card-header bg-transparent border-0 pb-2">
              <h6 className="mb-0">Rent Collection (last 6 months)</h6>
            </div>
            <div className="card-body p-4">
              {isLoading ? (
                <p className="text-center">Loading chart…</p>
              ) : (
                <div id="rent-collection-chart" />
              )}
            </div>
          </div>
        </div>

        {/* Tenant Screening */}
        <div className="col-lg-4">
          <div className="card border-0 shadow-sm rounded-4 h-100">
            <div className="card-header bg-transparent border-0 pb-2">
              <h6 className="mb-0">Tenant Payment</h6>
              <br/>
            </div>
            {isLoading ? (
              <p className="text-center mt-4">Loading tenants…</p>
            ) : noTenants ? (
              <div className="d-flex flex-column align-items-center justify-content-center py-5">
                <img
                  src={emptyCartSvg}
                  alt="No tenants"
                  className="img-fluid mb-3"
                  style={{ maxWidth: 160 }}
                />
                <p className="text-muted mb-0">No tenant data</p>
              </div>
            ) : (
              <div style={{ minHeight: 300, overflowY: 'auto', marginLeft:'15px' }}>
                <ul className="list-group list-group-flush">
                  {tenantScreening.map((t, idx) => (
                    <li
                      key={idx}
                      className="list-group-item d-flex justify-content-between align-items-center"
                      style={{
                        borderBottom:
                          idx < tenantScreening.length - 1 ? '1px dashed #dee2e6' : 'none',
                      }}
                    >
                      <div>
                        <div className="fw-semibold">{t.name}</div>
                        <small className="text-muted">
                          {truncate(`${t.property} (${t.unit})`)}
                        </small>
                        <br />
                        {/* <small className="text-muted">ID #{t.id}</small> */}
                      </div>
                      <span className={`text-${t.status === 'Paid' ? 'success' : 'danger'}`}>
                        {t.status}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Upcoming Leases */}
        <div className="col-lg-4">
          <div className="card border-0 shadow-sm rounded-4 h-100">
            <div className="card-header bg-transparent border-0 pb-2 d-flex justify-content-between align-items-center">
              <h6 className="mb-0">Upcoming Events</h6>
              <div>
                <ListIcon
                  size={18}
                  className={`me-2 cursor-pointer ${
                    leaseView === 'list' ? 'text-primary' : 'text-muted'
                  }`}
                  onClick={() => setLeaseView('list')}
                  title="List view"
                />
                <CalendarIcon
                  size={18}
                  className={`cursor-pointer ${
                    leaseView === 'calendar' ? 'text-primary' : 'text-muted'
                  }`}
                  onClick={() => setLeaseView('calendar')}
                  title="Calendar view"
                />
              </div>
            </div>
            <div className="card-body p-0" style={{ minHeight: 500 }}>
              {isLoading ? (
                <p className="text-center mt-4">Loading leases…</p>
              ) : leaseView === 'calendar' || noLeases ? (
                <FullCalendar
                  plugins={[dayGridPlugin]}
                  initialView="dayGridMonth"
                  events={upcomingLeases.map(e => ({ title: e.tenant, start: e.date }))}
                  height={500}
                  headerToolbar={{ left: '', center: 'title', right: 'prev,next' }}
                />
              ) : (
                <div style={{ overflowY: 'auto', maxHeight: 500 }}>
                  <ul className="list-group list-group-flush">
                    {upcomingLeases.map((e, idx) => (
                      <li
                        key={idx}
                        className="list-group-item d-flex justify-content-between"
                        style={{
                          borderBottom:
                            idx < upcomingLeases.length - 1
                              ? '1px dashed #dee2e6'
                              : 'none',
                        }}
                      >
                        <span>{e.tenant}</span>
                        <small className="text-muted">
                          {new Date(e.date).toLocaleDateString(undefined, {
                            month: 'numeric',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </small>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OwnerDashboard;
