import React, { useState, useEffect, useMemo, lazy, Suspense } from 'react';
import { FaTrashAlt, FaPlus, FaBuilding, FaUser, FaDollarSign, FaRobot } from 'react-icons/fa';
import { Modal, Button } from 'react-bootstrap';
import {
  useGetPropertyListQuery,
  useManagePropertyMutation,
  useManageUnitMutation,
  useGetUnitDetailsQuery,
} from '../api/propertyApi';
import { useGetOwnerDetailsQuery } from '../api/owner';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';

// Lazy load child components
const PropertyDetails = lazy(() =>
  import('../components/PropertyDetails/property.details.jsx').then(mod => ({ default: mod.PropertyDetails }))
);
const UnitDetails = lazy(() =>
  import('../components/PropertyDetails/units.details.jsx').then(mod => ({ default: mod.UnitDetails }))
);
const UnitTenants = lazy(() =>
  import('../components/PropertyDetails/units.tenants.jsx').then(mod => ({ default: mod.UnitTenants }))
);
const UnitFinance = lazy(() =>
  import('../components/PropertyDetails/units.finance.jsx').then(mod => ({ default: mod.UnitFinance }))
);
const PropertyAI = lazy(() =>
  import('../components/PropertyDetails/property.ai.jsx').then(mod => ({ default: mod.PropertyAI }))
);

// Add this style block at the top of the file, after imports
const styleSheet = document.createElement('style');
styleSheet.textContent = `
  .properties-container {
    height: calc(110vh - 110px);
    overflow: hidden;
    background: #f5f7fa;
  }
  
  .property-sidebar {
    width: 100%;
    max-width: 270px;
    height: auto;
    height: 100%;
    overflow: auto;
  }
  
  .property-main {
    height: 100%;
    overflow: hidden;
    min-width: 0;
  }
  
  .property-content {
    height: calc(100% - 60px);
    background: #fff;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
  
  .units-column {
    width: 100%;
    padding: 14px;
    max-width: 200px;
    overflow: auto;
  }
  
  .info-column {
    height: 100%;
    min-width: 0;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  }
  
  .content-panel {
    flex-grow: 1;
    width: 100%;
    overflow: auto;
  }
  
  /* Custom scrollbar styling */
  .custom-scrollbar {
    scrollbar-width: thin;
    scrollbar-color: transparent transparent;
    -ms-overflow-style: none;
  }
  
  .custom-scrollbar:hover {
    scrollbar-width: thin;
    scrollbar-color: #e0e0e0 #f8f8f8;
  }
  
  .custom-scrollbar::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
  
  .custom-scrollbar::-webkit-scrollbar-track {
    background: transparent;
    border-radius: 8px;
  }
  
  .custom-scrollbar::-webkit-scrollbar-thumb {
    background: transparent;
    border-radius: 8px;
  }
  
  .custom-scrollbar:hover::-webkit-scrollbar-thumb {
    background: #e0e0e0;
  }
  
  .custom-scrollbar:hover::-webkit-scrollbar-track {
    background: #f8f8f8;
  }
`;
document.head.appendChild(styleSheet);

export const Properties = () => {
  // User details from Redux store
  const user = useSelector(state => state.auth.user);
  const LOGGED_IN_USER_ID = user?.id;
  const LOGGED_IN_USER_TYPE = user?.type;
  const LOGGED_IN_USER_EMAIL = user?.email;
  const LOGGED_IN_USER_NAME =
    user?.first_name && user?.last_name
      ? `${user.first_name} ${user.last_name}`
      : user?.email || 'User';
  const LOGGED_IN_USER_AVATAR =
    user?.profile || `https://i.pravatar.cc/72?u=${LOGGED_IN_USER_ID || 'default'}`;

  const { data: ownersList = [] } = useGetOwnerDetailsQuery();


  // Component State
  const [currentOwnerId, setCurrentOwnerId] = useState(LOGGED_IN_USER_ID);
  const [activeInfoTab, setActiveInfoTab] = useState('details');
  const [activeSubTab, setActiveSubTab] = useState('description');
  const [selectedPropertyId, setSelectedPropertyId] = useState(null);
  const [selectedUnitId, setSelectedUnitId] = useState(null);
  const [activePane, setActivePane] = useState('property');
  const [isNewPropertyMode, setIsNewPropertyMode] = useState(false);
  const [isNewUnitMode, setIsNewUnitMode] = useState(false);
  const [ownerOptions, setOwnerOptions] = useState([]);

  // Initialize currentOwnerId when user data becomes available
  useEffect(() => {
    if (LOGGED_IN_USER_ID && !currentOwnerId) {
      setCurrentOwnerId(LOGGED_IN_USER_ID);
    }
  }, [LOGGED_IN_USER_ID]);

  // Generate owner options whenever ownersList changes
  useEffect(() => {
    const generateOwnerOptions = () => {
      // Map all owners from the array
      const options = ownersList?.owners?.map(owner => ({
        id: owner?.id,
        name: owner?.company
      })) || [];

      // Check if current user is already in the list
      const currentUserExists = options.some(option => option.id == LOGGED_IN_USER_ID);

      // Add current user if not already in the list
      if (!currentUserExists && LOGGED_IN_USER_ID) {
        options.unshift({
          id: LOGGED_IN_USER_ID,
          name: LOGGED_IN_USER_EMAIL || 'Current User' // Use email as fallback for current user
        });
      }

      return options;
    };

    setOwnerOptions(generateOwnerOptions());
  }, [ownersList, LOGGED_IN_USER_ID, LOGGED_IN_USER_EMAIL]);

  // Derive the currently selected owner's details for display in sidebar
  const selectedOwnerDetails = useMemo(() => {
    // First, try to find a company matching the currentOwnerId
    const owner = ownersList?.owners?.find(o => o.id == currentOwnerId);

    if (owner) {
      return {
        id: owner?.id,
        name: owner?.company || 'Unknown Company',
        email: owner?.email || 'N/A', // Assuming owner object might have an email for the company
        avatar: owner?.logo || `https://i.pravatar.cc/72?u=${owner?.id || 'default_company'}`, // Placeholder for company logo
      };
    } else {
      // If no company found for currentOwnerId, fall back to logged-in user details
      return {
        id: LOGGED_IN_USER_ID,
        name: LOGGED_IN_USER_NAME,
        email: LOGGED_IN_USER_EMAIL,
        avatar: LOGGED_IN_USER_AVATAR,
      };
    }
  }, [currentOwnerId, ownersList, LOGGED_IN_USER_ID, LOGGED_IN_USER_NAME, LOGGED_IN_USER_EMAIL, LOGGED_IN_USER_AVATAR]);


  // Reset property/unit selection when owner changes
  useEffect(() => {
    setSelectedPropertyId(null);
    setSelectedUnitId(null);
    setIsNewPropertyMode(false);
    setIsNewUnitMode(false);
    setActivePane('property');
  }, [currentOwnerId]);

  // Confirmation modal state
  const [showConfirm, setShowConfirm] = useState(false);
  const [confirmMessage, setConfirmMessage] = useState('');
  const [confirmAction, setConfirmAction] = useState(null);

  // RTK Query Hooks
  const {
    data: propertyListResponse,
    isLoading: isLoadingProperties,
    error: propertiesError,
    refetch: refetchProperties,
  } = useGetPropertyListQuery({ uid: currentOwnerId }, {
    skip: !currentOwnerId
  });

  const [manageProperty, { isLoading: isManagingProperty }] = useManagePropertyMutation();
  const [manageUnit, { isLoading: isManagingUnit }] = useManageUnitMutation();


  // Add unit details query
  const {
    data: unitDetailsResponse,
    isLoading: isLoadingUnitDetails,
    refetch: refetchUnitDetails
  } = useGetUnitDetailsQuery(
    { unit_id: selectedUnitId, property_id: selectedPropertyId, uid: currentOwnerId },
    { skip: !selectedUnitId || !selectedPropertyId }
  );

  const properties = useMemo(() => propertyListResponse?.properties || [], [propertyListResponse]);
  const selectedProperty = useMemo(
    () => properties.find(p => p.id === selectedPropertyId) || null,
    [properties, selectedPropertyId]
  );
  const unitsForSelectedProperty = useMemo(() => selectedProperty?.units || [], [selectedProperty]);
  const selectedUnit = useMemo(() => {
    if (unitDetailsResponse) {
      return unitDetailsResponse;
    }
    return unitsForSelectedProperty.find(u => u.id === selectedUnitId) || { unit: null };
  }, [unitsForSelectedProperty, selectedUnitId, unitDetailsResponse]);

  useEffect(() => {
    if (!selectedPropertyId && properties.length > 0 && !isNewPropertyMode) {
      setSelectedPropertyId(properties[0].id);
      setActivePane('property');
    }
  }, [properties, selectedPropertyId, isNewPropertyMode]);

  // Tab Definitions
  const propertyTabs = useMemo(
    () => [
      { key: 'details', label: 'Details', icon: <FaBuilding /> },
      { key: 'AI Analysis', label: 'AI Analysis', icon: <FaRobot /> },
    ],
    []
  );
  const unitTabs = useMemo(
    () => [
      { key: 'details', label: 'Unit Details', icon: <FaBuilding /> },
      { key: 'tenant', label: 'Tenant', icon: <FaUser /> },
      { key: 'finance', label: 'Finance', icon: <FaDollarSign /> },
    ],
    []
  );
  const unitDetailSubTabs = useMemo(() => ['description', 'amenities', 'rent'], []);
  const tenantSubTabs = useMemo(() => ['personal details', 'document', 'rentals', 'Payments'], []);
  const financeSubTabs = useMemo(() => ['transaction', 'Bond Track'], []);

  const currentInfoTabs = useMemo(
    () => (activePane === 'property' ? propertyTabs : unitTabs),
    [activePane, propertyTabs, unitTabs]
  );
  const currentSubTabs = useMemo(() => {
    if (activePane === 'unit') {
      if (activeInfoTab === 'details') return unitDetailSubTabs;
      if (activeInfoTab === 'tenant') return tenantSubTabs;
      if (activeInfoTab === 'finance') return financeSubTabs;
    }
    return [];
  }, [activePane, activeInfoTab, unitDetailSubTabs, tenantSubTabs, financeSubTabs]);

  // Effect to reset tabs
  useEffect(() => {
    if (activePane === 'property') {
      if (!propertyTabs.find(t => t.key === activeInfoTab)) {
        setActiveInfoTab(propertyTabs[0]?.key || 'details');
      }
      setActiveSubTab('');
    } else if (activePane === 'unit') {
      if (!unitTabs.find(t => t.key === activeInfoTab)) {
        setActiveInfoTab(unitTabs[0]?.key || 'details');
      }
      if (activeInfoTab === 'details' && !unitDetailSubTabs.includes(activeSubTab)) {
        setActiveSubTab(unitDetailSubTabs[0]);
      } else if (activeInfoTab === 'tenant' && !tenantSubTabs.includes(activeSubTab)) {
        setActiveSubTab(tenantSubTabs[0]);
      } else if (activeInfoTab === 'finance' && !financeSubTabs.includes(activeSubTab)) {
        setActiveSubTab(financeSubTabs[0]);
      }
    }
  }, [
    activePane,
    activeInfoTab,
    propertyTabs,
    unitTabs,
    unitDetailSubTabs,
    tenantSubTabs,
    financeSubTabs,
    activeSubTab,
  ]);

  // Effect to handle tab changes when unitDetailsResponse is loaded
  useEffect(() => {
    if (selectedUnitId && unitDetailsResponse?.unit) {
      // Make sure we're in unit view with appropriate tabs
      setActivePane('unit');
      if (!unitTabs.find(t => t.key === activeInfoTab)) {
        setActiveInfoTab(unitTabs[0]?.key || 'details');
      }
    }
  }, [unitDetailsResponse, selectedUnitId, unitTabs, activeInfoTab]);

  // Navigation handlers
  const handleSelectProperty = propertyId => {
    setSelectedPropertyId(propertyId);
    setSelectedUnitId(null);
    setActivePane('property');
    setActiveInfoTab('details');
    setIsNewPropertyMode(false);
    setIsNewUnitMode(false);
  };

  const handleSelectUnit = unitId => {
    setSelectedUnitId(unitId);
    setActivePane('unit');
    setActiveInfoTab('details');
    setActiveSubTab('description');
    setIsNewUnitMode(false);
  };

  const handleNewProperty = () => {
    setSelectedPropertyId(null);
    setSelectedUnitId(null);
    setActivePane('property');
    setActiveInfoTab('details');
    setActiveSubTab('');
    setIsNewPropertyMode(true);
    setIsNewUnitMode(false);
  };

  const handleAddNewUnit = () => {
    if (!selectedPropertyId) {
      toast.warn('Please select a property first.');
      return;
    }
    setSelectedUnitId(null);
    setActivePane('unit');
    setActiveInfoTab('details');
    setActiveSubTab('description');
    setIsNewUnitMode(true);
  };

  // Instead of window.confirm, open modal
  const confirmDeleteProperty = () => {
    setConfirmMessage(`Are you sure you want to delete property: ${selectedProperty?.name}? This action cannot be undone.`);
    setConfirmAction('property');
    setShowConfirm(true);
  };

  const confirmDeleteUnit = () => {
    setConfirmMessage(`Are you sure you want to delete unit: ${selectedUnit?.unit?.name}? This action cannot be undone.`);
    setConfirmAction('unit');
    setShowConfirm(true);
  };

  // Called when modal "Delete" clicked
  const onConfirmDelete = async () => {
    setShowConfirm(false);

    if (confirmAction === 'property') {
      try {
        await manageProperty({
          action: 'delete',
          property_id: selectedPropertyId,
          uid: currentOwnerId,
        }).unwrap();
        toast.success('Property deleted successfully.');
        refetchProperties();
        setSelectedPropertyId(
          properties.length > 1
            ? properties.find(p => p.id !== selectedPropertyId)?.id || null
            : null
        );
        setActivePane('property');
        setIsNewPropertyMode(false);
      } catch (err) {
        console.error('Failed to delete property:', err);
        toast.error(`Error deleting property: ${err.data?.message || 'Could not delete property.'}`);
      }
    } else if (confirmAction === 'unit') {
      try {
        await manageUnit({
          action: 'delete',
          unit_id: selectedUnitId,
          property_id: selectedPropertyId,
          uid: currentOwnerId,
        }).unwrap();
        toast.success('Unit deleted successfully.');
        refetchProperties();
        setSelectedUnitId(null);
        setActivePane('property');
        setIsNewUnitMode(false);
      } catch (err) {
        console.error('Failed to delete unit:', err);
        toast.error(`Error deleting unit: ${err.data?.message || 'Could not delete unit.'}`);
      }
    }
  };

  // -------------------------------------------------------
  //   HANDLERS TO PRESERVE CURRENT TAB AFTER A MUTATION
  // -------------------------------------------------------

  // When a property is created or updated, just refetch
  // and select it—DO NOT reset activePane/activeInfoTab.
  const handlePropertyCreatedOrUpdated = newlySelectedPropertyId => {
    setIsNewPropertyMode(false);
    refetchProperties().then(() => {
      if (newlySelectedPropertyId) {
        setSelectedPropertyId(newlySelectedPropertyId);
        // No setActivePane or setActiveInfoTab here—user stays on current tab.
      }
    });
  };

  // When a unit is created or updated, just refetch
  // and select it—DO NOT reset activePane/activeInfoTab/activeSubTab.
  const handleUnitCreatedOrUpdated = newlySelectedUnitId => {
    setIsNewUnitMode(false);
    refetchProperties().then(() => {
      if (newlySelectedUnitId) {
        setSelectedUnitId(newlySelectedUnitId);
        // No setActivePane, setActiveInfoTab, or setActiveSubTab here—
        // user remains on the same tab/sub‐tab they were on.
        if (selectedPropertyId) {
          refetchUnitDetails();
        }
      }
    });
  };

  // When tenants change, we still just refetch unit details;
  // no tab changes needed here either.
  const handleTenantUpdated = () => {
    refetchProperties();
    if (selectedUnitId && selectedPropertyId) {
      refetchUnitDetails();
    }
  };

  // Current component to render
  const CurrentActiveComponent = useMemo(() => {
    if (isNewPropertyMode && activePane === 'property' && activeInfoTab === 'details')
      return PropertyDetails;
    if (isNewUnitMode && activePane === 'unit' && activeInfoTab === 'details')
      return UnitDetails;

    if (activePane === 'property') {
      if (!selectedPropertyId && !isNewPropertyMode)
        return () => <div className="p-4 text-center text-muted">Please select a property or create a new one.</div>;
      if (activeInfoTab === 'details') return PropertyDetails;
      if (activeInfoTab === 'AI Analysis') return PropertyAI;
    } else if (activePane === 'unit') {
      if (!selectedPropertyId)
        return () => <div className="p-4 text-center text-muted">Please select a property first.</div>;
      if (!selectedUnitId && !isNewUnitMode)
        return () => <div className="p-4 text-center text-muted">Please select a unit or add a new one.</div>;
      if (activeInfoTab === 'details') return UnitDetails;
      if (activeInfoTab === 'tenant') return UnitTenants;
      if (activeInfoTab === 'finance') return UnitFinance;
    }
    return () => <div className="p-4 text-center text-muted">Select an item or tab to view details.</div>;
  }, [activePane, activeInfoTab, selectedPropertyId, selectedUnitId, isNewPropertyMode, isNewUnitMode]);

  return (
    <>
      <div className="d-flex flex-column flex-md-row properties-container">
        {/* LEFT SIDEBAR */}
        <aside className="bg-white p-3 p-md-4 border-end mt-4 property-sidebar custom-scrollbar">
          <div className="text-center mb-4">
            <img
              src={selectedOwnerDetails.avatar}
              className="rounded-circle mb-2"
              width={72}
              height={72}
              alt="Avatar"
              onError={e => {
                e.target.onerror = null;
                // Fallback to a generic avatar if the owner/company logo fails to load
                e.target.src = `https://i.pravatar.cc/72?u=${selectedOwnerDetails.id || 'default'}`;
              }}
            />
            <h6 className="fw-bold mb-0 text-truncate">{selectedOwnerDetails.name}</h6>
            <small className="text-muted text-truncate d-block">{selectedOwnerDetails.email}</small>
          </div>
          <button
            className="btn w-100 mb-3 fw-semibold btn-sm"
            style={{ borderColor: '#7665d8', color: '#7665d8', boxShadow: 'none', backgroundColor: 'white' }}
            onClick={handleNewProperty}
          >
            <FaPlus className="me-1" /> New Property
          </button>
          <h6 className="text-secondary fw-bold small mb-2">Properties</h6>
          <div className="overflow-auto p-2 custom-scrollbar" style={{
            width: '100%',
            maxHeight: 'calc(100vh - 380px)'
          }}>
            {isLoadingProperties && <p className="text-muted small">Loading properties...</p>}
            {propertiesError && <p className="text-danger small">Error loading properties.</p>}
            {!isLoadingProperties && properties.length === 0 && !isNewPropertyMode && (
              <p className="text-muted small text-center mt-3">
                No properties found. Click "New Property" to add one.
              </p>
            )}
            {properties.map(p => (
              <a
                key={p.id}
                onClick={() => handleSelectProperty(p.id)}
                className={`d-block small text-truncate p-2 rounded ${selectedPropertyId === p.id && !isNewPropertyMode ? 'fw-semibold text-white' : 'text-muted'
                  }`}
                style={{
                  cursor: 'pointer',
                  lineHeight: '1.8',
                  marginBottom: 4,
                  backgroundColor: selectedPropertyId === p.id && !isNewPropertyMode ? '#7665d8' : 'transparent',
                }}
                title={p.name}
              >
                {p.name}
              </a>
            ))}
          </div>
        </aside>

        {/* MAIN BOARD */}
        <main className="flex-fill p-2 p-md-4 property-main custom-scrollbar">
          {/* HEADER */}
          <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center bg-white p-3 rounded-top mb-1 shadow-sm">
            <div className="d-flex flex-column mb-2 mb-md-0">
              <small className="text-muted text-truncate">
                {isNewPropertyMode
                  ? 'Creating New Property'
                  : selectedProperty
                    ? `Property: ${selectedProperty.name}`
                    : 'No Property Selected'}
              </small>
              <h6 className="mb-0 text-truncate">
                {activePane === 'unit' && (selectedUnit?.unit || isNewUnitMode)
                  ? isNewUnitMode
                    ? ' / Adding New Unit'
                    : `Unit: ${selectedUnit?.unit?.name}`
                  : ''}
              </h6>
            </div>
            <div className="d-flex align-items-center gap-2 gap-md-3">
              <label className="small fw-semibold mb-0">Owner</label>
              <select
                className="form-select form-select-sm bg-white"
                style={{
                  width: '250px',
                  maxWidth: '100%',
                  borderColor: '#ced4da',
                  boxShadow: 'none'
                }}
                value={currentOwnerId}
                onChange={e => setCurrentOwnerId(e.target.value)}
                disabled={isManagingProperty || isLoadingProperties}
              >
                {ownerOptions.map(o => (
                  <option key={o.id} value={o.id}>
                    {o.name}
                  </option>
                ))}
              </select>
              <button
                className="btn btn-sm"
                onClick={activePane === 'property' ? confirmDeleteProperty : confirmDeleteUnit}
                disabled={
                  isManagingProperty ||
                  isManagingUnit ||
                  (activePane === 'property' && (!selectedPropertyId || isNewPropertyMode)) ||
                  (activePane === 'unit' && (!selectedPropertyId || (!selectedUnitId && !isNewUnitMode)))
                }
                title={activePane === 'property' ? 'Delete Property' : 'Delete Unit'}
                style={{ color: 'red', border: 'none', background: 'transparent' }}
              >
                <FaTrashAlt />
              </button>
            </div>
          </div>

          {/* CONTENT AREA */}
          <div className="d-flex flex-column flex-md-row property-content shadow-sm" style={{ height: 'calc(100% - 60px)' }}>
            {/* UNITS column */}
            {selectedPropertyId && !isNewPropertyMode && (
              <div className="border-end d-flex flex-column units-column custom-scrollbar" style={{ height: '100%' }}>
                <button
                  className="btn w-100 mb-3 fw-semibold btn-sm"
                  style={{ borderColor: '#7665d8', color: '#7665d8', boxShadow: 'none', backgroundColor: 'white' }}
                  onClick={handleAddNewUnit}
                  disabled={!selectedPropertyId || isNewPropertyMode || isManagingUnit}
                >
                  <FaPlus className="me-1" /> New Unit
                </button>
                <h6 className="text-secondary fw-bold small mb-2">Units</h6>
                <div className="flex-grow-1 overflow-auto p-3 custom-scrollbar">
                  {unitsForSelectedProperty.length === 0 && (
                    <p className="text-muted text-center small mt-2">No units for this property.</p>
                  )}
                  {unitsForSelectedProperty.map(u => {
                    const isSelected = selectedUnitId === u.id && !isNewUnitMode;
                    return (
                      <div
                        key={u.id}
                        onClick={() => handleSelectUnit(u.id)}
                        className={`d-flex align-items-center px-3 py-2 rounded ${isSelected ? 'text-white' : ''}`}
                        style={{
                          cursor: 'pointer',
                          background: isSelected ? '#7665d8' : 'transparent',
                          marginBottom: 4,
                        }}
                      >
                        <FaBuilding className="me-3" style={{ color: isSelected ? 'white' : '#6c757d' }} />
                        <div className="fw-semibold small text-truncate">{u.name}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* INFO column */}
            <div className="h-100 d-flex flex-column flex-fill info-column">
              {/* Top-level info tabs */}
              {(selectedPropertyId || isNewPropertyMode) && (
                <nav className="nav px-3 px-md-4 pt-3 mb-2 border-bottom-0 overflow-auto custom-scrollbar">
                  {currentInfoTabs.map(tab => (
                    <a
                      key={tab.key}
                      href="#"
                      onClick={e => {
                        e.preventDefault();
                        setActiveInfoTab(tab.key);
                      }}
                      className={`nav-link d-inline-flex align-items-center text-capitalize me-2 ${activeInfoTab === tab.key ? 'active fw-semibold' : 'text-secondary'
                        }`}
                    >
                      {tab.icon && React.cloneElement(tab.icon, { className: 'me-1' })}
                      {tab.label}
                    </a>
                  ))}
                </nav>
              )}

              {/* Sub-tabs for unit */}
              {activePane === 'unit' && currentSubTabs.length > 0 && (selectedPropertyId && (selectedUnitId || isNewUnitMode)) && (
                <ul className="nav nav-pills small mt-1 mb-3 px-3 px-md-4 overflow-auto flex-nowrap custom-scrollbar">
                  {currentSubTabs.map(st => (
                    <li className="nav-item" key={st}>
                      <button
                        className={`nav-link rounded-pill text-capitalize py-1 px-2 me-1 ${activeSubTab === st ? 'active' : 'text-secondary'
                          }`}
                        onClick={() => setActiveSubTab(st)}
                      >
                        {st}
                      </button>
                    </li>
                  ))}
                </ul>
              )}

              {/* Content panel */}
              <div className="flex-grow-1 px-3 px-md-4 pb-4 mt-2 content-panel custom-scrollbar">
                <Suspense fallback={<div className="text-center text-muted py-5">Loading component...</div>}>
                  {isLoadingUnitDetails && activePane === 'unit' && !isNewUnitMode ? (
                    <div className="text-center py-5">
                      <div className="spinner-border text-primary" role="status">
                        <span className="visually-hidden">Loading unit details...</span>
                      </div>
                      <p className="mt-2 text-muted">Loading unit details...</p>
                    </div>
                  ) : CurrentActiveComponent ? (
                    <CurrentActiveComponent
                      propertyId={selectedPropertyId}
                      unitId={selectedUnitId}
                      userId={currentOwnerId}
                      userType={LOGGED_IN_USER_TYPE}
                      parentId={selectedProperty?.parent_id}
                      subTab={activeSubTab}
                      isNewMode={activePane === 'property' ? isNewPropertyMode : isNewUnitMode}
                      onPropertySaved={handlePropertyCreatedOrUpdated}
                      onUnitSaved={handleUnitCreatedOrUpdated}
                      onTenantUpdated={handleTenantUpdated}
                      property={selectedProperty}
                      unit={selectedUnit}
                    />
                  ) : null}
                </Suspense>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Confirmation Modal */}
      <Modal show={showConfirm} onHide={() => setShowConfirm(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>{confirmMessage}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowConfirm(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={onConfirmDelete}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default Properties;