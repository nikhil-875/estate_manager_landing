import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { PERMISSIONS_MAPPING } from '../constants/config';
import { usePermissions } from '../hooks/usePermissions';
import { useGetS3DownloadUrlQuery } from '../api/uploadApi';
import { UserProfile } from '../components/settings/UserProfile';
import { Password } from '../components/settings/Password';
import { General } from '../components/settings/General';
import { Email } from '../components/settings/Email';
import { Payment } from '../components/settings/Payment';
import { Company } from '../components/settings/Company';
import { getFallbackImage, handleImageError } from '../utils/fallbackImage';

/***********************
 * SETTINGS WRAPPER UI *
 ***********************/
const views = [
  { id: 'profile', label: 'User Profile', component: UserProfile, permission: null },
  { id: 'password', label: 'Password', component: Password, permission: null },
  { id: 'general', label: 'General', component: General, permission: PERMISSIONS_MAPPING.MANAGE_GENERAL_SETTINGS },
  { id: 'company', label: 'Company', component: Company, permission: PERMISSIONS_MAPPING.MANAGE_COMPANY_SETTINGS },
  { id: 'email', label: 'Email', component: Email, permission: PERMISSIONS_MAPPING.MANAGE_EMAIL_SETTINGS },
  { id: 'payment', label: 'Payment', component: Payment, permission: PERMISSIONS_MAPPING.MANAGE_PAYMENT_SETTINGS }
];

export const Settings = () => {
  const loggedInUser = useSelector(state => state.auth.user);
  const { canHavePermission } = usePermissions();

  // determine which tabs the user can see
  const availableViews = views.filter(view =>
    !view.permission || canHavePermission(view.permission)
  );

  // active tab state
  const initialActiveId = availableViews.some(v => v.id === 'profile')
    ? 'profile'
    : availableViews[0]?.id || null;
  const [active, setActive] = useState(initialActiveId);

  // fetch remote profile image URL (if any)
  const { data: downloadData } = useGetS3DownloadUrlQuery(loggedInUser.profile, {
    skip: !loggedInUser.profile
  });

  const avatarUrl = downloadData?.data?.url || getFallbackImage(loggedInUser?.first_name);

  // ensure active tab stays valid if permissions change
  useEffect(() => {
    if (active && !availableViews.some(v => v.id === active)) {
      setActive(availableViews[0]?.id || null);
    } else if (!active && availableViews.length > 0) {
      setActive(availableViews[0].id);
    }
  }, [availableViews, active]);

  const currentView = availableViews.find(v => v.id === active);
  const ActiveComponent = currentView?.component;

  if (!ActiveComponent) {
    return (
      <div className="page-body-wrapper d-flex justify-content-center align-items-center" style={{ padding: '1rem', background: '#f5f6f8', minHeight: '100vh' }}>
        <div className="alert alert-warning" role="alert">
          No settings available or accessible for this user.
        </div>
      </div>
    );
  }

  return (
    <div className="page-body-wrapper d-flex" style={{ padding: '1rem', background: '#f5f6f8', minHeight: 'calc(100vh - 200px)' }}>
      <aside
        style={{
          width: 220,
          background: '#fff',
          borderRadius: 8,
          padding: '1rem',
          marginRight: '1rem',
          minHeight: 480
        }}
      >
        <div className="mb-3 d-flex align-items-center">
          <img
            src={avatarUrl}
            alt="avatar"
            onError={(e) => handleImageError(e, loggedInUser?.first_name)}
            className="rounded-circle me-2"
            width={48}
            height={48}
          />
          <div>
  <h6 className="fw-bold mb-0">
    {loggedInUser?.first_name?.length > 15
      ? `${loggedInUser.first_name.slice(0, 15)}...`
      : loggedInUser?.first_name}
  </h6>
  <small className="text-muted">
    {loggedInUser?.email?.length > 15
      ? `${loggedInUser.email.slice(0, 15)}...`
      : loggedInUser?.email}
  </small>
</div>

        </div>
<br></br>
        <h6 className="text-muted fw-bold mb-2" style={{marginLeft:'10px'}}>Settings</h6>
        <br></br>
        <ul className="list-unstyled">
          {availableViews.map(v => (
            <li key={v.id} className="mb-1">
              <button
                onClick={() => setActive(v.id)}
                className={`w-100 text-start btn ${v.id === active ? 'fw-bold text-white bg-primary' : 'text-muted'}`}
                style={{ borderRadius: 6, padding: '0.5rem 1rem' }}
              >
                {v.label}
              </button>
            </li>
          ))}
        </ul>
      </aside>

      <main className="flex-grow-1">
        <div className="card shadow-sm" style={{ minHeight: 480 }}>
          <div className="card-header">
            <h4 className="mb-0">{currentView.label}</h4>
          </div>
          <ActiveComponent />
        </div>
      </main>
    </div>
  );
};
