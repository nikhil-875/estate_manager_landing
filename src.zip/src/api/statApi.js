import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { env } from '../config/env';

export const statsApi = createApi({
    reducerPath: 'statsApi',
    baseQuery: fetchBaseQuery({
        baseUrl: `${env.API_URL}/api/v1`, // Base URL for stats routes
        prepareHeaders: (headers) => {
            const token = localStorage.getItem('token');

            if (token) {
                headers.set('Authorization', `Bearer ${token}`);
            }
            return headers;
        },
    }),
    tagTypes: ['Stats', 'Transactions'], // Define tags for caching invalidation
    endpoints: (builder) => ({

        // --- COMPANY STATS ---
        // Expects userId as argument, returns stats object
        getCompanyExpenseStats: builder.query({
            query: (userId) => `/company/expense/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `CompanyExpense-${arg}` }],
        }),
        // Expects userId as argument, returns stats object
        getCompanyRegistrationStats: builder.query({
            query: (userId) => `/company/registration/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `CompanyRegistration-${arg}` }],
        }),
        // Expects userId as argument, returns stats object
        getCompanyRevenueStats: builder.query({
            query: (userId) => `/company/revenue/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `CompanyRevenue-${arg}` }],
        }),
        // Expects userId as argument, returns { userId, monthlyData }
        getCompanySalesOverview: builder.query({
            query: (userId) => `/company/sales-overview/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `CompanySalesOverview-${arg}` }],
        }),
        // Expects userId as argument, returns stats object
        getCompanySubscriberStats: builder.query({
            query: (userId) => `/company/subscriber/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `CompanySubscriber-${arg}` }],
        }),
        // Expects userId as argument, returns { count, transactions }
        getCompanyTransactions: builder.query({
            query: (userId) => `/company/transactions/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Transactions', id: `Company-${arg}` }],
        }),
        

        // --- OWNER STATS ---
        // Expects userId as argument, returns stats object
        getOwnerExpenseStats: builder.query({
            query: (userId) => `stats/owner/expense/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `OwnerExpense-${arg}` }],
        }),
        // Expects userId as argument, returns stats object with registerUser
        getOwnerRegistrationStats: builder.query({
            query: (userId) => `stats/owner/registration/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `OwnerRegistration-${arg}` }],
        }),
        // Expects userId as argument, returns stats object with totalAmountPerYear
        getOwnerRevenueStats: builder.query({
            query: (userId) => `stats/owner/revenue/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `OwnerRevenue-${arg}` }],
        }),
        // Expects userId as argument, returns { userId, monthlyData }
        getOwnerSalesOverview: builder.query({
            query: (userId) => `stats/owner/sales-overview/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `OwnerSalesOverview-${arg}` }],
        }),
        // Expects userId as argument, returns stats object with activeCircle
        getOwnerSubscriberStats: builder.query({
            query: (userId) => `stats/owner/subscriber/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Stats', id: `OwnerSubscriber-${arg}` }],
        }),
        // Expects userId as argument, returns { count, transactions }
        getOwnerTransactions: builder.query({
            query: (userId) => `stats/owner/transactions/${userId}`,
            providesTags: (result, error, arg) => [{ type: 'Transactions', id: `Owner-${arg}` }],
        }),
    }),
});

// Export hooks for usage in functional components
export const {
    // Company hooks
    useGetCompanyExpenseStatsQuery,
    useGetCompanyRegistrationStatsQuery,
    useGetCompanyRevenueStatsQuery,
    useGetCompanySalesOverviewQuery,
    useGetCompanySubscriberStatsQuery,
    useGetCompanyTransactionsQuery,
    // Owner hooks
    useGetOwnerExpenseStatsQuery,
    useGetOwnerRegistrationStatsQuery,
    useGetOwnerRevenueStatsQuery,
    useGetOwnerSalesOverviewQuery,
    useGetOwnerSubscriberStatsQuery,
    useGetOwnerTransactionsQuery,
} = statsApi;