// src/api/settingsApi.js
import { createApi } from '@reduxjs/toolkit/query/react';
import { createBaseQueryWithTokenExpiration } from './baseQuery';

export const settingsApi = createApi({
  reducerPath: 'settingsApi',
  baseQuery: createBaseQueryWithTokenExpiration('/api/v1/settings'),
  tagTypes: [
    'UserProfile',
    'GeneralSettings',
    'EmailSettings',
    'PaymentSettings',
    'CompanySettings',    // ← added
  ],
  endpoints: (builder) => ({
    // ─── User Profile ────────────────────────────────────────────────────────────
    getUserProfile: builder.query({
      query: () => `/user-profile`,
      providesTags: ['UserProfile'],
    }),
    updateUserProfile: builder.mutation({
      query: (profileData) => ({
        url: `/user-profile`,
        method: 'PUT',
        body: profileData,
      }),
      invalidatesTags: ['UserProfile'],
    }),

    // ─── Password ────────────────────────────────────────────────────────────────
    changePassword: builder.mutation({
      query: (passwordData) => ({
        url: `/change-password`,
        method: 'POST',
        body: passwordData,
      }),
    }),

    // ─── General Settings ───────────────────────────────────────────────────────
    getGeneralSettings: builder.query({
      query: () => `/general-settings`,
      providesTags: ['GeneralSettings'],
    }),
    updateGeneralSettings: builder.mutation({
      query: (settingsData) => ({
        url: `/general-settings`,
        method: 'PUT',
        body: settingsData,
      }),
      invalidatesTags: ['GeneralSettings'],
    }),

    // ─── Email Settings ─────────────────────────────────────────────────────────
    getEmailSettings: builder.query({
      query: () => `/email-settings`,
      providesTags: ['EmailSettings'],
    }),
    updateEmailSettings: builder.mutation({
      query: (settingsData) => ({
        url: `/email-settings`,
        method: 'PUT',
        body: settingsData,
      }),
      invalidatesTags: ['EmailSettings'],
    }),
    testEmailSettings: builder.mutation({
      query: (test_recipient) => ({
        url: `/email-settings/test-mail`,
        method: 'POST',
        body: { test_recipient },
      }),
    }),
    requestPasswordResetSettings: builder.mutation({
      query: (body) => ({
        url: '/request-password-reset',
        method: 'POST',
        body,
      }),
    }),

    // ─── Payment Settings ───────────────────────────────────────────────────────
    getPaymentSettings: builder.query({
      query: () => `/payment-settings`,
      providesTags: ['PaymentSettings'],
    }),
    updatePaymentSettings: builder.mutation({
      query: (settingsData) => ({
        url: `/payment-settings`,
        method: 'PUT',
        body: settingsData,
      }),
      invalidatesTags: ['PaymentSettings'],
    }),

    // ─── Company Settings ───────────────────────────────────────────────────────
    getCompanySettings: builder.query({
      query: () => `/company-settings`,
      providesTags: ['CompanySettings'],
    }),
    updateCompanySettings: builder.mutation({
      query: (settingsData) => ({
        url: `/company-settings`,
        method: 'PUT',
        body: settingsData,
      }),
      invalidatesTags: ['CompanySettings'],
    }),

    // ─── Get Company By ID ───────────────────────────────────────────────────────
    getCompanyById: builder.query({
      query: (companyId) => `/company-settings/${companyId}`,
      providesTags: (result, error, companyId) => [
        { type: 'CompanySettings', id: companyId },
      ],
    }),

    // ─── Update Company Logo ─────────────────────────────────────────────────────
    updateCompanyLogo: builder.mutation({
      query: (formData) => ({
        url: `/company-settings/logo`,
        method: 'PUT',
        body: formData,
      }),
      invalidatesTags: ['CompanySettings'],
    }),
  }),
});

export const {
  useGetUserProfileQuery,
  useUpdateUserProfileMutation,
  useChangePasswordMutation,
  useGetGeneralSettingsQuery,
  useUpdateGeneralSettingsMutation,
  useGetEmailSettingsQuery,
  useUpdateEmailSettingsMutation,
  useTestEmailSettingsMutation,
  useRequestPasswordResetSettingsMutation,
  useGetPaymentSettingsQuery,
  useUpdatePaymentSettingsMutation,
  useGetCompanySettingsQuery,
  useUpdateCompanySettingsMutation,
  useGetCompanyByIdQuery,         // ← now exported
  useUpdateCompanyLogoMutation,   // ← now exported
} = settingsApi;
