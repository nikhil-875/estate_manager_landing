import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { env } from '../config/env';

export const propertyApi = createApi({
  reducerPath: 'propertyApi',
  baseQuery: fetchBaseQuery({
    baseUrl: `${env.API_URL}/api/v1/`,
    prepareHeaders: (headers) => {
      headers.set('Content-Type', 'application/json');
      const token = localStorage.getItem('token');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: [
    'Property',
    'Properties',
    'Unit',
    'Units',
    'Tenant',
    'Tenants',
    'Document',
    'Contract',
    'Invitation',
    'Amenity',
    'Image',
    'UnitTransaction',
    'UnitExpense',
    'UnitRevenue'
  ],
  endpoints: (builder) => ({
    // Property Management
    manageProperty: builder.mutation({
      query: (body) => ({
        url: 'property/manage',
        method: 'POST',
        body,
      }),
      invalidatesTags: (result, _error, arg) =>
        arg.action === 'insert' || arg.action === 'update'
          ? [
            { type: 'Property', id: result?.property_id || arg.property_id },
            { type: 'Properties', id: 'LIST' }
          ]
          : arg.action === 'delete'
            ? [
              { type: 'Property', id: arg.property_id },
              { type: 'Properties', id: 'LIST' }
            ]
            : [{ type: 'Properties', id: 'LIST' }],
    }),
    getPropertyList: builder.query({
      query: (body) => ({
        url: 'property/details',
        method: 'POST',
        body,
      }),
      providesTags: (result) =>
        result?.properties
          ? [
            ...result.properties.map(({ id }) => ({ type: 'Property', id })),
            { type: 'Properties', id: 'LIST' }
          ]
          : [{ type: 'Properties', id: 'LIST' }],
    }),
    getSinglePropertyDetails: builder.query({
      query: (body) => ({
        url: 'property/details',
        method: 'POST',
        body,
      }),
      providesTags: (result) =>
        result?.property ? [{ type: 'Property', id: result.property.id }] : [],
    }),

    // Unit Management
    manageUnit: builder.mutation({
      query: (body) => ({
        url: 'property/unit',
        method: 'POST',
        body,
      }),
      invalidatesTags: (_result, _error, arg) => [
        { type: 'Unit', id: arg.unit_id },
        { type: 'Units', id: `LIST-${arg.property_id}` },
        { type: 'Property', id: arg.property_id }
      ],
    }),
    getUnitDetails: builder.query({
      query: (body) => ({
        url: 'property/unit/details',
        method: 'POST',
        body,
      }),
      providesTags: (result) =>
        result?.unit ? [{ type: 'Unit', id: result.unit.id }] : [],
    }),

    // Amenities Management
    getAllAmenities: builder.query({
      query: () => ({
        url: 'property/amenities',
        method: 'GET',
      }),
      providesTags: [{ type: 'Amenity', id: 'LIST' }],
    }),
    setPropertyAmenities: builder.mutation({
      query: (body) => ({
        url: 'property/amenities',
        method: 'POST',
        body,
      }),
      invalidatesTags: (_result, _error, arg) =>
        [
          { type: 'Amenity', id: `PROPERTY-${arg.property_id}` },
          arg.unit_id && { type: 'Amenity', id: `UNIT-${arg.unit_id}` },
          { type: 'Property', id: arg.property_id },
          arg.unit_id && { type: 'Unit', id: arg.unit_id }
        ].filter(Boolean),
    }),

    // Image Management
    managePropertyImage: builder.mutation({
      query: (body) => ({
        url: 'property/image',
        method: 'POST',
        body,
      }),
      invalidatesTags: (_result, _error, arg) =>
        [
          { type: 'Image', id: `PROPERTY-${arg.property_id}` },
          arg.unit_id && { type: 'Image', id: `UNIT-${arg.unit_id}` },
          { type: 'Property', id: arg.property_id },
          arg.unit_id && { type: 'Unit', id: arg.unit_id }
        ].filter(Boolean),
    }),

    // Document Management (AI Analysis)
    managePropertyDocument: builder.mutation({
      query: (body) => ({
        url: 'property/document',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Document'],
    }),

    // Tenant Management
    manageTenant: builder.mutation({
      query: (body) => ({
        url: 'tenant/manage',
        method: 'POST',
        body,
      }),
      invalidatesTags: (result, _error, arg) =>
        arg.action === 'insert' || arg.action === 'update'
          ? [
            { type: 'Tenant', id: result?.tenant_id || arg.id },
            { type: 'Tenants', id: 'LIST' }
          ]
          : arg.action === 'delete'
            ? [
              { type: 'Tenant', id: arg.id },
              { type: 'Tenants', id: 'LIST' }
            ]
            : [{ type: 'Tenants', id: 'LIST' }],
    }),
    getTenantDetails: builder.query({
      query: (body) => ({
        url: 'tenant/details',
        method: 'POST',
        body,
      }),
      providesTags: (result) =>
        result?.tenant ? [{ type: 'Tenant', id: result.tenant.id }] : [],
    }),
    manageTenantInvitation: builder.mutation({
      query: (body) => ({
        url: 'tenant/invitation',
        method: 'POST',
        body,
      }),
      invalidatesTags: (_result, _error, arg) => [
        'Invitation',
        { type: 'Tenant', id: arg.tenant_id || _result?.tenant_id }
      ],
    }),
    manageTenantAddress: builder.mutation({
      query: (body) => ({
        url: 'tenant/address',
        method: 'POST',
        body,
      }),
      invalidatesTags: (_result, _error, arg) => [
        { type: 'Tenant', id: arg.tenant_id }
      ],
    }),
    manageTenantDocument: builder.mutation({
      query: (body) => ({
        url: 'tenant/document',
        method: 'POST',
        body,
      }),
      invalidatesTags: (_result, _error, arg) => [
        'Document',
        { type: 'Tenant', id: arg.tenant_id }
      ],
    }),
    manageTenantContract: builder.mutation({
      query: (body) => ({
        url: 'tenant/contract',
        method: 'POST',
        body,
      }),
      invalidatesTags: (_result, _error, arg) => [
        'Contract',
        { type: 'Tenant', id: arg.tenant_id }
      ],
    }),
    getTenantList: builder.query({
      query: (params) => ({
        url: 'tenant/list',
        method: 'POST',
        body: params,
      }),
      providesTags: (result) =>
        result?.tenants
          ? [
            ...result.tenants.map(({ id }) => ({ type: 'Tenant', id })),
            { type: 'Tenants', id: 'LIST' }
          ]
          : [{ type: 'Tenants', id: 'LIST' }],
    }),

    // Unit Financial Data Endpoints
    getUnitTransactions: builder.query({
      query: ({ unitId, propertyId, ownerId, userId }) => ({
        url: `property/unit/${unitId}/transactions`,
        method: 'POST',
        body: { property_id: propertyId, ownerId: ownerId || userId }
      }),
      providesTags: (_result, _error, arg) => [
        { type: 'UnitTransaction', id: arg.unitId }
      ],
    }),
    getUnitExpenses: builder.query({
      query: ({ unitId, propertyId, ownerId, userId }) => ({
        url: `property/unit/${unitId}/expenses`,
        method: 'POST',
        body: { property_id: propertyId, ownerId: ownerId || userId }
      }),
      providesTags: (_result, _error, arg) => [
        { type: 'UnitExpense', id: arg.unitId }
      ],
    }),
    managePropertyTransaction: builder.mutation({
      query: (body) => ({
        url: 'property/transaction',
        method: 'POST',
        body,
      }),
      invalidatesTags: (result, _error, arg) => {
        if (['insert', 'update'].includes(arg.action)) {
          return [
            { type: 'UnitTransaction', id: result?.transaction_id || arg.unit_id },
            { type: 'Unit', id: arg.unit_id },
            { type: 'Property', id: arg.property_id }
          ];
        }
        if (arg.action === 'delete') {
          return [
            { type: 'UnitTransaction', id: arg.id },
            { type: 'Unit', id: arg.unit_id },
            { type: 'Property', id: arg.property_id }
          ];
        }
        return [];
      }
    }),
    getUnitRevenue: builder.query({
      query: ({ unitId, propertyId, ownerId, userId }) => ({
        url: `property/unit/${unitId}/revenue`,
        method: 'POST',
        body: { property_id: propertyId, ownerId: ownerId || userId }
      }),
      providesTags: (_result, _error, arg) => [
        { type: 'UnitRevenue', id: arg.unitId }
      ],
    }),

    // Invitations
    getInvitations: builder.query({
      query: (senderId) => ({
        url: `tenant/invitations/${senderId}`,
        method: 'GET',
      }),
      providesTags: (_result, _error, arg) => [
        { type: 'Invitation', id: arg }
      ],
    }),

    /* ───────────── BONDS ───────────── */
    manageBond: builder.mutation({
      query: (body) => ({
        url: 'property/bonds/manage',
        method: 'POST',
        body,
      }),
      invalidatesTags: (_res, _err, arg) => [
        { type: 'Bond', id: arg.bond_id },
        arg.property_id && { type: 'Property', id: arg.property_id },
        arg.unit_id && { type: 'Unit', id: arg.unit_id },
      ].filter(Boolean),
    }),

    getBond: builder.query({
      query: ({ bond_id, property_id, unit_id }) => ({
        url: 'property/bonds/manage',
        method: 'POST',
        body: { action: 'get_bond', bond_id, property_id, unit_id },
      }),
      providesTags: (_res, _err, { bond_id, property_id, unit_id }) => [
        { type: 'Bond', id: bond_id },
        { type: 'Property', id: property_id },
        { type: 'Unit', id: unit_id },
      ],
    }),

    /* ───────────── GOALS ───────────── */
    manageGoal: builder.mutation({
      query: (body) => ({
        url: 'property/bonds/manage',
        method: 'POST',
        body,
      }),
      invalidatesTags: (_res, _err, arg) => [
        arg.goal_id && { type: 'Goal', id: arg.goal_id },
        arg.bond_id && { type: 'Bond', id: arg.bond_id },
      ].filter(Boolean),
    }),

    getGoals: builder.query({
      query: ({ bond_id }) => ({
        url: 'property/bonds/manage',
        method: 'POST',
        body: { action: 'get_goal', bond_id },
      }),
      providesTags: (result, _err, arg) =>
        Array.isArray(result?.goals)
          ? [
              ...result.goals.map((g) => ({
                type: 'Goal',
                id: g.goal_id,
              })),
              { type: 'Bond', id: arg.bond_id },
              { type: 'Goal', id: 'LIST' },
            ]
          : [{ type: 'Bond', id: arg.bond_id }],
    }),

    // Send transaction email
    sendTransactionEmail: builder.mutation({
      query: (body) => ({
        url: 'property/transaction/send-email',
        method: 'POST',
        body,
      }),
    }),
  }),
});

export const {
  useManagePropertyMutation,
  useGetPropertyListQuery,
  useLazyGetPropertyListQuery,
  useGetSinglePropertyDetailsQuery,
  useLazyGetSinglePropertyDetailsQuery,
  useManageUnitMutation,
  useGetUnitDetailsQuery,
  useLazyGetUnitDetailsQuery,
  useGetAllAmenitiesQuery,
  useSetPropertyAmenitiesMutation,
  useManagePropertyImageMutation,
  useManagePropertyDocumentMutation,
  useManageTenantMutation,
  useGetTenantDetailsQuery,
  useLazyGetTenantDetailsQuery,
  useManageTenantInvitationMutation,
  useManageTenantAddressMutation,
  useManageTenantDocumentMutation,
  useManageTenantContractMutation,
  useGetTenantListQuery,
  useLazyGetTenantListQuery,
  useGetUnitTransactionsQuery,
  useLazyGetUnitTransactionsQuery,
  useGetUnitExpensesQuery,
  useLazyGetUnitExpensesQuery,
  useGetUnitRevenueQuery,
  useLazyGetUnitRevenueQuery,
  useGetInvitationsQuery,
  useManagePropertyTransactionMutation,
  useSendTransactionEmailMutation,
  useManageBondMutation,
  useGetBondQuery,
  useManageGoalMutation,
  useGetGoalsQuery,
  useLazyGetGoalsQuery,
} = propertyApi;


