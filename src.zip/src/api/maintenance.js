// src/api/maintenance.js
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { env } from '../config/env';

export const maintenanceApi = createApi({
  reducerPath: 'maintenanceApi',
  baseQuery: fetchBaseQuery({
    baseUrl: `${env.API_URL}/api/v1/maintenance`,
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('token');
      if (token) headers.set('Authorization', `Bearer ${token}`);
      return headers;
    },
  }),
  tagTypes: ['Maintenance'],
  endpoints: (builder) => ({
    // === existing mutations & queries ===
    manageQuotation: builder.mutation({
      query: (body) => ({
        url: '/quotation',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),
    manageRequestAttachment: builder.mutation({
      query: (body) => ({
        url: '/request-attachment',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),
    manageRequestComment: builder.mutation({
      query: (body) => ({
        url: '/request-comment',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),
    manageJob: builder.mutation({
      query: (body) => ({
        url: '/job',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),
    manageRequestParticipant: builder.mutation({
      query: (body) => ({
        url: '/request-participant',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),
    manageContractorAddress: builder.mutation({
      query: (body) => ({
        url: '/contractor-address',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),
    manageContractorTrade: builder.mutation({
      query: (body) => ({
        url: '/contractor-trade',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),
    manageContractorInvitation: builder.mutation({
      query: (body) => ({
        url: '/contractor-invitation',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),
    manageContractor: builder.mutation({
      query: (body) => ({
        url: '/contractor',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),

    getUserContractors: builder.query({
  query: (body) => ({
    url: '/contractors',
    method: 'POST',
    body,
  }),
  providesTags: ['Maintenance'],
}),

    manageRequest: builder.mutation({
      query: (body) => ({
        url: '/request',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Maintenance'],
    }),

    // read-only fetch (table-returning fn_fetch_request)
    fetchRequest: builder.query({
      query: (body) => ({
        url: '/fetch-request',
        method: 'POST',
        body,
      }),
      providesTags: ['Maintenance'],
    }),

    // scalar-parameter fn_contractor_services
    contractorServices: builder.mutation({
      query: ({ user_id, contractor_id, email, phone, services }) => ({
        url: '/contractor-services',
        method: 'POST',
        body: { user_id, contractor_id, email, phone, services },
      }),
      invalidatesTags: ['Maintenance'],
    }),

    fetchNearbyRequests: builder.query({
      query: (body) => ({
        url: '/nearby-requests',
        method: 'POST',
        body,
      }),
      providesTags: ['Maintenance'],
    }), 
    fetchServices: builder.query({
      query: (body) => ({
        url: '/services',
        method: 'POST',
        body,
      }),
      providesTags: ['Maintenance'],
    }),

    getQuotationAmounts: builder.query({
      query: (body) => ({
        url: '/quotation-amounts',
        method: 'POST',
        body,
      }),
      providesTags: ['Maintenance'],
    }),

    manageRequestApply: builder.mutation({
        query: (body) => ({
          url: '/request-apply',
          method: 'POST',
          body,
        }),
        invalidatesTags: ['Maintenance'],
      }),

    // === NEW: fetch property units from property service ===
    fetchPropertyUnits: builder.query({
      query: (body) => ({
        // absolute URL to bypass the maintenance basePath
        url: `${env.API_URL}/api/v1/property/fetch-units`,
        method: 'POST',
        body,
      }),
      providesTags: ['Maintenance'],
    }),
  }),
});

export const {
  useManageQuotationMutation,
  useManageRequestAttachmentMutation,
  useManageRequestCommentMutation,
  useManageJobMutation,
  useManageRequestParticipantMutation,
  useManageContractorAddressMutation,
  useManageContractorTradeMutation,
  useManageContractorInvitationMutation,
  useManageContractorMutation,
  useManageRequestMutation,
  useFetchRequestQuery,
  useContractorServicesMutation,
  useFetchServicesQuery,
  useFetchPropertyUnitsQuery,
  useLazyFetchPropertyUnitsQuery,
  useGetUserContractorsQuery,
  useLazyGetUserContractorsQuery,
  useFetchNearbyRequestsQuery, 
  useLazyFetchNearbyRequestsQuery,
  useGetQuotationAmountsQuery,
  useLazyGetQuotationAmountsQuery,
  useManageRequestApplyMutation,
  useLazyManageRequestApplyMutation

} = maintenanceApi;
