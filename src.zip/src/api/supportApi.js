// src/api/supportApi.js
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { env } from '../config/env';

export const supportApi = createApi({
  reducerPath: 'supportApi',
  baseQuery: fetchBaseQuery({
    baseUrl: `${env.API_URL}/api/v1/support`,
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('token');
      if (token) headers.set('Authorization', `Bearer ${token}`);
      return headers;
    },
  }),
  tagTypes: ['Ticket'],
  endpoints: (builder) => ({
    // List tickets for a user
    getUserTickets: builder.query({
      query: (body) => ({
        url: '/tickets/query',
        method: 'POST',
        body,
      }),
      providesTags: (result) =>
        result?.tickets
          ? [
              ...result.tickets.map((t) => ({ type: 'Ticket', id: t.ticket_id })),
              { type: 'Ticket', id: 'LIST' },
            ]
          : [{ type: 'Ticket', id: 'LIST' }],
    }),

    // Create a new ticket
    createTicket: builder.mutation({
      query: (body) => ({
        url: '/tickets',
        method: 'POST',
        body,
      }),
      invalidatesTags: [{ type: 'Ticket', id: 'LIST' }],
    }),

    // Add a message to a ticket
    createTicketMessage: builder.mutation({
      query: (body) => ({
        url: '/tickets/message',
        method: 'POST',
        body,
      }),
      invalidatesTags: (result, error, { ticket_id }) => [
        { type: 'Ticket', id: ticket_id },
      ],
    }),

    // Upload or manage an attachment on a ticket
    manageTicketDocument: builder.mutation({
      query: (body) => ({
        url: '/tickets/attachment',
        method: 'POST',
        body,
      }),
      invalidatesTags: (result, error, { ticket_id }) => [
        { type: 'Ticket', id: ticket_id },
      ],
    }),

    // Update a ticket’s status
    updateTicketStatus: builder.mutation({
      query: (body) => ({
        url: '/tickets/status',
        method: 'PUT',
        body,
      }),
      invalidatesTags: (result, error, { ticket_id }) => [
        { type: 'Ticket', id: ticket_id },
        { type: 'Ticket', id: 'LIST' },
      ],
    }),
  }),
});

export const {
  useGetUserTicketsQuery,
  useCreateTicketMutation,
  useCreateTicketMessageMutation,
  useManageTicketDocumentMutation,
  useUpdateTicketStatusMutation,
} = supportApi;
