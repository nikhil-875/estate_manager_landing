import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { env } from '../config/env';

export const subscriptionApi = createApi({
  reducerPath: 'subscriptionApi',
  baseQuery: fetchBaseQuery({
    baseUrl: `${env.API_URL}/api/v1/subscriptions`,
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('token');
      if (token) headers.set('Authorization', `Bearer ${token}`);
      return headers;
    },
  }),
  tagTypes: ['Subscription', 'Contract'],
  endpoints: (builder) => ({
     // GET all subscriptions
     getSubscriptions: builder.query({
      query: () => '',
    }),

    // // INSERT a new subscription (action = 'insert')
    // createSubscription: builder.mutation({
    //   query: (body) => ({
    //     url: '/manage',
    //     method: 'POST',
    //     body: { action: 'insert', ...body },
    //   }),
    //   invalidatesTags: [{ type: 'Subscription', id: 'LIST' }],
    // }),

    // // UPDATE an existing subscription (action = 'update')
    // updateSubscription: builder.mutation({
    //   query: (body) => ({
    //     url: '/manage',
    //     method: 'POST',
    //     body: { action: 'update', ...body },
    //   }),
    //   invalidatesTags: (_result, _error, arg) => [
    //     { type: 'Subscription', id: arg.id },
    //     { type: 'Subscription', id: 'LIST' },
    //   ],
    // }),

    // // Manage subscription contracts (unchanged)
    // manageSubscriptionContract: builder.mutation({
    //   query: (body) => ({
    //     url: '/contract',
    //     method: 'POST',
    //     body,
    //   }),
    //   invalidatesTags: [{ type: 'Contract', id: 'LIST' }],
    // }),
    // Manage subscription
    manageSubscription: builder.mutation({
      query: (body) => ({
        url: '/manage',
        method: 'POST',
        body,
      }),
      invalidatesTags: [{ type: 'Contract', id: 'LIST' }],
    }),
  }),
});

export const {
  useGetSubscriptionsQuery,
  useManageSubscriptionMutation,
  useCreateSubscriptionMutation,
  useUpdateSubscriptionMutation,
  useManageSubscriptionContractMutation,
} = subscriptionApi;
