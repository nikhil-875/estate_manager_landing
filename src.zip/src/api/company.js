// src/api/company.js
import { createApi } from '@reduxjs/toolkit/query/react';
import { createBaseQueryWithTokenExpiration } from './baseQuery';

export const companyApi = createApi({
  reducerPath: 'companyApi',
  baseQuery: createBaseQueryWithTokenExpiration(`/api/v1/company`),
  tagTypes: ['Company'],
  endpoints: (builder) => ({
    // ─── Combined Dashboard Stats ──────────────────────
    getDashboardStats: builder.query({
      query: () => `/stats`,
      providesTags: ['Company'],
    }),

    // ─── Company Info ────────────────────────────────
    getOwnerCompanies: builder.query({
      query: () => `/members`,
      providesTags: ['Company'],
    }),
    getSubscription: builder.query({
      query: () => `/subscription`,
      providesTags: ['Company'],
    }),
    getCompanyById: builder.query({
      query: (id) => `/${id}`,
      providesTags: ['Company'],
    }),

    // ─── Transactions ────────────────────────────────
    getCompanyTransactions: builder.query({
      query: () => `/transactions`,
      providesTags: ['Company'],
    }),

    // ─── History (POST) ───────────────────────────────
    getTransactionHistory: builder.mutation({
      query: (body) => ({
        url: 'transactions/history',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Company'],
    }),

    getTransactionsList: builder.mutation({
      query: (body) => ({
        url: `/transactions/list`,
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Company'],
    }),

    // ─── Support Tickets ─────────────────────────────
    getSupportTickets: builder.mutation({
      query: (body) => ({
        url: `/tickets/list`,
        method: 'POST',
        body,
      }),
      providesTags: ['Company'],
    }),
    createSupportMessage: builder.mutation({
      query: (body) => ({
        url: `/tickets/message`,
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Company'],
    }),
    uploadSupportAttachment: builder.mutation({
      query: (body) => ({
        url: `/tickets/attachment`,
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Company'],
    }),

    // ─── Documents ──────────────────────────────────
    createDocument: builder.mutation({
      query: (body) => ({
        url: `/documents`,
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Company'],
    }),
    queryDocuments: builder.mutation({
      query: (body) => ({
        url: `/documents/query`,
        method: 'POST',
        body,
      }),
    }),

    // ─── Invitations ────────────────────────────────
    inviteUser: builder.mutation({
      query: (body) => ({
        url: `/invitation`,
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Company'],
    }),
    acceptInvitation: builder.mutation({
      query: (body) => ({
        url: `/invitation/accept`,
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Company'],
    }),
    getInvitations: builder.query({
      query: () => `/invitationList`,
      providesTags: ['Company'],
    }),

    removeCompany: builder.mutation({
      query: () => ({
        url: `/remove`, // Replace with actual endpoint when ready
        method: 'DELETE',
      }),
      invalidatesTags: ['Company'],
    }),

    // ─── Profile/Settings ────────────────────────────
    updateCompanyLogo: builder.mutation({
      query: (body) => ({
        url: `/logo`,
        method: 'PUT',
        body,
      }),
      invalidatesTags: ['Company'],
    }),
    updateBenefitStatus: builder.mutation({
      query: (body) => ({
        url: `/benefits/status`,
        method: 'PUT',
        body,
      }),
      invalidatesTags: ['Company'],
    }),

    // ─── Import Bank Lines ──────────────────────────
    importTransaction: builder.mutation({
        query: ({ fileName, lines }) => ({
        url: `/import`,
        method: 'POST',
        body: { fileName, lines },
      }),
      invalidatesTags: ['Company'],
      transformResponse: (response) => {
        if (!response.success) {
          throw new Error(response.message || 'Import failed');
        }
        return response.results;
      },
    }),

    // ─── Manage Transactions ────────────────────────
    manageTransaction: builder.mutation({
      query: (body) => ({
        url: `/transactions/manage`,
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Company'],
    }),
    manageTransactionAction: builder.mutation({
      query: (body) => ({
        url: `/transactions/action`,
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Company'],
    }),

    /* ── GET  (action = 'get') ─────────────────────────── */
    getCompanyDetails: builder.mutation({
      query: () => ({
        url: '/manage',
        method: 'POST',
        body: { action: 'get' },
      }),
      providesTags: ['Company'],
    }),

    /* ── UPDATE (action = 'update') ────────────────────── */
    updateCompany: builder.mutation({
      query: (payload) => ({
        url: '/manage',
        method: 'POST',
        body: { action: 'update', ...payload },
      }),
      invalidatesTags: ['Company'],
    }),

    // ─── User Invites ──────────────────────────────
    inviteUser: builder.mutation({
      query: (payload) => ({
        url: '/invitation',
        method: 'POST',
        body: payload,
      }),
      invalidatesTags: ['Company'],
    }),
    getInviteUserList: builder.query({
      query: () => `/invitationList`,
      providesTags: ['Company'],
    }),
  }),
});

export const {
  useGetDashboardStatsQuery,

  useGetOwnerCompaniesQuery,
  useGetSubscriptionQuery,
  useGetCompanyByIdQuery,

  useGetCompanyTransactionsQuery,
  useGetTransactionHistoryMutation,   // POST /transactions/history
  useGetTransactionsListMutation,

  useGetSupportTicketsMutation,
  useCreateSupportMessageMutation,
  useUploadSupportAttachmentMutation,

  useCreateDocumentMutation,
  useQueryDocumentsMutation,

  useInviteUserMutation,
  useAcceptInvitationMutation,
  useGetInvitationsQuery,

  useUpdateCompanyLogoMutation,
  useUpdateBenefitStatusMutation,

  useImportTransactionMutation,
  useManageTransactionMutation,
  useManageTransactionActionMutation,

  useGetInviteUserListQuery,

  useRemoveCompanyMutation,
  useGetCompanyDetailsMutation,
  useGetCompanyMutation,
  useUpdateCompanyMutation,
  // useGetCompanyDetailsMutation,
  // useUpdateCompanyMutation,

} = companyApi;
