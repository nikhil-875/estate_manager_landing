import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { env } from '../config/env';

export const uploadApi = createApi({
  reducerPath: "uploadApi",
  baseQuery: fetchBaseQuery({
    baseUrl: `${env.API_URL}/api/v1/upload`,
    prepareHeaders: async (headers, { endpoint }) => {
      if (endpoint === "getS3UploadUrl" || endpoint === "getS3DownloadUrl") {
        const token = localStorage.getItem('token');
        if (token) {
          headers.set("authorization", `Bearer ${token}`);
        }
      }
      return headers;
    },
  }),
  endpoints: (builder) => ({
    getS3UploadUrl: builder.mutation({
      query: (body) => ({
        url: "/get-s3-upload-url",
        method: "POST",
        body,
      }),
    }),
    uploadFileToS3: builder.mutation({
      query: ({ url, file }) => ({
        url,
        method: "PUT",
        body: file,
        headers: {
          "Content-Type": file.type,
        },
      }),
    }),
    getS3DownloadUrl: builder.query({
      query: (key) => ({
        url: `/get-s3-download-url?key=${encodeURIComponent(key)}`,
        method: "GET",
      }),
    }),
  }),
});

export const {
  useGetS3UploadUrlMutation,
  useUploadFileToS3Mutation,
  useGetS3DownloadUrlQuery,
} = uploadApi;
