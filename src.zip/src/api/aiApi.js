import { createApi } from '@reduxjs/toolkit/query/react';
import { createBaseQueryWithTokenExpiration } from './baseQuery';

export const aiApi = createApi({
  reducerPath: 'aiApi',
  baseQuery: createBaseQueryWithTokenExpiration('/api/v1/ai'),  
  tagTypes: ['AIDocument', 'AIDocuments', 'AIChat'],
  endpoints: (builder) => ({
    // AI Question-Answer with Database
    askAIDatabase: builder.mutation({
      query: (body) => ({
        url: '/ask-db',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['AIChat'],
    }),

    // AI Document Management
    getAIDocuments: builder.query({
      query: (body) => ({
        url: '/documents',
        method: 'POST',
        body,
      }),
      transformResponse: (response) => {
        // Handle both response formats: { documents: [...] } and direct array
        return Array.isArray(response) ? response : response.documents || [];
      },
      providesTags: (result) =>
        result
          ? [
            ...result?.map(({ doc_id }) => ({ type: 'AIDocument', id: doc_id })),
            { type: 'AIDocuments', id: 'LIST' },
          ]
          : [{ type: 'AIDocuments', id: 'LIST' }],
    }),


    // generate FAQs
    generateFAQs: builder.mutation({
      query: (body) => ({
        url: '/generate-faqs',
        method: 'POST',
        body,
      }),
    }),

    // Search Listing FAQs
    searchListingFaqs: builder.mutation({
      query: (body) => ({
        url: '/search-listing-faqs',
        method: 'POST',
        body,
      }),
    }),
  }),
});

export const {
  useAskAIDatabaseMutation,
  useGetAIDocumentsQuery,
  useGenerateFAQsMutation,
  useSearchListingFaqsMutation,
} = aiApi; 