import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { env } from '../config/env';

export const chatApi = createApi({
  reducerPath: "chatApi",
  baseQuery: fetchBaseQuery({
    baseUrl: `${env.API_URL}/api/v1/chat`,
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('token');
      if (token) {
        headers.set("authorization", `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Conversations', 'Messages', 'Contacts'],
  endpoints: (builder) => ({
    getConversations: builder.query({
      query: ({ userContactId }) => { // userContactId are now required
        if (!userContactId) {
          throw new Error("userContactId are required for getConversations");
        }
        return `/conversations/${userContactId}`; // Fetch conversations for the user
      },
      providesTags: (result = []) =>
        result
          ? [
            ...result.map(({ conversationId }) => ({ type: 'Conversations', id: conversationId })),
            { type: 'Conversations', id: 'LIST' },
          ]
          : [{ type: 'Conversations', id: 'LIST' }],
    }),
    getContacts: builder.query({
      query: ({ userContactId }) => { // userContactId are now required
        if (!userContactId) {
          throw new Error("userContactId are required for getConversations");
        }
        return `/contacts/${userContactId}`; // Fetch contacts
      },
    }),
    // Fetches messages for a specific conversation
    getMessages: builder.query({
      query: ({ conversationId, before, limit }) => {
        if (!conversationId) {
          throw new Error("conversationId are required for getMessages");
        }
        let url = `/messages/${conversationId}`;
        const params = new URLSearchParams();
        if (before) params.append('before', before);
        if (limit) params.append('limit', String(limit));

        const queryParams = params.toString();
        if (queryParams) url += `?${queryParams}`;
        return url;
      },
      providesTags: (result, error, { conversationId }) => [{ type: 'Messages', id: conversationId }],
    }),

    // Marks a conversation as read by the current user (via their contactId)
    markConversationAsRead: builder.mutation({
      query: ({ contactId, conversationId, lastReadMessageId }) => {
        if (!contactId || !conversationId) {
          throw new Error("contactId, conversationId are required for markConversationAsRead");
        }
        return {
          url: "/conversations/read",
          method: "POST",
          body: {
            contactId,
            conversationId,
            lastReadMessageId,
          },
        };
      },
      invalidatesTags: (result, error, { conversationId }) => [{ type: 'Conversations', id: conversationId }, { type: 'Conversations', id: 'LIST' }],
    }),

    // Manages a contact
    manageContacts: builder.mutation({
      query: ({ email, firstName, lastName, phoneNumber }) => {
        if (!email) {
          throw new Error("email are required for manageConversation");
        }
        return {
          url: "/contacts/manage",
          method: "POST",
          body: {
            email,
            firstName,
            lastName,
            phoneNumber
          },
        };
      },
      // When a new conversation is managed, refetch the list of conversations.
      invalidatesTags: [{ type: 'Conversations', id: 'LIST' }, { type: 'Contacts', id: 'LIST' }],
    }),

    // Updates contact details within a specific conversation (e.g., display name)
    updateConversationContactDetails: builder.mutation({
      query: ({ conversationId, updatedByContactId, updatingForContactId, firstName, lastName }) => {
        if (!conversationId || !updatedByContactId || !updatingForContactId || !firstName || !lastName) {
          throw new Error("conversationId,updatedByContactId, updatingForContactId, firstName, lastName are required.");
        }
        return {
          url: `/conversations/${conversationId}`,
          method: 'PUT',
          body: {
            updatedByContactId,
            updatingForContactId,
            firstName,
            lastName,
          }
        };
      },
      invalidatesTags: (result, error, { conversationId }) => [
        { type: 'Conversations', id: conversationId },
        { type: 'Conversations', id: 'LIST' },
        { type: 'Messages', id: conversationId }
      ],
    }),
  }),
});

export const {
  useGetConversationsQuery,
  useGetMessagesQuery,
  useMarkConversationAsReadMutation,
  useManageContactsMutation,
  useUpdateConversationContactDetailsMutation,
  useGetContactsQuery,
} = chatApi;
