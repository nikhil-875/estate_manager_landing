import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { env } from '../config/env';

export const tenantApi = createApi({
  reducerPath: 'tenantApi',
  baseQuery: fetchBaseQuery({
    baseUrl: `${env.API_URL}/api/v1/tenant`,
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('token');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Tenant'],
  endpoints: (builder) => ({
    getTenantPaymentStatus: builder.mutation({
      query: (body) => ({
        url: '/payment-status',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Tenant'],
    }),
  }),
});

export const { useGetTenantPaymentStatusMutation } = tenantApi; 