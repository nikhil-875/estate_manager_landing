import { fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { clearUser } from '../redux/authSlice';
import { env } from '../config/env';

// Create a base query with the proper headers
const createBaseQuery = (baseUrl) => fetchBaseQuery({
  baseUrl: `${env.API_URL}${baseUrl}`,
  prepareHeaders: (headers) => {
    const token = localStorage.getItem('token');
      if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }
    return headers;
  },
});

// Enhanced base query that handles 401 errors for token expiration
export const createBaseQueryWithTokenExpiration = (baseUrl) => {
  const baseQuery = createBaseQuery(baseUrl);
  
  return async (args, api, extraOptions) => {
    const result = await baseQuery(args, api, extraOptions);
    
    // Check if response indicates token is expired or invalid (401 Unauthorized)
    if (result.error && result.error.status === 401) {
      // Clear token and user data
      localStorage.removeItem('token');
      api.dispatch(clearUser());
      
      // Redirect to login
      window.location.href = env.LANDING_URL;
    }
    
    return result;
  };
}; 