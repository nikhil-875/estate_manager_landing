import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { createBaseQueryWithTokenExpiration } from './baseQuery';

export const listingApi = createApi({
  reducerPath: 'listingApi',
  baseQuery: createBaseQueryWithTokenExpiration('/api/v1/listing'),
  // Define tags for caching and invalidation
  tagTypes: ['Listings', 'Applicants', 'Conversations', 'Messages', 'Presence', 'Bookings', 'Applications'],
  endpoints: (builder) => ({

    // ╔═══════════════════════════════════╗
    // ║            LISTINGS               ║
    // ╚═══════════════════════════════════╝

    /**
     * Search for listings by address or lat/lon
     */
    searchListings: builder.mutation({
      query: (body) => ({
        url: '/listings/search',
        method: 'POST',
        body,
      }),
      transformResponse: (res) => res.results || [],
    }),

    /**
     * Fetch data to initialize a new listing form
     */
    initiateListing: builder.mutation({
      query: (body) => ({
        url: '/listings/initiate',
        method: 'POST',
        body,
      }),
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Create or update a listing (the backend function handles upsert logic)
     */
    manageListing: builder.mutation({
      query: (body) => ({
        url: '/listings',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Listings'],
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Fetch all listings, typically for an owner
     */
    getListings: builder.mutation({
      query: (body) => ({
        url: '/get-listings',
        method: 'POST',
        body,
      }),
      providesTags: (result) =>
        result
          ? [...result.map(({ id }) => ({ type: 'Listings', id })), { type: 'Listings', id: 'LIST' }]
          : [{ type: 'Listings', id: 'LIST' }],
      transformResponse: (res) => res.results || [],
    }),

    // ╔═══════════════════════════════════╗
    // ║    APPLICATIONS & BOOKINGS        ║
    // ╚═══════════════════════════════════╝

    /**
     * Get all applicants for a specific listing
     */
    getApplicants: builder.query({
      query: (listingId) => `/listings/${listingId}/applicants`,
      providesTags: (result, error, listingId) => [{ type: 'Applicants', id: listingId }],
      transformResponse: (res) => res.results || { applicants: [] },
    }),

    /**
     * Manage a rental application (insert, update, delete)
     */
    manageRentalApplication: builder.mutation({
      query: (body) => ({
        url: '/rental-applications',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Applications'],
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Manage a viewing booking (insert, update, delete)
     */
    manageViewingBooking: builder.mutation({
      query: (body) => ({
        url: '/viewing-bookings',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Bookings'],
      transformResponse: (res) => res.results || {},
    }),

    // ╔═══════════════════════════════════╗
    // ║         MESSAGING & CONTACTS      ║
    // ╚═══════════════════════════════════╝

    /**
     * Ensure a contact exists for a user
     */
    ensureContact: builder.mutation({
      query: (body) => ({
        url: '/contacts/ensure',
        method: 'POST',
        body,
      }),
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Initiate a conversation and send the first message
     */
    manageContact: builder.mutation({
      query: (body) => ({
        url: '/manage-contact',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Conversations', 'Messages'],
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Get conversations for a user
     */
    getConversations: builder.query({
      query: ({ email, listing_id, user_type }) => ({
        url: '/conversations',
        params: { email, listing_id, user_type },
      }),
      providesTags: (result = []) => [
        ...result.map((item) => ({ type: 'Conversations', id: item.conversation_id })),
        { type: 'Conversations', id: 'LIST' },
      ],
      transformResponse: (res) => res.results || [],
    }),

    /**
     * Get messages for a specific conversation
     */
    getMessages: builder.query({
      query: ({ conversationId, user_type, limit, before }) => ({
        url: `/conversations/${conversationId}/messages`,
        params: { user_type, limit, before },
      }),
      providesTags: (result, error, { conversationId }) => [{ type: 'Messages', id: conversationId }],
      transformResponse: (res) => res.results || [],
    }),

    /**
     * Send a new message
     */
    sendMessage: builder.mutation({
      query: (body) => ({
        url: '/messages',
        method: 'POST',
        body,
      }),
      invalidatesTags: (result) => [
        { type: 'Messages', id: result?.data?.conversationId },
        { type: 'Conversations', id: 'LIST' }
      ],
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Edit an existing message
     */
    editMessage: builder.mutation({
      query: ({ id, ...body }) => ({
        url: `/messages/${id}`,
        method: 'PUT',
        body,
      }),
      invalidatesTags: (result) => [{ type: 'Messages', id: result?.data?.conversationId }],
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Delete an existing message
     */
    deleteMessage: builder.mutation({
      query: ({ id, ...body }) => ({
        url: `/messages/${id}`,
        method: 'DELETE',
        body,
      }),
      invalidatesTags: (result) => [{ type: 'Messages', id: result?.data?.conversationId }],
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Mark a conversation as read
     */
    markConversationAsRead: builder.mutation({
      query: (body) => ({
        url: '/conversations/mark-as-read',
        method: 'POST',
        body,
      }),
      invalidatesTags: (result) => [{ type: 'Conversations', id: result?.data?.conversation_id }],
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Update the status of a single message
     */
    updateMessageStatus: builder.mutation({
      query: ({ id, ...body }) => ({
        url: `/messages/${id}/status`,
        method: 'PUT',
        body,
      }),
      invalidatesTags: (result) => [{ type: 'Messages', id: result?.data?.conversationId }],
      transformResponse: (res) => res.results || {},
    }),

    // ╔═══════════════════════════════════╗
    // ║           USER PRESENCE           ║
    // ╚═══════════════════════════════════╝

    /**
     * Get a user's presence status
     */
    getUserPresence: builder.query({
      query: ({ contactId, user_type }) => ({
        url: `/presence/${contactId}`,
        params: { user_type },
      }),
      providesTags: (result, error, { contactId }) => [{ type: 'Presence', id: contactId }],
      transformResponse: (res) => res.results || {},
    }),

    /**
     * Set a user's presence status (online, offline, typing)
     */
    setUserPresence: builder.mutation({
      query: (body) => ({
        url: '/presence',
        method: 'POST',
        body,
      }),
      invalidatesTags: (result) => [{ type: 'Presence', id: result?.data?.user_id }],
      transformResponse: (res) => res.results || {},
    }),
  }),
});

// Export hooks for usage in functional components
export const {
  useSearchListingsMutation,
  useInitiateListingMutation,
  useManageListingMutation,
  useGetListingsMutation,
  useLazyGetListingsQuery,
  useGetApplicantsQuery,
  useLazyGetApplicantsQuery,
  useManageRentalApplicationMutation,
  useManageViewingBookingMutation,
  useEnsureContactMutation,
  useManageContactMutation,
  useGetConversationsQuery,
  useLazyGetConversationsQuery,
  useGetMessagesQuery,
  useLazyGetMessagesQuery,
  useSendMessageMutation,
  useEditMessageMutation,
  useDeleteMessageMutation,
  useMarkConversationAsReadMutation,
  useUpdateMessageStatusMutation,
  useGetUserPresenceQuery,
  useLazyGetUserPresenceQuery,
  useSetUserPresenceMutation,
} = listingApi;