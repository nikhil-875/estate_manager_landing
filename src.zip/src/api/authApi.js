import { createApi } from '@reduxjs/toolkit/query/react'
import { createBaseQueryWithTokenExpiration } from './baseQuery'

export const authApi = createApi({
  reducerPath: 'authApi',
  baseQuery: createBaseQueryWithTokenExpiration('/api/v1/users'),
  endpoints: (builder) => ({
    /* ───────────── Authentication ───────────── */
    login: builder.mutation({
      query: (credentials) => ({
        url: '/login',
        method: 'POST',
        body: credentials,
      }),
    }),
    googleAuth: builder.mutation({
      query: (tokenData) => ({
        url: '/google-auth',
        method: 'POST',
        body: tokenData,
      }),
    }),
    getMe: builder.query({
      query: () => '/me',
    }),
    logout: builder.mutation({
      query: () => ({
        url: '/auth/logout',
        method: 'POST',
      }),
    }),

    /* ───────────── User CRUD ───────────── */
    createUser: builder.mutation({
      query: (userData) => ({
        url: '/',
        method: 'POST',
        body: userData,
      }),
    }),
    updateUser: builder.mutation({
      query: ({ id, ...userData }) => ({
        url: `/${id}`,
        method: 'PUT',
        body: userData,
      }),
    }),
    deactivateUser: builder.mutation({
      query: (deactivateData) => ({
        url: '/deactivate',
        method: 'POST',
        body: deactivateData,
      }),
    }),

    /* ───────────── Passwords ───────────── */
    requestPasswordReset: builder.mutation({
      query: (email) => ({
        url: '/request-password-reset',
        method: 'POST',
        body: email,
      }),
    }),
    resetPassword: builder.mutation({
      query: (resetData) => ({
        url: '/reset-password',
        method: 'POST',
        body: resetData,
      }),
    }),
    changePassword: builder.mutation({
      query: (passwordData) => ({
        url: '/change-password',
        method: 'POST',
        body: passwordData,
      }),
    }),

    /* ───────────── Profile & Picture ───────────── */
    uploadProfileImage: builder.mutation({
      query: ({ id, formData }) => ({
        url: `/${id}/upload-image`,
        method: 'POST',
        body: formData,
        formData: true,
      }),
    }),
    verifyAccount: builder.mutation({
      query: (verificationData) => ({
        url: '/verify',
        method: 'POST',
        body: verificationData,
      }),
    }),
    resendActivationToken: builder.mutation({
      query: (body) => ({
        url: '/activation-token',
        method: 'POST',
        body,
      }),
    }),

    /* ───────────── Permissions ───────────── */
    managePermissions: builder.mutation({
      query: (data) => ({
        url: '/permissions/manage',
        method: 'POST',
        body: data,
      }),
    }),
    manageModelPermissions: builder.mutation({
      query: (data) => ({
        url: '/model-permissions/manage',
        method: 'POST',
        body: data,
      }),
    }),
    manageRolePermissions: builder.mutation({
      query: (data) => ({
        url: '/role-permissions/manage',
        method: 'POST',
        body: data,
      }),
    }),

    /* ───────────── Switch / Default / Request Access ───────────── */
    manageUserProfile: builder.mutation({
      query: (profileData) => ({
        url: '/profile/type',
        method: 'POST',
        body: profileData,
      }),
    }),
    /** POST /profile/switch -> returns {status,data:[…]} from fn_get_switch_accounts */
    getSwitchableAccounts: builder.mutation({
      query: (payload = {}) => ({
        url: '/profile/switch',
        method: 'POST',
        body: payload,
      }),
    }),

    /* ───────────── Credits ───────────── */
    getUserCredits: builder.query({
      query: () => ({
        url: '/credits',
        method: 'GET',
      }),
      providesTags: ['Credits'],
    }),

    /* ───────────── Impersonation ───────────── */
    impersonateUser: builder.mutation({
      query: (targetUserId) => ({
        url: `/impersonate/${targetUserId}`,
        method: 'POST',
      }),
      async onQueryStarted(_, { queryFulfilled }) {
        try {
          const { data } = await queryFulfilled
          if (data.status === 'success' && data.token) {
            localStorage.setItem('token', data.token)
          }
        } catch (error) {
          console.error('Error during impersonation:', error)
        }
      },
    }),
    endImpersonation: builder.mutation({
      query: () => ({
        url: '/end-impersonation',
        method: 'POST',
      }),
      async onQueryStarted(_, { queryFulfilled }) {
        try {
          const { data } = await queryFulfilled
          if (data.status === 'success' && data.token) {
            localStorage.setItem('token', data.token)
          }
        } catch (error) {
          console.error('Error ending impersonation:', error)
        }
      },
    }),
  }),
})

export const {
  useLoginMutation,
  useGoogleAuthMutation,
  useGetMeQuery,
  useLogoutMutation,
  useCreateUserMutation,
  useUpdateUserMutation,
  useDeactivateUserMutation,
  useRequestPasswordResetMutation,
  useResetPasswordMutation,
  useChangePasswordMutation,
  useUploadProfileImageMutation,
  useVerifyAccountMutation,
  useResendActivationTokenMutation,
  useManagePermissionsMutation,
  useManageModelPermissionsMutation,
  useManageRolePermissionsMutation,
  useManageUserProfileMutation,
  useGetSwitchableAccountsMutation,
  useGetUserCreditsQuery,
  useImpersonateUserMutation,
  useEndImpersonationMutation,
} = authApi
