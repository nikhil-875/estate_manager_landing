// src/api/owner.js

import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { env } from '../config/env';

export const ownerApi = createApi({
  reducerPath: 'ownerApi',
  baseQuery: fetchBaseQuery({
    baseUrl: `${env.API_URL}/api/v1/owner`,
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('token');
      if (token) headers.set('Authorization', `Bearer ${token}`);
      return headers;
    },
  }),
  tagTypes: ['Owner'],
  endpoints: (builder) => ({
    /* ─── Combined Dashboard Stats ───────────────────── */
    getDashboardStats: builder.mutation({
     query: () => ({
       url: '/stats',
       method: 'POST',
     }),
     invalidatesTags: ['Owner'],
     transformResponse: (response) => response,
   }),

    /* ─── Owner Members ─────────────────────────────── */
    getOwnerMembers: builder.query({
      query: () => '/members',
      providesTags: ['Owner'],
    }),

    /* ─── Invitations ───────────────────────────────── */
    sendInvitation: builder.mutation({
      query: (body) => ({
        url: '/invitation',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),
    acceptInvitation: builder.mutation({
      query: (body) => ({
        url: '/invitation',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),
    getInvitations: builder.query({
      query: () => '/invitationList',
      providesTags: ['Owner'],
    }),

    /* ─── Logo & Benefits ───────────────────────────── */
    updateLogo: builder.mutation({
      query: (body) => ({
        url: '/logo',
        method: 'PUT',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),
    updateBenefitStatus: builder.mutation({
      query: (body) => ({
        url: '/benefits/status',
        method: 'PUT',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),

    /* ─── Documents ─────────────────────────────────── */
    createDocument: builder.mutation({
      query: (body) => ({
        url: '/documents',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),
    queryDocuments: builder.query({
      query: (body) => ({
        url: '/documents/query',
        method: 'POST',
        body,
      }),
      providesTags: ['Owner'],
    }),

    /* ─── Subscriptions & Transactions ──────────────── */
    getSubscription: builder.query({
      query: () => '/subscription',
      providesTags: ['Owner'],
    }),
    getTransactionHistory: builder.mutation({
      query: (body) => ({
        url: '/transactions/history',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),

    /* ─── Support Tickets ───────────────────────────── */
    getSupportTickets: builder.mutation({
      query: (body) => ({
        url: '/tickets/list',
        method: 'POST',
        body,
      }),
      providesTags: ['Owner'],
    }),
    createSupportMessage: builder.mutation({
      query: (body) => ({
        url: '/tickets/message',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),
    uploadSupportAttachment: builder.mutation({
      query: (body) => ({
        url: '/tickets/attachment',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),

    /* ─── Transaction Import & Management ───────────── */
    importTransaction: builder.mutation({
      query: ({ parentId, fileName, lines }) => ({
        url: '/import',
        method: 'POST',
        body: { parentId, fileName, lines },
      }),
      invalidatesTags: ['Owner'],
      transformResponse: (response) => {
        if (!response.success) throw new Error(response.message || 'Import failed');
        return response.results;
      },
    }),
    getTransactionsList: builder.mutation({
      query: (body) => ({
        url: '/transactions/list',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),
    manageTransaction: builder.mutation({
      query: (body) => ({
        url: '/transactions/manage',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),
    manageTransactionAction: builder.mutation({
      query: (body) => ({
        url: '/transactions/action',
        method: 'POST',
        body,
      }),
      invalidatesTags: ['Owner'],
    }),

    /* ─── Owner Details ─────────────────────────────── */
    getOwnerDetails: builder.query({
      query: () => '/details',
      providesTags: ['Owner'],
    }),
  }),
});

/* ──────── Hook Exports ──────── */
export const {
  useGetDashboardStatsMutation,

  useGetOwnerMembersQuery,

  useSendInvitationMutation,
  useAcceptInvitationMutation,
  useGetInvitationsQuery,

  useUpdateLogoMutation,
  useUpdateBenefitStatusMutation,

  useCreateDocumentMutation,
  useQueryDocumentsQuery,

  useGetSubscriptionQuery,
  useGetTransactionHistoryMutation,

  useGetSupportTicketsMutation,
  useCreateSupportMessageMutation,
  useUploadSupportAttachmentMutation,

  useImportTransactionMutation,
  useGetTransactionsListMutation,
  useManageTransactionMutation,
  useManageTransactionActionMutation,

  useGetOwnerDetailsQuery,
} = ownerApi;
